package lol.wocky.hook;

import java.util.function.BooleanSupplier;

public final class ClientInputHook {
   public static volatile Runnable onTick;
   public static volatile BooleanSupplier cancelItemUse;
   public static volatile BooleanSupplier cancelAttack;
   public static volatile Runnable activeShutdown;

   private ClientInputHook() {
   }

   public static void tick() {
      Runnable r = onTick;
      if (r != null) {
         try {
            r.run();
         } catch (Throwable t) {
            t.printStackTrace();
         }
      }

   }

   public static boolean cancelItemUse() {
      BooleanSupplier p = cancelItemUse;

      try {
         return p != null && p.getAsBoolean();
      } catch (Throwable var2) {
         return false;
      }
   }

   public static boolean cancelAttack() {
      BooleanSupplier p = cancelAttack;

      try {
         return p != null && p.getAsBoolean();
      } catch (Throwable var2) {
         return false;
      }
   }
}
