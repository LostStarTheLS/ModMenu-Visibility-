package lol.wocky.hook;

import java.util.function.Consumer;

public final class RenderHook {
   public static volatile Consumer<Object[]> onWorldRender;
   public static volatile Consumer<Object> onHudRender;

   private RenderHook() {
   }

   public static void worldRender(Object tickCounter, Object camera, Object view, Object projection) {
      Consumer<Object[]> c = onWorldRender;
      if (c != null) {
         try {
            c.accept(new Object[]{tickCounter, camera, view, projection});
         } catch (Throwable t) {
            t.printStackTrace();
         }

      }
   }

   public static void hudRender(Object drawContext) {
      Consumer<Object> c = onHudRender;
      if (c != null) {
         try {
            c.accept(drawContext);
         } catch (Throwable t) {
            t.printStackTrace();
         }

      }
   }
}
