package lol.wocky.hook;

import java.util.function.BiFunction;

public final class Hooks {
   public static volatile BiFunction<String, Object, Object> handler;

   private Hooks() {
   }

   public static boolean test(String id, Object arg) {
      BiFunction<String, Object, Object> h = handler;
      if (h == null) {
         return false;
      } else {
         try {
            return Boolean.TRUE.equals(h.apply(id, arg));
         } catch (Throwable var4) {
            return false;
         }
      }
   }

   public static void run(String id) {
      BiFunction<String, Object, Object> h = handler;
      if (h != null) {
         try {
            h.apply(id, (Object)null);
         } catch (Throwable t) {
            t.printStackTrace();
         }

      }
   }
}
