package lol.wocky.feature.movement;

import java.util.ArrayList;
import java.util.List;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.ModuleManager;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;

public class InvWalk extends Module {
   private static final MinecraftBridge.MoveKey[] WALK_KEYS;
   private final BooleanProperty sneak = new BooleanProperty(a(-23669, -7626), false);
   private final NumberProperty resumeDelay;
   private final List<Object[]> queue;
   private boolean active;
   private boolean moving;
   private long haltSince;
   private boolean haltRequested;
   private int holdTicks;
   private static final String[] a;
   private static final String[] b;
   private static final long c;
   private static final long[] d;
   private static final Long[] e;

   public InvWalk() {
      super(a(-23672, 14546), a(-23671, -28440), ModuleCategory.MOVEMENT);
      this.resumeDelay = new NumberProperty(a(-23670, -5292), 4, 0, (int)c, 1);
      this.queue = new ArrayList();
      this.haltSince = a(31666, 2657521959026522733L);
      this.addProperties(new Property[]{this.sneak, this.resumeDelay});
      this.setWarning(a(-23665, 21326));
   }

   public void onTick() {
      if (!MinecraftBridge.isWalkableScreen()) {
         this.leaveScreen();
      } else {
         this.active = true;
         if (this.holdTicks > 0) {
            --this.holdTicks;
         }

         if (!this.queue.isEmpty() && this.stopped()) {
            this.sendQueued();
         }

         if (!this.haltRequested && this.queue.isEmpty() && this.holdTicks <= 0) {
            this.haltSince = a(22058, 2523194748557023220L);
            MinecraftBridge.setMovementHalted(false);
            this.mirrorKeys();
         } else {
            this.haltRequested = false;
            if (this.haltSince < 0L) {
               this.haltSince = MinecraftBridge.getTickCount();
            }

            MinecraftBridge.setMovementHalted(true);

            for(MinecraftBridge.MoveKey var4 : MinecraftBridge.MoveKey.values()) {
               MinecraftBridge.holdKey(var4, false);
            }

            this.moving = false;
         }
      }
   }

   public boolean clickReady() {
      if (!this.active) {
         return true;
      } else if (this.queue.isEmpty() && this.stopped()) {
         this.holdTicks = Math.max(this.holdTicks, this.resumeDelay.intValue());
         return true;
      } else {
         this.haltRequested = true;
         return false;
      }
   }

   public boolean deferClick(Object[] var1) {
      if (this.active && MinecraftBridge.isWalkableScreen() && !this.clickReady()) {
         this.queue.add(var1);
         return true;
      } else {
         return false;
      }
   }

   private boolean stopped() {
      Object var1 = MinecraftBridge.getPlayer();
      if (!MinecraftBridge.isSprinting(var1) && !MinecraftBridge.isSneaking(var1)) {
         if (this.haltSince < 0L) {
            return !this.moving;
         } else {
            long var2 = MinecraftBridge.getTickCount();
            return MinecraftBridge.isInModuleTick() ? var2 > this.haltSince : var2 >= this.haltSince;
         }
      } else {
         return false;
      }
   }

   private void sendQueued() {
      int var1 = MinecraftBridge.getScreenSyncId();

      for(Object[] var3 : this.queue) {
         Object var5 = var3[1];
         if (var5 instanceof Integer var4) {
            if (var4 == var1) {
               MinecraftBridge.replayClick(var3);
            }
         }
      }

      this.queue.clear();
      this.holdTicks = Math.max(this.holdTicks, this.resumeDelay.intValue());
   }

   private void mirrorKeys() {
      boolean var1 = false;

      for(MinecraftBridge.MoveKey var5 : WALK_KEYS) {
         MinecraftBridge.holdKey(var5, false);
         var1 |= MinecraftBridge.isPhysicallyDown(var5);
      }

      if ((Boolean)this.sneak.getValue()) {
         MinecraftBridge.holdKey(MinecraftBridge.MoveKey.SNEAK, false);
         var1 |= MinecraftBridge.isPhysicallyDown(MinecraftBridge.MoveKey.SNEAK);
      }

      Sprint var6 = (Sprint)ModuleManager.getByClass(Sprint.class);
      if (var6 == null || !var6.isEnabled()) {
         MinecraftBridge.holdKey(MinecraftBridge.MoveKey.SPRINT, false);
      }

      this.moving = var1;
   }

   private void leaveScreen() {
      this.queue.clear();
      MinecraftBridge.setMovementHalted(false);
      this.haltSince = a(22058, 2523194748557023220L);
      this.haltRequested = false;
      this.holdTicks = 0;
      if (this.active && MinecraftBridge.getCurrentScreen() == null) {
         this.mirrorKeys();
      }

      this.active = false;
      this.moving = false;
   }

   public void onDisable() {
      this.queue.clear();
      if (this.active && MinecraftBridge.isInGame()) {
         MinecraftBridge.setMovementHalted(true);

         for(MinecraftBridge.MoveKey var4 : MinecraftBridge.MoveKey.values()) {
            MinecraftBridge.holdKey(var4, false);
         }
      }

      MinecraftBridge.setMovementHalted(false);
      this.active = false;
      this.moving = false;
      this.haltSince = a(22058, 2523194748557023220L);
      this.haltRequested = false;
      this.holdTicks = 0;
   }

   static {
      String[] var15 = new String[5];
      int var13 = 0;
      String var12 = "Ü\u0019¬8¿\f\u00940\u0092cªm_\u0085l{ü\u007f-tæ4#ÃýQK¦©í¢H\u0097/¯ÚCÄ\u0085B\u0096\u0003ôT:ï¼\u0014Î¬ W\u0099Æ@£¯%\u0086\u0007\u0003\u0011AY";
      int var14 = "Ü\u0019¬8¿\f\u00940\u0092cªm_\u0085l{ü\u007f-tæ4#ÃýQK¦©í¢H\u0097/¯ÚCÄ\u0085B\u0096\u0003ôT:ï¼\u0014Î¬ W\u0099Æ@£¯%\u0086\u0007\u0003\u0011AY".length();
      char var11 = 5;
      int var18 = -1;

      label67:
      while(true) {
         ++var18;
         String var10000 = var12.substring(var18, var18 + var11);
         int var10001 = -1;

         while(true) {
            char[] var33;
            label62: {
               char[] var21 = var10000.toCharArray();
               int var10003 = var21.length;
               int var16 = 0;
               var33 = var21;
               int var24 = var10003;
               char[] var42;
               int var10004;
               if (var10003 <= 1) {
                  var42 = var21;
                  var10004 = var16;
               } else {
                  var33 = var21;
                  var24 = var10003;
                  if (var10003 <= var16) {
                     break label62;
                  }

                  var42 = var21;
                  var10004 = var16;
               }

               while(true) {
                  char var10005 = var42[var10004];
                  byte var10006;
                  switch (var16 % 7) {
                     case 0 -> var10006 = 34;
                     case 1 -> var10006 = 46;
                     case 2 -> var10006 = 47;
                     case 3 -> var10006 = 28;
                     case 4 -> var10006 = 109;
                     case 5 -> var10006 = 60;
                     default -> var10006 = 71;
                  }

                  var42[var10004] = (char)(var10005 ^ var10006);
                  ++var16;
                  if (var24 == 0) {
                     var10004 = var24;
                     var42 = var33;
                  } else {
                     if (var24 <= var16) {
                        break;
                     }

                     var42 = var33;
                     var10004 = var16;
                  }
               }
            }

            String var49 = (new String(var33)).intern();
            switch (var10001) {
               case 0:
                  var15[var13++] = var49;
                  if ((var18 += var11) >= var14) {
                     a = var15;
                     b = new String[5];
                     long var8 = 8479849434895434532L;
                     long var38 = 8361741227279598384L ^ var8;
                     var10001 = (byte)-1;
                     c = var38;
                     long var0 = 7554438210755490131L;
                     long[] var6 = new long[2];
                     int var3 = 0;
                     String var4 = "³ÈT\\ÌÛtÁ´-\u000e9¬\u0097YX";
                     int var5 = "³ÈT\\ÌÛtÁ´-\u000e9¬\u0097YX".length();
                     int var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var51 = (((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L) ^ var0;
                        boolean var50 = true;
                        var6[var10001] = var51;
                     } while(var2 < var5);

                     d = var6;
                     e = new Long[2];
                     WALK_KEYS = new MinecraftBridge.MoveKey[]{MinecraftBridge.MoveKey.FORWARD, MinecraftBridge.MoveKey.BACK, MinecraftBridge.MoveKey.LEFT, MinecraftBridge.MoveKey.RIGHT, MinecraftBridge.MoveKey.JUMP};
                     return;
                  }

                  var11 = var12.charAt(var18);
                  break;
               default:
                  var15[var13++] = var49;
                  if ((var18 += var11) < var14) {
                     var11 = var12.charAt(var18);
                     continue label67;
                  }

                  var12 = "à±a\u001b}\rcPýî\u0091i~ÓÚ6\u001eæ9ö!qÁË\u0095gÉ\u009bÏ\u009c\u00062\u0080âÅ² ®¥wt\u009aâ\u009bxRä\u0004õ××´jSð\u009d\u0092\u0094»\u0085\u0088RâPðí´ÀU\u0011«Q\u0090Âh¹êUWä:bÒ\u0095%=\u0093F";
                  var14 = "à±a\u001b}\rcPýî\u0091i~ÓÚ6\u001eæ9ö!qÁË\u0095gÉ\u009bÏ\u009c\u00062\u0080âÅ² ®¥wt\u009aâ\u009bxRä\u0004õ××´jSð\u009d\u0092\u0094»\u0085\u0088RâPðí´ÀU\u0011«Q\u0090Âh¹êUWä:bÒ\u0095%=\u0093F".length();
                  var11 = 7;
                  var18 = -1;
            }

            ++var18;
            var10000 = var12.substring(var18, var18 + var11);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ -23669) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 61;
            case 1 -> var10000 = 152;
            case 2 -> var10000 = 73;
            case 3 -> var10000 = 58;
            case 4 -> var10000 = 108;
            case 5 -> var10000 = 1;
            case 6 -> var10000 = 40;
            case 7 -> var10000 = 53;
            case 8 -> var10000 = 198;
            case 9 -> var10000 = 251;
            case 10 -> var10000 = 97;
            case 11 -> var10000 = 111;
            case 12 -> var10000 = 169;
            case 13 -> var10000 = 189;
            case 14 -> var10000 = 21;
            case 15 -> var10000 = 72;
            case 16 -> var10000 = 44;
            case 17 -> var10000 = 6;
            case 18 -> var10000 = 186;
            case 19 -> var10000 = 240;
            case 20 -> var10000 = 239;
            case 21 -> var10000 = 254;
            case 22 -> var10000 = 54;
            case 23 -> var10000 = 188;
            case 24 -> var10000 = 100;
            case 25 -> var10000 = 10;
            case 26 -> var10000 = 204;
            case 27 -> var10000 = 131;
            case 28 -> var10000 = 217;
            case 29 -> var10000 = 79;
            case 30 -> var10000 = 230;
            case 31 -> var10000 = 47;
            case 32 -> var10000 = 26;
            case 33 -> var10000 = 232;
            case 34 -> var10000 = 17;
            case 35 -> var10000 = 121;
            case 36 -> var10000 = 24;
            case 37 -> var10000 = 171;
            case 38 -> var10000 = 128;
            case 39 -> var10000 = 224;
            case 40 -> var10000 = 172;
            case 41 -> var10000 = 148;
            case 42 -> var10000 = 216;
            case 43 -> var10000 = 199;
            case 44 -> var10000 = 253;
            case 45 -> var10000 = 36;
            case 46 -> var10000 = 250;
            case 47 -> var10000 = 184;
            case 48 -> var10000 = 96;
            case 49 -> var10000 = 165;
            case 50 -> var10000 = 205;
            case 51 -> var10000 = 223;
            case 52 -> var10000 = 67;
            case 53 -> var10000 = 221;
            case 54 -> var10000 = 3;
            case 55 -> var10000 = 219;
            case 56 -> var10000 = 16;
            case 57 -> var10000 = 106;
            case 58 -> var10000 = 235;
            case 59 -> var10000 = 151;
            case 60 -> var10000 = 209;
            case 61 -> var10000 = 185;
            case 62 -> var10000 = 246;
            case 63 -> var10000 = 157;
            case 64 -> var10000 = 243;
            case 65 -> var10000 = 183;
            case 66 -> var10000 = 173;
            case 67 -> var10000 = 163;
            case 68 -> var10000 = 51;
            case 69 -> var10000 = 76;
            case 70 -> var10000 = 98;
            case 71 -> var10000 = 138;
            case 72 -> var10000 = 94;
            case 73 -> var10000 = 143;
            case 74 -> var10000 = 105;
            case 75 -> var10000 = 60;
            case 76 -> var10000 = 45;
            case 77 -> var10000 = 31;
            case 78 -> var10000 = 85;
            case 79 -> var10000 = 119;
            case 80 -> var10000 = 64;
            case 81 -> var10000 = 55;
            case 82 -> var10000 = 139;
            case 83 -> var10000 = 114;
            case 84 -> var10000 = 195;
            case 85 -> var10000 = 176;
            case 86 -> var10000 = 231;
            case 87 -> var10000 = 83;
            case 88 -> var10000 = 57;
            case 89 -> var10000 = 144;
            case 90 -> var10000 = 81;
            case 91 -> var10000 = 180;
            case 92 -> var10000 = 37;
            case 93 -> var10000 = 117;
            case 94 -> var10000 = 179;
            case 95 -> var10000 = 65;
            case 96 -> var10000 = 39;
            case 97 -> var10000 = 9;
            case 98 -> var10000 = 215;
            case 99 -> var10000 = 156;
            case 100 -> var10000 = 158;
            case 101 -> var10000 = 196;
            case 102 -> var10000 = 200;
            case 103 -> var10000 = 87;
            case 104 -> var10000 = 233;
            case 105 -> var10000 = 38;
            case 106 -> var10000 = 2;
            case 107 -> var10000 = 236;
            case 108 -> var10000 = 23;
            case 109 -> var10000 = 153;
            case 110 -> var10000 = 59;
            case 111 -> var10000 = 242;
            case 112 -> var10000 = 249;
            case 113 -> var10000 = 208;
            case 114 -> var10000 = 66;
            case 115 -> var10000 = 89;
            case 116 -> var10000 = 116;
            case 117 -> var10000 = 174;
            case 118 -> var10000 = 33;
            case 119 -> var10000 = 229;
            case 120 -> var10000 = 220;
            case 121 -> var10000 = 130;
            case 122 -> var10000 = 62;
            case 123 -> var10000 = 70;
            case 124 -> var10000 = 69;
            case 125 -> var10000 = 244;
            case 126 -> var10000 = 168;
            case 127 -> var10000 = 18;
            case 128 -> var10000 = 56;
            case 129 -> var10000 = 32;
            case 130 -> var10000 = 90;
            case 131 -> var10000 = 102;
            case 132 -> var10000 = 201;
            case 133 -> var10000 = 210;
            case 134 -> var10000 = 104;
            case 135 -> var10000 = 80;
            case 136 -> var10000 = 187;
            case 137 -> var10000 = 191;
            case 138 -> var10000 = 234;
            case 139 -> var10000 = 82;
            case 140 -> var10000 = 225;
            case 141 -> var10000 = 193;
            case 142 -> var10000 = 5;
            case 143 -> var10000 = 25;
            case 144 -> var10000 = 122;
            case 145 -> var10000 = 95;
            case 146 -> var10000 = 107;
            case 147 -> var10000 = 218;
            case 148 -> var10000 = 77;
            case 149 -> var10000 = 182;
            case 150 -> var10000 = 162;
            case 151 -> var10000 = 247;
            case 152 -> var10000 = 147;
            case 153 -> var10000 = 123;
            case 154 -> var10000 = 34;
            case 155 -> var10000 = 136;
            case 156 -> var10000 = 127;
            case 157 -> var10000 = 7;
            case 158 -> var10000 = 88;
            case 159 -> var10000 = 166;
            case 160 -> var10000 = 48;
            case 161 -> var10000 = 30;
            case 162 -> var10000 = 133;
            case 163 -> var10000 = 91;
            case 164 -> var10000 = 19;
            case 165 -> var10000 = 13;
            case 166 -> var10000 = 237;
            case 167 -> var10000 = 42;
            case 168 -> var10000 = 207;
            case 169 -> var10000 = 101;
            case 170 -> var10000 = 140;
            case 171 -> var10000 = 175;
            case 172 -> var10000 = 52;
            case 173 -> var10000 = 46;
            case 174 -> var10000 = 43;
            case 175 -> var10000 = 75;
            case 176 -> var10000 = 28;
            case 177 -> var10000 = 192;
            case 178 -> var10000 = 125;
            case 179 -> var10000 = 202;
            case 180 -> var10000 = 155;
            case 181 -> var10000 = 227;
            case 182 -> var10000 = 112;
            case 183 -> var10000 = 68;
            case 184 -> var10000 = 0;
            case 185 -> var10000 = 145;
            case 186 -> var10000 = 197;
            case 187 -> var10000 = 177;
            case 188 -> var10000 = 245;
            case 189 -> var10000 = 252;
            case 190 -> var10000 = 113;
            case 191 -> var10000 = 213;
            case 192 -> var10000 = 8;
            case 193 -> var10000 = 124;
            case 194 -> var10000 = 71;
            case 195 -> var10000 = 74;
            case 196 -> var10000 = 167;
            case 197 -> var10000 = 27;
            case 198 -> var10000 = 63;
            case 199 -> var10000 = 84;
            case 200 -> var10000 = 4;
            case 201 -> var10000 = 35;
            case 202 -> var10000 = 14;
            case 203 -> var10000 = 161;
            case 204 -> var10000 = 41;
            case 205 -> var10000 = 238;
            case 206 -> var10000 = 92;
            case 207 -> var10000 = 109;
            case 208 -> var10000 = 132;
            case 209 -> var10000 = 206;
            case 210 -> var10000 = 141;
            case 211 -> var10000 = 29;
            case 212 -> var10000 = 255;
            case 213 -> var10000 = 194;
            case 214 -> var10000 = 164;
            case 215 -> var10000 = 248;
            case 216 -> var10000 = 93;
            case 217 -> var10000 = 15;
            case 218 -> var10000 = 228;
            case 219 -> var10000 = 12;
            case 220 -> var10000 = 181;
            case 221 -> var10000 = 120;
            case 222 -> var10000 = 160;
            case 223 -> var10000 = 178;
            case 224 -> var10000 = 118;
            case 225 -> var10000 = 149;
            case 226 -> var10000 = 78;
            case 227 -> var10000 = 146;
            case 228 -> var10000 = 134;
            case 229 -> var10000 = 20;
            case 230 -> var10000 = 190;
            case 231 -> var10000 = 222;
            case 232 -> var10000 = 11;
            case 233 -> var10000 = 129;
            case 234 -> var10000 = 159;
            case 235 -> var10000 = 212;
            case 236 -> var10000 = 22;
            case 237 -> var10000 = 226;
            case 238 -> var10000 = 211;
            case 239 -> var10000 = 110;
            case 240 -> var10000 = 150;
            case 241 -> var10000 = 154;
            case 242 -> var10000 = 135;
            case 243 -> var10000 = 170;
            case 244 -> var10000 = 49;
            case 245 -> var10000 = 203;
            case 246 -> var10000 = 115;
            case 247 -> var10000 = 142;
            case 248 -> var10000 = 99;
            case 249 -> var10000 = 103;
            case 250 -> var10000 = 126;
            case 251 -> var10000 = 50;
            case 252 -> var10000 = 214;
            case 253 -> var10000 = 241;
            case 254 -> var10000 = 137;
            default -> var10000 = 86;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static long a(int var0, long var1) {
      int var3 = (var0 ^ (int)var1 ^ 479) & 32767;
      if (e[var3] == null) {
         e[var3] = d[var3] ^ var1;
      }

      return e[var3];
   }
}
