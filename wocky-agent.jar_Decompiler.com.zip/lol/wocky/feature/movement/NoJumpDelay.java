package lol.wocky.feature.movement;

import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;

public class NoJumpDelay extends Module {
   private static final String[] a;
   private static final String[] b;

   public NoJumpDelay() {
      super(a(-1832, 5265), a(-1831, -8496), ModuleCategory.MOVEMENT);
   }

   public void onTick() {
      MinecraftBridge.resetJumpCooldown();
   }

   static {
      String[] var5 = new String[2];
      int var3 = 0;
      String var2 = "H\u0083¡pZE<\u0092è\u009fr1S÷a¢Ì«)x\bI\u0092ëåãóøi\u0004\u008f¢U\u0018\u0001-ô\u0007ÉV\u0097,\u0014íÎ\u00ad#µjrñG8\u0093 \u009eòÅ\u000f\u0012¹";
      int var4 = "H\u0083¡pZE<\u0092è\u009fr1S÷a¢Ì«)x\bI\u0092ëåãóøi\u0004\u008f¢U\u0018\u0001-ô\u0007ÉV\u0097,\u0014íÎ\u00ad#µjrñG8\u0093 \u009eòÅ\u000f\u0012¹".length();
      char var1 = 11;
      int var0 = -1;

      while(true) {
         char[] var16;
         label41: {
            ++var0;
            char[] var10001 = var2.substring(var0, var0 + var1).toCharArray();
            int var10003 = var10001.length;
            int var6 = 0;
            var16 = var10001;
            int var10 = var10003;
            char[] var23;
            int var10004;
            if (var10003 <= 1) {
               var23 = var10001;
               var10004 = var6;
            } else {
               var16 = var10001;
               var10 = var10003;
               if (var10003 <= var6) {
                  break label41;
               }

               var23 = var10001;
               var10004 = var6;
            }

            while(true) {
               char var10005 = var23[var10004];
               byte var10006;
               switch (var6 % 7) {
                  case 0 -> var10006 = 96;
                  case 1 -> var10006 = 5;
                  case 2 -> var10006 = 105;
                  case 3 -> var10006 = 87;
                  case 4 -> var10006 = 45;
                  case 5 -> var10006 = 10;
                  default -> var10006 = 86;
               }

               var23[var10004] = (char)(var10005 ^ var10006);
               ++var6;
               if (var10 == 0) {
                  var10004 = var10;
                  var23 = var16;
               } else {
                  if (var10 <= var6) {
                     break;
                  }

                  var23 = var16;
                  var10004 = var6;
               }
            }
         }

         String var30 = (new String(var16)).intern();
         boolean var14 = true;
         var5[var3++] = var30;
         if ((var0 += var1) >= var4) {
            a = var5;
            b = new String[2];
            return;
         }

         var1 = var2.charAt(var0);
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ -1832) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 138;
            case 1 -> var10000 = 31;
            case 2 -> var10000 = 55;
            case 3 -> var10000 = 158;
            case 4 -> var10000 = 171;
            case 5 -> var10000 = 116;
            case 6 -> var10000 = 101;
            case 7 -> var10000 = 249;
            case 8 -> var10000 = 215;
            case 9 -> var10000 = 160;
            case 10 -> var10000 = 129;
            case 11 -> var10000 = 151;
            case 12 -> var10000 = 104;
            case 13 -> var10000 = 193;
            case 14 -> var10000 = 238;
            case 15 -> var10000 = 91;
            case 16 -> var10000 = 8;
            case 17 -> var10000 = 159;
            case 18 -> var10000 = 168;
            case 19 -> var10000 = 203;
            case 20 -> var10000 = 108;
            case 21 -> var10000 = 233;
            case 22 -> var10000 = 243;
            case 23 -> var10000 = 224;
            case 24 -> var10000 = 187;
            case 25 -> var10000 = 161;
            case 26 -> var10000 = 130;
            case 27 -> var10000 = 92;
            case 28 -> var10000 = 212;
            case 29 -> var10000 = 79;
            case 30 -> var10000 = 145;
            case 31 -> var10000 = 58;
            case 32 -> var10000 = 214;
            case 33 -> var10000 = 93;
            case 34 -> var10000 = 148;
            case 35 -> var10000 = 251;
            case 36 -> var10000 = 235;
            case 37 -> var10000 = 180;
            case 38 -> var10000 = 166;
            case 39 -> var10000 = 206;
            case 40 -> var10000 = 43;
            case 41 -> var10000 = 232;
            case 42 -> var10000 = 90;
            case 43 -> var10000 = 170;
            case 44 -> var10000 = 68;
            case 45 -> var10000 = 67;
            case 46 -> var10000 = 220;
            case 47 -> var10000 = 1;
            case 48 -> var10000 = 81;
            case 49 -> var10000 = 225;
            case 50 -> var10000 = 240;
            case 51 -> var10000 = 87;
            case 52 -> var10000 = 97;
            case 53 -> var10000 = 32;
            case 54 -> var10000 = 186;
            case 55 -> var10000 = 218;
            case 56 -> var10000 = 131;
            case 57 -> var10000 = 156;
            case 58 -> var10000 = 163;
            case 59 -> var10000 = 72;
            case 60 -> var10000 = 181;
            case 61 -> var10000 = 178;
            case 62 -> var10000 = 5;
            case 63 -> var10000 = 82;
            case 64 -> var10000 = 122;
            case 65 -> var10000 = 112;
            case 66 -> var10000 = 176;
            case 67 -> var10000 = 95;
            case 68 -> var10000 = 239;
            case 69 -> var10000 = 119;
            case 70 -> var10000 = 71;
            case 71 -> var10000 = 205;
            case 72 -> var10000 = 100;
            case 73 -> var10000 = 42;
            case 74 -> var10000 = 88;
            case 75 -> var10000 = 17;
            case 76 -> var10000 = 201;
            case 77 -> var10000 = 16;
            case 78 -> var10000 = 222;
            case 79 -> var10000 = 110;
            case 80 -> var10000 = 189;
            case 81 -> var10000 = 70;
            case 82 -> var10000 = 117;
            case 83 -> var10000 = 136;
            case 84 -> var10000 = 127;
            case 85 -> var10000 = 103;
            case 86 -> var10000 = 154;
            case 87 -> var10000 = 142;
            case 88 -> var10000 = 133;
            case 89 -> var10000 = 139;
            case 90 -> var10000 = 234;
            case 91 -> var10000 = 167;
            case 92 -> var10000 = 27;
            case 93 -> var10000 = 11;
            case 94 -> var10000 = 15;
            case 95 -> var10000 = 102;
            case 96 -> var10000 = 7;
            case 97 -> var10000 = 124;
            case 98 -> var10000 = 62;
            case 99 -> var10000 = 250;
            case 100 -> var10000 = 169;
            case 101 -> var10000 = 12;
            case 102 -> var10000 = 22;
            case 103 -> var10000 = 173;
            case 104 -> var10000 = 141;
            case 105 -> var10000 = 69;
            case 106 -> var10000 = 208;
            case 107 -> var10000 = 165;
            case 108 -> var10000 = 221;
            case 109 -> var10000 = 34;
            case 110 -> var10000 = 248;
            case 111 -> var10000 = 6;
            case 112 -> var10000 = 60;
            case 113 -> var10000 = 226;
            case 114 -> var10000 = 65;
            case 115 -> var10000 = 99;
            case 116 -> var10000 = 199;
            case 117 -> var10000 = 25;
            case 118 -> var10000 = 118;
            case 119 -> var10000 = 197;
            case 120 -> var10000 = 4;
            case 121 -> var10000 = 84;
            case 122 -> var10000 = 191;
            case 123 -> var10000 = 123;
            case 124 -> var10000 = 85;
            case 125 -> var10000 = 132;
            case 126 -> var10000 = 0;
            case 127 -> var10000 = 105;
            case 128 -> var10000 = 77;
            case 129 -> var10000 = 150;
            case 130 -> var10000 = 13;
            case 131 -> var10000 = 229;
            case 132 -> var10000 = 54;
            case 133 -> var10000 = 44;
            case 134 -> var10000 = 10;
            case 135 -> var10000 = 86;
            case 136 -> var10000 = 162;
            case 137 -> var10000 = 204;
            case 138 -> var10000 = 217;
            case 139 -> var10000 = 59;
            case 140 -> var10000 = 83;
            case 141 -> var10000 = 75;
            case 142 -> var10000 = 227;
            case 143 -> var10000 = 182;
            case 144 -> var10000 = 211;
            case 145 -> var10000 = 125;
            case 146 -> var10000 = 128;
            case 147 -> var10000 = 207;
            case 148 -> var10000 = 219;
            case 149 -> var10000 = 134;
            case 150 -> var10000 = 89;
            case 151 -> var10000 = 200;
            case 152 -> var10000 = 153;
            case 153 -> var10000 = 66;
            case 154 -> var10000 = 195;
            case 155 -> var10000 = 26;
            case 156 -> var10000 = 152;
            case 157 -> var10000 = 41;
            case 158 -> var10000 = 253;
            case 159 -> var10000 = 175;
            case 160 -> var10000 = 113;
            case 161 -> var10000 = 23;
            case 162 -> var10000 = 115;
            case 163 -> var10000 = 109;
            case 164 -> var10000 = 2;
            case 165 -> var10000 = 213;
            case 166 -> var10000 = 14;
            case 167 -> var10000 = 39;
            case 168 -> var10000 = 18;
            case 169 -> var10000 = 80;
            case 170 -> var10000 = 20;
            case 171 -> var10000 = 38;
            case 172 -> var10000 = 143;
            case 173 -> var10000 = 121;
            case 174 -> var10000 = 51;
            case 175 -> var10000 = 114;
            case 176 -> var10000 = 147;
            case 177 -> var10000 = 40;
            case 178 -> var10000 = 63;
            case 179 -> var10000 = 228;
            case 180 -> var10000 = 3;
            case 181 -> var10000 = 241;
            case 182 -> var10000 = 47;
            case 183 -> var10000 = 188;
            case 184 -> var10000 = 64;
            case 185 -> var10000 = 202;
            case 186 -> var10000 = 111;
            case 187 -> var10000 = 37;
            case 188 -> var10000 = 230;
            case 189 -> var10000 = 21;
            case 190 -> var10000 = 52;
            case 191 -> var10000 = 237;
            case 192 -> var10000 = 78;
            case 193 -> var10000 = 177;
            case 194 -> var10000 = 242;
            case 195 -> var10000 = 135;
            case 196 -> var10000 = 35;
            case 197 -> var10000 = 196;
            case 198 -> var10000 = 194;
            case 199 -> var10000 = 254;
            case 200 -> var10000 = 94;
            case 201 -> var10000 = 107;
            case 202 -> var10000 = 252;
            case 203 -> var10000 = 210;
            case 204 -> var10000 = 223;
            case 205 -> var10000 = 46;
            case 206 -> var10000 = 140;
            case 207 -> var10000 = 120;
            case 208 -> var10000 = 179;
            case 209 -> var10000 = 50;
            case 210 -> var10000 = 244;
            case 211 -> var10000 = 174;
            case 212 -> var10000 = 192;
            case 213 -> var10000 = 48;
            case 214 -> var10000 = 98;
            case 215 -> var10000 = 9;
            case 216 -> var10000 = 24;
            case 217 -> var10000 = 106;
            case 218 -> var10000 = 137;
            case 219 -> var10000 = 149;
            case 220 -> var10000 = 45;
            case 221 -> var10000 = 30;
            case 222 -> var10000 = 28;
            case 223 -> var10000 = 216;
            case 224 -> var10000 = 172;
            case 225 -> var10000 = 56;
            case 226 -> var10000 = 190;
            case 227 -> var10000 = 96;
            case 228 -> var10000 = 33;
            case 229 -> var10000 = 29;
            case 230 -> var10000 = 185;
            case 231 -> var10000 = 36;
            case 232 -> var10000 = 61;
            case 233 -> var10000 = 209;
            case 234 -> var10000 = 255;
            case 235 -> var10000 = 74;
            case 236 -> var10000 = 247;
            case 237 -> var10000 = 57;
            case 238 -> var10000 = 231;
            case 239 -> var10000 = 49;
            case 240 -> var10000 = 198;
            case 241 -> var10000 = 245;
            case 242 -> var10000 = 73;
            case 243 -> var10000 = 76;
            case 244 -> var10000 = 183;
            case 245 -> var10000 = 53;
            case 246 -> var10000 = 144;
            case 247 -> var10000 = 164;
            case 248 -> var10000 = 19;
            case 249 -> var10000 = 246;
            case 250 -> var10000 = 157;
            case 251 -> var10000 = 126;
            case 252 -> var10000 = 155;
            case 253 -> var10000 = 146;
            case 254 -> var10000 = 236;
            default -> var10000 = 184;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }
}
