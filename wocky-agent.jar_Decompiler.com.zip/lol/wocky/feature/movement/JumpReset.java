package lol.wocky.feature.movement;

import java.util.concurrent.ThreadLocalRandom;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;

public class JumpReset extends Module {
   private static final int HURT_TICKS;
   private final NumberProperty chance = new NumberProperty(a(14908, -4915), a(24351, 8248432310115861058L), 0, a(24351, 8248432310115861058L), 1);
   private final NumberProperty delay = new NumberProperty(a(14904, -9621), 0, 0, 3, 1);
   private final BooleanProperty onlyForward = new BooleanProperty(a(14905, -32031), true);
   private int jumpIn = -1;
   private boolean holding;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;

   public JumpReset() {
      super(a(14907, -17211), a(14906, 13150), ModuleCategory.MOVEMENT);
      this.addProperties(new Property[]{this.chance, this.delay, this.onlyForward});
   }

   public void onTick() {
      if (this.holding) {
         MinecraftBridge.holdKey(MinecraftBridge.MoveKey.JUMP, false);
         this.holding = false;
      }

      Object var1 = MinecraftBridge.getPlayer();
      if (MinecraftBridge.getCurrentScreen() != null) {
         this.jumpIn = -1;
      } else {
         if (MinecraftBridge.getHurtTime(var1) == a(21846, 3100793895804471311L) && this.jumpIn < 0) {
            int var2 = this.chance.intValue();
            if (var2 >= a(20459, 7941932378703106736L) || var2 > 0 && ThreadLocalRandom.current().nextInt(1, a(10116, 9043934433424472796L)) <= var2) {
               this.jumpIn = this.delay.intValue();
            }
         }

         if (this.jumpIn >= 0) {
            if (this.jumpIn-- <= 0) {
               if (MinecraftBridge.isOnGround(var1) && !MinecraftBridge.isInLiquidOrClimbing(var1)) {
                  if (!(Boolean)this.onlyForward.getValue() || MinecraftBridge.isPhysicallyDown(MinecraftBridge.MoveKey.FORWARD)) {
                     MinecraftBridge.holdKey(MinecraftBridge.MoveKey.JUMP, true);
                     this.holding = true;
                  }
               }
            }
         }
      }
   }

   public void onDisable() {
      if (this.holding && MinecraftBridge.isInGame()) {
         MinecraftBridge.holdKey(MinecraftBridge.MoveKey.JUMP, false);
      }

      this.holding = false;
      this.jumpIn = -1;
   }

   static {
      String[] var13 = new String[5];
      int var11 = 0;
      String var10 = "&û\u000f1\b\u0013üQ>\u0016wÂÏ\u0012èÿØ\rÍ\u0080\u009d\u001f\u0085îè3\u000b,dÈN\\Ê\u001f<ÍÅ\u0083\u000eý·ø\u001ezùw÷\u008aEÅ§[¢\u0010èv=ò \u0000ÿð#ÐÃùÙh\u0095½°\u0091\u008eDÜ\u001dG";
      int var12 = "&û\u000f1\b\u0013üQ>\u0016wÂÏ\u0012èÿØ\rÍ\u0080\u009d\u001f\u0085îè3\u000b,dÈN\\Ê\u001f<ÍÅ\u0083\u000eý·ø\u001ezùw÷\u008aEÅ§[¢\u0010èv=ò \u0000ÿð#ÐÃùÙh\u0095½°\u0091\u008eDÜ\u001dG".length();
      char var9 = 5;
      int var17 = -1;

      label73:
      while(true) {
         ++var17;
         String var10000 = var10.substring(var17, var17 + var9);
         int var10001 = -1;

         while(true) {
            char[] var33;
            label68: {
               char[] var21 = var10000.toCharArray();
               int var10003 = var21.length;
               int var14 = 0;
               var33 = var21;
               int var24 = var10003;
               char[] var43;
               int var10004;
               if (var10003 <= 1) {
                  var43 = var21;
                  var10004 = var14;
               } else {
                  var33 = var21;
                  var24 = var10003;
                  if (var10003 <= var14) {
                     break label68;
                  }

                  var43 = var21;
                  var10004 = var14;
               }

               while(true) {
                  char var10005 = var43[var10004];
                  byte var10006;
                  switch (var14 % 7) {
                     case 0 -> var10006 = 27;
                     case 1 -> var10006 = 118;
                     case 2 -> var10006 = 8;
                     case 3 -> var10006 = 40;
                     case 4 -> var10006 = 112;
                     case 5 -> var10006 = 30;
                     default -> var10006 = 100;
                  }

                  var43[var10004] = (char)(var10005 ^ var10006);
                  ++var14;
                  if (var24 == 0) {
                     var10004 = var24;
                     var43 = var33;
                  } else {
                     if (var24 <= var14) {
                        break;
                     }

                     var43 = var33;
                     var10004 = var14;
                  }
               }
            }

            String var50 = (new String(var33)).intern();
            switch (var10001) {
               case 0:
                  var13[var11++] = var50;
                  if ((var17 += var9) >= var12) {
                     a = var13;
                     b = new String[5];
                     long var0 = 6014232566634073479L;
                     long[] var6 = new long[5];
                     int var3 = 0;
                     String var4 = "ïD\u0083\u009a\u000bïE\u0082&\u0002¬\u001bÞÿ7>3\u0083°L\u0004\nßS";
                     int var5 = "ïD\u0083\u009a\u000bïE\u0082&\u0002¬\u001bÞÿ7>3\u0083°L\u0004\nßS".length();
                     int var2 = 0;

                     label44:
                     while(true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var19 = var6;
                        var10001 = var3++;
                        long var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                        byte var51 = -1;

                        while(true) {
                           long var54 = var38 ^ var0;
                           switch (var51) {
                              case 0:
                                 var19[var10001] = var54;
                                 if (var2 >= var5) {
                                    c = var6;
                                    d = new Integer[5];
                                    HURT_TICKS = a(21895, 8401487857650763997L);
                                    return;
                                 }
                                 break;
                              default:
                                 var19[var10001] = var54;
                                 if (var2 < var5) {
                                    continue label44;
                                 }

                                 var4 = "\u001au\u0001û\u001eÇEP\u0088Û×_t\u0080Ï¡";
                                 var5 = "\u001au\u0001û\u001eÇEP\u0088Û×_t\u0080Ï¡".length();
                                 var2 = 0;
                           }

                           var10001 = var2;
                           var2 += 8;
                           var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                           var19 = var6;
                           var10001 = var3++;
                           var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                           var51 = 0;
                        }
                     }
                  }

                  var9 = var10.charAt(var17);
                  break;
               default:
                  var13[var11++] = var50;
                  if ((var17 += var9) < var12) {
                     var9 = var10.charAt(var17);
                     continue label73;
                  }

                  var10 = "\u008c×\u0094·qö/ªv\u0006G Ééfà";
                  var12 = "\u008c×\u0094·qö/ªv\u0006G Ééfà".length();
                  var9 = '\t';
                  var17 = -1;
            }

            ++var17;
            var10000 = var10.substring(var17, var17 + var9);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 14904) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 80;
            case 1 -> var10000 = 238;
            case 2 -> var10000 = 29;
            case 3 -> var10000 = 155;
            case 4 -> var10000 = 240;
            case 5 -> var10000 = 178;
            case 6 -> var10000 = 239;
            case 7 -> var10000 = 92;
            case 8 -> var10000 = 192;
            case 9 -> var10000 = 107;
            case 10 -> var10000 = 40;
            case 11 -> var10000 = 223;
            case 12 -> var10000 = 184;
            case 13 -> var10000 = 165;
            case 14 -> var10000 = 123;
            case 15 -> var10000 = 198;
            case 16 -> var10000 = 4;
            case 17 -> var10000 = 83;
            case 18 -> var10000 = 127;
            case 19 -> var10000 = 18;
            case 20 -> var10000 = 76;
            case 21 -> var10000 = 55;
            case 22 -> var10000 = 150;
            case 23 -> var10000 = 197;
            case 24 -> var10000 = 99;
            case 25 -> var10000 = 154;
            case 26 -> var10000 = 124;
            case 27 -> var10000 = 160;
            case 28 -> var10000 = 218;
            case 29 -> var10000 = 151;
            case 30 -> var10000 = 48;
            case 31 -> var10000 = 187;
            case 32 -> var10000 = 129;
            case 33 -> var10000 = 177;
            case 34 -> var10000 = 251;
            case 35 -> var10000 = 186;
            case 36 -> var10000 = 114;
            case 37 -> var10000 = 164;
            case 38 -> var10000 = 158;
            case 39 -> var10000 = 136;
            case 40 -> var10000 = 126;
            case 41 -> var10000 = 113;
            case 42 -> var10000 = 25;
            case 43 -> var10000 = 170;
            case 44 -> var10000 = 203;
            case 45 -> var10000 = 94;
            case 46 -> var10000 = 225;
            case 47 -> var10000 = 24;
            case 48 -> var10000 = 49;
            case 49 -> var10000 = 208;
            case 50 -> var10000 = 230;
            case 51 -> var10000 = 66;
            case 52 -> var10000 = 121;
            case 53 -> var10000 = 64;
            case 54 -> var10000 = 213;
            case 55 -> var10000 = 81;
            case 56 -> var10000 = 209;
            case 57 -> var10000 = 224;
            case 58 -> var10000 = 134;
            case 59 -> var10000 = 73;
            case 60 -> var10000 = 112;
            case 61 -> var10000 = 242;
            case 62 -> var10000 = 88;
            case 63 -> var10000 = 167;
            case 64 -> var10000 = 122;
            case 65 -> var10000 = 115;
            case 66 -> var10000 = 103;
            case 67 -> var10000 = 128;
            case 68 -> var10000 = 37;
            case 69 -> var10000 = 163;
            case 70 -> var10000 = 144;
            case 71 -> var10000 = 60;
            case 72 -> var10000 = 204;
            case 73 -> var10000 = 143;
            case 74 -> var10000 = 52;
            case 75 -> var10000 = 65;
            case 76 -> var10000 = 130;
            case 77 -> var10000 = 162;
            case 78 -> var10000 = 227;
            case 79 -> var10000 = 67;
            case 80 -> var10000 = 243;
            case 81 -> var10000 = 222;
            case 82 -> var10000 = 32;
            case 83 -> var10000 = 15;
            case 84 -> var10000 = 47;
            case 85 -> var10000 = 56;
            case 86 -> var10000 = 141;
            case 87 -> var10000 = 191;
            case 88 -> var10000 = 68;
            case 89 -> var10000 = 8;
            case 90 -> var10000 = 23;
            case 91 -> var10000 = 185;
            case 92 -> var10000 = 174;
            case 93 -> var10000 = 20;
            case 94 -> var10000 = 226;
            case 95 -> var10000 = 101;
            case 96 -> var10000 = 196;
            case 97 -> var10000 = 188;
            case 98 -> var10000 = 97;
            case 99 -> var10000 = 19;
            case 100 -> var10000 = 104;
            case 101 -> var10000 = 89;
            case 102 -> var10000 = 142;
            case 103 -> var10000 = 34;
            case 104 -> var10000 = 166;
            case 105 -> var10000 = 111;
            case 106 -> var10000 = 138;
            case 107 -> var10000 = 54;
            case 108 -> var10000 = 161;
            case 109 -> var10000 = 38;
            case 110 -> var10000 = 3;
            case 111 -> var10000 = 157;
            case 112 -> var10000 = 156;
            case 113 -> var10000 = 96;
            case 114 -> var10000 = 148;
            case 115 -> var10000 = 102;
            case 116 -> var10000 = 36;
            case 117 -> var10000 = 42;
            case 118 -> var10000 = 86;
            case 119 -> var10000 = 201;
            case 120 -> var10000 = 171;
            case 121 -> var10000 = 110;
            case 122 -> var10000 = 255;
            case 123 -> var10000 = 71;
            case 124 -> var10000 = 117;
            case 125 -> var10000 = 248;
            case 126 -> var10000 = 21;
            case 127 -> var10000 = 11;
            case 128 -> var10000 = 146;
            case 129 -> var10000 = 91;
            case 130 -> var10000 = 159;
            case 131 -> var10000 = 84;
            case 132 -> var10000 = 139;
            case 133 -> var10000 = 9;
            case 134 -> var10000 = 219;
            case 135 -> var10000 = 247;
            case 136 -> var10000 = 214;
            case 137 -> var10000 = 90;
            case 138 -> var10000 = 205;
            case 139 -> var10000 = 118;
            case 140 -> var10000 = 252;
            case 141 -> var10000 = 183;
            case 142 -> var10000 = 109;
            case 143 -> var10000 = 59;
            case 144 -> var10000 = 69;
            case 145 -> var10000 = 63;
            case 146 -> var10000 = 70;
            case 147 -> var10000 = 245;
            case 148 -> var10000 = 147;
            case 149 -> var10000 = 27;
            case 150 -> var10000 = 210;
            case 151 -> var10000 = 232;
            case 152 -> var10000 = 125;
            case 153 -> var10000 = 45;
            case 154 -> var10000 = 95;
            case 155 -> var10000 = 53;
            case 156 -> var10000 = 249;
            case 157 -> var10000 = 135;
            case 158 -> var10000 = 250;
            case 159 -> var10000 = 202;
            case 160 -> var10000 = 16;
            case 161 -> var10000 = 35;
            case 162 -> var10000 = 0;
            case 163 -> var10000 = 93;
            case 164 -> var10000 = 190;
            case 165 -> var10000 = 237;
            case 166 -> var10000 = 46;
            case 167 -> var10000 = 132;
            case 168 -> var10000 = 153;
            case 169 -> var10000 = 182;
            case 170 -> var10000 = 26;
            case 171 -> var10000 = 33;
            case 172 -> var10000 = 2;
            case 173 -> var10000 = 246;
            case 174 -> var10000 = 75;
            case 175 -> var10000 = 179;
            case 176 -> var10000 = 175;
            case 177 -> var10000 = 78;
            case 178 -> var10000 = 206;
            case 179 -> var10000 = 169;
            case 180 -> var10000 = 254;
            case 181 -> var10000 = 253;
            case 182 -> var10000 = 41;
            case 183 -> var10000 = 13;
            case 184 -> var10000 = 10;
            case 185 -> var10000 = 30;
            case 186 -> var10000 = 168;
            case 187 -> var10000 = 5;
            case 188 -> var10000 = 14;
            case 189 -> var10000 = 241;
            case 190 -> var10000 = 221;
            case 191 -> var10000 = 173;
            case 192 -> var10000 = 216;
            case 193 -> var10000 = 62;
            case 194 -> var10000 = 43;
            case 195 -> var10000 = 180;
            case 196 -> var10000 = 51;
            case 197 -> var10000 = 211;
            case 198 -> var10000 = 137;
            case 199 -> var10000 = 82;
            case 200 -> var10000 = 7;
            case 201 -> var10000 = 119;
            case 202 -> var10000 = 140;
            case 203 -> var10000 = 87;
            case 204 -> var10000 = 108;
            case 205 -> var10000 = 207;
            case 206 -> var10000 = 244;
            case 207 -> var10000 = 172;
            case 208 -> var10000 = 176;
            case 209 -> var10000 = 199;
            case 210 -> var10000 = 120;
            case 211 -> var10000 = 195;
            case 212 -> var10000 = 231;
            case 213 -> var10000 = 105;
            case 214 -> var10000 = 50;
            case 215 -> var10000 = 31;
            case 216 -> var10000 = 145;
            case 217 -> var10000 = 17;
            case 218 -> var10000 = 79;
            case 219 -> var10000 = 233;
            case 220 -> var10000 = 181;
            case 221 -> var10000 = 228;
            case 222 -> var10000 = 39;
            case 223 -> var10000 = 61;
            case 224 -> var10000 = 200;
            case 225 -> var10000 = 12;
            case 226 -> var10000 = 236;
            case 227 -> var10000 = 28;
            case 228 -> var10000 = 106;
            case 229 -> var10000 = 193;
            case 230 -> var10000 = 220;
            case 231 -> var10000 = 57;
            case 232 -> var10000 = 1;
            case 233 -> var10000 = 72;
            case 234 -> var10000 = 189;
            case 235 -> var10000 = 229;
            case 236 -> var10000 = 234;
            case 237 -> var10000 = 217;
            case 238 -> var10000 = 44;
            case 239 -> var10000 = 85;
            case 240 -> var10000 = 235;
            case 241 -> var10000 = 194;
            case 242 -> var10000 = 58;
            case 243 -> var10000 = 212;
            case 244 -> var10000 = 74;
            case 245 -> var10000 = 116;
            case 246 -> var10000 = 152;
            case 247 -> var10000 = 133;
            case 248 -> var10000 = 6;
            case 249 -> var10000 = 77;
            case 250 -> var10000 = 149;
            case 251 -> var10000 = 98;
            case 252 -> var10000 = 215;
            case 253 -> var10000 = 131;
            case 254 -> var10000 = 22;
            default -> var10000 = 100;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 23897;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }
}
