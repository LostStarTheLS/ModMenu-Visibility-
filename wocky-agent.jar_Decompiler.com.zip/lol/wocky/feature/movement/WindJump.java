package lol.wocky.feature.movement;

import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.KeyProperty;
import lol.wocky.core.module.property.Property;

public class WindJump extends Module {
   private static final String WIND_CHARGE;
   private final KeyProperty activateKey = new KeyProperty(a(14226, -12905), 0);
   private final BooleanProperty jump = new BooleanProperty(a(14229, 13850), true);
   private final BooleanProperty swapBack = new BooleanProperty(a(14228, 14921), true);
   private boolean keyWasDown;
   private boolean holdingJump;
   private boolean queued;
   private int queuedTicks;
   private int previousSlot = -1;
   private static final String[] a;
   private static final String[] b;

   public WindJump() {
      super(a(14224, 8481), a(14225, 10794), ModuleCategory.MOVEMENT);
      this.addProperties(new Property[]{this.activateKey, this.jump, this.swapBack});
   }

   public void onTick() {
      if (this.holdingJump) {
         MinecraftBridge.holdKey(MinecraftBridge.MoveKey.JUMP, false);
         this.holdingJump = false;
      }

      boolean var1 = MinecraftBridge.getCurrentScreen() != null;
      boolean var2 = !var1 && this.activateKey.getKey() != 0 && this.activateKey.isDown();
      boolean var3 = var2 && !this.keyWasDown;
      this.keyWasDown = var2;
      if (var1) {
         this.queued = false;
      } else {
         if (var3 && !this.queued) {
            int var4 = MinecraftBridge.findHotbarSlot(a(14231, -6416));
            if (var4 == -1) {
               return;
            }

            this.previousSlot = MinecraftBridge.getSelectedSlot();
            MinecraftBridge.setSelectedSlot(var4);
            this.queued = true;
            this.queuedTicks = 0;
         }

         if (this.queued) {
            if (++this.queuedTicks > 3) {
               this.queued = false;
            } else if (!MinecraftBridge.isHolding(a(14230, -940))) {
               if (MinecraftBridge.findHotbarSlot(a(14230, -940)) == -1) {
                  this.queued = false;
               }

            } else if (MinecraftBridge.canAct(true)) {
               this.queued = false;
               Object var6 = MinecraftBridge.getPlayer();
               boolean var5 = MinecraftBridge.isOnGround(var6);
               if (MinecraftBridge.interactItemAtPitch(90.0F)) {
                  if ((Boolean)this.jump.getValue() && var5 && !MinecraftBridge.isInLiquidOrClimbing(var6)) {
                     MinecraftBridge.holdKey(MinecraftBridge.MoveKey.JUMP, true);
                     this.holdingJump = true;
                  }

                  if ((Boolean)this.swapBack.getValue() && this.previousSlot != -1) {
                     MinecraftBridge.setSelectedSlot(this.previousSlot);
                  }

                  this.previousSlot = -1;
               }
            }
         }
      }
   }

   public void onDisable() {
      if (this.holdingJump && MinecraftBridge.isInGame()) {
         MinecraftBridge.holdKey(MinecraftBridge.MoveKey.JUMP, false);
      }

      this.holdingJump = false;
      this.queued = false;
      this.keyWasDown = false;
      this.previousSlot = -1;
   }

   static {
      String[] var5 = new String[8];
      int var3 = 0;
      String var2 = "kvOÝ\t¶ÏÂ¨\u0089n¤\u009d«\u000bW\u0011Qºj\u009bA$&â%\u000b\u008c´*\u000e\u0005\r¬ö\u009b¸\u00928E7HTþ<¶ÂË.\u008c\u008eö\u0082l\u0005¯\u000fcÿ\u0017n«ìNj\u00admwîãª}ûä\f¬N¯$øÿ\u0095¸\u0094âÃ7rÕ\u001d\u0011\u0098<\u0015(\bë\u009bâë\t§\u009ff";
      int var4 = "kvOÝ\t¶ÏÂ¨\u0089n¤\u009d«\u000bW\u0011Qºj\u009bA$&â%\u000b\u008c´*\u000e\u0005\r¬ö\u009b¸\u00928E7HTþ<¶ÂË.\u008c\u008eö\u0082l\u0005¯\u000fcÿ\u0017n«ìNj\u00admwîãª}ûä\f¬N¯$øÿ\u0095¸\u0094âÃ7rÕ\u001d\u0011\u0098<\u0015(\bë\u009bâë\t§\u009ff".length();
      char var1 = 4;
      int var8 = -1;

      label55:
      while(true) {
         ++var8;
         String var10000 = var2.substring(var8, var8 + var1);
         byte var10001 = -1;

         while(true) {
            char[] var20;
            label50: {
               char[] var11 = var10000.toCharArray();
               int var10003 = var11.length;
               int var6 = 0;
               var20 = var11;
               int var14 = var10003;
               char[] var28;
               int var10004;
               if (var10003 <= 1) {
                  var28 = var11;
                  var10004 = var6;
               } else {
                  var20 = var11;
                  var14 = var10003;
                  if (var10003 <= var6) {
                     break label50;
                  }

                  var28 = var11;
                  var10004 = var6;
               }

               while(true) {
                  char var10005 = var28[var10004];
                  byte var10006;
                  switch (var6 % 7) {
                     case 0 -> var10006 = 24;
                     case 1 -> var10006 = 86;
                     case 2 -> var10006 = 79;
                     case 3 -> var10006 = 114;
                     case 4 -> var10006 = 85;
                     case 5 -> var10006 = 9;
                     default -> var10006 = 122;
                  }

                  var28[var10004] = (char)(var10005 ^ var10006);
                  ++var6;
                  if (var14 == 0) {
                     var10004 = var14;
                     var28 = var20;
                  } else {
                     if (var14 <= var6) {
                        break;
                     }

                     var28 = var20;
                     var10004 = var6;
                  }
               }
            }

            String var35 = (new String(var20)).intern();
            switch (var10001) {
               case 0:
                  var5[var3++] = var35;
                  if ((var8 += var1) >= var4) {
                     a = var5;
                     b = new String[8];
                     WIND_CHARGE = a(14227, 9098);
                     return;
                  }

                  var1 = var2.charAt(var8);
                  break;
               default:
                  var5[var3++] = var35;
                  if ((var8 += var1) < var4) {
                     var1 = var2.charAt(var8);
                     continue label55;
                  }

                  var2 = "!Ø\u009f\u0083³¼zÀA~É\fQ\u000b{¿_\u0095÷£=º^°";
                  var4 = "!Ø\u009f\u0083³¼zÀA~É\fQ\u000b{¿_\u0095÷£=º^°".length();
                  var1 = 11;
                  var8 = -1;
            }

            ++var8;
            var10000 = var2.substring(var8, var8 + var1);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 14229) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 51;
            case 1 -> var10000 = 64;
            case 2 -> var10000 = 11;
            case 3 -> var10000 = 206;
            case 4 -> var10000 = 250;
            case 5 -> var10000 = 71;
            case 6 -> var10000 = 142;
            case 7 -> var10000 = 12;
            case 8 -> var10000 = 115;
            case 9 -> var10000 = 253;
            case 10 -> var10000 = 167;
            case 11 -> var10000 = 22;
            case 12 -> var10000 = 120;
            case 13 -> var10000 = 190;
            case 14 -> var10000 = 150;
            case 15 -> var10000 = 67;
            case 16 -> var10000 = 151;
            case 17 -> var10000 = 50;
            case 18 -> var10000 = 7;
            case 19 -> var10000 = 1;
            case 20 -> var10000 = 102;
            case 21 -> var10000 = 96;
            case 22 -> var10000 = 188;
            case 23 -> var10000 = 86;
            case 24 -> var10000 = 198;
            case 25 -> var10000 = 91;
            case 26 -> var10000 = 248;
            case 27 -> var10000 = 144;
            case 28 -> var10000 = 92;
            case 29 -> var10000 = 197;
            case 30 -> var10000 = 171;
            case 31 -> var10000 = 32;
            case 32 -> var10000 = 106;
            case 33 -> var10000 = 165;
            case 34 -> var10000 = 209;
            case 35 -> var10000 = 100;
            case 36 -> var10000 = 145;
            case 37 -> var10000 = 109;
            case 38 -> var10000 = 114;
            case 39 -> var10000 = 37;
            case 40 -> var10000 = 81;
            case 41 -> var10000 = 0;
            case 42 -> var10000 = 25;
            case 43 -> var10000 = 230;
            case 44 -> var10000 = 128;
            case 45 -> var10000 = 20;
            case 46 -> var10000 = 2;
            case 47 -> var10000 = 219;
            case 48 -> var10000 = 98;
            case 49 -> var10000 = 221;
            case 50 -> var10000 = 15;
            case 51 -> var10000 = 215;
            case 52 -> var10000 = 207;
            case 53 -> var10000 = 43;
            case 54 -> var10000 = 235;
            case 55 -> var10000 = 196;
            case 56 -> var10000 = 5;
            case 57 -> var10000 = 60;
            case 58 -> var10000 = 189;
            case 59 -> var10000 = 35;
            case 60 -> var10000 = 75;
            case 61 -> var10000 = 148;
            case 62 -> var10000 = 90;
            case 63 -> var10000 = 164;
            case 64 -> var10000 = 174;
            case 65 -> var10000 = 93;
            case 66 -> var10000 = 87;
            case 67 -> var10000 = 222;
            case 68 -> var10000 = 77;
            case 69 -> var10000 = 62;
            case 70 -> var10000 = 34;
            case 71 -> var10000 = 95;
            case 72 -> var10000 = 227;
            case 73 -> var10000 = 143;
            case 74 -> var10000 = 89;
            case 75 -> var10000 = 69;
            case 76 -> var10000 = 234;
            case 77 -> var10000 = 47;
            case 78 -> var10000 = 74;
            case 79 -> var10000 = 184;
            case 80 -> var10000 = 16;
            case 81 -> var10000 = 40;
            case 82 -> var10000 = 228;
            case 83 -> var10000 = 166;
            case 84 -> var10000 = 182;
            case 85 -> var10000 = 178;
            case 86 -> var10000 = 156;
            case 87 -> var10000 = 212;
            case 88 -> var10000 = 49;
            case 89 -> var10000 = 107;
            case 90 -> var10000 = 119;
            case 91 -> var10000 = 213;
            case 92 -> var10000 = 173;
            case 93 -> var10000 = 33;
            case 94 -> var10000 = 48;
            case 95 -> var10000 = 231;
            case 96 -> var10000 = 132;
            case 97 -> var10000 = 240;
            case 98 -> var10000 = 175;
            case 99 -> var10000 = 13;
            case 100 -> var10000 = 4;
            case 101 -> var10000 = 136;
            case 102 -> var10000 = 177;
            case 103 -> var10000 = 30;
            case 104 -> var10000 = 55;
            case 105 -> var10000 = 157;
            case 106 -> var10000 = 108;
            case 107 -> var10000 = 226;
            case 108 -> var10000 = 200;
            case 109 -> var10000 = 6;
            case 110 -> var10000 = 153;
            case 111 -> var10000 = 247;
            case 112 -> var10000 = 179;
            case 113 -> var10000 = 249;
            case 114 -> var10000 = 137;
            case 115 -> var10000 = 225;
            case 116 -> var10000 = 186;
            case 117 -> var10000 = 241;
            case 118 -> var10000 = 53;
            case 119 -> var10000 = 52;
            case 120 -> var10000 = 117;
            case 121 -> var10000 = 44;
            case 122 -> var10000 = 46;
            case 123 -> var10000 = 101;
            case 124 -> var10000 = 85;
            case 125 -> var10000 = 162;
            case 126 -> var10000 = 146;
            case 127 -> var10000 = 21;
            case 128 -> var10000 = 23;
            case 129 -> var10000 = 159;
            case 130 -> var10000 = 88;
            case 131 -> var10000 = 127;
            case 132 -> var10000 = 83;
            case 133 -> var10000 = 158;
            case 134 -> var10000 = 39;
            case 135 -> var10000 = 191;
            case 136 -> var10000 = 204;
            case 137 -> var10000 = 242;
            case 138 -> var10000 = 141;
            case 139 -> var10000 = 138;
            case 140 -> var10000 = 255;
            case 141 -> var10000 = 239;
            case 142 -> var10000 = 111;
            case 143 -> var10000 = 130;
            case 144 -> var10000 = 72;
            case 145 -> var10000 = 214;
            case 146 -> var10000 = 68;
            case 147 -> var10000 = 58;
            case 148 -> var10000 = 113;
            case 149 -> var10000 = 14;
            case 150 -> var10000 = 3;
            case 151 -> var10000 = 229;
            case 152 -> var10000 = 202;
            case 153 -> var10000 = 181;
            case 154 -> var10000 = 208;
            case 155 -> var10000 = 118;
            case 156 -> var10000 = 110;
            case 157 -> var10000 = 185;
            case 158 -> var10000 = 56;
            case 159 -> var10000 = 84;
            case 160 -> var10000 = 42;
            case 161 -> var10000 = 147;
            case 162 -> var10000 = 82;
            case 163 -> var10000 = 245;
            case 164 -> var10000 = 140;
            case 165 -> var10000 = 224;
            case 166 -> var10000 = 163;
            case 167 -> var10000 = 94;
            case 168 -> var10000 = 133;
            case 169 -> var10000 = 216;
            case 170 -> var10000 = 17;
            case 171 -> var10000 = 36;
            case 172 -> var10000 = 131;
            case 173 -> var10000 = 19;
            case 174 -> var10000 = 76;
            case 175 -> var10000 = 99;
            case 176 -> var10000 = 194;
            case 177 -> var10000 = 126;
            case 178 -> var10000 = 180;
            case 179 -> var10000 = 232;
            case 180 -> var10000 = 97;
            case 181 -> var10000 = 63;
            case 182 -> var10000 = 243;
            case 183 -> var10000 = 155;
            case 184 -> var10000 = 78;
            case 185 -> var10000 = 187;
            case 186 -> var10000 = 112;
            case 187 -> var10000 = 73;
            case 188 -> var10000 = 218;
            case 189 -> var10000 = 18;
            case 190 -> var10000 = 27;
            case 191 -> var10000 = 169;
            case 192 -> var10000 = 8;
            case 193 -> var10000 = 29;
            case 194 -> var10000 = 24;
            case 195 -> var10000 = 201;
            case 196 -> var10000 = 195;
            case 197 -> var10000 = 183;
            case 198 -> var10000 = 104;
            case 199 -> var10000 = 70;
            case 200 -> var10000 = 54;
            case 201 -> var10000 = 124;
            case 202 -> var10000 = 103;
            case 203 -> var10000 = 236;
            case 204 -> var10000 = 28;
            case 205 -> var10000 = 61;
            case 206 -> var10000 = 80;
            case 207 -> var10000 = 210;
            case 208 -> var10000 = 246;
            case 209 -> var10000 = 10;
            case 210 -> var10000 = 105;
            case 211 -> var10000 = 237;
            case 212 -> var10000 = 122;
            case 213 -> var10000 = 121;
            case 214 -> var10000 = 168;
            case 215 -> var10000 = 192;
            case 216 -> var10000 = 116;
            case 217 -> var10000 = 233;
            case 218 -> var10000 = 66;
            case 219 -> var10000 = 217;
            case 220 -> var10000 = 79;
            case 221 -> var10000 = 193;
            case 222 -> var10000 = 254;
            case 223 -> var10000 = 129;
            case 224 -> var10000 = 161;
            case 225 -> var10000 = 31;
            case 226 -> var10000 = 134;
            case 227 -> var10000 = 172;
            case 228 -> var10000 = 9;
            case 229 -> var10000 = 223;
            case 230 -> var10000 = 238;
            case 231 -> var10000 = 149;
            case 232 -> var10000 = 152;
            case 233 -> var10000 = 170;
            case 234 -> var10000 = 220;
            case 235 -> var10000 = 252;
            case 236 -> var10000 = 135;
            case 237 -> var10000 = 59;
            case 238 -> var10000 = 199;
            case 239 -> var10000 = 38;
            case 240 -> var10000 = 26;
            case 241 -> var10000 = 154;
            case 242 -> var10000 = 160;
            case 243 -> var10000 = 125;
            case 244 -> var10000 = 205;
            case 245 -> var10000 = 45;
            case 246 -> var10000 = 211;
            case 247 -> var10000 = 203;
            case 248 -> var10000 = 176;
            case 249 -> var10000 = 139;
            case 250 -> var10000 = 57;
            case 251 -> var10000 = 123;
            case 252 -> var10000 = 244;
            case 253 -> var10000 = 65;
            case 254 -> var10000 = 251;
            default -> var10000 = 41;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }
}
