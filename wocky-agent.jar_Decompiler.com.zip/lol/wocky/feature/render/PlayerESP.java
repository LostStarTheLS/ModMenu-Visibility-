package lol.wocky.feature.render;

import java.util.ArrayList;
import java.util.List;
import lol.wocky.core.GlOverlay;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.render.Hud2D;

public class PlayerESP extends Module {
   private static final int PINK;
   private static final int OUTLINE;
   private static final int[] GLOW_OUT;
   private static final int[] GLOW_IN;
   private static final int TAG_BG;
   private static final int TAG_EDGE;
   private static final int TAG_TEXT = -1;
   private final BooleanProperty self = new BooleanProperty(a(2697, -21582), false);
   private final BooleanProperty glow = new BooleanProperty(a(2696, 24235), true);
   private final BooleanProperty nametags = new BooleanProperty(a(2699, -15430), true);
   private final float[] pt = new float[2];
   private final List<Target> targets = new ArrayList();
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;

   public boolean drawsNametags() {
      return (Boolean)this.nametags.getValue();
   }

   public PlayerESP() {
      super(a(2698, -9202), a(2701, -30259), ModuleCategory.RENDER);
      this.addProperties(new Property[]{this.self, this.glow, this.nametags});
   }

   public void onHudRender(Hud2D var1) {
      Object var2 = MinecraftBridge.getPlayer();
      Object var3 = MinecraftBridge.getCameraEntity();
      boolean var4 = MinecraftBridge.isFirstPerson();
      float var5 = var1.tickDelta();
      this.targets.clear();

      for(Object var7 : MinecraftBridge.getPlayers()) {
         if ((var7 != var3 || !var4) && (var7 != var2 || (Boolean)this.self.getValue()) && !MinecraftBridge.isEntityRemoved(var7) && !MinecraftBridge.isDead(var7)) {
            Target var8 = this.project(var1, var7, var5);
            if (var8 != null) {
               this.targets.add(var8);
            }
         }
      }

      int var10 = Math.max(1, Math.round((float)var1.guiScale() * 0.5F));

      for(Target var13 : this.targets) {
         this.drawBox(var1, var13, var10);
      }

      if ((Boolean)this.nametags.getValue() && MinecraftBridge.isHudOnlyScreen()) {
         boolean var12 = GlOverlay.active();

         for(Target var9 : this.targets) {
            if (var12) {
               this.queueTag(var1, var9, var10);
            } else {
               this.drawTag(var1, var9, var10);
            }
         }
      }

   }

   private Target project(Hud2D var1, Object var2, float var3) {
      double[] var4 = MinecraftBridge.getBoundingBox(var2);
      double[] var5 = MinecraftBridge.getLerpedPos(var2, var3);
      if (var4 != null && var5 != null) {
         double var6 = var5[0] - MinecraftBridge.getEntityX(var2);
         double var8 = var5[1] - MinecraftBridge.getEntityY(var2);
         double var10 = var5[2] - MinecraftBridge.getEntityZ(var2);
         float var12 = Float.MAX_VALUE;
         float var13 = Float.MAX_VALUE;
         float var14 = -Float.MAX_VALUE;
         float var15 = -Float.MAX_VALUE;

         for(int var16 = 0; var16 < a(17918, 5887824771960142290L); ++var16) {
            double var17 = ((var16 & 1) == 0 ? var4[0] : var4[3]) + var6;
            double var19 = ((var16 & 2) == 0 ? var4[1] : var4[4]) + var8;
            double var21 = ((var16 & 4) == 0 ? var4[2] : var4[5]) + var10;
            if (!var1.project(var17, var19, var21, this.pt)) {
               return null;
            }

            var12 = Math.min(var12, this.pt[0]);
            var13 = Math.min(var13, this.pt[1]);
            var14 = Math.max(var14, this.pt[0]);
            var15 = Math.max(var15, this.pt[1]);
         }

         if (!(var14 < 0.0F) && !(var15 < 0.0F) && !(var12 > (float)var1.width()) && !(var13 > (float)var1.height())) {
            return new Target(Math.round(var12), Math.round(var13), Math.round(var14), Math.round(var15), MinecraftBridge.getEntityName(var2));
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private void drawBox(Hud2D var1, Target var2, int var3) {
      int var4 = var2.x1();
      int var5 = var2.y1();
      int var6 = var2.x2();
      int var7 = var2.y2();
      if (var6 - var4 >= 4 * var3 && var7 - var5 >= 4 * var3) {
         if ((Boolean)this.glow.getValue()) {
            for(int var8 = 0; var8 < GLOW_OUT.length; ++var8) {
               int var9 = var3 * (2 + var8);
               var1.outline(var4 - var9, var5 - var9, var6 + var9, var7 + var9, var3, withAlpha(a(23843, 6108050126039081247L), GLOW_OUT[var8]));
            }

            for(int var10 = 0; var10 < GLOW_IN.length; ++var10) {
               int var11 = var3 * (2 + var10);
               var1.outline(var4 + var11, var5 + var11, var6 - var11, var7 - var11, var3, withAlpha(a(23843, 6108050126039081247L), GLOW_IN[var10]));
            }
         }

         var1.outline(var4 - var3, var5 - var3, var6 + var3, var7 + var3, var3, a(11854, 5486528252444349034L));
         var1.outline(var4 + var3, var5 + var3, var6 - var3, var7 - var3, var3, a(12019, 4405743908104606428L));
         var1.outline(var4, var5, var6, var7, var3, a(23843, 6108050126039081247L));
      }
   }

   private void queueTag(Hud2D var1, Target var2, int var3) {
      if (!var2.name().isEmpty()) {
         int var4 = ((Boolean)this.glow.getValue() ? a(19186, 5034525537448326867L) : 3) * var3;
         GlOverlay.tag((float)(var2.x1() + var2.x2()) / 2.0F, (float)(var2.y1() - var3 - var4), var2.name(), (float)var1.guiScale() / 2.0F);
      }
   }

   private void drawTag(Hud2D var1, Target var2, int var3) {
      String var4 = var2.name();
      if (!var4.isEmpty()) {
         int var5 = var1.guiScale();
         int var6 = var1.textWidth(var4);
         int var7 = var1.fontHeight() - var5;
         int var8 = 4 * var5;
         int var9 = 3 * var5;
         int var10 = var6 + var8 * 2;
         int var11 = var7 + var9 * 2;
         int var12 = (var2.x1() + var2.x2()) / 2;
         int var13 = ((Boolean)this.glow.getValue() ? a(29783, 8379875249532094577L) : 3) * var3;
         int var14 = var12 - var10 / 2;
         int var15 = var2.y1() - var3 - var13;
         int var16 = var15 - var11;
         int var17 = var14 + var10;
         int var18 = Math.min(var11 / 2, 4 * var5);
         var1.roundedRect(var14, var16, var17, var15, var18, a(28746, 5616801058129661024L));
         var1.roundedOutline(var14, var16, var17, var15, var18, a(5705, 6305674309892024942L));
         var1.fill(var14 + var18, var15 - var3, var17 - var18, var15, a(20396, 5948942508770227081L));
         var1.text(var4, var14 + var8, var16 + var9, -1, false);
      }
   }

   private static int withAlpha(int var0, int var1) {
      return var1 << a(7493, 5382545860846690685L) | var0 & a(24863, 8929263828098276657L);
   }

   static {
      String[] var13 = new String[5];
      int var11 = 0;
      String var10 = "è\u00852r\u0004¶\flz\b¤Æ\u0004\u009d\u000f¤\u001a$";
      int var12 = "è\u00852r\u0004¶\flz\b¤Æ\u0004\u009d\u000f¤\u001a$".length();
      char var9 = 4;
      int var17 = -1;

      label73:
      while(true) {
         ++var17;
         String var10000 = var10.substring(var17, var17 + var9);
         int var10001 = -1;

         while(true) {
            char[] var33;
            label68: {
               char[] var21 = var10000.toCharArray();
               int var10003 = var21.length;
               int var14 = 0;
               var33 = var21;
               int var24 = var10003;
               char[] var43;
               int var10004;
               if (var10003 <= 1) {
                  var43 = var21;
                  var10004 = var14;
               } else {
                  var33 = var21;
                  var24 = var10003;
                  if (var10003 <= var14) {
                     break label68;
                  }

                  var43 = var21;
                  var10004 = var14;
               }

               while(true) {
                  char var10005 = var43[var10004];
                  byte var10006;
                  switch (var14 % 7) {
                     case 0 -> var10006 = 73;
                     case 1 -> var10006 = 11;
                     case 2 -> var10006 = 83;
                     case 3 -> var10006 = 12;
                     case 4 -> var10006 = 81;
                     case 5 -> var10006 = 62;
                     default -> var10006 = 76;
                  }

                  var43[var10004] = (char)(var10005 ^ var10006);
                  ++var14;
                  if (var24 == 0) {
                     var10004 = var24;
                     var43 = var33;
                  } else {
                     if (var24 <= var14) {
                        break;
                     }

                     var43 = var33;
                     var10004 = var14;
                  }
               }
            }

            String var50 = (new String(var33)).intern();
            switch (var10001) {
               case 0:
                  var13[var11++] = var50;
                  if ((var17 += var9) >= var12) {
                     a = var13;
                     b = new String[5];
                     long var0 = 8862829849642572161L;
                     long[] var6 = new long[21];
                     int var3 = 0;
                     String var4 = "\n**Ó\u001cÁ`[ê\u0015\u009aàä&\u008a\u0007åòG8\u000fÙ»O¥0åÀEF\u000b]]\u0016df.'~\u0015\u001a-ñcú\u0087+ñ_\u0001÷FIwÕá@\f=³r;CÄ\u0014\n\u0092¹Ñ»\u008bëL¾\u0097Vã8\u0084ØÞ\u009c\u00191jÞQö*\u0000\fhf8Ì\u0010ØìÇ3säí±Ü\u0011¹m\u001c\u0091ïT3 ¦\u0010\u0090(@ùz\u0010,@S¥?k\u00ad\u0096\u0005\u0084Ó\u0096\u0016N8Ê9\u001b\u0016¿\u0096öÎÒ£SÌA\u001f\u0097";
                     int var5 = "\n**Ó\u001cÁ`[ê\u0015\u009aàä&\u008a\u0007åòG8\u000fÙ»O¥0åÀEF\u000b]]\u0016df.'~\u0015\u001a-ñcú\u0087+ñ_\u0001÷FIwÕá@\f=³r;CÄ\u0014\n\u0092¹Ñ»\u008bëL¾\u0097Vã8\u0084ØÞ\u009c\u00191jÞQö*\u0000\fhf8Ì\u0010ØìÇ3säí±Ü\u0011¹m\u001c\u0091ïT3 ¦\u0010\u0090(@ùz\u0010,@S¥?k\u00ad\u0096\u0005\u0084Ó\u0096\u0016N8Ê9\u001b\u0016¿\u0096öÎÒ£SÌA\u001f\u0097".length();
                     int var2 = 0;

                     label44:
                     while(true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var19 = var6;
                        var10001 = var3++;
                        long var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                        byte var51 = -1;

                        while(true) {
                           long var54 = var38 ^ var0;
                           switch (var51) {
                              case 0:
                                 var19[var10001] = var54;
                                 if (var2 >= var5) {
                                    c = var6;
                                    d = new Integer[21];
                                    PINK = a(2954, 5239069153153300392L);
                                    TAG_EDGE = a(9283, 990052004517910635L);
                                    OUTLINE = a(26222, 9021301246519663173L);
                                    TAG_BG = a(6857, 3139929741420242666L);
                                    GLOW_OUT = new int[]{a(664, 1207477025394572967L), a(12191, 2960881857203934130L), a(14900, 3917398188560844298L), a(18460, 5071629006940959804L)};
                                    GLOW_IN = new int[]{a(3689, 3980042390389633600L), a(13144, 2130201079337652069L)};
                                    return;
                                 }
                                 break;
                              default:
                                 var19[var10001] = var54;
                                 if (var2 < var5) {
                                    continue label44;
                                 }

                                 var4 = ",Ý\u008cÇyº'~M>ô÷;¨¸ä";
                                 var5 = ",Ý\u008cÇyº'~M>ô÷;¨¸ä".length();
                                 var2 = 0;
                           }

                           var10001 = var2;
                           var2 += 8;
                           var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                           var19 = var6;
                           var10001 = var3++;
                           var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                           var51 = 0;
                        }
                     }
                  }

                  var9 = var10.charAt(var17);
                  break;
               default:
                  var13[var11++] = var50;
                  if ((var17 += var9) < var12) {
                     var9 = var10.charAt(var17);
                     continue label73;
                  }

                  var10 = "¹\tvÔÝ\u0001QÁ\u0015%\u0012¥\fö9U!p\b?:;üèmÕþTbpä¨ªÇ¥ý «ÐU³\u008fRÖ\u0004p¸";
                  var12 = "¹\tvÔÝ\u0001QÁ\u0015%\u0012¥\fö9U!p\b?:;üèmÕþTbpä¨ªÇ¥ý «ÐU³\u008fRÖ\u0004p¸".length();
                  var9 = '\t';
                  var17 = -1;
            }

            ++var17;
            var10000 = var10.substring(var17, var17 + var9);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 2697) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 91;
            case 1 -> var10000 = 29;
            case 2 -> var10000 = 195;
            case 3 -> var10000 = 64;
            case 4 -> var10000 = 57;
            case 5 -> var10000 = 236;
            case 6 -> var10000 = 201;
            case 7 -> var10000 = 78;
            case 8 -> var10000 = 59;
            case 9 -> var10000 = 65;
            case 10 -> var10000 = 119;
            case 11 -> var10000 = 244;
            case 12 -> var10000 = 113;
            case 13 -> var10000 = 21;
            case 14 -> var10000 = 135;
            case 15 -> var10000 = 174;
            case 16 -> var10000 = 217;
            case 17 -> var10000 = 28;
            case 18 -> var10000 = 231;
            case 19 -> var10000 = 67;
            case 20 -> var10000 = 99;
            case 21 -> var10000 = 159;
            case 22 -> var10000 = 212;
            case 23 -> var10000 = 27;
            case 24 -> var10000 = 117;
            case 25 -> var10000 = 49;
            case 26 -> var10000 = 9;
            case 27 -> var10000 = 133;
            case 28 -> var10000 = 142;
            case 29 -> var10000 = 138;
            case 30 -> var10000 = 167;
            case 31 -> var10000 = 2;
            case 32 -> var10000 = 228;
            case 33 -> var10000 = 177;
            case 34 -> var10000 = 164;
            case 35 -> var10000 = 170;
            case 36 -> var10000 = 20;
            case 37 -> var10000 = 237;
            case 38 -> var10000 = 154;
            case 39 -> var10000 = 211;
            case 40 -> var10000 = 253;
            case 41 -> var10000 = 230;
            case 42 -> var10000 = 161;
            case 43 -> var10000 = 48;
            case 44 -> var10000 = 235;
            case 45 -> var10000 = 126;
            case 46 -> var10000 = 140;
            case 47 -> var10000 = 186;
            case 48 -> var10000 = 147;
            case 49 -> var10000 = 234;
            case 50 -> var10000 = 105;
            case 51 -> var10000 = 239;
            case 52 -> var10000 = 248;
            case 53 -> var10000 = 218;
            case 54 -> var10000 = 22;
            case 55 -> var10000 = 36;
            case 56 -> var10000 = 39;
            case 57 -> var10000 = 111;
            case 58 -> var10000 = 106;
            case 59 -> var10000 = 93;
            case 60 -> var10000 = 249;
            case 61 -> var10000 = 224;
            case 62 -> var10000 = 157;
            case 63 -> var10000 = 58;
            case 64 -> var10000 = 112;
            case 65 -> var10000 = 14;
            case 66 -> var10000 = 102;
            case 67 -> var10000 = 114;
            case 68 -> var10000 = 202;
            case 69 -> var10000 = 11;
            case 70 -> var10000 = 66;
            case 71 -> var10000 = 87;
            case 72 -> var10000 = 79;
            case 73 -> var10000 = 153;
            case 74 -> var10000 = 149;
            case 75 -> var10000 = 189;
            case 76 -> var10000 = 245;
            case 77 -> var10000 = 205;
            case 78 -> var10000 = 182;
            case 79 -> var10000 = 68;
            case 80 -> var10000 = 247;
            case 81 -> var10000 = 54;
            case 82 -> var10000 = 225;
            case 83 -> var10000 = 180;
            case 84 -> var10000 = 73;
            case 85 -> var10000 = 241;
            case 86 -> var10000 = 32;
            case 87 -> var10000 = 120;
            case 88 -> var10000 = 41;
            case 89 -> var10000 = 165;
            case 90 -> var10000 = 191;
            case 91 -> var10000 = 194;
            case 92 -> var10000 = 232;
            case 93 -> var10000 = 101;
            case 94 -> var10000 = 209;
            case 95 -> var10000 = 46;
            case 96 -> var10000 = 163;
            case 97 -> var10000 = 33;
            case 98 -> var10000 = 18;
            case 99 -> var10000 = 8;
            case 100 -> var10000 = 83;
            case 101 -> var10000 = 146;
            case 102 -> var10000 = 40;
            case 103 -> var10000 = 1;
            case 104 -> var10000 = 168;
            case 105 -> var10000 = 115;
            case 106 -> var10000 = 10;
            case 107 -> var10000 = 181;
            case 108 -> var10000 = 60;
            case 109 -> var10000 = 30;
            case 110 -> var10000 = 118;
            case 111 -> var10000 = 169;
            case 112 -> var10000 = 223;
            case 113 -> var10000 = 210;
            case 114 -> var10000 = 43;
            case 115 -> var10000 = 172;
            case 116 -> var10000 = 246;
            case 117 -> var10000 = 158;
            case 118 -> var10000 = 233;
            case 119 -> var10000 = 82;
            case 120 -> var10000 = 155;
            case 121 -> var10000 = 184;
            case 122 -> var10000 = 6;
            case 123 -> var10000 = 125;
            case 124 -> var10000 = 26;
            case 125 -> var10000 = 13;
            case 126 -> var10000 = 229;
            case 127 -> var10000 = 185;
            case 128 -> var10000 = 31;
            case 129 -> var10000 = 156;
            case 130 -> var10000 = 150;
            case 131 -> var10000 = 104;
            case 132 -> var10000 = 206;
            case 133 -> var10000 = 134;
            case 134 -> var10000 = 124;
            case 135 -> var10000 = 97;
            case 136 -> var10000 = 145;
            case 137 -> var10000 = 200;
            case 138 -> var10000 = 221;
            case 139 -> var10000 = 152;
            case 140 -> var10000 = 50;
            case 141 -> var10000 = 75;
            case 142 -> var10000 = 130;
            case 143 -> var10000 = 226;
            case 144 -> var10000 = 86;
            case 145 -> var10000 = 190;
            case 146 -> var10000 = 215;
            case 147 -> var10000 = 72;
            case 148 -> var10000 = 252;
            case 149 -> var10000 = 71;
            case 150 -> var10000 = 193;
            case 151 -> var10000 = 240;
            case 152 -> var10000 = 128;
            case 153 -> var10000 = 5;
            case 154 -> var10000 = 52;
            case 155 -> var10000 = 160;
            case 156 -> var10000 = 107;
            case 157 -> var10000 = 162;
            case 158 -> var10000 = 121;
            case 159 -> var10000 = 208;
            case 160 -> var10000 = 88;
            case 161 -> var10000 = 192;
            case 162 -> var10000 = 63;
            case 163 -> var10000 = 213;
            case 164 -> var10000 = 25;
            case 165 -> var10000 = 254;
            case 166 -> var10000 = 17;
            case 167 -> var10000 = 207;
            case 168 -> var10000 = 255;
            case 169 -> var10000 = 187;
            case 170 -> var10000 = 74;
            case 171 -> var10000 = 3;
            case 172 -> var10000 = 132;
            case 173 -> var10000 = 251;
            case 174 -> var10000 = 214;
            case 175 -> var10000 = 196;
            case 176 -> var10000 = 45;
            case 177 -> var10000 = 89;
            case 178 -> var10000 = 227;
            case 179 -> var10000 = 12;
            case 180 -> var10000 = 37;
            case 181 -> var10000 = 62;
            case 182 -> var10000 = 122;
            case 183 -> var10000 = 238;
            case 184 -> var10000 = 24;
            case 185 -> var10000 = 70;
            case 186 -> var10000 = 139;
            case 187 -> var10000 = 4;
            case 188 -> var10000 = 92;
            case 189 -> var10000 = 141;
            case 190 -> var10000 = 95;
            case 191 -> var10000 = 15;
            case 192 -> var10000 = 90;
            case 193 -> var10000 = 116;
            case 194 -> var10000 = 103;
            case 195 -> var10000 = 144;
            case 196 -> var10000 = 219;
            case 197 -> var10000 = 137;
            case 198 -> var10000 = 96;
            case 199 -> var10000 = 19;
            case 200 -> var10000 = 166;
            case 201 -> var10000 = 123;
            case 202 -> var10000 = 100;
            case 203 -> var10000 = 136;
            case 204 -> var10000 = 203;
            case 205 -> var10000 = 51;
            case 206 -> var10000 = 69;
            case 207 -> var10000 = 85;
            case 208 -> var10000 = 176;
            case 209 -> var10000 = 216;
            case 210 -> var10000 = 80;
            case 211 -> var10000 = 34;
            case 212 -> var10000 = 56;
            case 213 -> var10000 = 188;
            case 214 -> var10000 = 199;
            case 215 -> var10000 = 108;
            case 216 -> var10000 = 84;
            case 217 -> var10000 = 44;
            case 218 -> var10000 = 7;
            case 219 -> var10000 = 148;
            case 220 -> var10000 = 16;
            case 221 -> var10000 = 173;
            case 222 -> var10000 = 53;
            case 223 -> var10000 = 175;
            case 224 -> var10000 = 38;
            case 225 -> var10000 = 47;
            case 226 -> var10000 = 109;
            case 227 -> var10000 = 98;
            case 228 -> var10000 = 127;
            case 229 -> var10000 = 35;
            case 230 -> var10000 = 81;
            case 231 -> var10000 = 183;
            case 232 -> var10000 = 76;
            case 233 -> var10000 = 222;
            case 234 -> var10000 = 94;
            case 235 -> var10000 = 55;
            case 236 -> var10000 = 131;
            case 237 -> var10000 = 23;
            case 238 -> var10000 = 171;
            case 239 -> var10000 = 61;
            case 240 -> var10000 = 110;
            case 241 -> var10000 = 42;
            case 242 -> var10000 = 197;
            case 243 -> var10000 = 204;
            case 244 -> var10000 = 0;
            case 245 -> var10000 = 77;
            case 246 -> var10000 = 220;
            case 247 -> var10000 = 151;
            case 248 -> var10000 = 198;
            case 249 -> var10000 = 178;
            case 250 -> var10000 = 129;
            case 251 -> var10000 = 179;
            case 252 -> var10000 = 143;
            case 253 -> var10000 = 250;
            case 254 -> var10000 = 242;
            default -> var10000 = 243;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15404;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }

   private static record Target(int x1, int y1, int x2, int y2, String name) {
      private Target(int var1, int var2, int var3, int var4, String var5) {
         this.x1 = var1;
         this.y1 = var2;
         this.x2 = var3;
         this.y2 = var4;
         this.name = var5;
      }
   }
}
