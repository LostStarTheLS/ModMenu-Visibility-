package lol.wocky.feature.render;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import lol.wocky.core.GlOverlay;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BlockListProperty;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.EnumProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.render.Hud2D;
import lol.wocky.core.render.WorldShapes;

public class BlockESP extends Module {
   private static final long BUDGET_NS;
   private static final int MAX_PER_CHUNK;
   private static final int MAX_DRAWN;
   private static final int PINK;
   private final BlockListProperty blocks = new BlockListProperty(a(19467, -20242), new String[]{a(19487, -12433), a(19459, 18909), a(19465, -17323)});
   private final NumberProperty range = new NumberProperty(a(19481, 6581), a(28006, 8803170669054341104L), a(25033, 1007555490779898705L), a(23606, 3064908558324932266L), a(18133, 3919401538373715063L));
   private final EnumProperty<Color> color;
   private final BooleanProperty fill;
   private final BooleanProperty tracers;
   private final Map<Long, long[]> found;
   private final Map<Long, int[]> foundColors;
   private final List<long[]> queue;
   private int queueIndex;
   private Object[] chunkSections;
   private long chunkKey;
   private int chunkX;
   private int chunkZ;
   private int sectionIndex;
   private int bottomSection;
   private final List<Long> chunkHits;
   private final List<Integer> chunkHitColors;
   private Set<String> targets;
   private int seenVersion;
   private Object seenWorld;
   private Color seenColor;
   private boolean dirty;
   private int rebuildClock;
   private final Map<Object, Boolean> matches;
   private final Map<Object, Integer> stateColors;
   private final Predicate<Object> matcher;
   private volatile long[] drawPos;
   private volatile int[] drawColor;
   private final WorldShapes shapes;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;
   private static final long[] e;
   private static final Long[] f;

   public BlockESP() {
      super(a(19473, 13525), a(19468, 17673), ModuleCategory.RENDER);
      this.color = new EnumProperty<Color>(a(19486, -22973), BlockESP.Color.AUTO);
      this.fill = new BooleanProperty(a(19456, -7134), true);
      this.tracers = new BooleanProperty(a(19475, -3798), false);
      this.found = new HashMap();
      this.foundColors = new HashMap();
      this.queue = new ArrayList();
      this.chunkHits = new ArrayList();
      this.chunkHitColors = new ArrayList();
      this.targets = Set.of();
      this.seenVersion = -1;
      this.matches = new IdentityHashMap();
      this.stateColors = new IdentityHashMap();
      this.matcher = this::matches;
      this.drawPos = new long[0];
      this.drawColor = new int[0];
      this.shapes = new WorldShapes();
      this.addProperties(new Property[]{this.blocks, this.range, this.color, this.fill, this.tracers});
   }

   public void onEnable() {
      this.resetScan();
   }

   public void onDisable() {
      this.resetScan();
      this.drawPos = new long[0];
      this.drawColor = new int[0];
   }

   public void onTick() {
      Object var1 = MinecraftBridge.getWorld();
      if (this.blocks.version() != this.seenVersion || var1 != this.seenWorld || this.color.getValue() != this.seenColor) {
         this.seenVersion = this.blocks.version();
         this.seenWorld = var1;
         this.seenColor = (Color)this.color.getValue();
         this.targets = new HashSet((Collection)this.blocks.getValue());
         this.resetScan();
      }

      if (this.targets.isEmpty()) {
         this.drawPos = new long[0];
      } else {
         long var2 = System.nanoTime() + b(14111, 5709124601251581714L);

         while(System.nanoTime() < var2 && (this.chunkSections != null || this.nextChunk())) {
            this.scanSection();
         }

         if (this.dirty || ++this.rebuildClock >= a(21059, 6618627330394591427L)) {
            this.rebuildDrawList();
         }

      }
   }

   private void resetScan() {
      this.found.clear();
      this.foundColors.clear();
      this.queue.clear();
      this.queueIndex = 0;
      this.chunkSections = null;
      this.matches.clear();
      this.stateColors.clear();
      this.dirty = true;
   }

   private boolean nextChunk() {
      Object var1 = MinecraftBridge.getPlayer();
      int var2 = (int)Math.floor(MinecraftBridge.getEntityX(var1)) >> 4;
      int var3 = (int)Math.floor(MinecraftBridge.getEntityZ(var1)) >> 4;
      if (this.queueIndex >= this.queue.size()) {
         this.startPass(var2, var3);
      }

      long var6;
      for(; this.queueIndex < this.queue.size(); this.foundColors.remove(var6)) {
         long[] var4 = (long[])this.queue.get(this.queueIndex++);
         Object[] var5 = MinecraftBridge.getChunkSections((int)var4[0], (int)var4[1]);
         var6 = key((int)var4[0], (int)var4[1]);
         if (var5 != null) {
            this.chunkSections = var5;
            this.chunkKey = var6;
            this.chunkX = (int)var4[0];
            this.chunkZ = (int)var4[1];
            this.sectionIndex = 0;
            this.bottomSection = MinecraftBridge.getBottomSectionCoord();
            this.chunkHits.clear();
            this.chunkHitColors.clear();
            return true;
         }

         if (this.found.remove(var6) != null) {
            this.dirty = true;
         }
      }

      return false;
   }

   private void startPass(int var1, int var2) {
      this.queue.clear();
      this.queueIndex = 0;
      int var3 = (int)Math.ceil(this.range.doubleValue() / (double)16.0F) + 1;

      for(int var4 = -var3; var4 <= var3; ++var4) {
         for(int var5 = -var3; var5 <= var3; ++var5) {
            if (var4 * var4 + var5 * var5 <= var3 * var3) {
               this.queue.add(new long[]{(long)(var1 + var4), (long)(var2 + var5), (long)(var4 * var4 + var5 * var5)});
            }
         }
      }

      this.queue.sort((var0, var1x) -> Long.compare(var0[2], var1x[2]));
      HashSet var7 = new HashSet();

      for(long[] var6 : this.queue) {
         var7.add(key((int)var6[0], (int)var6[1]));
      }

      if (this.found.keySet().retainAll(var7)) {
         this.dirty = true;
      }

      this.foundColors.keySet().retainAll(var7);
   }

   private void scanSection() {
      if (this.sectionIndex >= this.chunkSections.length) {
         this.finishChunk();
      } else {
         Object var1 = this.chunkSections[this.sectionIndex];
         int var2 = (this.bottomSection + this.sectionIndex) * a(19014, 9070833931501930698L);
         ++this.sectionIndex;
         double var3 = MinecraftBridge.getEntityY(MinecraftBridge.getPlayer());
         if (!(Math.abs((double)(var2 + a(13786, 116010498376693598L)) - var3) > this.range.doubleValue() + (double)8.0F)) {
            if (!MinecraftBridge.isSectionEmpty(var1) && MinecraftBridge.sectionHasAny(var1, this.matcher)) {
               int var5 = this.chunkX * a(19014, 9070833931501930698L);
               int var6 = this.chunkZ * a(19014, 9070833931501930698L);

               for(int var7 = 0; var7 < a(19014, 9070833931501930698L); ++var7) {
                  for(int var8 = 0; var8 < a(19014, 9070833931501930698L); ++var8) {
                     for(int var9 = 0; var9 < a(19014, 9070833931501930698L); ++var9) {
                        Object var10 = MinecraftBridge.sectionBlockState(var1, var9, var7, var8);
                        if (this.matches(var10)) {
                           if (this.chunkHits.size() >= a(29062, 6771288241663980297L)) {
                              return;
                           }

                           this.chunkHits.add(pack(var5 + var9, var2 + var7, var6 + var8));
                           this.chunkHitColors.add(this.colorOf(var10));
                        }
                     }
                  }
               }

            }
         }
      }
   }

   private void finishChunk() {
      this.chunkSections = null;
      if (this.chunkHits.isEmpty()) {
         if (this.found.remove(this.chunkKey) != null) {
            this.dirty = true;
         }

         this.foundColors.remove(this.chunkKey);
      } else {
         long[] var1 = new long[this.chunkHits.size()];
         int[] var2 = new int[var1.length];

         for(int var3 = 0; var3 < var1.length; ++var3) {
            var1[var3] = (Long)this.chunkHits.get(var3);
            var2[var3] = (Integer)this.chunkHitColors.get(var3);
         }

         long[] var4 = (long[])this.found.put(this.chunkKey, var1);
         this.foundColors.put(this.chunkKey, var2);
         if (var4 == null || !Arrays.equals(var4, var1)) {
            this.dirty = true;
         }

      }
   }

   private boolean matches(Object var1) {
      Boolean var2 = (Boolean)this.matches.get(var1);
      if (var2 == null) {
         String var3 = var1 == null ? "" : MinecraftBridge.stateBlockId(var1);
         var2 = !var3.isEmpty() && (this.targets.contains(var3) || this.targets.contains(floorVariant(var3)));
         this.matches.put(var1, var2);
      }

      return var2;
   }

   public static String floorVariant(String var0) {
      return var0.startsWith(a(19483, 29678)) ? var0.substring(5) : var0.replace(a(19482, 14957), "_");
   }

   private void rebuildDrawList() {
      this.dirty = false;
      this.rebuildClock = 0;
      Object var1 = MinecraftBridge.getPlayer();
      double var2 = MinecraftBridge.getEntityX(var1);
      double var4 = MinecraftBridge.getEntityY(var1);
      double var6 = MinecraftBridge.getEntityZ(var1);
      double var8 = this.range.doubleValue() * this.range.doubleValue();
      ArrayList var10 = new ArrayList();

      for(Map.Entry var12 : this.found.entrySet()) {
         int[] var13 = (int[])this.foundColors.get(var12.getKey());
         long[] var14 = (long[])var12.getValue();

         for(int var15 = 0; var15 < var14.length; ++var15) {
            double var16 = (double)unpackX(var14[var15]) + (double)0.5F - var2;
            double var18 = (double)unpackY(var14[var15]) + (double)0.5F - var4;
            double var20 = (double)unpackZ(var14[var15]) + (double)0.5F - var6;
            double var22 = var16 * var16 + var18 * var18 + var20 * var20;
            if (var22 <= var8) {
               var10.add(new long[]{var14[var15], (long)var13[var15], (long)var22});
            }
         }
      }

      var10.sort((var0, var1x) -> Long.compare(var0[2], var1x[2]));
      int var24 = Math.min(var10.size(), a(21086, 3632821558954135793L));
      long[] var25 = new long[var24];
      int[] var26 = new int[var24];

      for(int var27 = 0; var27 < var24; ++var27) {
         var25[var27] = ((long[])var10.get(var27))[0];
         var26[var27] = (int)((long[])var10.get(var27))[1];
      }

      this.drawColor = var26;
      this.drawPos = var25;
   }

   private int colorOf(Object var1) {
      if (this.color.getValue() == BlockESP.Color.PINK) {
         return a(26785, 7166290311240198669L);
      } else {
         Integer var2 = (Integer)this.stateColors.get(var1);
         if (var2 == null) {
            var2 = autoColor(MinecraftBridge.stateBlockId(var1), var1);
            this.stateColors.put(var1, var2);
         }

         return var2;
      }
   }

   private static int autoColor(String var0, Object var1) {
      if (var0.contains(a(19457, 5986))) {
         return a(7956, 6425723420213403023L);
      } else if (var0.contains(a(19458, 1316))) {
         return a(24657, 4836419839979954928L);
      } else if (!var0.contains(a(19466, -19677)) && !var0.contains(a(19470, -12951))) {
         if (var0.contains(a(19461, 1334))) {
            return a(19070, 3557836725068990688L);
         } else if (var0.contains(a(19480, 29134))) {
            return a(4010, 7507607957228834055L);
         } else if (var0.contains(a(19478, -13256))) {
            return a(20238, 341833355188276634L);
         } else if (var0.contains(a(19485, -22929))) {
            return a(23947, 9179764625531248397L);
         } else if (var0.contains(a(19476, -4758))) {
            return a(235, 7692602536202027628L);
         } else if (var0.contains(a(19474, -17783))) {
            return a(26771, 8530848042424576568L);
         } else if (var0.contains(a(19484, 21327))) {
            return a(1511, 7497115442793301870L);
         } else if (var0.equals(a(19471, 4880))) {
            return a(5857, 6193414948178285643L);
         } else if (!var0.equals(a(19469, 4320)) && !var0.equals(a(19479, 420))) {
            if (var0.equals(a(19472, 21308))) {
               return a(30376, 6693904658939720715L);
            } else if (!var0.contains(a(19464, 22474)) && !var0.equals(a(19477, 19073))) {
               int var2 = MinecraftBridge.stateMapColor(var1);
               return var2 != 0 ? var2 : a(30540, 9203504307735573974L);
            } else {
               return a(30675, 8941580007199454532L);
            }
         } else {
            return a(23376, 1676790116667693504L);
         }
      } else {
         return a(15796, 8916407840283131689L);
      }
   }

   public void onHudRender(Hud2D var1) {
      if (MinecraftBridge.isHudOnlyScreen() && GlOverlay.active()) {
         long[] var2 = this.drawPos;
         int[] var3 = this.drawColor;
         if (var2.length != 0 && var3.length == var2.length) {
            boolean var4 = (Boolean)this.fill.getValue();
            boolean var5 = (Boolean)this.tracers.getValue();
            this.shapes.begin(var1);

            for(int var6 = 0; var6 < var2.length; ++var6) {
               int var7 = unpackX(var2[var6]);
               int var8 = unpackY(var2[var6]);
               int var9 = unpackZ(var2[var6]);
               int var10 = var3[var6] & a(22630, 4629999533222304500L);
               this.shapes.box((double)var7, (double)var8, (double)var9, (double)(var7 + 1), (double)(var8 + 1), (double)(var9 + 1), a(28568, 7546654793534745910L) | var10, var4 ? a(326, 2217482560692372462L) | var10 : 0);
               if (var5) {
                  this.shapes.tracer((double)var7 + (double)0.5F, (double)var8 + (double)0.5F, (double)var9 + (double)0.5F, a(26849, 6995559219468905058L) | var10, a(14387, 3830108902810581694L) | var10);
               }
            }

            if (!this.shapes.isEmpty()) {
               this.shapes.submit(1.25F * (float)var1.guiScale() / 2.0F);
            }

         }
      }
   }

   private static long key(int var0, int var1) {
      return (long)var0 << a(1775, 4092527659205968999L) | (long)var1 & b(25759, 4161891250978626707L);
   }

   private static long pack(int var0, int var1, int var2) {
      return (long)(var0 & a(17815, 1365594866869470990L)) << a(20155, 6723399259418496046L) | (long)(var2 & a(32361, 7564887470616231143L)) << a(21425, 8333792128453415214L) | (long)(var1 & a(19138, 302454166209366097L));
   }

   private static int unpackX(long var0) {
      return (int)(var0 >> a(12759, 8972359805095375702L));
   }

   private static int unpackY(long var0) {
      return (int)(var0 << a(10752, 8034226216918313129L) >> a(2998, 3544512646688655667L));
   }

   private static int unpackZ(long var0) {
      return (int)(var0 << a(2215, 8710379472108440108L) >> a(12759, 8972359805095375702L));
   }

   static {
      String[] var21 = new String[29];
      int var19 = 0;
      String var18 = "7Äã\u0019\u000f\u00042f\u001e5\u0005îQ[ `\u0006\u0014M$÷\u0010\u001b\bTV¡Û\u001dR\u0089Ì\u0006ñÝs¹â*\u000boî\u0017_u\u001eö^Ü~×\u0005|\u001f»¥Q\bí\u0088«8)\u0016Î\u001e\u000bQOô\u0084±]×\u0016\u0015§´\u0007k\u009e¡'©Â1\u0004(ù\u0018z\u0006\u0082â\u007fÈ\u0003\u0012\u0005ñ/Üj#\u0005üh!\u0087>\u0006¨\u001c\u0019Ú\u008d\f\u000e_å¶Ý\tÊ\"Ä_:ÊIEØ\u0005·ãïÁõ\u0006\u0099Ù%\u0012øe\u000e®\u001d\u0088ÂÎ)Ú¸@µ)¸9æ\r%ßD\r\u0015è\u008e¸(m\u008dä;&w>»@%_\u009c¦é±Lý\u009ea¤N\u0094\u008bæb#¯\bú\u008c\u0083\u0086F»\u0004á\u0098\"Z¿ßS\u001a\u0007¸\u0094\u00180\u0095¡Ý\t\u0013¨Æ\u001fò¯@Ü¬\u0007|\u0096uP9ÿ\u007f\u0004ï*lÆ\u0015\u0098!í6²\u008f\u0094\u0005?vá¦îC\u009eCF?úz\u0006";
      int var20 = "7Äã\u0019\u000f\u00042f\u001e5\u0005îQ[ `\u0006\u0014M$÷\u0010\u001b\bTV¡Û\u001dR\u0089Ì\u0006ñÝs¹â*\u000boî\u0017_u\u001eö^Ü~×\u0005|\u001f»¥Q\bí\u0088«8)\u0016Î\u001e\u000bQOô\u0084±]×\u0016\u0015§´\u0007k\u009e¡'©Â1\u0004(ù\u0018z\u0006\u0082â\u007fÈ\u0003\u0012\u0005ñ/Üj#\u0005üh!\u0087>\u0006¨\u001c\u0019Ú\u008d\f\u000e_å¶Ý\tÊ\"Ä_:ÊIEØ\u0005·ãïÁõ\u0006\u0099Ù%\u0012øe\u000e®\u001d\u0088ÂÎ)Ú¸@µ)¸9æ\r%ßD\r\u0015è\u008e¸(m\u008dä;&w>»@%_\u009c¦é±Lý\u009ea¤N\u0094\u008bæb#¯\bú\u008c\u0083\u0086F»\u0004á\u0098\"Z¿ßS\u001a\u0007¸\u0094\u00180\u0095¡Ý\t\u0013¨Æ\u001fò¯@Ü¬\u0007|\u0096uP9ÿ\u007f\u0004ï*lÆ\u0015\u0098!í6²\u008f\u0094\u0005?vá¦îC\u009eCF?úz\u0006".length();
      char var17 = 5;
      int var25 = -1;

      label82:
      while(true) {
         ++var25;
         String var10000 = var18.substring(var25, var25 + var17);
         int var10001 = -1;

         while(true) {
            char[] var43;
            label77: {
               char[] var29 = var10000.toCharArray();
               int var10003 = var29.length;
               int var22 = 0;
               var43 = var29;
               int var32 = var10003;
               char[] var53;
               int var10004;
               if (var10003 <= 1) {
                  var53 = var29;
                  var10004 = var22;
               } else {
                  var43 = var29;
                  var32 = var10003;
                  if (var10003 <= var22) {
                     break label77;
                  }

                  var53 = var29;
                  var10004 = var22;
               }

               while(true) {
                  char var10005 = var53[var10004];
                  byte var10006;
                  switch (var22 % 7) {
                     case 0 -> var10006 = 35;
                     case 1 -> var10006 = 15;
                     case 2 -> var10006 = 23;
                     case 3 -> var10006 = 74;
                     case 4 -> var10006 = 87;
                     case 5 -> var10006 = 18;
                     default -> var10006 = 84;
                  }

                  var53[var10004] = (char)(var10005 ^ var10006);
                  ++var22;
                  if (var32 == 0) {
                     var10004 = var32;
                     var53 = var43;
                  } else {
                     if (var32 <= var22) {
                        break;
                     }

                     var53 = var43;
                     var10004 = var22;
                  }
               }
            }

            String var60 = (new String(var43)).intern();
            switch (var10001) {
               case 0:
                  var21[var19++] = var60;
                  if ((var25 += var17) >= var20) {
                     a = var21;
                     b = new String[29];
                     long var8 = 2554166472745687731L;
                     long[] var14 = new long[43];
                     int var11 = 0;
                     String var12 = "y\u001dÒ~,ØÐ\u0085YD<Ìëæ&nF\u001aXDÎ\u001f¸\u0001« \u009föÉVÞôwö\u009e\u0090u\u00119º\u008b?!m)%Ù«5X\u000bÒ\u0002-à\r\t\u009fæ\u0016f\u0083\u0092i´\u0090$\u0005\b\u009f0Ñ²ðåeí\u0094N·Ðõ=£Z\u008béÃ\u0013n·\u0019©ä\u008az\u0090Å\u0014v9\u0095:?6kÓ®\u0083»¾\u0085£]u\u0096.ùÓ´\u001b\u0099Ò\u009fØÍmåá\u0081\u009bh\u0007Èªå#%Í±\u000e\u008fAµ$Ãì·\b\u001dâB×U-®¶V9ò\u0010z³·\u0081Q\u008b\u0091\u0000\u0019ÌEoW|\u0018zÿ\u008câQ\u0018\u0014Àóì þ¹;\u0005\u0019C2\u0000\u008cè\u0087\u001d\u001d4 §3¶7\u007f¸\u009e\u0004½iÿá\u0016¨Ìb,[û\u001a\u0099O:\\h'\u0082\u001c\rË\t¼cÚË'5\u0003\u001dcÿ2Åû\u0096»\u0087á\u0001\u0003Å¸äe\u009bJ~ux?:\u0001á\u0015Ý\u0094\u0015N¥\u0007êe\u001f÷\u0081³ò.\u009f5¡s\u0012\u0089Y]È±ô\u0083\u0000ï\u008eB{@&=<\u001b7\u0085^_JÃ\"_\u0097\u001eW8ÅÚ\u001f\u001fÞn·\r{Ë\u0095ÝcG";
                     int var13 = "y\u001dÒ~,ØÐ\u0085YD<Ìëæ&nF\u001aXDÎ\u001f¸\u0001« \u009föÉVÞôwö\u009e\u0090u\u00119º\u008b?!m)%Ù«5X\u000bÒ\u0002-à\r\t\u009fæ\u0016f\u0083\u0092i´\u0090$\u0005\b\u009f0Ñ²ðåeí\u0094N·Ðõ=£Z\u008béÃ\u0013n·\u0019©ä\u008az\u0090Å\u0014v9\u0095:?6kÓ®\u0083»¾\u0085£]u\u0096.ùÓ´\u001b\u0099Ò\u009fØÍmåá\u0081\u009bh\u0007Èªå#%Í±\u000e\u008fAµ$Ãì·\b\u001dâB×U-®¶V9ò\u0010z³·\u0081Q\u008b\u0091\u0000\u0019ÌEoW|\u0018zÿ\u008câQ\u0018\u0014Àóì þ¹;\u0005\u0019C2\u0000\u008cè\u0087\u001d\u001d4 §3¶7\u007f¸\u009e\u0004½iÿá\u0016¨Ìb,[û\u001a\u0099O:\\h'\u0082\u001c\rË\t¼cÚË'5\u0003\u001dcÿ2Åû\u0096»\u0087á\u0001\u0003Å¸äe\u009bJ~ux?:\u0001á\u0015Ý\u0094\u0015N¥\u0007êe\u001f÷\u0081³ò.\u009f5¡s\u0012\u0089Y]È±ô\u0083\u0000ï\u008eB{@&=<\u001b7\u0085^_JÃ\"_\u0097\u001eW8ÅÚ\u001f\u001fÞn·\r{Ë\u0095ÝcG".length();
                     int var10 = 0;

                     label53:
                     while(true) {
                        var10001 = var10;
                        var10 += 8;
                        byte[] var15 = var12.substring(var10001, var10).getBytes("ISO-8859-1");
                        long[] var27 = var14;
                        var10001 = var11++;
                        long var48 = ((long)var15[0] & 255L) << 56 | ((long)var15[1] & 255L) << 48 | ((long)var15[2] & 255L) << 40 | ((long)var15[3] & 255L) << 32 | ((long)var15[4] & 255L) << 24 | ((long)var15[5] & 255L) << 16 | ((long)var15[6] & 255L) << 8 | (long)var15[7] & 255L;
                        byte var61 = -1;

                        while(true) {
                           long var65 = var48 ^ var8;
                           switch (var61) {
                              case 0:
                                 var27[var10001] = var65;
                                 if (var10 >= var13) {
                                    c = var14;
                                    d = new Integer[43];
                                    MAX_DRAWN = a(31319, 81275896083658973L);
                                    MAX_PER_CHUNK = a(1670, 8485970021811241988L);
                                    PINK = a(8282, 5139683734793315019L);
                                    long var0 = 7865890092801461401L;
                                    long[] var6 = new long[3];
                                    int var3 = 0;
                                    String var4 = "TëCW\u0000.ïõ\"\u0013£Î«¯ ëX\u001d°Ý}AZ\u0019";
                                    int var5 = "TëCW\u0000.ïõ\"\u0013£Î«¯ ëX\u001d°Ý}AZ\u0019".length();
                                    int var2 = 0;

                                    do {
                                       var10001 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                                       var10001 = var3++;
                                       var65 = (((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L) ^ var0;
                                       var61 = -1;
                                       var6[var10001] = var65;
                                    } while(var2 < var5);

                                    e = var6;
                                    f = new Long[3];
                                    BUDGET_NS = b(19950, 3833954716113810912L);
                                    return;
                                 }
                                 break;
                              default:
                                 var27[var10001] = var65;
                                 if (var10 < var13) {
                                    continue label53;
                                 }

                                 var12 = "RÒÆ=3Ú\u009eÌ¢\u009a\u0099§\u008b\u0087å!";
                                 var13 = "RÒÆ=3Ú\u009eÌ¢\u009a\u0099§\u008b\u0087å!".length();
                                 var10 = 0;
                           }

                           var10001 = var10;
                           var10 += 8;
                           var15 = var12.substring(var10001, var10).getBytes("ISO-8859-1");
                           var27 = var14;
                           var10001 = var11++;
                           var48 = ((long)var15[0] & 255L) << 56 | ((long)var15[1] & 255L) << 48 | ((long)var15[2] & 255L) << 40 | ((long)var15[3] & 255L) << 32 | ((long)var15[4] & 255L) << 24 | ((long)var15[5] & 255L) << 16 | ((long)var15[6] & 255L) << 8 | (long)var15[7] & 255L;
                           var61 = 0;
                        }
                     }
                  }

                  var17 = var18.charAt(var25);
                  break;
               default:
                  var21[var19++] = var60;
                  if ((var25 += var17) < var20) {
                     var17 = var18.charAt(var25);
                     continue label82;
                  }

                  var18 = ".+\u001a|^\u0084\\\u0004Ü\u0007\u000f\u00ad";
                  var20 = ".+\u001a|^\u0084\\\u0004Ü\u0007\u000f\u00ad".length();
                  var17 = 7;
                  var25 = -1;
            }

            ++var25;
            var10000 = var18.substring(var25, var25 + var17);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 19481) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 192;
            case 1 -> var10000 = 124;
            case 2 -> var10000 = 156;
            case 3 -> var10000 = 25;
            case 4 -> var10000 = 157;
            case 5 -> var10000 = 115;
            case 6 -> var10000 = 110;
            case 7 -> var10000 = 38;
            case 8 -> var10000 = 203;
            case 9 -> var10000 = 204;
            case 10 -> var10000 = 170;
            case 11 -> var10000 = 33;
            case 12 -> var10000 = 3;
            case 13 -> var10000 = 188;
            case 14 -> var10000 = 79;
            case 15 -> var10000 = 198;
            case 16 -> var10000 = 66;
            case 17 -> var10000 = 86;
            case 18 -> var10000 = 47;
            case 19 -> var10000 = 194;
            case 20 -> var10000 = 111;
            case 21 -> var10000 = 34;
            case 22 -> var10000 = 183;
            case 23 -> var10000 = 209;
            case 24 -> var10000 = 151;
            case 25 -> var10000 = 176;
            case 26 -> var10000 = 173;
            case 27 -> var10000 = 215;
            case 28 -> var10000 = 94;
            case 29 -> var10000 = 109;
            case 30 -> var10000 = 161;
            case 31 -> var10000 = 93;
            case 32 -> var10000 = 242;
            case 33 -> var10000 = 22;
            case 34 -> var10000 = 186;
            case 35 -> var10000 = 72;
            case 36 -> var10000 = 17;
            case 37 -> var10000 = 249;
            case 38 -> var10000 = 200;
            case 39 -> var10000 = 96;
            case 40 -> var10000 = 122;
            case 41 -> var10000 = 162;
            case 42 -> var10000 = 59;
            case 43 -> var10000 = 131;
            case 44 -> var10000 = 179;
            case 45 -> var10000 = 18;
            case 46 -> var10000 = 113;
            case 47 -> var10000 = 226;
            case 48 -> var10000 = 11;
            case 49 -> var10000 = 255;
            case 50 -> var10000 = 103;
            case 51 -> var10000 = 99;
            case 52 -> var10000 = 150;
            case 53 -> var10000 = 65;
            case 54 -> var10000 = 160;
            case 55 -> var10000 = 5;
            case 56 -> var10000 = 89;
            case 57 -> var10000 = 163;
            case 58 -> var10000 = 229;
            case 59 -> var10000 = 129;
            case 60 -> var10000 = 130;
            case 61 -> var10000 = 167;
            case 62 -> var10000 = 138;
            case 63 -> var10000 = 98;
            case 64 -> var10000 = 252;
            case 65 -> var10000 = 12;
            case 66 -> var10000 = 159;
            case 67 -> var10000 = 91;
            case 68 -> var10000 = 234;
            case 69 -> var10000 = 9;
            case 70 -> var10000 = 8;
            case 71 -> var10000 = 88;
            case 72 -> var10000 = 14;
            case 73 -> var10000 = 97;
            case 74 -> var10000 = 104;
            case 75 -> var10000 = 100;
            case 76 -> var10000 = 71;
            case 77 -> var10000 = 83;
            case 78 -> var10000 = 126;
            case 79 -> var10000 = 120;
            case 80 -> var10000 = 128;
            case 81 -> var10000 = 58;
            case 82 -> var10000 = 193;
            case 83 -> var10000 = 232;
            case 84 -> var10000 = 237;
            case 85 -> var10000 = 84;
            case 86 -> var10000 = 101;
            case 87 -> var10000 = 137;
            case 88 -> var10000 = 77;
            case 89 -> var10000 = 231;
            case 90 -> var10000 = 107;
            case 91 -> var10000 = 238;
            case 92 -> var10000 = 228;
            case 93 -> var10000 = 185;
            case 94 -> var10000 = 82;
            case 95 -> var10000 = 39;
            case 96 -> var10000 = 213;
            case 97 -> var10000 = 247;
            case 98 -> var10000 = 44;
            case 99 -> var10000 = 134;
            case 100 -> var10000 = 102;
            case 101 -> var10000 = 206;
            case 102 -> var10000 = 32;
            case 103 -> var10000 = 235;
            case 104 -> var10000 = 7;
            case 105 -> var10000 = 191;
            case 106 -> var10000 = 214;
            case 107 -> var10000 = 70;
            case 108 -> var10000 = 123;
            case 109 -> var10000 = 174;
            case 110 -> var10000 = 225;
            case 111 -> var10000 = 227;
            case 112 -> var10000 = 187;
            case 113 -> var10000 = 29;
            case 114 -> var10000 = 37;
            case 115 -> var10000 = 164;
            case 116 -> var10000 = 81;
            case 117 -> var10000 = 133;
            case 118 -> var10000 = 132;
            case 119 -> var10000 = 106;
            case 120 -> var10000 = 60;
            case 121 -> var10000 = 36;
            case 122 -> var10000 = 236;
            case 123 -> var10000 = 87;
            case 124 -> var10000 = 56;
            case 125 -> var10000 = 27;
            case 126 -> var10000 = 240;
            case 127 -> var10000 = 223;
            case 128 -> var10000 = 149;
            case 129 -> var10000 = 13;
            case 130 -> var10000 = 171;
            case 131 -> var10000 = 61;
            case 132 -> var10000 = 202;
            case 133 -> var10000 = 182;
            case 134 -> var10000 = 118;
            case 135 -> var10000 = 41;
            case 136 -> var10000 = 50;
            case 137 -> var10000 = 208;
            case 138 -> var10000 = 78;
            case 139 -> var10000 = 80;
            case 140 -> var10000 = 26;
            case 141 -> var10000 = 55;
            case 142 -> var10000 = 178;
            case 143 -> var10000 = 245;
            case 144 -> var10000 = 250;
            case 145 -> var10000 = 219;
            case 146 -> var10000 = 217;
            case 147 -> var10000 = 189;
            case 148 -> var10000 = 211;
            case 149 -> var10000 = 222;
            case 150 -> var10000 = 145;
            case 151 -> var10000 = 1;
            case 152 -> var10000 = 248;
            case 153 -> var10000 = 139;
            case 154 -> var10000 = 184;
            case 155 -> var10000 = 40;
            case 156 -> var10000 = 136;
            case 157 -> var10000 = 177;
            case 158 -> var10000 = 207;
            case 159 -> var10000 = 35;
            case 160 -> var10000 = 114;
            case 161 -> var10000 = 190;
            case 162 -> var10000 = 166;
            case 163 -> var10000 = 244;
            case 164 -> var10000 = 199;
            case 165 -> var10000 = 16;
            case 166 -> var10000 = 144;
            case 167 -> var10000 = 233;
            case 168 -> var10000 = 0;
            case 169 -> var10000 = 49;
            case 170 -> var10000 = 64;
            case 171 -> var10000 = 112;
            case 172 -> var10000 = 105;
            case 173 -> var10000 = 116;
            case 174 -> var10000 = 62;
            case 175 -> var10000 = 31;
            case 176 -> var10000 = 216;
            case 177 -> var10000 = 140;
            case 178 -> var10000 = 74;
            case 179 -> var10000 = 108;
            case 180 -> var10000 = 135;
            case 181 -> var10000 = 54;
            case 182 -> var10000 = 230;
            case 183 -> var10000 = 90;
            case 184 -> var10000 = 42;
            case 185 -> var10000 = 45;
            case 186 -> var10000 = 246;
            case 187 -> var10000 = 254;
            case 188 -> var10000 = 146;
            case 189 -> var10000 = 239;
            case 190 -> var10000 = 147;
            case 191 -> var10000 = 53;
            case 192 -> var10000 = 241;
            case 193 -> var10000 = 221;
            case 194 -> var10000 = 154;
            case 195 -> var10000 = 243;
            case 196 -> var10000 = 127;
            case 197 -> var10000 = 142;
            case 198 -> var10000 = 30;
            case 199 -> var10000 = 197;
            case 200 -> var10000 = 68;
            case 201 -> var10000 = 253;
            case 202 -> var10000 = 212;
            case 203 -> var10000 = 169;
            case 204 -> var10000 = 152;
            case 205 -> var10000 = 52;
            case 206 -> var10000 = 73;
            case 207 -> var10000 = 153;
            case 208 -> var10000 = 43;
            case 209 -> var10000 = 21;
            case 210 -> var10000 = 172;
            case 211 -> var10000 = 121;
            case 212 -> var10000 = 23;
            case 213 -> var10000 = 69;
            case 214 -> var10000 = 6;
            case 215 -> var10000 = 92;
            case 216 -> var10000 = 165;
            case 217 -> var10000 = 196;
            case 218 -> var10000 = 117;
            case 219 -> var10000 = 148;
            case 220 -> var10000 = 85;
            case 221 -> var10000 = 220;
            case 222 -> var10000 = 143;
            case 223 -> var10000 = 251;
            case 224 -> var10000 = 195;
            case 225 -> var10000 = 48;
            case 226 -> var10000 = 10;
            case 227 -> var10000 = 218;
            case 228 -> var10000 = 181;
            case 229 -> var10000 = 76;
            case 230 -> var10000 = 75;
            case 231 -> var10000 = 20;
            case 232 -> var10000 = 155;
            case 233 -> var10000 = 2;
            case 234 -> var10000 = 168;
            case 235 -> var10000 = 95;
            case 236 -> var10000 = 24;
            case 237 -> var10000 = 19;
            case 238 -> var10000 = 175;
            case 239 -> var10000 = 201;
            case 240 -> var10000 = 46;
            case 241 -> var10000 = 4;
            case 242 -> var10000 = 67;
            case 243 -> var10000 = 210;
            case 244 -> var10000 = 63;
            case 245 -> var10000 = 119;
            case 246 -> var10000 = 57;
            case 247 -> var10000 = 141;
            case 248 -> var10000 = 205;
            case 249 -> var10000 = 15;
            case 250 -> var10000 = 51;
            case 251 -> var10000 = 180;
            case 252 -> var10000 = 28;
            case 253 -> var10000 = 125;
            case 254 -> var10000 = 224;
            default -> var10000 = 158;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 17035;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }

   private static long b(int var0, long var1) {
      int var3 = (var0 ^ (int)var1 ^ 30732) & 32767;
      if (f[var3] == null) {
         f[var3] = e[var3] ^ var1;
      }

      return f[var3];
   }

   public static enum Color {
      AUTO,
      PINK;

      // $FF: synthetic method
      private static Color[] $values() {
         return new Color[]{AUTO, PINK};
      }

      static {
         String[] var0 = new String[2];
         int var4 = 0;
         String var3 = "f\u0012R~\u0004w\u000eHz";
         int var5 = "f\u0012R~\u0004w\u000eHz".length();
         char var2 = 4;
         int var1 = -1;

         while(true) {
            char[] var16;
            label42: {
               ++var1;
               char[] var10001 = var3.substring(var1, var1 + var2).toCharArray();
               int var10003 = var10001.length;
               int var6 = 0;
               var16 = var10001;
               int var10 = var10003;
               char[] var23;
               int var10004;
               if (var10003 <= 1) {
                  var23 = var10001;
                  var10004 = var6;
               } else {
                  var16 = var10001;
                  var10 = var10003;
                  if (var10003 <= var6) {
                     break label42;
                  }

                  var23 = var10001;
                  var10004 = var6;
               }

               while(true) {
                  char var10005 = var23[var10004];
                  byte var10006;
                  switch (var6 % 7) {
                     case 0 -> var10006 = 39;
                     case 1 -> var10006 = 71;
                     case 2 -> var10006 = 6;
                     case 3 -> var10006 = 49;
                     case 4 -> var10006 = 97;
                     case 5 -> var10006 = 127;
                     default -> var10006 = 67;
                  }

                  var23[var10004] = (char)(var10005 ^ var10006);
                  ++var6;
                  if (var10 == 0) {
                     var10004 = var10;
                     var23 = var16;
                  } else {
                     if (var10 <= var6) {
                        break;
                     }

                     var23 = var16;
                     var10004 = var6;
                  }
               }
            }

            String var30 = (new String(var16)).intern();
            boolean var14 = true;
            var0[var4++] = var30;
            if ((var1 += var2) >= var5) {
               AUTO = new Color(var0[0], 0);
               PINK = new Color(var0[1], 1);
               return;
            }

            var2 = var3.charAt(var1);
         }
      }
   }
}
