package lol.wocky.feature.render;

import java.util.ArrayList;
import lol.wocky.core.GlOverlay;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.ModuleManager;
import lol.wocky.core.render.Hud2D;
import lol.wocky.core.render.HudElement;
import lol.wocky.core.render.HudPosition;

public class ArrayListHud extends Module implements HudElement {
   private final HudPosition position = new HudPosition();
   private static final String[] a;
   private static final String[] b;

   public ArrayListHud() {
      super(a(23706, 26418), a(23707, 22479), ModuleCategory.RENDER);
      this.addProperties(this.position.properties());
   }

   public HudPosition hudPosition() {
      return this.position;
   }

   public void onHudRender(Hud2D var1) {
      if (MinecraftBridge.isHudVisible() && GlOverlay.active()) {
         ArrayList var2 = new ArrayList();

         for(Module var4 : ModuleManager.getModules()) {
            if (var4.isEnabled() && !(var4 instanceof HudElement)) {
               var2.add(var4.getName());
            }
         }

         if (var2.isEmpty() && MinecraftBridge.isHudEditing()) {
            var2.add(a(23704, 6431));
         }

         if (!var2.isEmpty()) {
            GlOverlay.moduleList((String[])var2.toArray(new String[0]), (float)var1.guiScale() / 2.0F, this.position.spec());
         }

      }
   }

   static {
      String[] var5 = new String[3];
      int var3 = 0;
      String var2 = "¹C\u001f\u0091eh_\u007fÈ'aÞ\u0093¾\u0090Ç[ÕýÂ¿l(ÿS\u0005-N\u0002EÀóNð&W0*#\r{úé\u009dº\n¨+`\tÒçr\u0005Èúê-~";
      int var4 = "¹C\u001f\u0091eh_\u007fÈ'aÞ\u0093¾\u0090Ç[ÕýÂ¿l(ÿS\u0005-N\u0002EÀóNð&W0*#\r{úé\u009dº\n¨+`\tÒçr\u0005Èúê-~".length();
      char var1 = '\t';
      int var0 = -1;

      while(true) {
         char[] var16;
         label41: {
            ++var0;
            char[] var10001 = var2.substring(var0, var0 + var1).toCharArray();
            int var10003 = var10001.length;
            int var6 = 0;
            var16 = var10001;
            int var10 = var10003;
            char[] var23;
            int var10004;
            if (var10003 <= 1) {
               var23 = var10001;
               var10004 = var6;
            } else {
               var16 = var10001;
               var10 = var10003;
               if (var10003 <= var6) {
                  break label41;
               }

               var23 = var10001;
               var10004 = var6;
            }

            while(true) {
               char var10005 = var23[var10004];
               byte var10006;
               switch (var6 % 7) {
                  case 0 -> var10006 = 34;
                  case 1 -> var10006 = 62;
                  case 2 -> var10006 = 119;
                  case 3 -> var10006 = 99;
                  case 4 -> var10006 = 45;
                  case 5 -> var10006 = 55;
                  default -> var10006 = 105;
               }

               var23[var10004] = (char)(var10005 ^ var10006);
               ++var6;
               if (var10 == 0) {
                  var10004 = var10;
                  var23 = var16;
               } else {
                  if (var10 <= var6) {
                     break;
                  }

                  var23 = var16;
                  var10004 = var6;
               }
            }
         }

         String var30 = (new String(var16)).intern();
         boolean var14 = true;
         var5[var3++] = var30;
         if ((var0 += var1) >= var4) {
            a = var5;
            b = new String[3];
            return;
         }

         var1 = var2.charAt(var0);
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 23706) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 165;
            case 1 -> var10000 = 230;
            case 2 -> var10000 = 104;
            case 3 -> var10000 = 105;
            case 4 -> var10000 = 115;
            case 5 -> var10000 = 22;
            case 6 -> var10000 = 234;
            case 7 -> var10000 = 139;
            case 8 -> var10000 = 187;
            case 9 -> var10000 = 242;
            case 10 -> var10000 = 124;
            case 11 -> var10000 = 166;
            case 12 -> var10000 = 188;
            case 13 -> var10000 = 136;
            case 14 -> var10000 = 193;
            case 15 -> var10000 = 95;
            case 16 -> var10000 = 97;
            case 17 -> var10000 = 75;
            case 18 -> var10000 = 190;
            case 19 -> var10000 = 81;
            case 20 -> var10000 = 112;
            case 21 -> var10000 = 66;
            case 22 -> var10000 = 21;
            case 23 -> var10000 = 13;
            case 24 -> var10000 = 245;
            case 25 -> var10000 = 51;
            case 26 -> var10000 = 150;
            case 27 -> var10000 = 100;
            case 28 -> var10000 = 102;
            case 29 -> var10000 = 199;
            case 30 -> var10000 = 160;
            case 31 -> var10000 = 46;
            case 32 -> var10000 = 20;
            case 33 -> var10000 = 120;
            case 34 -> var10000 = 171;
            case 35 -> var10000 = 221;
            case 36 -> var10000 = 111;
            case 37 -> var10000 = 5;
            case 38 -> var10000 = 235;
            case 39 -> var10000 = 204;
            case 40 -> var10000 = 225;
            case 41 -> var10000 = 77;
            case 42 -> var10000 = 132;
            case 43 -> var10000 = 125;
            case 44 -> var10000 = 122;
            case 45 -> var10000 = 135;
            case 46 -> var10000 = 238;
            case 47 -> var10000 = 198;
            case 48 -> var10000 = 240;
            case 49 -> var10000 = 157;
            case 50 -> var10000 = 232;
            case 51 -> var10000 = 246;
            case 52 -> var10000 = 144;
            case 53 -> var10000 = 137;
            case 54 -> var10000 = 25;
            case 55 -> var10000 = 44;
            case 56 -> var10000 = 168;
            case 57 -> var10000 = 181;
            case 58 -> var10000 = 179;
            case 59 -> var10000 = 7;
            case 60 -> var10000 = 206;
            case 61 -> var10000 = 243;
            case 62 -> var10000 = 163;
            case 63 -> var10000 = 126;
            case 64 -> var10000 = 72;
            case 65 -> var10000 = 154;
            case 66 -> var10000 = 37;
            case 67 -> var10000 = 201;
            case 68 -> var10000 = 159;
            case 69 -> var10000 = 62;
            case 70 -> var10000 = 17;
            case 71 -> var10000 = 127;
            case 72 -> var10000 = 229;
            case 73 -> var10000 = 36;
            case 74 -> var10000 = 207;
            case 75 -> var10000 = 43;
            case 76 -> var10000 = 186;
            case 77 -> var10000 = 217;
            case 78 -> var10000 = 121;
            case 79 -> var10000 = 148;
            case 80 -> var10000 = 131;
            case 81 -> var10000 = 192;
            case 82 -> var10000 = 156;
            case 83 -> var10000 = 10;
            case 84 -> var10000 = 250;
            case 85 -> var10000 = 203;
            case 86 -> var10000 = 147;
            case 87 -> var10000 = 155;
            case 88 -> var10000 = 151;
            case 89 -> var10000 = 149;
            case 90 -> var10000 = 172;
            case 91 -> var10000 = 33;
            case 92 -> var10000 = 216;
            case 93 -> var10000 = 247;
            case 94 -> var10000 = 241;
            case 95 -> var10000 = 42;
            case 96 -> var10000 = 197;
            case 97 -> var10000 = 173;
            case 98 -> var10000 = 101;
            case 99 -> var10000 = 140;
            case 100 -> var10000 = 233;
            case 101 -> var10000 = 99;
            case 102 -> var10000 = 117;
            case 103 -> var10000 = 128;
            case 104 -> var10000 = 184;
            case 105 -> var10000 = 143;
            case 106 -> var10000 = 133;
            case 107 -> var10000 = 182;
            case 108 -> var10000 = 146;
            case 109 -> var10000 = 76;
            case 110 -> var10000 = 35;
            case 111 -> var10000 = 48;
            case 112 -> var10000 = 108;
            case 113 -> var10000 = 19;
            case 114 -> var10000 = 152;
            case 115 -> var10000 = 196;
            case 116 -> var10000 = 211;
            case 117 -> var10000 = 202;
            case 118 -> var10000 = 65;
            case 119 -> var10000 = 40;
            case 120 -> var10000 = 222;
            case 121 -> var10000 = 31;
            case 122 -> var10000 = 30;
            case 123 -> var10000 = 32;
            case 124 -> var10000 = 244;
            case 125 -> var10000 = 142;
            case 126 -> var10000 = 227;
            case 127 -> var10000 = 70;
            case 128 -> var10000 = 236;
            case 129 -> var10000 = 34;
            case 130 -> var10000 = 6;
            case 131 -> var10000 = 60;
            case 132 -> var10000 = 9;
            case 133 -> var10000 = 23;
            case 134 -> var10000 = 16;
            case 135 -> var10000 = 71;
            case 136 -> var10000 = 228;
            case 137 -> var10000 = 237;
            case 138 -> var10000 = 252;
            case 139 -> var10000 = 0;
            case 140 -> var10000 = 183;
            case 141 -> var10000 = 134;
            case 142 -> var10000 = 145;
            case 143 -> var10000 = 74;
            case 144 -> var10000 = 86;
            case 145 -> var10000 = 93;
            case 146 -> var10000 = 15;
            case 147 -> var10000 = 220;
            case 148 -> var10000 = 58;
            case 149 -> var10000 = 90;
            case 150 -> var10000 = 255;
            case 151 -> var10000 = 98;
            case 152 -> var10000 = 18;
            case 153 -> var10000 = 189;
            case 154 -> var10000 = 28;
            case 155 -> var10000 = 88;
            case 156 -> var10000 = 215;
            case 157 -> var10000 = 56;
            case 158 -> var10000 = 3;
            case 159 -> var10000 = 118;
            case 160 -> var10000 = 162;
            case 161 -> var10000 = 153;
            case 162 -> var10000 = 194;
            case 163 -> var10000 = 4;
            case 164 -> var10000 = 85;
            case 165 -> var10000 = 138;
            case 166 -> var10000 = 130;
            case 167 -> var10000 = 174;
            case 168 -> var10000 = 114;
            case 169 -> var10000 = 96;
            case 170 -> var10000 = 53;
            case 171 -> var10000 = 8;
            case 172 -> var10000 = 214;
            case 173 -> var10000 = 83;
            case 174 -> var10000 = 178;
            case 175 -> var10000 = 63;
            case 176 -> var10000 = 224;
            case 177 -> var10000 = 116;
            case 178 -> var10000 = 205;
            case 179 -> var10000 = 107;
            case 180 -> var10000 = 249;
            case 181 -> var10000 = 67;
            case 182 -> var10000 = 176;
            case 183 -> var10000 = 29;
            case 184 -> var10000 = 251;
            case 185 -> var10000 = 87;
            case 186 -> var10000 = 254;
            case 187 -> var10000 = 89;
            case 188 -> var10000 = 175;
            case 189 -> var10000 = 248;
            case 190 -> var10000 = 123;
            case 191 -> var10000 = 80;
            case 192 -> var10000 = 1;
            case 193 -> var10000 = 79;
            case 194 -> var10000 = 103;
            case 195 -> var10000 = 52;
            case 196 -> var10000 = 200;
            case 197 -> var10000 = 106;
            case 198 -> var10000 = 109;
            case 199 -> var10000 = 14;
            case 200 -> var10000 = 253;
            case 201 -> var10000 = 164;
            case 202 -> var10000 = 167;
            case 203 -> var10000 = 54;
            case 204 -> var10000 = 170;
            case 205 -> var10000 = 161;
            case 206 -> var10000 = 61;
            case 207 -> var10000 = 59;
            case 208 -> var10000 = 49;
            case 209 -> var10000 = 180;
            case 210 -> var10000 = 82;
            case 211 -> var10000 = 73;
            case 212 -> var10000 = 195;
            case 213 -> var10000 = 39;
            case 214 -> var10000 = 119;
            case 215 -> var10000 = 210;
            case 216 -> var10000 = 41;
            case 217 -> var10000 = 45;
            case 218 -> var10000 = 208;
            case 219 -> var10000 = 50;
            case 220 -> var10000 = 239;
            case 221 -> var10000 = 38;
            case 222 -> var10000 = 129;
            case 223 -> var10000 = 12;
            case 224 -> var10000 = 212;
            case 225 -> var10000 = 231;
            case 226 -> var10000 = 26;
            case 227 -> var10000 = 91;
            case 228 -> var10000 = 226;
            case 229 -> var10000 = 47;
            case 230 -> var10000 = 78;
            case 231 -> var10000 = 27;
            case 232 -> var10000 = 185;
            case 233 -> var10000 = 177;
            case 234 -> var10000 = 223;
            case 235 -> var10000 = 55;
            case 236 -> var10000 = 24;
            case 237 -> var10000 = 219;
            case 238 -> var10000 = 57;
            case 239 -> var10000 = 169;
            case 240 -> var10000 = 110;
            case 241 -> var10000 = 92;
            case 242 -> var10000 = 84;
            case 243 -> var10000 = 69;
            case 244 -> var10000 = 113;
            case 245 -> var10000 = 141;
            case 246 -> var10000 = 191;
            case 247 -> var10000 = 64;
            case 248 -> var10000 = 94;
            case 249 -> var10000 = 68;
            case 250 -> var10000 = 11;
            case 251 -> var10000 = 158;
            case 252 -> var10000 = 213;
            case 253 -> var10000 = 209;
            case 254 -> var10000 = 218;
            default -> var10000 = 2;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }
}
