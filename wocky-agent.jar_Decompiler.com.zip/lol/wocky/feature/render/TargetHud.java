package lol.wocky.feature.render;

import java.util.Locale;
import lol.wocky.core.GlOverlay;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.PopTracker;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.render.Hud2D;
import lol.wocky.core.render.HudElement;
import lol.wocky.core.render.HudPosition;

public class TargetHud extends Module implements HudElement {
   private final NumberProperty range = new NumberProperty(a(-5879, 13558), a(21597, 1165716650192950798L), 3, a(21204, 1560803908143829125L), 1);
   private final NumberProperty keepTime = new NumberProperty(a(-5880, 26371), (double)3.0F, (double)0.0F, (double)10.0F, (double)0.5F);
   private final BooleanProperty nearest = new BooleanProperty(a(-5873, 26514), true);
   private final BooleanProperty pops = new BooleanProperty(a(-5874, -20583), true);
   private final HudPosition position = new HudPosition();
   private volatile Object target;
   private long lastAimed;
   private Object shown;
   private String shownName = "";
   private static final long GHOST_HOLD_NS;
   private float alpha;
   private float health;
   private float ghost;
   private float lastHp;
   private float lastMax = 20.0F;
   private long lastFrame;
   private long ghostHoldUntil;
   private int skin;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;
   private static final long[] e;
   private static final Long[] f;

   public TargetHud() {
      super(a(-5878, 30400), a(-5875, -17090), ModuleCategory.RENDER);
      this.addProperties(new Property[]{this.range, this.keepTime, this.nearest, this.pops});
      this.addProperties(this.position.properties());
   }

   public HudPosition hudPosition() {
      return this.position;
   }

   public void onTick() {
      Object var1 = MinecraftBridge.getPlayer();
      long var2 = System.currentTimeMillis();
      Object var4 = MinecraftBridge.getHitEntity(MinecraftBridge.getCrosshairTarget());
      if (this.valid(var4, var1)) {
         this.target = var4;
         this.lastAimed = var2;
      } else {
         Object var5 = this.target;
         boolean var6 = this.valid(var5, var1) && (double)(var2 - this.lastAimed) <= this.keepTime.doubleValue() * (double)1000.0F;
         if (!var6) {
            this.target = (Boolean)this.nearest.getValue() ? this.closest(var1) : null;
         }
      }
   }

   private boolean valid(Object var1, Object var2) {
      return var1 != null && var1 != var2 && MinecraftBridge.isPlayer(var1) && !MinecraftBridge.isEntityRemoved(var1) && !MinecraftBridge.isDead(var1) && distance(var2, var1) <= this.range.doubleValue();
   }

   private Object closest(Object var1) {
      Object var2 = null;
      double var3 = Double.MAX_VALUE;

      for(Object var6 : MinecraftBridge.getPlayers()) {
         if (this.valid(var6, var1)) {
            double var7 = distance(var1, var6);
            if (var7 < var3) {
               var3 = var7;
               var2 = var6;
            }
         }
      }

      return var2;
   }

   private static double distance(Object var0, Object var1) {
      double var2 = MinecraftBridge.getEntityX(var0) - MinecraftBridge.getEntityX(var1);
      double var4 = MinecraftBridge.getEntityY(var0) - MinecraftBridge.getEntityY(var1);
      double var6 = MinecraftBridge.getEntityZ(var0) - MinecraftBridge.getEntityZ(var1);
      return Math.sqrt(var2 * var2 + var4 * var4 + var6 * var6);
   }

   public void onHudRender(Hud2D var1) {
      long var2 = System.nanoTime();
      float var4 = this.lastFrame == 0L ? 0.0F : Math.min(0.1F, (float)(var2 - this.lastFrame) / 1.0E9F);
      this.lastFrame = var2;
      if (MinecraftBridge.isHudVisible() && GlOverlay.active()) {
         Object var5 = MinecraftBridge.getPlayer();
         Object var6 = this.target;
         if (var6 == null && MinecraftBridge.isHudEditing()) {
            var6 = var5;
         }

         if (var6 != null && var6 != this.shown) {
            this.shown = var6;
            this.shownName = MinecraftBridge.getEntityName(var6);
            this.health = this.ghost = this.lastHp = MinecraftBridge.getHealth(var6);
            this.ghostHoldUntil = 0L;
         }

         this.alpha = approach(this.alpha, var6 != null ? 1.0F : 0.0F, var6 != null ? 10.0F : 6.0F, var4);
         if (this.shown != null && !(this.alpha <= 0.01F)) {
            Object var7 = this.shown;
            float var8 = var6 != null ? MinecraftBridge.getHealth(var7) : this.health;
            float var9 = var6 != null ? MinecraftBridge.getMaxHealth(var7) : this.lastMax;
            this.lastMax = var9;
            if (var8 < this.lastHp) {
               this.ghostHoldUntil = var2 + b(741, 8138002788649580637L);
            }

            this.lastHp = var8;
            this.health = approach(this.health, var8, 14.0F, var4);
            if (this.ghost < this.health) {
               this.ghost = this.health;
            } else if (var2 > this.ghostHoldUntil) {
               this.ghost = approach(this.ghost, this.health, 5.0F, var4);
            }

            this.skin = MinecraftBridge.getSkinGlId(var7);
            float var10 = (float)MinecraftBridge.getHurtTime(var7) / 10.0F;
            String var11 = var7 == var5 ? a(-5876, -5014) : String.format(Locale.ROOT, a(-5881, -26675), distance(var5, var7));
            String var12 = "";
            if ((Boolean)this.pops.getValue()) {
               int var13 = PopTracker.get(MinecraftBridge.getUuid(var7));
               if (var13 > 0) {
                  var12 = var13 + (var13 == 1 ? a(-5877, 550) : a(-5882, -8860));
               }
            }

            float[] var10000 = new float[a(7342, 5759574463729639166L)];
            var10000[0] = this.health;
            var10000[1] = var9;
            var10000[2] = MinecraftBridge.getAbsorption(var7);
            var10000[3] = this.ghost;
            var10000[4] = var10;
            var10000[5] = this.alpha;
            float[] var14 = var10000;
            GlOverlay.targetHud(this.shownName, this.skin, var14, var11, var12, (float)var1.guiScale() / 2.0F, this.position.spec());
         } else {
            if (var6 == null) {
               this.shown = null;
            }

         }
      }
   }

   private static float approach(float var0, float var1, float var2, float var3) {
      float var4 = 1.0F - (float)Math.exp((double)(-var2 * var3));
      float var5 = var0 + (var1 - var0) * var4;
      return Math.abs(var1 - var5) < 0.01F ? var1 : var5;
   }

   public void onDisable() {
      this.target = null;
      this.shown = null;
      this.alpha = 0.0F;
   }

   static {
      String[] var21 = new String[10];
      int var19 = 0;
      String var18 = "\noçÖ\u0007EuÂß\u0098g\u0092\u0003\u0082zÿ-Þ\u0000wo?·\r¤{S«sø.BïG¹E-¼\u009d2}.\u0099Z\u0090\u0019¨çÀ\u008cã\u0089\u0082w\u0097\u0007¸\u008ef\u000bã\u0012\t\u0007øÀÿ©Ó\u0088Â\u0017\u0004ú>\u0098\u0003\tºH\u009cz\u0092¶#rF\u0005)(ßåÕ";
      int var20 = "\noçÖ\u0007EuÂß\u0098g\u0092\u0003\u0082zÿ-Þ\u0000wo?·\r¤{S«sø.BïG¹E-¼\u009d2}.\u0099Z\u0090\u0019¨çÀ\u008cã\u0089\u0082w\u0097\u0007¸\u008ef\u000bã\u0012\t\u0007øÀÿ©Ó\u0088Â\u0017\u0004ú>\u0098\u0003\tºH\u009cz\u0092¶#rF\u0005)(ßåÕ".length();
      char var17 = 4;
      int var24 = -1;

      label74:
      while(true) {
         ++var24;
         String var10000 = var18.substring(var24, var24 + var17);
         int var10001 = -1;

         while(true) {
            char[] var40;
            label69: {
               char[] var27 = var10000.toCharArray();
               int var10003 = var27.length;
               int var22 = 0;
               var40 = var27;
               int var30 = var10003;
               char[] var48;
               int var10004;
               if (var10003 <= 1) {
                  var48 = var27;
                  var10004 = var22;
               } else {
                  var40 = var27;
                  var30 = var10003;
                  if (var10003 <= var22) {
                     break label69;
                  }

                  var48 = var27;
                  var10004 = var22;
               }

               while(true) {
                  char var10005 = var48[var10004];
                  byte var10006;
                  switch (var22 % 7) {
                     case 0 -> var10006 = 84;
                     case 1 -> var10006 = 36;
                     case 2 -> var10006 = 6;
                     case 3 -> var10006 = 78;
                     case 4 -> var10006 = 40;
                     case 5 -> var10006 = 26;
                     default -> var10006 = 57;
                  }

                  var48[var10004] = (char)(var10005 ^ var10006);
                  ++var22;
                  if (var30 == 0) {
                     var10004 = var30;
                     var48 = var40;
                  } else {
                     if (var30 <= var22) {
                        break;
                     }

                     var48 = var40;
                     var10004 = var22;
                  }
               }
            }

            String var55 = (new String(var40)).intern();
            switch (var10001) {
               case 0:
                  var21[var19++] = var55;
                  if ((var24 += var17) >= var20) {
                     a = var21;
                     b = new String[10];
                     long var8 = 7078121625797711606L;
                     long[] var14 = new long[3];
                     int var11 = 0;
                     String var12 = "\u001e\u001eÁ\u0088rZ\u00863ò\u0000¾rnªÈ\u000eÊÍ\u008fç\u0005,\u0080ô";
                     int var13 = "\u001e\u001eÁ\u0088rZ\u00863ò\u0000¾rnªÈ\u000eÊÍ\u008fç\u0005,\u0080ô".length();
                     int var10 = 0;

                     do {
                        var10001 = var10;
                        var10 += 8;
                        byte[] var15 = var12.substring(var10001, var10).getBytes("ISO-8859-1");
                        var10001 = var11++;
                        long var58 = (((long)var15[0] & 255L) << 56 | ((long)var15[1] & 255L) << 48 | ((long)var15[2] & 255L) << 40 | ((long)var15[3] & 255L) << 32 | ((long)var15[4] & 255L) << 24 | ((long)var15[5] & 255L) << 16 | ((long)var15[6] & 255L) << 8 | (long)var15[7] & 255L) ^ var8;
                        boolean var56 = true;
                        var14[var10001] = var58;
                     } while(var10 < var13);

                     c = var14;
                     d = new Integer[3];
                     long var0 = 7603551010418398779L;
                     long[] var6 = new long[2];
                     int var3 = 0;
                     String var4 = " \u00adê@±\u0081èö\u0019jÃ0\u0083ÇÚæ";
                     int var5 = " \u00adê@±\u0081èö\u0019jÃ0\u0083ÇÚæ".length();
                     int var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var59 = (((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L) ^ var0;
                        boolean var57 = true;
                        var6[var10001] = var59;
                     } while(var2 < var5);

                     e = var6;
                     f = new Long[2];
                     GHOST_HOLD_NS = b(12532, 5271699876493560397L);
                     return;
                  }

                  var17 = var18.charAt(var24);
                  break;
               default:
                  var21[var19++] = var55;
                  if ((var24 += var17) < var20) {
                     var17 = var18.charAt(var24);
                     continue label74;
                  }

                  var18 = "3\u0094¡V-\u0005\u007fÒÓ\u001dè";
                  var20 = "3\u0094¡V-\u0005\u007fÒÓ\u001dè".length();
                  var17 = 5;
                  var24 = -1;
            }

            ++var24;
            var10000 = var18.substring(var24, var24 + var17);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ -5874) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 44;
            case 1 -> var10000 = 17;
            case 2 -> var10000 = 3;
            case 3 -> var10000 = 43;
            case 4 -> var10000 = 193;
            case 5 -> var10000 = 254;
            case 6 -> var10000 = 95;
            case 7 -> var10000 = 132;
            case 8 -> var10000 = 232;
            case 9 -> var10000 = 127;
            case 10 -> var10000 = 55;
            case 11 -> var10000 = 212;
            case 12 -> var10000 = 210;
            case 13 -> var10000 = 1;
            case 14 -> var10000 = 97;
            case 15 -> var10000 = 164;
            case 16 -> var10000 = 151;
            case 17 -> var10000 = 51;
            case 18 -> var10000 = 50;
            case 19 -> var10000 = 60;
            case 20 -> var10000 = 211;
            case 21 -> var10000 = 220;
            case 22 -> var10000 = 49;
            case 23 -> var10000 = 188;
            case 24 -> var10000 = 242;
            case 25 -> var10000 = 91;
            case 26 -> var10000 = 251;
            case 27 -> var10000 = 182;
            case 28 -> var10000 = 106;
            case 29 -> var10000 = 25;
            case 30 -> var10000 = 229;
            case 31 -> var10000 = 173;
            case 32 -> var10000 = 144;
            case 33 -> var10000 = 14;
            case 34 -> var10000 = 198;
            case 35 -> var10000 = 16;
            case 36 -> var10000 = 57;
            case 37 -> var10000 = 56;
            case 38 -> var10000 = 163;
            case 39 -> var10000 = 165;
            case 40 -> var10000 = 90;
            case 41 -> var10000 = 136;
            case 42 -> var10000 = 225;
            case 43 -> var10000 = 191;
            case 44 -> var10000 = 224;
            case 45 -> var10000 = 180;
            case 46 -> var10000 = 19;
            case 47 -> var10000 = 13;
            case 48 -> var10000 = 7;
            case 49 -> var10000 = 2;
            case 50 -> var10000 = 130;
            case 51 -> var10000 = 27;
            case 52 -> var10000 = 62;
            case 53 -> var10000 = 6;
            case 54 -> var10000 = 153;
            case 55 -> var10000 = 170;
            case 56 -> var10000 = 158;
            case 57 -> var10000 = 83;
            case 58 -> var10000 = 100;
            case 59 -> var10000 = 217;
            case 60 -> var10000 = 239;
            case 61 -> var10000 = 250;
            case 62 -> var10000 = 202;
            case 63 -> var10000 = 89;
            case 64 -> var10000 = 166;
            case 65 -> var10000 = 235;
            case 66 -> var10000 = 87;
            case 67 -> var10000 = 93;
            case 68 -> var10000 = 227;
            case 69 -> var10000 = 65;
            case 70 -> var10000 = 230;
            case 71 -> var10000 = 218;
            case 72 -> var10000 = 34;
            case 73 -> var10000 = 0;
            case 74 -> var10000 = 102;
            case 75 -> var10000 = 122;
            case 76 -> var10000 = 241;
            case 77 -> var10000 = 252;
            case 78 -> var10000 = 35;
            case 79 -> var10000 = 184;
            case 80 -> var10000 = 30;
            case 81 -> var10000 = 26;
            case 82 -> var10000 = 21;
            case 83 -> var10000 = 185;
            case 84 -> var10000 = 61;
            case 85 -> var10000 = 155;
            case 86 -> var10000 = 74;
            case 87 -> var10000 = 176;
            case 88 -> var10000 = 119;
            case 89 -> var10000 = 249;
            case 90 -> var10000 = 46;
            case 91 -> var10000 = 88;
            case 92 -> var10000 = 246;
            case 93 -> var10000 = 171;
            case 94 -> var10000 = 139;
            case 95 -> var10000 = 147;
            case 96 -> var10000 = 24;
            case 97 -> var10000 = 143;
            case 98 -> var10000 = 96;
            case 99 -> var10000 = 99;
            case 100 -> var10000 = 33;
            case 101 -> var10000 = 75;
            case 102 -> var10000 = 112;
            case 103 -> var10000 = 29;
            case 104 -> var10000 = 4;
            case 105 -> var10000 = 84;
            case 106 -> var10000 = 179;
            case 107 -> var10000 = 233;
            case 108 -> var10000 = 197;
            case 109 -> var10000 = 48;
            case 110 -> var10000 = 200;
            case 111 -> var10000 = 178;
            case 112 -> var10000 = 219;
            case 113 -> var10000 = 204;
            case 114 -> var10000 = 207;
            case 115 -> var10000 = 146;
            case 116 -> var10000 = 156;
            case 117 -> var10000 = 37;
            case 118 -> var10000 = 209;
            case 119 -> var10000 = 18;
            case 120 -> var10000 = 189;
            case 121 -> var10000 = 154;
            case 122 -> var10000 = 71;
            case 123 -> var10000 = 9;
            case 124 -> var10000 = 66;
            case 125 -> var10000 = 199;
            case 126 -> var10000 = 248;
            case 127 -> var10000 = 53;
            case 128 -> var10000 = 138;
            case 129 -> var10000 = 135;
            case 130 -> var10000 = 148;
            case 131 -> var10000 = 168;
            case 132 -> var10000 = 5;
            case 133 -> var10000 = 72;
            case 134 -> var10000 = 28;
            case 135 -> var10000 = 39;
            case 136 -> var10000 = 183;
            case 137 -> var10000 = 109;
            case 138 -> var10000 = 124;
            case 139 -> var10000 = 133;
            case 140 -> var10000 = 20;
            case 141 -> var10000 = 216;
            case 142 -> var10000 = 79;
            case 143 -> var10000 = 162;
            case 144 -> var10000 = 128;
            case 145 -> var10000 = 104;
            case 146 -> var10000 = 206;
            case 147 -> var10000 = 195;
            case 148 -> var10000 = 38;
            case 149 -> var10000 = 82;
            case 150 -> var10000 = 80;
            case 151 -> var10000 = 244;
            case 152 -> var10000 = 222;
            case 153 -> var10000 = 253;
            case 154 -> var10000 = 31;
            case 155 -> var10000 = 240;
            case 156 -> var10000 = 201;
            case 157 -> var10000 = 221;
            case 158 -> var10000 = 137;
            case 159 -> var10000 = 69;
            case 160 -> var10000 = 15;
            case 161 -> var10000 = 125;
            case 162 -> var10000 = 36;
            case 163 -> var10000 = 63;
            case 164 -> var10000 = 22;
            case 165 -> var10000 = 161;
            case 166 -> var10000 = 110;
            case 167 -> var10000 = 70;
            case 168 -> var10000 = 107;
            case 169 -> var10000 = 54;
            case 170 -> var10000 = 129;
            case 171 -> var10000 = 76;
            case 172 -> var10000 = 117;
            case 173 -> var10000 = 237;
            case 174 -> var10000 = 152;
            case 175 -> var10000 = 121;
            case 176 -> var10000 = 123;
            case 177 -> var10000 = 131;
            case 178 -> var10000 = 116;
            case 179 -> var10000 = 159;
            case 180 -> var10000 = 157;
            case 181 -> var10000 = 23;
            case 182 -> var10000 = 145;
            case 183 -> var10000 = 172;
            case 184 -> var10000 = 174;
            case 185 -> var10000 = 77;
            case 186 -> var10000 = 115;
            case 187 -> var10000 = 203;
            case 188 -> var10000 = 114;
            case 189 -> var10000 = 160;
            case 190 -> var10000 = 208;
            case 191 -> var10000 = 73;
            case 192 -> var10000 = 226;
            case 193 -> var10000 = 126;
            case 194 -> var10000 = 118;
            case 195 -> var10000 = 111;
            case 196 -> var10000 = 98;
            case 197 -> var10000 = 12;
            case 198 -> var10000 = 238;
            case 199 -> var10000 = 205;
            case 200 -> var10000 = 243;
            case 201 -> var10000 = 190;
            case 202 -> var10000 = 40;
            case 203 -> var10000 = 103;
            case 204 -> var10000 = 67;
            case 205 -> var10000 = 175;
            case 206 -> var10000 = 81;
            case 207 -> var10000 = 236;
            case 208 -> var10000 = 10;
            case 209 -> var10000 = 228;
            case 210 -> var10000 = 214;
            case 211 -> var10000 = 140;
            case 212 -> var10000 = 134;
            case 213 -> var10000 = 45;
            case 214 -> var10000 = 187;
            case 215 -> var10000 = 247;
            case 216 -> var10000 = 108;
            case 217 -> var10000 = 92;
            case 218 -> var10000 = 113;
            case 219 -> var10000 = 52;
            case 220 -> var10000 = 196;
            case 221 -> var10000 = 78;
            case 222 -> var10000 = 192;
            case 223 -> var10000 = 213;
            case 224 -> var10000 = 181;
            case 225 -> var10000 = 58;
            case 226 -> var10000 = 215;
            case 227 -> var10000 = 85;
            case 228 -> var10000 = 231;
            case 229 -> var10000 = 64;
            case 230 -> var10000 = 150;
            case 231 -> var10000 = 194;
            case 232 -> var10000 = 186;
            case 233 -> var10000 = 11;
            case 234 -> var10000 = 169;
            case 235 -> var10000 = 255;
            case 236 -> var10000 = 86;
            case 237 -> var10000 = 32;
            case 238 -> var10000 = 94;
            case 239 -> var10000 = 142;
            case 240 -> var10000 = 47;
            case 241 -> var10000 = 120;
            case 242 -> var10000 = 8;
            case 243 -> var10000 = 41;
            case 244 -> var10000 = 223;
            case 245 -> var10000 = 234;
            case 246 -> var10000 = 101;
            case 247 -> var10000 = 68;
            case 248 -> var10000 = 105;
            case 249 -> var10000 = 245;
            case 250 -> var10000 = 149;
            case 251 -> var10000 = 141;
            case 252 -> var10000 = 177;
            case 253 -> var10000 = 167;
            case 254 -> var10000 = 42;
            default -> var10000 = 59;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 593;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }

   private static long b(int var0, long var1) {
      int var3 = (var0 ^ (int)var1 ^ 15033) & 32767;
      if (f[var3] == null) {
         f[var3] = e[var3] ^ var1;
      }

      return f[var3];
   }
}
