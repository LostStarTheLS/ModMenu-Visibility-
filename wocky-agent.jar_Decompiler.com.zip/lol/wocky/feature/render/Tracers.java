package lol.wocky.feature.render;

import lol.wocky.core.GlOverlay;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.EnumProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.render.Hud2D;
import lol.wocky.core.render.WorldShapes;

public class Tracers extends Module {
   private static final int PINK;
   private static final int WHITE;
   private static final int NEAR;
   private static final double NEAR_DIST = (double)8.0F;
   private static final double FAR_DIST = (double)64.0F;
   private final EnumProperty<Target> target;
   private final EnumProperty<Color> color;
   private final NumberProperty width;
   private final NumberProperty opacity;
   private final NumberProperty maxDistance;
   private final BooleanProperty fade;
   private static final float FAR_OPACITY = 0.45F;
   private final WorldShapes shapes;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;

   public Tracers() {
      super(a(-10241, -28456), a(-10242, -29399), ModuleCategory.RENDER);
      this.target = new EnumProperty<Target>(a(-10244, 160), Tracers.Target.BODY);
      this.color = new EnumProperty<Color>(a(-10245, -1596), Tracers.Color.WHITE);
      this.width = new NumberProperty(a(-10248, -17868), (double)1.0F, (double)0.5F, (double)3.0F, (double)0.25F);
      this.opacity = new NumberProperty(a(-10243, 28064), a(27587, 2546762651254657285L), a(29804, 5457473735937855153L), a(32586, 6897665324495537560L), 1);
      this.maxDistance = new NumberProperty(a(-10246, -17295), a(20524, 4211398559265860343L), a(142, 3951154639753149004L), a(32563, 8469370628216980972L), a(20541, 3646291282502855401L));
      this.fade = new BooleanProperty(a(-10247, 2627), false);
      this.shapes = new WorldShapes();
      Property[] var10001 = new Property[a(13983, 497701063150029891L)];
      var10001[0] = this.target;
      var10001[1] = this.color;
      var10001[2] = this.width;
      var10001[3] = this.opacity;
      var10001[4] = this.maxDistance;
      var10001[5] = this.fade;
      this.addProperties(var10001);
   }

   public void onHudRender(Hud2D var1) {
      if (MinecraftBridge.isHudOnlyScreen() && GlOverlay.active()) {
         Object var2 = MinecraftBridge.getPlayer();
         Object var3 = MinecraftBridge.getCameraEntity();
         float var4 = var1.tickDelta();
         double var5 = this.maxDistance.doubleValue();
         int var7 = Math.round(this.opacity.floatValue() * 2.55F);
         this.shapes.begin(var1);

         for(Object var9 : MinecraftBridge.getPlayers()) {
            if (var9 != var2 && var9 != var3 && !MinecraftBridge.isEntityRemoved(var9) && !MinecraftBridge.isDead(var9)) {
               double[] var10 = MinecraftBridge.getLerpedPos(var9, var4);
               double[] var11 = MinecraftBridge.getBoundingBox(var9);
               if (var10 != null && var11 != null) {
                  double var12 = var11[4] - var11[1];
                  double var10000;
                  switch (((Target)this.target.getValue()).ordinal()) {
                     case 0 -> var10000 = var10[1] + var12 * (double)0.5F;
                     case 1 -> var10000 = var10[1] + var12 * 0.9;
                     case 2 -> var10000 = var10[1];
                     default -> throw new MatchException((String)null, (Throwable)null);
                  }

                  double var14 = var10000;
                  double var16 = var10[0] - var1.camX();
                  double var18 = var14 - var1.camY();
                  double var20 = var10[2] - var1.camZ();
                  double var22 = Math.sqrt(var16 * var16 + var18 * var18 + var20 * var20);
                  if (!(var22 > var5)) {
                     int var24 = this.rgbFor(var22);
                     float var25 = 1.0F - (float)Math.min((double)1.0F, var22 / var5) * 0.55F;
                     int var26 = Math.max(1, Math.round((float)var7 * var25));
                     int var27 = var26 << a(18299, 7734689887324323245L) | var24;
                     int var28 = (Boolean)this.fade.getValue() ? var26 / a(893, 8463313554157009338L) << a(21279, 382734765972892106L) | var24 : var27;
                     this.shapes.tracer(var10[0], var14, var10[2], var28, var27);
                  }
               }
            }
         }

         if (!this.shapes.isEmpty()) {
            this.shapes.submit(this.width.floatValue());
         }

      }
   }

   private int rgbFor(double var1) {
      int var10000;
      switch (((Color)this.color.getValue()).ordinal()) {
         case 0:
            var10000 = a(29411, 332227421583771696L);
            break;
         case 1:
            float var3 = (float)Math.max((double)0.0F, Math.min((double)1.0F, (var1 - (double)8.0F) / (double)56.0F));
            var10000 = var3 < 0.5F ? lerp(a(2297, 310036681038950945L), a(24875, 7918462092509486066L), var3 * 2.0F) : lerp(a(24875, 7918462092509486066L), a(16884, 8904060509424696101L), var3 * 2.0F - 1.0F);
            break;
         case 2:
            var10000 = a(7150, 4510184296191877419L);
            break;
         default:
            throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private static int lerp(int var0, int var1, float var2) {
      int var3 = Math.round((float)(var0 >> a(21273, 999996691155855833L) & a(8046, 7365212503747159472L)) + (float)((var1 >> a(21273, 999996691155855833L) & a(5196, 7247459555196595867L)) - (var0 >> a(21273, 999996691155855833L) & a(5196, 7247459555196595867L))) * var2);
      int var4 = Math.round((float)(var0 >> a(20952, 2741666347814398722L) & a(5196, 7247459555196595867L)) + (float)((var1 >> a(20952, 2741666347814398722L) & a(5196, 7247459555196595867L)) - (var0 >> a(20952, 2741666347814398722L) & a(5196, 7247459555196595867L))) * var2);
      int var5 = Math.round((float)(var0 & a(5196, 7247459555196595867L)) + (float)((var1 & a(5196, 7247459555196595867L)) - (var0 & a(5196, 7247459555196595867L))) * var2);
      return var3 << a(21273, 999996691155855833L) | var4 << a(20952, 2741666347814398722L) | var5;
   }

   static {
      String[] var13 = new String[8];
      int var11 = 0;
      String var10 = "\u0019\f\u0018É\nÝU\u0006i[}\u0014Ûâ\u0007\u0080\u0099S9oÅ~*¾\u0010\u0080ví¸ïbÖá-¨q\u001fýö\u001cÝÎk\u0001;²\u0097<»P\u0015ó¡Ò\u008bèùÝP\u001dén8v\u0094\u0004\r\u0014·ÿ\u0005|¿ª\u0092ø";
      int var12 = "\u0019\f\u0018É\nÝU\u0006i[}\u0014Ûâ\u0007\u0080\u0099S9oÅ~*¾\u0010\u0080ví¸ïbÖá-¨q\u001fýö\u001cÝÎk\u0001;²\u0097<»P\u0015ó¡Ò\u008bèùÝP\u001dén8v\u0094\u0004\r\u0014·ÿ\u0005|¿ª\u0092ø".length();
      char var9 = 7;
      int var17 = -1;

      label73:
      while(true) {
         ++var17;
         String var10000 = var10.substring(var17, var17 + var9);
         int var10001 = -1;

         while(true) {
            char[] var33;
            label68: {
               char[] var21 = var10000.toCharArray();
               int var10003 = var21.length;
               int var14 = 0;
               var33 = var21;
               int var24 = var10003;
               char[] var43;
               int var10004;
               if (var10003 <= 1) {
                  var43 = var21;
                  var10004 = var14;
               } else {
                  var33 = var21;
                  var24 = var10003;
                  if (var10003 <= var14) {
                     break label68;
                  }

                  var43 = var21;
                  var10004 = var14;
               }

               while(true) {
                  char var10005 = var43[var10004];
                  byte var10006;
                  switch (var14 % 7) {
                     case 0 -> var10006 = 36;
                     case 1 -> var10006 = 67;
                     case 2 -> var10006 = 120;
                     case 3 -> var10006 = 61;
                     case 4 -> var10006 = 34;
                     case 5 -> var10006 = 56;
                     default -> var10006 = 109;
                  }

                  var43[var10004] = (char)(var10005 ^ var10006);
                  ++var14;
                  if (var24 == 0) {
                     var10004 = var24;
                     var43 = var33;
                  } else {
                     if (var24 <= var14) {
                        break;
                     }

                     var43 = var33;
                     var10004 = var14;
                  }
               }
            }

            String var50 = (new String(var33)).intern();
            switch (var10001) {
               case 0:
                  var13[var11++] = var50;
                  if ((var17 += var9) >= var12) {
                     a = var13;
                     b = new String[8];
                     long var0 = 2582227973903172585L;
                     long[] var6 = new long[23];
                     int var3 = 0;
                     String var4 = "\u0002\u0005'oQZ%\t\u0096oPi\u000f\u0085F\u0015µÈ·\u0019³»\u00073\"¼l¤ò\t\u009cLYh\u0015\u0013.\u0013\u00ad\u008d¯(@+ÔVþ\\±eJØÐ\u0092ê;À<Ã\u0006x¼é\bSíÞé\u00051h\u001e\u0080\u0011xþK\u008dèã¤À\u008a?\u0086\u0013¶ËüÛJÇ9Æ\u008a\u0094ôj^ \u008f\u0093D\u0005?óOCÜ\u008e&¦$ðÕ¦\u0090\nÍR\"\bÃ\u009eØ÷\u000f¬ZÒ\u0091\\\u0084\u0015}®ñ)ùäÊ\u008c9µ\u0015H\u0098\u0080V\u000e\u008a\u0084*\u001d,Jyzj \u001bbêß{ÕºU";
                     int var5 = "\u0002\u0005'oQZ%\t\u0096oPi\u000f\u0085F\u0015µÈ·\u0019³»\u00073\"¼l¤ò\t\u009cLYh\u0015\u0013.\u0013\u00ad\u008d¯(@+ÔVþ\\±eJØÐ\u0092ê;À<Ã\u0006x¼é\bSíÞé\u00051h\u001e\u0080\u0011xþK\u008dèã¤À\u008a?\u0086\u0013¶ËüÛJÇ9Æ\u008a\u0094ôj^ \u008f\u0093D\u0005?óOCÜ\u008e&¦$ðÕ¦\u0090\nÍR\"\bÃ\u009eØ÷\u000f¬ZÒ\u0091\\\u0084\u0015}®ñ)ùäÊ\u008c9µ\u0015H\u0098\u0080V\u000e\u008a\u0084*\u001d,Jyzj \u001bbêß{ÕºU".length();
                     int var2 = 0;

                     label44:
                     while(true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var19 = var6;
                        var10001 = var3++;
                        long var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                        byte var51 = -1;

                        while(true) {
                           long var54 = var38 ^ var0;
                           switch (var51) {
                              case 0:
                                 var19[var10001] = var54;
                                 if (var2 >= var5) {
                                    c = var6;
                                    d = new Integer[23];
                                    WHITE = a(23178, 1434208360867373146L);
                                    PINK = a(10836, 7163296525603983511L);
                                    NEAR = a(2288, 7419532821475291697L);
                                    return;
                                 }
                                 break;
                              default:
                                 var19[var10001] = var54;
                                 if (var2 < var5) {
                                    continue label44;
                                 }

                                 var4 = "t\u0011P»j×R§Ä/¢i\u0097c]=";
                                 var5 = "t\u0011P»j×R§Ä/¢i\u0097c]=".length();
                                 var2 = 0;
                           }

                           var10001 = var2;
                           var2 += 8;
                           var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                           var19 = var6;
                           var10001 = var3++;
                           var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                           var51 = 0;
                        }
                     }
                  }

                  var9 = var10.charAt(var17);
                  break;
               default:
                  var13[var11++] = var50;
                  if ((var17 += var9) < var12) {
                     var9 = var10.charAt(var17);
                     continue label73;
                  }

                  var10 = "ÛÝÀ\u0003¦\f\u0011áB\u0004VR\\Y\u0019CX\u0083";
                  var12 = "ÛÝÀ\u0003¦\f\u0011áB\u0004VR\\Y\u0019CX\u0083".length();
                  var9 = 5;
                  var17 = -1;
            }

            ++var17;
            var10000 = var10.substring(var17, var17 + var9);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ -10243) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 159;
            case 1 -> var10000 = 100;
            case 2 -> var10000 = 133;
            case 3 -> var10000 = 33;
            case 4 -> var10000 = 201;
            case 5 -> var10000 = 230;
            case 6 -> var10000 = 204;
            case 7 -> var10000 = 29;
            case 8 -> var10000 = 60;
            case 9 -> var10000 = 72;
            case 10 -> var10000 = 40;
            case 11 -> var10000 = 106;
            case 12 -> var10000 = 211;
            case 13 -> var10000 = 84;
            case 14 -> var10000 = 95;
            case 15 -> var10000 = 252;
            case 16 -> var10000 = 56;
            case 17 -> var10000 = 253;
            case 18 -> var10000 = 34;
            case 19 -> var10000 = 42;
            case 20 -> var10000 = 209;
            case 21 -> var10000 = 206;
            case 22 -> var10000 = 158;
            case 23 -> var10000 = 19;
            case 24 -> var10000 = 50;
            case 25 -> var10000 = 9;
            case 26 -> var10000 = 113;
            case 27 -> var10000 = 82;
            case 28 -> var10000 = 154;
            case 29 -> var10000 = 48;
            case 30 -> var10000 = 149;
            case 31 -> var10000 = 241;
            case 32 -> var10000 = 30;
            case 33 -> var10000 = 117;
            case 34 -> var10000 = 163;
            case 35 -> var10000 = 36;
            case 36 -> var10000 = 127;
            case 37 -> var10000 = 250;
            case 38 -> var10000 = 136;
            case 39 -> var10000 = 66;
            case 40 -> var10000 = 125;
            case 41 -> var10000 = 212;
            case 42 -> var10000 = 197;
            case 43 -> var10000 = 4;
            case 44 -> var10000 = 51;
            case 45 -> var10000 = 242;
            case 46 -> var10000 = 213;
            case 47 -> var10000 = 5;
            case 48 -> var10000 = 227;
            case 49 -> var10000 = 85;
            case 50 -> var10000 = 44;
            case 51 -> var10000 = 93;
            case 52 -> var10000 = 75;
            case 53 -> var10000 = 249;
            case 54 -> var10000 = 233;
            case 55 -> var10000 = 24;
            case 56 -> var10000 = 14;
            case 57 -> var10000 = 226;
            case 58 -> var10000 = 38;
            case 59 -> var10000 = 217;
            case 60 -> var10000 = 141;
            case 61 -> var10000 = 46;
            case 62 -> var10000 = 188;
            case 63 -> var10000 = 240;
            case 64 -> var10000 = 151;
            case 65 -> var10000 = 190;
            case 66 -> var10000 = 205;
            case 67 -> var10000 = 116;
            case 68 -> var10000 = 79;
            case 69 -> var10000 = 181;
            case 70 -> var10000 = 203;
            case 71 -> var10000 = 107;
            case 72 -> var10000 = 228;
            case 73 -> var10000 = 178;
            case 74 -> var10000 = 10;
            case 75 -> var10000 = 0;
            case 76 -> var10000 = 156;
            case 77 -> var10000 = 135;
            case 78 -> var10000 = 254;
            case 79 -> var10000 = 101;
            case 80 -> var10000 = 71;
            case 81 -> var10000 = 165;
            case 82 -> var10000 = 74;
            case 83 -> var10000 = 194;
            case 84 -> var10000 = 12;
            case 85 -> var10000 = 6;
            case 86 -> var10000 = 120;
            case 87 -> var10000 = 208;
            case 88 -> var10000 = 37;
            case 89 -> var10000 = 111;
            case 90 -> var10000 = 175;
            case 91 -> var10000 = 186;
            case 92 -> var10000 = 119;
            case 93 -> var10000 = 105;
            case 94 -> var10000 = 169;
            case 95 -> var10000 = 251;
            case 96 -> var10000 = 118;
            case 97 -> var10000 = 138;
            case 98 -> var10000 = 45;
            case 99 -> var10000 = 124;
            case 100 -> var10000 = 2;
            case 101 -> var10000 = 43;
            case 102 -> var10000 = 162;
            case 103 -> var10000 = 167;
            case 104 -> var10000 = 225;
            case 105 -> var10000 = 155;
            case 106 -> var10000 = 152;
            case 107 -> var10000 = 218;
            case 108 -> var10000 = 55;
            case 109 -> var10000 = 195;
            case 110 -> var10000 = 215;
            case 111 -> var10000 = 70;
            case 112 -> var10000 = 41;
            case 113 -> var10000 = 248;
            case 114 -> var10000 = 157;
            case 115 -> var10000 = 150;
            case 116 -> var10000 = 121;
            case 117 -> var10000 = 86;
            case 118 -> var10000 = 145;
            case 119 -> var10000 = 224;
            case 120 -> var10000 = 98;
            case 121 -> var10000 = 13;
            case 122 -> var10000 = 200;
            case 123 -> var10000 = 170;
            case 124 -> var10000 = 231;
            case 125 -> var10000 = 166;
            case 126 -> var10000 = 182;
            case 127 -> var10000 = 147;
            case 128 -> var10000 = 153;
            case 129 -> var10000 = 237;
            case 130 -> var10000 = 185;
            case 131 -> var10000 = 216;
            case 132 -> var10000 = 47;
            case 133 -> var10000 = 59;
            case 134 -> var10000 = 187;
            case 135 -> var10000 = 32;
            case 136 -> var10000 = 25;
            case 137 -> var10000 = 52;
            case 138 -> var10000 = 39;
            case 139 -> var10000 = 104;
            case 140 -> var10000 = 20;
            case 141 -> var10000 = 62;
            case 142 -> var10000 = 23;
            case 143 -> var10000 = 92;
            case 144 -> var10000 = 18;
            case 145 -> var10000 = 99;
            case 146 -> var10000 = 238;
            case 147 -> var10000 = 192;
            case 148 -> var10000 = 77;
            case 149 -> var10000 = 81;
            case 150 -> var10000 = 177;
            case 151 -> var10000 = 28;
            case 152 -> var10000 = 128;
            case 153 -> var10000 = 90;
            case 154 -> var10000 = 83;
            case 155 -> var10000 = 219;
            case 156 -> var10000 = 202;
            case 157 -> var10000 = 114;
            case 158 -> var10000 = 22;
            case 159 -> var10000 = 21;
            case 160 -> var10000 = 89;
            case 161 -> var10000 = 87;
            case 162 -> var10000 = 132;
            case 163 -> var10000 = 58;
            case 164 -> var10000 = 232;
            case 165 -> var10000 = 126;
            case 166 -> var10000 = 246;
            case 167 -> var10000 = 160;
            case 168 -> var10000 = 3;
            case 169 -> var10000 = 1;
            case 170 -> var10000 = 129;
            case 171 -> var10000 = 196;
            case 172 -> var10000 = 244;
            case 173 -> var10000 = 199;
            case 174 -> var10000 = 137;
            case 175 -> var10000 = 255;
            case 176 -> var10000 = 91;
            case 177 -> var10000 = 64;
            case 178 -> var10000 = 198;
            case 179 -> var10000 = 7;
            case 180 -> var10000 = 17;
            case 181 -> var10000 = 207;
            case 182 -> var10000 = 68;
            case 183 -> var10000 = 27;
            case 184 -> var10000 = 144;
            case 185 -> var10000 = 143;
            case 186 -> var10000 = 11;
            case 187 -> var10000 = 172;
            case 188 -> var10000 = 94;
            case 189 -> var10000 = 108;
            case 190 -> var10000 = 110;
            case 191 -> var10000 = 148;
            case 192 -> var10000 = 140;
            case 193 -> var10000 = 15;
            case 194 -> var10000 = 61;
            case 195 -> var10000 = 210;
            case 196 -> var10000 = 57;
            case 197 -> var10000 = 31;
            case 198 -> var10000 = 65;
            case 199 -> var10000 = 173;
            case 200 -> var10000 = 183;
            case 201 -> var10000 = 109;
            case 202 -> var10000 = 49;
            case 203 -> var10000 = 220;
            case 204 -> var10000 = 180;
            case 205 -> var10000 = 184;
            case 206 -> var10000 = 176;
            case 207 -> var10000 = 16;
            case 208 -> var10000 = 63;
            case 209 -> var10000 = 73;
            case 210 -> var10000 = 189;
            case 211 -> var10000 = 76;
            case 212 -> var10000 = 222;
            case 213 -> var10000 = 245;
            case 214 -> var10000 = 26;
            case 215 -> var10000 = 54;
            case 216 -> var10000 = 168;
            case 217 -> var10000 = 229;
            case 218 -> var10000 = 142;
            case 219 -> var10000 = 134;
            case 220 -> var10000 = 234;
            case 221 -> var10000 = 67;
            case 222 -> var10000 = 239;
            case 223 -> var10000 = 221;
            case 224 -> var10000 = 164;
            case 225 -> var10000 = 103;
            case 226 -> var10000 = 236;
            case 227 -> var10000 = 243;
            case 228 -> var10000 = 80;
            case 229 -> var10000 = 146;
            case 230 -> var10000 = 122;
            case 231 -> var10000 = 191;
            case 232 -> var10000 = 115;
            case 233 -> var10000 = 53;
            case 234 -> var10000 = 102;
            case 235 -> var10000 = 35;
            case 236 -> var10000 = 139;
            case 237 -> var10000 = 69;
            case 238 -> var10000 = 223;
            case 239 -> var10000 = 161;
            case 240 -> var10000 = 88;
            case 241 -> var10000 = 130;
            case 242 -> var10000 = 235;
            case 243 -> var10000 = 96;
            case 244 -> var10000 = 112;
            case 245 -> var10000 = 174;
            case 246 -> var10000 = 179;
            case 247 -> var10000 = 214;
            case 248 -> var10000 = 97;
            case 249 -> var10000 = 131;
            case 250 -> var10000 = 123;
            case 251 -> var10000 = 78;
            case 252 -> var10000 = 193;
            case 253 -> var10000 = 171;
            case 254 -> var10000 = 247;
            default -> var10000 = 8;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 31443;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }

   public static enum Color {
      PINK,
      DISTANCE,
      WHITE;

      // $FF: synthetic method
      private static Color[] $values() {
         return new Color[]{PINK, DISTANCE, WHITE};
      }

      static {
         String[] var0 = new String[3];
         int var4 = 0;
         String var3 = "\u0017.|U\u0005\u0010/{J \b\u0003.aJ$'W\u0002";
         int var5 = "\u0017.|U\u0005\u0010/{J \b\u0003.aJ$'W\u0002".length();
         char var2 = 4;
         int var1 = -1;

         while(true) {
            char[] var16;
            label42: {
               ++var1;
               char[] var10001 = var3.substring(var1, var1 + var2).toCharArray();
               int var10003 = var10001.length;
               int var6 = 0;
               var16 = var10001;
               int var10 = var10003;
               char[] var23;
               int var10004;
               if (var10003 <= 1) {
                  var23 = var10001;
                  var10004 = var6;
               } else {
                  var16 = var10001;
                  var10 = var10003;
                  if (var10003 <= var6) {
                     break label42;
                  }

                  var23 = var10001;
                  var10004 = var6;
               }

               while(true) {
                  char var10005 = var23[var10004];
                  byte var10006;
                  switch (var6 % 7) {
                     case 0 -> var10006 = 71;
                     case 1 -> var10006 = 103;
                     case 2 -> var10006 = 50;
                     case 3 -> var10006 = 30;
                     case 4 -> var10006 = 101;
                     case 5 -> var10006 = 105;
                     default -> var10006 = 20;
                  }

                  var23[var10004] = (char)(var10005 ^ var10006);
                  ++var6;
                  if (var10 == 0) {
                     var10004 = var10;
                     var23 = var16;
                  } else {
                     if (var10 <= var6) {
                        break;
                     }

                     var23 = var16;
                     var10004 = var6;
                  }
               }
            }

            String var30 = (new String(var16)).intern();
            boolean var14 = true;
            var0[var4++] = var30;
            if ((var1 += var2) >= var5) {
               PINK = new Color(var0[0], 0);
               DISTANCE = new Color(var0[2], 1);
               WHITE = new Color(var0[1], 2);
               return;
            }

            var2 = var3.charAt(var1);
         }
      }
   }

   public static enum Target {
      BODY,
      HEAD,
      FEET;

      // $FF: synthetic method
      private static Target[] $values() {
         return new Target[]{BODY, HEAD, FEET};
      }

      static {
         String[] var0 = new String[3];
         int var4 = 0;
         String var3 = "P'RU\u0004Z-WH\u0004^'VE";
         int var5 = "P'RU\u0004Z-WH\u0004^'VE".length();
         char var2 = 4;
         int var1 = -1;

         while(true) {
            char[] var16;
            label42: {
               ++var1;
               char[] var10001 = var3.substring(var1, var1 + var2).toCharArray();
               int var10003 = var10001.length;
               int var6 = 0;
               var16 = var10001;
               int var10 = var10003;
               char[] var23;
               int var10004;
               if (var10003 <= 1) {
                  var23 = var10001;
                  var10004 = var6;
               } else {
                  var16 = var10001;
                  var10 = var10003;
                  if (var10003 <= var6) {
                     break label42;
                  }

                  var23 = var10001;
                  var10004 = var6;
               }

               while(true) {
                  char var10005 = var23[var10004];
                  byte var10006;
                  switch (var6 % 7) {
                     case 0 -> var10006 = 24;
                     case 1 -> var10006 = 98;
                     case 2 -> var10006 = 19;
                     case 3 -> var10006 = 17;
                     case 4 -> var10006 = 78;
                     case 5 -> var10006 = 97;
                     default -> var10006 = 92;
                  }

                  var23[var10004] = (char)(var10005 ^ var10006);
                  ++var6;
                  if (var10 == 0) {
                     var10004 = var10;
                     var23 = var16;
                  } else {
                     if (var10 <= var6) {
                        break;
                     }

                     var23 = var16;
                     var10004 = var6;
                  }
               }
            }

            String var30 = (new String(var16)).intern();
            boolean var14 = true;
            var0[var4++] = var30;
            if ((var1 += var2) >= var5) {
               BODY = new Target(var0[1], 0);
               HEAD = new Target(var0[0], 1);
               FEET = new Target(var0[2], 2);
               return;
            }

            var2 = var3.charAt(var1);
         }
      }
   }
}
