package lol.wocky.feature.render;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lol.wocky.core.GlOverlay;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.render.Hud2D;
import lol.wocky.core.render.HudElement;
import lol.wocky.core.render.HudPosition;

public class StatusEffectsHud extends Module implements HudElement {
   private static final String[] ROMAN;
   private static final int EXPIRING_TICKS;
   private final Set<String> iconsSent = new HashSet();
   private final HudPosition position = new HudPosition();
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;

   public StatusEffectsHud() {
      super(a(32123, 11632), a(32114, 23627), ModuleCategory.RENDER);
      this.addProperties(this.position.properties());
   }

   public HudPosition hudPosition() {
      return this.position;
   }

   public void onHudRender(Hud2D var1) {
      if (MinecraftBridge.isHudVisible() && GlOverlay.active()) {
         Object var2 = MinecraftBridge.getPlayerEffects();
         if (((List)var2).isEmpty() && MinecraftBridge.isHudEditing()) {
            var2 = new ArrayList(List.of(new MinecraftBridge.Effect(a(32121, -29603), a(32120, -13094), 1, a(22103, 1467746100800897647L), false), new MinecraftBridge.Effect(a(32117, 29217), a(32116, -10389), 0, a(9953, 5474563594219631316L), false)));
         }

         if (!((List)var2).isEmpty()) {
            ((List)var2).sort(Comparator.comparing((var0) -> !var0.infinite()).thenComparing(MinecraftBridge.Effect::ticks, Comparator.reverseOrder()));
            int var3 = ((List)var2).size();
            String[] var4 = new String[var3];
            String[] var5 = new String[var3];
            String[] var6 = new String[var3];
            boolean[] var7 = new boolean[var3];

            for(int var8 = 0; var8 < var3; ++var8) {
               MinecraftBridge.Effect var9 = (MinecraftBridge.Effect)((List)var2).get(var8);
               if (this.iconsSent.add(var9.id())) {
                  byte[] var10 = MinecraftBridge.getEffectIconPng(var9.id());
                  if (var10 != null) {
                     GlOverlay.effectIcon(var9.id(), var10);
                  }
               }

               var4[var8] = var9.id();
               var5[var8] = var9.amplifier() > 0 ? var9.name() + " " + level(var9.amplifier() + 1) : var9.name();
               var6[var8] = var9.infinite() ? "∞" : duration(var9.ticks());
               var7[var8] = !var9.infinite() && var9.ticks() < a(26358, 2931064595687797449L);
            }

            GlOverlay.effects(var4, var5, var6, var7, (float)var1.guiScale() / 2.0F, this.position.spec());
         }
      }
   }

   private static String level(int var0) {
      return var0 <= ROMAN.length ? ROMAN[var0 - 1] : String.valueOf(var0);
   }

   private static String duration(int var0) {
      int var1 = Math.max(0, var0 / a(21251, 8380506470544426805L));
      int var2 = var1 / a(22826, 2099247134941072660L);
      int var3 = var1 / a(21615, 7653071356440100946L) % a(14636, 6397330106074082581L);
      int var4 = var1 % a(14636, 6397330106074082581L);
      return var2 > 0 ? String.format(a(32127, 12410), var2, var3, var4) : String.format(a(32112, 2624), var3, var4);
   }

   static {
      String[] var13 = new String[15];
      int var11 = 0;
      String var10 = "óÊ\u0005?\u0006Y\u001b\u0012\bÈÞF½n\t\u0016\u0018\u0002Z\u0086\u0002B\u0003\u0004x\u0001Îð\u0007<ê(i¼\u008eÉ\u0003\u0085Ïq&\u0088Ö\u0018E{\u0099ûP!\u00146ãüÒ\u0083\rË\u0097D_øëx#TGÖ{Eßý\u0085ö*[Ò\u0007o\u0002¬é\u0003õ¿\u0083\fôN1ý\u009f\u001c\u00ad\u0017m»çÑ\u0002ì\u0007\u0005\u00885}Dö";
      int var12 = "óÊ\u0005?\u0006Y\u001b\u0012\bÈÞF½n\t\u0016\u0018\u0002Z\u0086\u0002B\u0003\u0004x\u0001Îð\u0007<ê(i¼\u008eÉ\u0003\u0085Ïq&\u0088Ö\u0018E{\u0099ûP!\u00146ãüÒ\u0083\rË\u0097D_øëx#TGÖ{Eßý\u0085ö*[Ò\u0007o\u0002¬é\u0003õ¿\u0083\fôN1ý\u009f\u001c\u00ad\u0017m»çÑ\u0002ì\u0007\u0005\u00885}Dö".length();
      char var9 = '\b';
      int var17 = -1;

      label73:
      while(true) {
         ++var17;
         String var10000 = var10.substring(var17, var17 + var9);
         int var10001 = -1;

         while(true) {
            char[] var34;
            label68: {
               char[] var22 = var10000.toCharArray();
               int var10003 = var22.length;
               int var14 = 0;
               var34 = var22;
               int var25 = var10003;
               char[] var44;
               int var10004;
               if (var10003 <= 1) {
                  var44 = var22;
                  var10004 = var14;
               } else {
                  var34 = var22;
                  var25 = var10003;
                  if (var10003 <= var14) {
                     break label68;
                  }

                  var44 = var22;
                  var10004 = var14;
               }

               while(true) {
                  char var10005 = var44[var10004];
                  byte var10006;
                  switch (var14 % 7) {
                     case 0 -> var10006 = 17;
                     case 1 -> var10006 = 92;
                     case 2 -> var10006 = 54;
                     case 3 -> var10006 = 114;
                     case 4 -> var10006 = 50;
                     case 5 -> var10006 = 94;
                     default -> var10006 = 74;
                  }

                  var44[var10004] = (char)(var10005 ^ var10006);
                  ++var14;
                  if (var25 == 0) {
                     var10004 = var25;
                     var44 = var34;
                  } else {
                     if (var25 <= var14) {
                        break;
                     }

                     var44 = var34;
                     var10004 = var14;
                  }
               }
            }

            String var51 = (new String(var34)).intern();
            switch (var10001) {
               case 0:
                  var13[var11++] = var51;
                  if ((var17 += var9) >= var12) {
                     a = var13;
                     b = new String[15];
                     long var0 = 3858116155030133499L;
                     long[] var6 = new long[13];
                     int var3 = 0;
                     String var4 = "EDZ\rýô¾åÙá´vs\u0090\u001a\u0095}êÏ~7/\u0019ÿ\u008e&ç<Íu¨úïìº¾ôw\u009f\u009c\u007fµHÊé±wÒÙ\u0016\rÂEÊ\u009e\u0086¯¬sn\u0011\u001aòö)F\u0000¨\u0003=#$\u0089¬\u008f ÷{k«ÒÊ§z\u0004m\u009dÚ";
                     int var5 = "EDZ\rýô¾åÙá´vs\u0090\u001a\u0095}êÏ~7/\u0019ÿ\u008e&ç<Íu¨úïìº¾ôw\u009f\u009c\u007fµHÊé±wÒÙ\u0016\rÂEÊ\u009e\u0086¯¬sn\u0011\u001aòö)F\u0000¨\u0003=#$\u0089¬\u008f ÷{k«ÒÊ§z\u0004m\u009dÚ".length();
                     int var2 = 0;

                     label44:
                     while(true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var19 = var6;
                        var10001 = var3++;
                        long var39 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                        byte var52 = -1;

                        while(true) {
                           long var55 = var39 ^ var0;
                           switch (var52) {
                              case 0:
                                 var19[var10001] = var55;
                                 if (var2 >= var5) {
                                    c = var6;
                                    d = new Integer[13];
                                    EXPIRING_TICKS = a(27939, 776647540144175383L);
                                    String[] var20 = new String[a(1720, 5813623123998315151L)];
                                    var20[0] = "I";
                                    var20[1] = a(32118, 14910);
                                    var20[2] = a(32124, 30329);
                                    var20[3] = a(32119, -25582);
                                    var20[4] = "V";
                                    var20[5] = a(32125, 23113);
                                    var20[a(20545, 347423026730419323L)] = a(32115, 746);
                                    var20[a(15409, 4123563757188065290L)] = a(32113, 25486);
                                    var20[a(28714, 3931650542105846806L)] = a(32126, 177);
                                    var20[a(2154, 2808481945724623962L)] = "X";
                                    ROMAN = var20;
                                    return;
                                 }
                                 break;
                              default:
                                 var19[var10001] = var55;
                                 if (var2 < var5) {
                                    continue label44;
                                 }

                                 var4 = "¤p\u008dÇA.È~\u00012\u008fõ·ÇÆ¨";
                                 var5 = "¤p\u008dÇA.È~\u00012\u008fõ·ÇÆ¨".length();
                                 var2 = 0;
                           }

                           var10001 = var2;
                           var2 += 8;
                           var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                           var19 = var6;
                           var10001 = var3++;
                           var39 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                           var52 = 0;
                        }
                     }
                  }

                  var9 = var10.charAt(var17);
                  break;
               default:
                  var13[var11++] = var51;
                  if ((var17 += var9) < var12) {
                     var9 = var10.charAt(var17);
                     continue label73;
                  }

                  var10 = "\u0083\u009f8\u0011^\u0007 \u008b\u008bGLEù";
                  var12 = "\u0083\u009f8\u0011^\u0007 \u008b\u008bGLEù".length();
                  var9 = 5;
                  var17 = -1;
            }

            ++var17;
            var10000 = var10.substring(var17, var17 + var9);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 32117) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 202;
            case 1 -> var10000 = 231;
            case 2 -> var10000 = 106;
            case 3 -> var10000 = 116;
            case 4 -> var10000 = 24;
            case 5 -> var10000 = 90;
            case 6 -> var10000 = 134;
            case 7 -> var10000 = 216;
            case 8 -> var10000 = 212;
            case 9 -> var10000 = 57;
            case 10 -> var10000 = 95;
            case 11 -> var10000 = 140;
            case 12 -> var10000 = 89;
            case 13 -> var10000 = 114;
            case 14 -> var10000 = 227;
            case 15 -> var10000 = 152;
            case 16 -> var10000 = 128;
            case 17 -> var10000 = 17;
            case 18 -> var10000 = 135;
            case 19 -> var10000 = 27;
            case 20 -> var10000 = 117;
            case 21 -> var10000 = 250;
            case 22 -> var10000 = 74;
            case 23 -> var10000 = 104;
            case 24 -> var10000 = 9;
            case 25 -> var10000 = 38;
            case 26 -> var10000 = 240;
            case 27 -> var10000 = 162;
            case 28 -> var10000 = 137;
            case 29 -> var10000 = 180;
            case 30 -> var10000 = 59;
            case 31 -> var10000 = 179;
            case 32 -> var10000 = 159;
            case 33 -> var10000 = 153;
            case 34 -> var10000 = 252;
            case 35 -> var10000 = 82;
            case 36 -> var10000 = 101;
            case 37 -> var10000 = 119;
            case 38 -> var10000 = 157;
            case 39 -> var10000 = 4;
            case 40 -> var10000 = 103;
            case 41 -> var10000 = 51;
            case 42 -> var10000 = 73;
            case 43 -> var10000 = 183;
            case 44 -> var10000 = 34;
            case 45 -> var10000 = 56;
            case 46 -> var10000 = 23;
            case 47 -> var10000 = 199;
            case 48 -> var10000 = 143;
            case 49 -> var10000 = 210;
            case 50 -> var10000 = 97;
            case 51 -> var10000 = 251;
            case 52 -> var10000 = 178;
            case 53 -> var10000 = 241;
            case 54 -> var10000 = 145;
            case 55 -> var10000 = 218;
            case 56 -> var10000 = 84;
            case 57 -> var10000 = 200;
            case 58 -> var10000 = 147;
            case 59 -> var10000 = 160;
            case 60 -> var10000 = 18;
            case 61 -> var10000 = 71;
            case 62 -> var10000 = 121;
            case 63 -> var10000 = 78;
            case 64 -> var10000 = 83;
            case 65 -> var10000 = 133;
            case 66 -> var10000 = 219;
            case 67 -> var10000 = 198;
            case 68 -> var10000 = 3;
            case 69 -> var10000 = 229;
            case 70 -> var10000 = 109;
            case 71 -> var10000 = 168;
            case 72 -> var10000 = 173;
            case 73 -> var10000 = 125;
            case 74 -> var10000 = 174;
            case 75 -> var10000 = 16;
            case 76 -> var10000 = 172;
            case 77 -> var10000 = 8;
            case 78 -> var10000 = 246;
            case 79 -> var10000 = 63;
            case 80 -> var10000 = 175;
            case 81 -> var10000 = 242;
            case 82 -> var10000 = 29;
            case 83 -> var10000 = 36;
            case 84 -> var10000 = 6;
            case 85 -> var10000 = 217;
            case 86 -> var10000 = 41;
            case 87 -> var10000 = 70;
            case 88 -> var10000 = 120;
            case 89 -> var10000 = 44;
            case 90 -> var10000 = 67;
            case 91 -> var10000 = 2;
            case 92 -> var10000 = 64;
            case 93 -> var10000 = 14;
            case 94 -> var10000 = 122;
            case 95 -> var10000 = 181;
            case 96 -> var10000 = 21;
            case 97 -> var10000 = 177;
            case 98 -> var10000 = 187;
            case 99 -> var10000 = 53;
            case 100 -> var10000 = 32;
            case 101 -> var10000 = 244;
            case 102 -> var10000 = 203;
            case 103 -> var10000 = 167;
            case 104 -> var10000 = 190;
            case 105 -> var10000 = 79;
            case 106 -> var10000 = 22;
            case 107 -> var10000 = 215;
            case 108 -> var10000 = 30;
            case 109 -> var10000 = 113;
            case 110 -> var10000 = 221;
            case 111 -> var10000 = 10;
            case 112 -> var10000 = 223;
            case 113 -> var10000 = 197;
            case 114 -> var10000 = 11;
            case 115 -> var10000 = 88;
            case 116 -> var10000 = 43;
            case 117 -> var10000 = 47;
            case 118 -> var10000 = 150;
            case 119 -> var10000 = 196;
            case 120 -> var10000 = 156;
            case 121 -> var10000 = 7;
            case 122 -> var10000 = 62;
            case 123 -> var10000 = 92;
            case 124 -> var10000 = 245;
            case 125 -> var10000 = 248;
            case 126 -> var10000 = 230;
            case 127 -> var10000 = 99;
            case 128 -> var10000 = 184;
            case 129 -> var10000 = 236;
            case 130 -> var10000 = 237;
            case 131 -> var10000 = 220;
            case 132 -> var10000 = 110;
            case 133 -> var10000 = 98;
            case 134 -> var10000 = 123;
            case 135 -> var10000 = 37;
            case 136 -> var10000 = 192;
            case 137 -> var10000 = 205;
            case 138 -> var10000 = 76;
            case 139 -> var10000 = 201;
            case 140 -> var10000 = 243;
            case 141 -> var10000 = 170;
            case 142 -> var10000 = 86;
            case 143 -> var10000 = 19;
            case 144 -> var10000 = 87;
            case 145 -> var10000 = 139;
            case 146 -> var10000 = 25;
            case 147 -> var10000 = 108;
            case 148 -> var10000 = 40;
            case 149 -> var10000 = 28;
            case 150 -> var10000 = 193;
            case 151 -> var10000 = 151;
            case 152 -> var10000 = 176;
            case 153 -> var10000 = 115;
            case 154 -> var10000 = 208;
            case 155 -> var10000 = 5;
            case 156 -> var10000 = 209;
            case 157 -> var10000 = 149;
            case 158 -> var10000 = 26;
            case 159 -> var10000 = 80;
            case 160 -> var10000 = 211;
            case 161 -> var10000 = 206;
            case 162 -> var10000 = 163;
            case 163 -> var10000 = 164;
            case 164 -> var10000 = 50;
            case 165 -> var10000 = 66;
            case 166 -> var10000 = 161;
            case 167 -> var10000 = 91;
            case 168 -> var10000 = 254;
            case 169 -> var10000 = 222;
            case 170 -> var10000 = 171;
            case 171 -> var10000 = 138;
            case 172 -> var10000 = 166;
            case 173 -> var10000 = 136;
            case 174 -> var10000 = 234;
            case 175 -> var10000 = 49;
            case 176 -> var10000 = 85;
            case 177 -> var10000 = 124;
            case 178 -> var10000 = 55;
            case 179 -> var10000 = 238;
            case 180 -> var10000 = 182;
            case 181 -> var10000 = 255;
            case 182 -> var10000 = 127;
            case 183 -> var10000 = 42;
            case 184 -> var10000 = 118;
            case 185 -> var10000 = 65;
            case 186 -> var10000 = 77;
            case 187 -> var10000 = 141;
            case 188 -> var10000 = 69;
            case 189 -> var10000 = 94;
            case 190 -> var10000 = 13;
            case 191 -> var10000 = 112;
            case 192 -> var10000 = 31;
            case 193 -> var10000 = 249;
            case 194 -> var10000 = 60;
            case 195 -> var10000 = 158;
            case 196 -> var10000 = 169;
            case 197 -> var10000 = 233;
            case 198 -> var10000 = 0;
            case 199 -> var10000 = 185;
            case 200 -> var10000 = 61;
            case 201 -> var10000 = 39;
            case 202 -> var10000 = 52;
            case 203 -> var10000 = 232;
            case 204 -> var10000 = 235;
            case 205 -> var10000 = 224;
            case 206 -> var10000 = 126;
            case 207 -> var10000 = 194;
            case 208 -> var10000 = 148;
            case 209 -> var10000 = 45;
            case 210 -> var10000 = 129;
            case 211 -> var10000 = 72;
            case 212 -> var10000 = 111;
            case 213 -> var10000 = 46;
            case 214 -> var10000 = 93;
            case 215 -> var10000 = 33;
            case 216 -> var10000 = 189;
            case 217 -> var10000 = 225;
            case 218 -> var10000 = 155;
            case 219 -> var10000 = 58;
            case 220 -> var10000 = 48;
            case 221 -> var10000 = 81;
            case 222 -> var10000 = 239;
            case 223 -> var10000 = 1;
            case 224 -> var10000 = 100;
            case 225 -> var10000 = 15;
            case 226 -> var10000 = 144;
            case 227 -> var10000 = 132;
            case 228 -> var10000 = 204;
            case 229 -> var10000 = 186;
            case 230 -> var10000 = 130;
            case 231 -> var10000 = 146;
            case 232 -> var10000 = 191;
            case 233 -> var10000 = 188;
            case 234 -> var10000 = 131;
            case 235 -> var10000 = 12;
            case 236 -> var10000 = 247;
            case 237 -> var10000 = 226;
            case 238 -> var10000 = 154;
            case 239 -> var10000 = 214;
            case 240 -> var10000 = 102;
            case 241 -> var10000 = 165;
            case 242 -> var10000 = 213;
            case 243 -> var10000 = 105;
            case 244 -> var10000 = 68;
            case 245 -> var10000 = 195;
            case 246 -> var10000 = 35;
            case 247 -> var10000 = 207;
            case 248 -> var10000 = 96;
            case 249 -> var10000 = 142;
            case 250 -> var10000 = 75;
            case 251 -> var10000 = 20;
            case 252 -> var10000 = 54;
            case 253 -> var10000 = 253;
            case 254 -> var10000 = 228;
            default -> var10000 = 107;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 5180;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }
}
