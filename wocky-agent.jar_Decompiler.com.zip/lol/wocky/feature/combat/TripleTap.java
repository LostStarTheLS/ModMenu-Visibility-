package lol.wocky.feature.combat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.ModuleManager;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.KeyProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.render.Hud2D;
import lol.wocky.core.util.BlockUtils;

public class TripleTap extends Module {
   private static final int MAX_TICKS;
   private static final int AIM_TICKS;
   private static final int SETTLED_TICKS;
   private static final double SWITCH_MARGIN = (double)1.0F;
   private static final int WAIT_CRYSTAL_TICKS;
   private static final int AIR_HIT_TICKS;
   private static final int HIT_TICKS;
   private static final int FRESH_HIT_TICKS;
   private static final int[][] GAP_HIT_OBBY;
   private static final int[][] GAP_OBBY1_CRYSTAL;
   private static final int[][] GAP_OBBY2_CRYSTAL;
   private static final int[][] GAP_SPAWN_BREAK;
   private static final int[][] GAP_BREAK_AIR_HIT;
   private static final int[][] GAP_AIR_HIT_OBBY;
   private static final int[][] GAP_BREAK_OBBY;
   private static final int[][] GAP_BREAK_CRYSTAL;
   private static final int[][] SWITCH_LEAD;
   private static final int BLAST1_AT;
   private static final int BLAST2_AT;
   private static final int BLAST3_AT;
   private final KeyProperty activateKey = new KeyProperty(a(-30845, 10545), 0);
   private final NumberProperty rotationSpeed = new NumberProperty(a(-30810, 31137), (double)18.0F, (double)6.0F, (double)40.0F, (double)1.0F);
   private final BooleanProperty airHit = new BooleanProperty(a(-30826, -30001), true);
   private final BooleanProperty stopOnKill = new BooleanProperty(a(-30815, 2297), true);
   private final BooleanProperty swapBack = new BooleanProperty(a(-30848, 14894), true);
   private final NumberProperty targetMemory = new NumberProperty(a(-30829, 13744), (double)3.0F, (double)1.0F, (double)10.0F, (double)0.5F);
   private Step step;
   private Object target;
   private Plan plan;
   private Plan firstPlan;
   private List<Plan> plans;
   private int planIndex;
   private int aimIndex;
   private int stepTicks;
   private int aimTicks;
   private int totalTicks;
   private int previousSlot;
   private boolean keyWasDown;
   private boolean attackWasDown;
   private int unsettledTicks;
   private double[][] stepAims;
   private volatile float aimError;
   private Object lastHit;
   private long lastHitAt;
   private long lastHitTick;
   private boolean lastHitCharged;
   private long lastActionTick;
   private long spawnTick;
   private int gap;
   private int switchLead;
   private long hitTick;
   private int spawnTicks;
   private volatile double[] aimPoint;
   private volatile Object aimEntity;
   private volatile boolean aimNearest;
   private long lastFrame;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;
   private static final long[] e;
   private static final Long[] f;

   public TripleTap() {
      super(a(-30821, 14768), a(-30819, 429), ModuleCategory.CPVP);
      this.step = TripleTap.Step.IDLE;
      this.plans = new ArrayList();
      this.previousSlot = -1;
      this.aimError = 180.0F;
      this.lastHitTick = b(11833, 5940014152886334608L);
      this.spawnTick = b(20722, 7585012232815856216L);
      this.spawnTicks = 1;
      Property[] var10001 = new Property[a(4837, 2192873786165536486L)];
      var10001[0] = this.activateKey;
      var10001[1] = this.rotationSpeed;
      var10001[2] = this.airHit;
      var10001[3] = this.stopOnKill;
      var10001[4] = this.swapBack;
      var10001[5] = this.targetMemory;
      this.addProperties(var10001);
   }

   public static boolean isRunning() {
      TripleTap var0 = (TripleTap)ModuleManager.getByClass(TripleTap.class);
      return var0 != null && var0.isEnabled() && var0.step != TripleTap.Step.IDLE;
   }

   public boolean isExclusive() {
      return this.step != TripleTap.Step.IDLE;
   }

   public boolean cancelsItemUse() {
      return this.step != TripleTap.Step.IDLE;
   }

   public boolean cancelsAttack() {
      return this.step != TripleTap.Step.IDLE;
   }

   public void onTick() {
      Object var1 = MinecraftBridge.getPlayer();
      boolean var2 = MinecraftBridge.getCurrentScreen() != null;
      boolean var3 = !var2 && this.activateKey.getKey() != 0 && this.activateKey.isDown();
      boolean var4 = var3 && !this.keyWasDown;
      this.keyWasDown = var3;
      if (this.step == TripleTap.Step.IDLE) {
         this.rememberHits();
         if (var4 && !var2) {
            this.start(var1);
         }

      } else if (!var4 && !var2 && ++this.totalTicks <= a(16755, 6024924940459308373L) && !MinecraftBridge.isDead(var1)) {
         if (alive(this.target) || !(Boolean)this.stopOnKill.getValue() && this.step.ordinal() > TripleTap.Step.AIR_HIT.ordinal()) {
            ++this.stepTicks;
            switch (this.step.ordinal()) {
               case 1:
                  this.openingHit();
                  break;
               case 2:
               case 6:
                  this.placeObby(this.step == TripleTap.Step.OBBY1 ? TripleTap.Step.CRYSTAL1 : TripleTap.Step.CRYSTAL2);
                  break;
               case 3:
                  this.placeCrystal(TripleTap.Step.BREAK1);
                  break;
               case 4:
                  this.breakCrystal((Boolean)this.airHit.getValue() ? TripleTap.Step.AIR_HIT : TripleTap.Step.OBBY2);
                  break;
               case 5:
                  this.airHit();
                  break;
               case 7:
                  this.placeCrystal(TripleTap.Step.BREAK2);
                  break;
               case 8:
                  this.breakCrystal(TripleTap.Step.CRYSTAL3);
                  break;
               case 9:
                  this.placeCrystal(TripleTap.Step.BREAK3);
                  break;
               case 10:
                  this.breakCrystal(TripleTap.Step.IDLE);
            }

            if (this.step != TripleTap.Step.IDLE) {
               this.move();
            }

         } else {
            this.finish();
         }
      } else {
         this.finish();
      }
   }

   private void rememberHits() {
      boolean var1 = MinecraftBridge.isKeyDown(a(12362, 7508645659178107971L));
      if (var1 && !this.attackWasDown) {
         Object var2 = MinecraftBridge.getHitEntity(MinecraftBridge.getCrosshairTarget());
         if (MinecraftBridge.isPlayer(var2) && var2 != MinecraftBridge.getPlayer()) {
            this.lastHit = var2;
            this.lastHitAt = System.currentTimeMillis();
            this.lastHitTick = MinecraftBridge.getTickCount();
            this.lastHitCharged = MinecraftBridge.getAttackCooldownProgress() >= 0.95F;
         }
      }

      this.attackWasDown = var1;
   }

   private void start(Object var1) {
      Object var2 = MinecraftBridge.getHitEntity(MinecraftBridge.getCrosshairTarget());
      Object var3 = MinecraftBridge.isPlayer(var2) && var2 != var1 ? var2 : ((double)(System.currentTimeMillis() - this.lastHitAt) <= this.targetMemory.doubleValue() * (double)1000.0F ? this.lastHit : null);
      if (alive(var3) && !(distance(var1, var3) > (double)6.0F)) {
         if (MinecraftBridge.findHotbarSlot(a(-30834, 32468)) != -1 && MinecraftBridge.findHotbarSlot(a(-30838, 4831)) != -1) {
            this.target = var3;
            this.previousSlot = MinecraftBridge.getSelectedSlot();
            this.totalTicks = 0;
            this.firstPlan = null;
            long var4 = MinecraftBridge.getTickCount();
            int var6 = MinecraftBridge.getPing();
            this.spawnTicks = var6 < 0 ? 1 : Math.max(1, Math.min(a(29326, 3231316307068110505L), (int)Math.ceil((double)(var6 + a(7920, 8807168451650792141L)) / (double)50.0F)));
            if (var3 == this.lastHit && var4 - this.lastHitTick <= b(12689, 3749315241676516153L) && this.lastHitCharged) {
               this.lastActionTick = this.lastHitTick;
               this.hitTick = this.lastHitTick;
               if (!this.beginObby(TripleTap.Step.OBBY1)) {
                  this.finish();
                  return;
               }
            } else {
               this.step = TripleTap.Step.HIT;
               this.stepTicks = 0;
            }

            MinecraftBridge.setMouseLocked(true);
            MinecraftBridge.setMovementOverride(true);
         }
      }
   }

   private void openingHit() {
      this.aimEntity = this.target;
      this.aimNearest = true;
      if (this.stepTicks > a(25318, 1133005548511090393L)) {
         this.finish();
      } else if (MinecraftBridge.getHitEntity(MinecraftBridge.getCrosshairTarget()) == this.target) {
         if (!(MinecraftBridge.getAttackCooldownProgress() < 0.95F)) {
            if (MinecraftBridge.attackEntity(this.target, true)) {
               this.acted();
               this.hitTick = this.lastActionTick;
               if (!this.beginObby(TripleTap.Step.OBBY1)) {
                  this.finish();
               }
            }

         }
      }
   }

   private void acted() {
      this.lastActionTick = MinecraftBridge.getTickCount();
   }

   private boolean due(long var1) {
      long var3 = MinecraftBridge.getTickCount();
      int var5 = this.deadline();
      return var3 - var1 >= (long)this.gap || var5 >= 0 && var3 - this.hitTick >= (long)var5;
   }

   private boolean switchDue(long var1) {
      long var3 = MinecraftBridge.getTickCount();
      int var5 = this.deadline();
      return var3 - var1 >= (long)(this.gap - this.switchLead) || var5 >= 0 && var3 - this.hitTick >= (long)(var5 - this.switchLead);
   }

   private int deadline() {
      int var10000;
      switch (this.step.ordinal()) {
         case 2:
            var10000 = Math.max(1, a(29326, 3231316307068110505L) - this.spawnTicks - 2);
            break;
         case 3:
            var10000 = Math.max(2, a(29326, 3231316307068110505L) - this.spawnTicks);
            break;
         case 4:
            var10000 = a(29326, 3231316307068110505L);
            break;
         case 5:
         case 6:
         default:
            var10000 = -1;
            break;
         case 7:
            var10000 = a(17134, 8005402620627482356L) - this.spawnTicks;
            break;
         case 8:
            var10000 = a(17134, 8005402620627482356L);
            break;
         case 9:
            var10000 = a(29812, 7525384555601543233L) - this.spawnTicks;
            break;
         case 10:
            var10000 = a(29812, 7525384555601543233L);
      }

      return var10000;
   }

   private static int sample(int[][] var0) {
      int var1 = 0;

      for(int[] var5 : var0) {
         var1 += var5[1];
      }

      int var7 = ThreadLocalRandom.current().nextInt(var1);

      for(int[] var6 : var0) {
         if ((var7 -= var6[1]) < 0) {
            return var6[0];
         }
      }

      return var0[var0.length - 1][0];
   }

   private void sampleGap(Step var1) {
      int var10001;
      switch (var1.ordinal()) {
         case 2:
            var10001 = sample(GAP_HIT_OBBY);
            break;
         case 3:
            var10001 = sample(GAP_OBBY1_CRYSTAL);
            break;
         case 4:
         case 8:
         case 10:
            var10001 = sample(GAP_SPAWN_BREAK);
            break;
         case 5:
            var10001 = sample(GAP_BREAK_AIR_HIT);
            break;
         case 6:
            var10001 = (Boolean)this.airHit.getValue() ? sample(GAP_AIR_HIT_OBBY) : sample(GAP_BREAK_OBBY);
            break;
         case 7:
            var10001 = sample(GAP_OBBY2_CRYSTAL);
            break;
         case 9:
            var10001 = sample(GAP_BREAK_CRYSTAL);
            break;
         default:
            var10001 = 0;
      }

      this.gap = var10001;
      this.switchLead = sample(SWITCH_LEAD);
      this.spawnTick = b(20188, 4684799646426944631L);
      this.stepAims = null;
   }

   private void finish() {
      if (this.step != TripleTap.Step.IDLE && (Boolean)this.swapBack.getValue() && this.previousSlot != -1) {
         MinecraftBridge.setSelectedSlot(this.previousSlot);
      }

      this.step = TripleTap.Step.IDLE;
      this.target = null;
      this.plan = null;
      this.previousSlot = -1;
      this.aimPoint = null;
      this.aimEntity = null;
      MinecraftBridge.setMouseLocked(false);
      MinecraftBridge.setMovementOverride(false);
   }

   private void go(Step var1) {
      if (var1 == TripleTap.Step.IDLE) {
         this.finish();
      } else if (var1 == TripleTap.Step.OBBY2) {
         if (!this.beginObby(TripleTap.Step.OBBY2)) {
            this.finish();
         }

      } else {
         this.step = var1;
         this.stepTicks = 0;
         this.resetAim();
         this.sampleGap(var1);
      }
   }

   private boolean beginObby(Step var1) {
      boolean var2 = var1 == TripleTap.Step.OBBY2;
      this.plans = this.plans(this.target, this.firstPlan, var2);
      if (this.plans.isEmpty() && var2) {
         this.plans = this.plans(this.target, (Plan)null, true);
      }

      if (this.plans.isEmpty()) {
         return false;
      } else {
         this.planIndex = 0;
         this.plan = (Plan)this.plans.get(0);
         this.step = var1;
         this.stepTicks = 0;
         this.resetAim();
         this.sampleGap(var1);
         return true;
      }
   }

   private void placeObby(Step var1) {
      if (!this.due(this.lastActionTick)) {
         boolean var2 = this.step == TripleTap.Step.OBBY2;
         List var3 = this.plans(this.target, var2 ? this.firstPlan : null, var2);
         if (!var3.isEmpty()) {
            Plan var4 = (Plan)var3.get(0);

            for(Plan var6 : var3) {
               if (var6.x() == this.plan.x() && var6.y() == this.plan.y() && var6.z() == this.plan.z()) {
                  if (var4.score() - var6.score() < (double)1.0F) {
                     var4 = var6;
                  }
                  break;
               }
            }

            if (var4.x() != this.plan.x() || var4.y() != this.plan.y() || var4.z() != this.plan.z()) {
               this.resetAim();
            }

            this.plans = var3;
            this.planIndex = var3.indexOf(var4);
            this.plan = var4;
         }
      }

      Object var7 = this.plan.cell();
      if (this.plan.needsObby() && !BlockUtils.isCrystalBase(var7)) {
         if (MinecraftBridge.isReplaceable(var7) && MinecraftBridge.isFreeForBlock(var7)) {
            this.aimAt(this.plan.obbyAims());
            if (this.switchDue(this.lastActionTick)) {
               MinecraftBridge.selectHotbarItem(a(-30816, -31249));
            }

            Object var8 = MinecraftBridge.getCrosshairTarget();
            boolean var9 = MinecraftBridge.isBlockHit(var8) && (same(MinecraftBridge.coords(MinecraftBridge.getPlacementPos(var8)), this.plan) || same(MinecraftBridge.coords(MinecraftBridge.getHitBlockPos(var8)), this.plan) && !MinecraftBridge.isAir(var7));
            if (var9) {
               if (this.due(this.lastActionTick) && MinecraftBridge.isHolding(a(-30816, -31249))) {
                  if (MinecraftBridge.interactBlock(var8, true)) {
                     if (this.step == TripleTap.Step.OBBY1) {
                        this.firstPlan = this.plan;
                     }

                     this.acted();
                     this.go(var1);
                  }

               }
            } else {
               if (this.aimTimedOut(this.plan.obbyAims().length)) {
                  this.nextPlan();
               }

            }
         } else {
            this.nextPlan();
         }
      } else {
         if (this.step == TripleTap.Step.OBBY1) {
            this.firstPlan = this.plan;
         }

         this.go(var1);
      }
   }

   private void nextPlan() {
      if (++this.planIndex >= this.plans.size()) {
         this.finish();
      } else {
         this.plan = (Plan)this.plans.get(this.planIndex);
         this.resetAim();
      }
   }

   private void resetAim() {
      this.aimIndex = 0;
      this.aimTicks = 0;
      this.unsettledTicks = 0;
      this.aimError = 180.0F;
   }

   private void placeCrystal(Step var1) {
      if ((Boolean)this.stopOnKill.getValue() && !alive(this.target)) {
         this.finish();
      } else {
         Object var2 = this.plan.cell();
         if (!BlockUtils.isCrystalBase(var2)) {
            if (this.stepTicks > a(27854, 437862397022951668L)) {
               this.finish();
            }

         } else {
            if (this.switchDue(this.lastActionTick)) {
               MinecraftBridge.selectHotbarItem(a(-30836, 6863));
            }

            if (this.stepAims == null) {
               this.stepAims = crystalAims(this.plan);
            }

            double[][] var3 = this.stepAims;
            if (!MinecraftBridge.canPlaceCrystal(var2)) {
               this.aimPoint = var3[0];
               this.aimEntity = null;
               if (this.stepTicks > a(27854, 437862397022951668L)) {
                  this.finish();
               }

            } else {
               this.aimAt(var3);
               Object var4 = MinecraftBridge.getCrosshairTarget();
               if (MinecraftBridge.isBlockHit(var4) && same(MinecraftBridge.coords(MinecraftBridge.getHitBlockPos(var4)), this.plan)) {
                  if (this.due(this.lastActionTick) && MinecraftBridge.isHolding(a(-30836, 6863))) {
                     if (MinecraftBridge.interactBlock(var4, true)) {
                        this.acted();
                        this.go(var1);
                     }

                  }
               } else {
                  if (this.aimTimedOut(var3.length)) {
                     this.finish();
                  }

               }
            }
         }
      }
   }

   private void breakCrystal(Step var1) {
      if ((Boolean)this.stopOnKill.getValue() && !alive(this.target)) {
         this.finish();
      } else {
         Object var2 = this.findCrystal(this.plan);
         if (var2 == null) {
            this.aimPoint = new double[]{(double)this.plan.x() + (double)0.5F, (double)this.plan.y() + 1.8, (double)this.plan.z() + (double)0.5F};
            this.aimEntity = null;
            if (this.stepTicks > a(28894, 7790276719916729562L)) {
               this.go(var1);
            }

         } else {
            this.aimEntity = var2;
            this.aimNearest = false;
            if (this.spawnTick < 0L) {
               this.spawnTick = MinecraftBridge.getTickCount();
            }

            if (MinecraftBridge.getHitEntity(MinecraftBridge.getCrosshairTarget()) != var2) {
               if (this.stepTicks > a(9507, 4912430403471282492L)) {
                  this.go(var1);
               }

            } else if (this.due(this.spawnTick)) {
               if (MinecraftBridge.hasWeakness()) {
                  int var3 = MinecraftBridge.findSwordSlot();
                  if (var3 != -1) {
                     MinecraftBridge.setSelectedSlot(var3);
                  }
               }

               if (MinecraftBridge.attackEntity(var2, true)) {
                  this.acted();
                  this.go(var1);
               }

            }
         }
      }
   }

   private Object findCrystal(Plan var1) {
      double var2 = (double)var1.x() + (double)0.5F;
      double var4 = (double)(var1.y() + 1);
      double var6 = (double)var1.z() + (double)0.5F;

      for(Object var9 : MinecraftBridge.getEntities()) {
         if (MinecraftBridge.isEndCrystal(var9) && !MinecraftBridge.isEntityRemoved(var9)) {
            double var10 = MinecraftBridge.getEntityX(var9) - var2;
            double var12 = MinecraftBridge.getEntityY(var9) - var4;
            double var14 = MinecraftBridge.getEntityZ(var9) - var6;
            if (var10 * var10 + var12 * var12 + var14 * var14 < 0.36) {
               return var9;
            }
         }
      }

      return null;
   }

   private void airHit() {
      this.aimEntity = this.target;
      this.aimNearest = true;
      if (this.stepTicks > a(25318, 1133005548511090393L)) {
         this.go(TripleTap.Step.OBBY2);
      } else if (this.due(this.lastActionTick) && MinecraftBridge.getHitEntity(MinecraftBridge.getCrosshairTarget()) == this.target) {
         if (MinecraftBridge.attackEntity(this.target, true)) {
            this.acted();
            this.go(TripleTap.Step.OBBY2);
         }

      }
   }

   private void move() {
      Object var1 = MinecraftBridge.getPlayer();
      double var2 = MinecraftBridge.getEntityX(var1);
      double var4 = MinecraftBridge.getEntityZ(var1);
      double var6 = MinecraftBridge.getEntityX(this.target) - var2;
      double var8 = MinecraftBridge.getEntityZ(this.target) - var4;
      double var10 = Math.max(1.0E-6, Math.sqrt(var6 * var6 + var8 * var8));
      var6 /= var10;
      var8 /= var10;
      double var12 = (double)0.0F;
      double var14 = (double)0.0F;
      switch (this.step.ordinal()) {
         case 1:
            if (var10 > 1.4) {
               var12 = var6;
               var14 = var8;
            }
            break;
         case 2:
         case 3:
            if (this.plan != null) {
               double var16 = Math.signum(((double)this.plan.x() + (double)0.5F - var2) * var8 - ((double)this.plan.z() + (double)0.5F - var4) * var6);
               var12 = var8 * var16 * 0.11 + (var10 > (double)1.0F ? var6 * 0.05 : (double)0.0F);
               var14 = -var6 * var16 * 0.11 + (var10 > (double)1.0F ? var8 * 0.05 : (double)0.0F);
            }
            break;
         case 4:
         case 5:
            if (var10 > (double)1.5F) {
               var12 = var6;
               var14 = var8;
            }
      }

      boolean var30 = false;
      boolean var17 = false;
      boolean var18 = false;
      boolean var19 = false;
      double var20 = Math.sqrt(var12 * var12 + var14 * var14);
      if (var20 > 1.0E-6 && !dropAhead(var1, var12 / var20, var14 / var20)) {
         double var22 = Math.toRadians((double)MinecraftBridge.getYaw(var1));
         double var24 = (var12 * -Math.sin(var22) + var14 * Math.cos(var22)) / var20;
         double var26 = (var12 * -Math.cos(var22) + var14 * -Math.sin(var22)) / var20;
         var30 = var24 > 0.38;
         var17 = var24 < -0.38;
         var19 = var26 > 0.38;
         var18 = var26 < -0.38;
      }

      MinecraftBridge.holdKey(MinecraftBridge.MoveKey.FORWARD, var30);
      MinecraftBridge.holdKey(MinecraftBridge.MoveKey.BACK, var17);
      MinecraftBridge.holdKey(MinecraftBridge.MoveKey.LEFT, var18);
      MinecraftBridge.holdKey(MinecraftBridge.MoveKey.RIGHT, var19);
      MinecraftBridge.holdKey(MinecraftBridge.MoveKey.SPRINT, true);
      MinecraftBridge.holdKey(MinecraftBridge.MoveKey.JUMP, false);
      MinecraftBridge.holdKey(MinecraftBridge.MoveKey.SNEAK, false);
   }

   private static boolean dropAhead(Object var0, double var1, double var3) {
      int var5 = (int)Math.floor(MinecraftBridge.getEntityX(var0) + var1 * 0.7);
      int var6 = (int)Math.floor(MinecraftBridge.getEntityZ(var0) + var3 * 0.7);
      int var7 = (int)Math.floor(MinecraftBridge.getEntityY(var0) + 0.01);
      return MinecraftBridge.isReplaceable(MinecraftBridge.blockPos(var5, var7 - 1, var6)) && MinecraftBridge.isReplaceable(MinecraftBridge.blockPos(var5, var7 - 2, var6));
   }

   private static int groundLevel(Object var0) {
      int var1 = (int)Math.floor(MinecraftBridge.getEntityX(var0));
      int var2 = (int)Math.floor(MinecraftBridge.getEntityZ(var0));
      int var3 = (int)Math.floor(MinecraftBridge.getEntityY(var0) + 0.01);

      for(int var4 = 0; var4 < a(1114, 643114697439096913L); --var3) {
         if (!MinecraftBridge.isReplaceable(MinecraftBridge.blockPos(var1, var3 - 1, var2))) {
            return var3;
         }

         ++var4;
      }

      return (int)Math.floor(MinecraftBridge.getEntityY(var0));
   }

   private List<Plan> plans(Object var1, Plan var2, boolean var3) {
      ArrayList var4 = new ArrayList();
      ArrayList var5 = new ArrayList();
      Object var6 = MinecraftBridge.getPlayer();
      double var7 = MinecraftBridge.getEntityX(var1);
      double var9 = MinecraftBridge.getEntityZ(var1);
      double var11 = MinecraftBridge.getEntityX(var6);
      double var13 = MinecraftBridge.getEyeY(var6);
      double var15 = MinecraftBridge.getEntityZ(var6);
      double var17 = var7 - var11;
      double var19 = var9 - var15;
      double var21 = Math.max(1.0E-6, Math.sqrt(var17 * var17 + var19 * var19));
      var17 /= var21;
      var19 /= var21;
      double var23 = MinecraftBridge.getBlockInteractionRange() - (double)0.25F;
      double var25 = MinecraftBridge.getEntityX(var6);
      double var27 = MinecraftBridge.getEntityZ(var6);
      double[] var29 = MinecraftBridge.getBoundingBox(var1);
      double var30 = var7;
      double var32 = var9;
      double var34 = var17;
      double var36 = var19;
      int var38 = groundLevel(var1);
      double[] var39 = null;
      boolean var40 = var3 && MinecraftBridge.getEntityY(var1) - MinecraftBridge.getLastPos(var1)[1] > 0.02;
      double var41 = Math.toRadians((double)MinecraftBridge.getYaw(var6));
      double var43 = -Math.sin(var41) * var19 - Math.cos(var41) * var17;
      if (var3 && !var40) {
         double[] var45 = predictLanding(var1);
         var30 = var45[0];
         var32 = var45[2];
         var38 = Math.min((int)var45[1], groundLevel(var1));
         double var46 = Math.sqrt(var45[3] * var45[3] + var45[4] * var45[4]);
         if (var46 > 0.02) {
            var34 = var45[3] / var46;
            var36 = var45[4] / var46;
         }

         double[] var10000 = new double[a(29326, 3231316307068110505L)];
         var10000[0] = var30 - 0.4;
         var10000[1] = (double)var38;
         var10000[2] = var32 - 0.4;
         var10000[3] = var30 + 0.4;
         var10000[4] = (double)var38 + 1.8;
         var10000[5] = var32 + 0.4;
         var39 = var10000;
      }

      int var78 = (int)Math.floor(var30);
      int var79 = (int)Math.floor(var32);
      int var47 = var3 ? 1 : 2;

      for(int var48 = -var47; var48 <= var47; ++var48) {
         for(int var49 = -var47; var49 <= var47; ++var49) {
            if (var48 != 0 || var49 != 0 || var40) {
               int var50 = var78 + var48;
               int var51 = var79 + var49;

               for(int var52 = var38; var52 >= var38 - 1; --var52) {
                  Object var53 = MinecraftBridge.blockPos(var50, var52, var51);
                  Object var54 = MinecraftBridge.blockPos(var50, var52 - 1, var51);
                  Object var55 = MinecraftBridge.blockPos(var50, var52 + 1, var51);
                  boolean var56 = BlockUtils.isCrystalBase(var53);
                  boolean var57 = MinecraftBridge.isReplaceable(var53) && !MinecraftBridge.isReplaceable(var54);
                  if (var56 || var57) {
                     if ((var56 || !isInteractable(MinecraftBridge.blockId(var54))) && MinecraftBridge.isAir(var55) && (var56 || MinecraftBridge.isFreeForBlock(var53)) && (var40 || var29 == null || !overlaps(var29, (double)var50, (double)(var52 + 1), (double)var51, (double)(var50 + 1), (double)(var52 + 3), (double)(var51 + 1))) && (var39 == null || !overlaps(var39, (double)var50, (double)var52, (double)var51, (double)(var50 + 1), (double)(var52 + 3), (double)(var51 + 1)))) {
                        double[] var58 = new double[]{(double)var50 + (double)0.5F, (double)var52, (double)var51 + (double)0.5F};
                        double[] var59 = new double[]{(double)var50 + (double)0.5F, (double)(var52 + 1), (double)var51 + (double)0.5F};
                        if (!(dist(var11, var13, var15, var56 ? var59 : var58) > var23) && !(dist(var11, var13, var15, var59) > var23) && (var2 == null || var2.x() != var50 || var2.y() != var52 || var2.z() != var51)) {
                           double var60 = (double)var50 + (double)0.5F - var25;
                           double var62 = (double)var51 + (double)0.5F - var27;
                           if (!(var60 * var60 + var62 * var62 < (double)2.25F) && (var3 || !onPath((double)var50 + (double)0.5F, (double)var51 + (double)0.5F, var25, var27, var7, var9))) {
                              double[][] var64 = orderedAims(faceTop(var50, var52, var51), var11, var13, var15);
                              double[][] var65 = orderedAims(concat(faceTop(var50, var52 + 1, var51), sideTowards(var50, var52, var51, var11, var15)), var11, var13, var15);
                              double var66 = (double)var50 + (double)0.5F - var30;
                              double var68 = (double)var51 + (double)0.5F - var32;
                              double var70;
                              if (!var3) {
                                 double var72 = var66 * var17 + var68 * var19;
                                 double var74 = var66 * var19 - var68 * var17;
                                 var70 = -((var72 - (double)0.5F) * (var72 - (double)0.5F) + (Math.abs(var74) - 1.3) * (Math.abs(var74) - 1.3)) * (double)3.0F;
                                 if (var74 * var43 > (double)0.0F) {
                                    ++var70;
                                 }
                              } else if (var40) {
                                 var70 = -(var66 * var66 + var68 * var68) * (double)3.0F;
                              } else {
                                 double var84 = var66 * var34 + var68 * var36;
                                 var70 = var84 * (double)2.5F - Math.sqrt(var66 * var66 + var68 * var68) * (double)0.5F;
                              }

                              var70 += (double)(-(var38 - var52)) * (double)1.5F + (var56 ? (double)1.0F : (double)0.0F);
                              var5.add(new Plan(var50, var52, var51, !var56, var64, var65, var70));
                              var4.add(new double[]{var70, (double)(var5.size() - 1)});
                           }
                        }
                     }
                     break;
                  }
               }
            }
         }
      }

      var4.sort((var0, var1x) -> Double.compare(var1x[0], var0[0]));
      ArrayList var80 = new ArrayList();

      for(double[] var82 : var4) {
         var80.add((Plan)var5.get((int)var82[1]));
      }

      return var80;
   }

   private static boolean solid(double var0, double var2, double var4) {
      return !MinecraftBridge.isReplaceable(MinecraftBridge.blockPos((int)Math.floor(var0), (int)Math.floor(var2), (int)Math.floor(var4)));
   }

   private static double[] predictLanding(Object var0) {
      double var1 = MinecraftBridge.getEntityX(var0);
      double var3 = MinecraftBridge.getEntityY(var0);
      double var5 = MinecraftBridge.getEntityZ(var0);
      double[] var7 = MinecraftBridge.getLastPos(var0);
      double var8 = var1 - var7[0];
      double var10 = var3 - var7[1];
      double var12 = var5 - var7[2];
      double var14 = var8;
      double var16 = var12;
      if (MinecraftBridge.isOnGround(var0)) {
         return new double[]{var1, (double)groundLevel(var0), var5, var8, var12};
      } else {
         for(int var18 = 0; var18 < a(14761, 2263761566359195041L); ++var18) {
            double var19 = var1 + var8;
            double var21 = var5 + var12;
            if (!solid(var19, var3, var21) && !solid(var19, var3 + (double)1.0F, var21)) {
               var1 = var19;
               var5 = var21;
            } else {
               var8 = (double)0.0F;
               var12 = (double)0.0F;
            }

            double var23 = var3 + var10;
            if (var10 <= (double)0.0F && solid(var1, var23, var5)) {
               return new double[]{var1, Math.floor(var23) + (double)1.0F, var5, var14, var16};
            }

            var3 = var23;
            var10 = (var10 - 0.08) * 0.98;
            var8 *= 0.91;
            var12 *= 0.91;
         }

         return new double[]{var1, Math.floor(var3), var5, var14, var16};
      }
   }

   private static boolean onPath(double var0, double var2, double var4, double var6, double var8, double var10) {
      double var12 = var8 - var4;
      double var14 = var10 - var6;
      double var16 = var12 * var12 + var14 * var14;
      if (var16 < 1.0E-6) {
         return false;
      } else {
         double var18 = ((var0 - var4) * var12 + (var2 - var6) * var14) / var16;
         if (!(var18 <= (double)0.0F) && !(var18 >= 0.95)) {
            double var20 = Math.abs((var0 - var4) * var14 - (var2 - var6) * var12) / Math.sqrt(var16);
            return var20 < 0.9;
         } else {
            return false;
         }
      }
   }

   private static double[][] faceTop(int var0, int var1, int var2) {
      double[][] var3 = new double[5][];
      var3[0] = new double[]{(double)var0 + (double)0.5F, (double)var1, (double)var2 + (double)0.5F};
      int var4 = 1;

      for(double var8 : new double[]{0.22, 0.78}) {
         for(double var13 : new double[]{0.22, 0.78}) {
            var3[var4++] = new double[]{(double)var0 + var8, (double)var1, (double)var2 + var13};
         }
      }

      return var3;
   }

   private static double[][] sideTowards(int var0, int var1, int var2, double var3, double var5) {
      double var7 = var3 - ((double)var0 + (double)0.5F);
      double var9 = var5 - ((double)var2 + (double)0.5F);
      return Math.abs(var7) > Math.abs(var9) ? new double[][]{{var7 > (double)0.0F ? (double)(var0 + 1) : (double)var0, (double)var1 + 0.85, (double)var2 + (double)0.5F}} : new double[][]{{(double)var0 + (double)0.5F, (double)var1 + 0.85, var9 > (double)0.0F ? (double)(var2 + 1) : (double)var2}};
   }

   private static double[][] crystalAims(Plan var0) {
      Object var1 = MinecraftBridge.getPlayer();
      return orderedAims(byTurn(var0.crystalAims()), MinecraftBridge.getEntityX(var1), MinecraftBridge.getEyeY(var1), MinecraftBridge.getEntityZ(var1));
   }

   private static double[][] byTurn(double[][] var0) {
      Object var1 = MinecraftBridge.getPlayer();
      double var2 = MinecraftBridge.getEntityX(var1);
      double var4 = MinecraftBridge.getEyeY(var1);
      double var6 = MinecraftBridge.getEntityZ(var1);
      float var8 = MinecraftBridge.getYaw(var1);
      float var9 = MinecraftBridge.getPitch(var1);
      double[][] var10 = (double[][])(([[D)var0).clone();
      Arrays.sort(var10, Comparator.comparingDouble((var8x) -> {
         double var9x = var8x[0] - var2;
         double var11 = var8x[1] - var4;
         double var13 = var8x[2] - var6;
         float var15 = (float)Math.toDegrees(Math.atan2(var13, var9x)) - 90.0F;
         float var16 = (float)(-Math.toDegrees(Math.atan2(var11, Math.sqrt(var9x * var9x + var13 * var13))));
         float var17 = wrap(var15 - var8);
         float var18 = var16 - var9;
         return (double)(var17 * var17 + var18 * var18);
      }));
      return var10;
   }

   private static double[][] orderedAims(double[][] var0, double var1, double var3, double var5) {
      ArrayList var7 = new ArrayList();
      ArrayList var8 = new ArrayList();
      Object var9 = MinecraftBridge.getPlayer();
      ArrayList var10 = new ArrayList();

      for(Object var12 : MinecraftBridge.getPlayers()) {
         if (var12 != var9) {
            double[] var13 = MinecraftBridge.getBoundingBox(var12);
            if (var13 != null) {
               var10.add(var13);
            }
         }
      }

      for(double[] var14 : var0) {
         boolean var15 = false;

         for(double[] var17 : var10) {
            if (segmentHitsBox(var1, var3, var5, var14, var17, 0.1)) {
               var15 = true;
               break;
            }
         }

         (var15 ? var8 : var7).add(var14);
      }

      var7.addAll(var8);
      return (double[][])var7.toArray(new double[0][]);
   }

   private static boolean segmentHitsBox(double var0, double var2, double var4, double[] var6, double[] var7, double var8) {
      double[] var10 = new double[]{var0, var2, var4};
      double[] var11 = new double[]{var6[0] - var0, var6[1] - var2, var6[2] - var4};
      double var12 = (double)0.0F;
      double var14 = 0.97;

      for(int var16 = 0; var16 < 3; ++var16) {
         double var17 = var7[var16] - var8;
         double var19 = var7[var16 + 3] + var8;
         if (Math.abs(var11[var16]) < 1.0E-9) {
            if (var10[var16] < var17 || var10[var16] > var19) {
               return false;
            }
         } else {
            double var21 = (var17 - var10[var16]) / var11[var16];
            double var23 = (var19 - var10[var16]) / var11[var16];
            var12 = Math.max(var12, Math.min(var21, var23));
            var14 = Math.min(var14, Math.max(var21, var23));
            if (var12 > var14) {
               return false;
            }
         }
      }

      return true;
   }

   private static boolean isInteractable(String var0) {
      if (!var0.endsWith(a(-30805, 8648)) && !var0.endsWith(a(-30832, -25663)) && !var0.endsWith(a(-30802, -11753)) && !var0.endsWith(a(-30822, 24111)) && !var0.endsWith(a(-30817, -6968)) && !var0.endsWith(a(-30820, -8399)) && !var0.endsWith(a(-30831, -450)) && !var0.endsWith(a(-30818, -19948)) && !var0.contains(a(-30801, -12121)) && !var0.endsWith(a(-30811, -27975)) && !var0.endsWith(a(-30799, -11454)) && !var0.endsWith(a(-30808, -9720))) {
         int var2 = -1;
         switch (var0.hashCode()) {
            case -1399743986:
               if (var0.equals(a(-30796, 24270))) {
                  var2 = a(15883, 5943494355447417387L);
               }
               break;
            case -1396219994:
               if (var0.equals(a(-30795, 22972))) {
                  var2 = 1;
               }
               break;
            case -1393046460:
               if (var0.equals(a(-30803, 29197))) {
                  var2 = 2;
               }
               break;
            case -1293396564:
               if (var0.equals(a(-30823, 15167))) {
                  var2 = a(15849, 3086553047643097541L);
               }
               break;
            case -1257323578:
               if (var0.equals(a(-30844, -22361))) {
                  var2 = a(13374, 2156252724640415806L);
               }
               break;
            case -1211577292:
               if (var0.equals(a(-30800, -21643))) {
                  var2 = a(27854, 437862397022951668L);
               }
               break;
            case -1156955785:
               if (var0.equals(a(-30806, 9573))) {
                  var2 = a(23623, 2978497511270836348L);
               }
               break;
            case -1045183219:
               if (var0.equals(a(-30793, 17980))) {
                  var2 = a(10940, 5951159851001880194L);
               }
               break;
            case -1012642497:
               if (var0.equals(a(-30794, 19352))) {
                  var2 = a(31091, 7098123722658106704L);
               }
               break;
            case -898538269:
               if (var0.equals(a(-30842, -11201))) {
                  var2 = a(19945, 6059578349665384940L);
               }
               break;
            case -844673834:
               if (var0.equals(a(-30807, -4850))) {
                  var2 = a(21625, 2393450002679259229L);
               }
               break;
            case -758067976:
               if (var0.equals(a(-30804, -7415))) {
                  var2 = a(7727, 2225434692397050369L);
               }
               break;
            case -640902656:
               if (var0.equals(a(-30841, -4517))) {
                  var2 = a(13398, 179668540822913104L);
               }
               break;
            case -504019183:
               if (var0.equals(a(-30827, -14552))) {
                  var2 = a(7852, 8470670269656181396L);
               }
               break;
            case -436781176:
               if (var0.equals(a(-30797, -27117))) {
                  var2 = a(26480, 6657689003841016642L);
               }
               break;
            case 3020035:
               if (var0.equals(a(-30785, 7046))) {
                  var2 = 3;
               }
               break;
            case 3045944:
               if (var0.equals(a(-30812, 23857))) {
                  var2 = 5;
               }
               break;
            case 3327649:
               if (var0.equals(a(-30809, -5488))) {
                  var2 = a(3027, 4434165000933294058L);
               }
               break;
            case 52679031:
               if (var0.equals(a(-30843, -22072))) {
                  var2 = a(18970, 9050374834545589813L);
               }
               break;
            case 92975308:
               if (var0.equals(a(-30830, 21777))) {
                  var2 = 0;
               }
               break;
            case 102865802:
               if (var0.equals(a(-30837, 11545))) {
                  var2 = a(1697, 6796658793658823312L);
               }
               break;
            case 111981106:
               if (var0.equals(a(-30828, -10628))) {
                  var2 = a(14525, 9165025488947907725L);
               }
               break;
            case 241511093:
               if (var0.equals(a(-30840, -16146))) {
                  var2 = a(6149, 1334804957963627564L);
               }
               break;
            case 249386820:
               if (var0.equals(a(-30847, -12694))) {
                  var2 = a(7868, 2949758318684777122L);
               }
               break;
            case 455962475:
               if (var0.equals(a(-30798, 29142))) {
                  var2 = a(9581, 4596585954140918142L);
               }
               break;
            case 497689241:
               if (var0.equals(a(-30833, -16727))) {
                  var2 = a(3170, 7902552828251322483L);
               }
               break;
            case 571004489:
               if (var0.equals(a(-30825, -7311))) {
                  var2 = a(29326, 3231316307068110505L);
               }
               break;
            case 915846769:
               if (var0.equals(a(-30813, 16481))) {
                  var2 = a(12398, 5340768494909260869L);
               }
               break;
            case 1025009357:
               if (var0.equals(a(-30824, 17123))) {
                  var2 = a(4732, 1910310542278534763L);
               }
               break;
            case 1172333710:
               if (var0.equals(a(-30814, 7020))) {
                  var2 = a(31914, 1241633678711802034L);
               }
               break;
            case 1378766353:
               if (var0.equals(a(-30846, -24455))) {
                  var2 = 4;
               }
               break;
            case 1467901393:
               if (var0.equals(a(-30835, -12805))) {
                  var2 = a(31026, 5096795788708891935L);
               }
               break;
            case 1925736398:
               if (var0.equals(a(-30839, 26086))) {
                  var2 = a(20856, 4773405401699640655L);
               }
         }

         boolean var10000;
         switch (var2) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 27:
            case 28:
            case 29:
            case 30:
            case 31:
            case 32:
               var10000 = true;
               break;
            default:
               var10000 = false;
         }

         return var10000;
      } else {
         return true;
      }
   }

   private static boolean overlaps(double[] var0, double var1, double var3, double var5, double var7, double var9, double var11) {
      return var0[0] < var7 && var0[3] > var1 && var0[1] < var9 && var0[4] > var3 && var0[2] < var11 && var0[5] > var5;
   }

   private static double[][] concat(double[][] var0, double[][] var1) {
      double[][] var2 = (double[][])Arrays.copyOf(var0, var0.length + var1.length);
      System.arraycopy(var1, 0, var2, var0.length, var1.length);
      return var2;
   }

   private void aimAt(double[][] var1) {
      this.aimEntity = null;
      this.aimPoint = var1[Math.min(this.aimIndex, var1.length - 1)];
   }

   private boolean aimTimedOut(int var1) {
      if (this.aimError > 1.5F && ++this.unsettledTicks < a(13148, 2181546250200418139L)) {
         return false;
      } else if (++this.aimTicks < 3) {
         return false;
      } else {
         this.aimTicks = 0;
         this.unsettledTicks = 0;
         this.aimError = 180.0F;
         return ++this.aimIndex >= var1;
      }
   }

   public void onHudRender(Hud2D var1) {
      long var2 = System.nanoTime();
      float var4 = this.lastFrame == 0L ? 0.0F : Math.min(0.05F, (float)(var2 - this.lastFrame) / 1.0E9F);
      this.lastFrame = var2;
      if (this.step != TripleTap.Step.IDLE && !(var4 <= 0.0F)) {
         double[] var5 = this.currentAim(var1);
         if (var5 != null) {
            double var6 = var5[0] - var1.camX();
            double var8 = var5[1] - var1.camY();
            double var10 = var5[2] - var1.camZ();
            float var12 = (float)Math.toDegrees(Math.atan2(var10, var6)) - 90.0F;
            float var13 = (float)(-Math.toDegrees(Math.atan2(var8, Math.sqrt(var6 * var6 + var10 * var10))));
            Object var14 = MinecraftBridge.getPlayer();
            float var15 = wrap(var12 - MinecraftBridge.getYaw(var14));
            float var16 = var13 - MinecraftBridge.getPitch(var14);
            float var17 = (float)Math.sqrt((double)(var15 * var15 + var16 * var16));
            this.aimError = var17;
            if (!(var17 < 0.05F)) {
               float var18 = 1.0F - (float)Math.exp(-this.rotationSpeed.doubleValue() * (double)var4);
               float var19 = Math.max(var17 * var18, Math.min(var17, 120.0F * var4));
               MinecraftBridge.turnPlayer(var15 * var19 / var17, var16 * var19 / var17);
            }
         }
      }
   }

   private double[] currentAim(Hud2D var1) {
      Object var2 = this.aimEntity;
      if (var2 == null) {
         return this.aimPoint;
      } else {
         double[] var3 = MinecraftBridge.getBoundingBox(var2);
         double[] var4 = MinecraftBridge.getLerpedPos(var2, var1.tickDelta());
         if (var3 != null && var4 != null) {
            double var5 = var4[0] - MinecraftBridge.getEntityX(var2);
            double var7 = var4[1] - MinecraftBridge.getEntityY(var2);
            double var9 = var4[2] - MinecraftBridge.getEntityZ(var2);
            return !this.aimNearest ? new double[]{(var3[0] + var3[3]) / (double)2.0F + var5, var3[1] + (var3[4] - var3[1]) * 0.4 + var7, (var3[2] + var3[5]) / (double)2.0F + var9} : new double[]{clamp(var1.camX(), var3[0] + var5 + 0.15, var3[3] + var5 - 0.15), clamp(var1.camY(), var3[1] + var7 + 0.3, var3[4] + var7 - 0.2), clamp(var1.camZ(), var3[2] + var9 + 0.15, var3[5] + var9 - 0.15)};
         } else {
            return this.aimPoint;
         }
      }
   }

   private static boolean same(int[] var0, Plan var1) {
      return var0 != null && var0[0] == var1.x() && var0[1] == var1.y() && var0[2] == var1.z();
   }

   private static boolean alive(Object var0) {
      return var0 != null && !MinecraftBridge.isEntityRemoved(var0) && !MinecraftBridge.isDead(var0) && MinecraftBridge.getHealth(var0) > 0.0F;
   }

   private static double distance(Object var0, Object var1) {
      double var2 = MinecraftBridge.getEntityX(var0) - MinecraftBridge.getEntityX(var1);
      double var4 = MinecraftBridge.getEntityY(var0) - MinecraftBridge.getEntityY(var1);
      double var6 = MinecraftBridge.getEntityZ(var0) - MinecraftBridge.getEntityZ(var1);
      return Math.sqrt(var2 * var2 + var4 * var4 + var6 * var6);
   }

   private static double dist(double var0, double var2, double var4, double[] var6) {
      return Math.sqrt((var6[0] - var0) * (var6[0] - var0) + (var6[1] - var2) * (var6[1] - var2) + (var6[2] - var4) * (var6[2] - var4));
   }

   private static double clamp(double var0, double var2, double var4) {
      return var2 > var4 ? (var2 + var4) / (double)2.0F : Math.max(var2, Math.min(var4, var0));
   }

   private static float wrap(float var0) {
      var0 %= 360.0F;
      if (var0 >= 180.0F) {
         var0 -= 360.0F;
      }

      if (var0 < -180.0F) {
         var0 += 360.0F;
      }

      return var0;
   }

   public void onDisable() {
      this.finish();
      this.keyWasDown = false;
      this.lastFrame = 0L;
   }

   static {
      String[] var21 = new String[57];
      int var19 = 0;
      String var18 = "µO$à?] \u0010À®\u0006\u0096]åîEC\u0007<z@\u001c|á·\u0007+]lû÷37\f1\u0005~(]Êø\u008b\u0093¶Ý\u0093\røÿ\u0015\u0083\u0085Ø³ øô¬@W\u000bÍØ\u008ea(\u0006&A=òÁ\tú\u008cB\u0096;\u0004½\u0013Ç\r?°À\u0017§¦BÒ\u0094Ç=d¤\u000b\u0010ÃêjÈað\u0099j\n5\n³\u0096Ñn\u0004÷\u0083v²l\u000b pü\u001c\n¯¨@a1T\u0005{\u0000½Bc\b\u00855\u0004\u000fç&ê\u0014\u00072Í\u0084\u001b|\u0092\u001c\t\u0094¡Lîï'ØØ\"\u0011\u0006ôøIR^%Û¾\u001b>G\u000f¢\u0083#~\u0007ëf#F\u000eok\u000e:$l0ª/^<a=\u0017!)ð\u0005\u0018\u008b\u008b¾À\rÐ\u0006ó\u00049\u0095Qÿ=3ïÊì\u0005Ãæ\u0006ø\n\u000bùL\u0012nì£v\u0018Æ\u009d`\tß¤xá]ÿ%\u0082\u0002\u0004>QS\u008e\u0006\fÂ\u001e\u008d\u0017\u008fJyr8ï;knöZSèK\u0093¢Å\u0013\u0099\u0017g!ðR\u0003\u0092nûl!Ý$\u0088%-2¬ÑM5åo\u001aíüR\u0092»Ôµ!¥7º+ë<¯lË\u0012X\r'\u0089\u0086¦¢ks3f\u007f.\u008e²\u0005\u0095\u0089*¥q\tÐ\u0011è\u0080+áOn\u0011\u0007`\u0002\u0088ô á\u001f\u000eù\u008c5ÆÄ;$[\u0010ôÂKÒá\u0007-õ\u008e\nödÉ\u0004s´¥\u0097\u000e\u000bpH\u0003\u0099®9\u0005Ó\u0015Ààé.\u0007$`\u0019W`À»\u0004k[L\u00ad\n¦áTDs\u0089g\u0087a¿\u000e¸\u0099&iöTJSãÐG\u009c#G\fÒêI9\u0095ügãRtê¸\bU \u001e½¤p\u0082Þ\u00055¹\u0089Ï\u0092\u000bvìZ·ÿÚ0\u000f\u0085[v\u0006ÓÑp~2D\u0010\u0088\u008bþT¯kS]¨Í\u0007Xß\f \u009c\u0005>\u0094YûÅ\u0012]ø\u0088ç.gö\u0093\u001e½öèÝs/@©I\nWÖÍÆ\u0006>su\u001ac\u0006\u0011a§¾~\u0014\r\u00ad<{Ï\fðVÌ\u0002J6\u008c&\rsÆ¸k!\u0095)\u008c\u000fÝ,Y¾\u0006Ç\táð{¤\t\u0010â%@\u0015ïË\u007f§\b)Õ,ø\u0084H'{\u0011qÿú0~j|HãÒCØ.\u001d\u0082\u0095\u009d\u0006~\u008c_çÔ]";
      int var20 = "µO$à?] \u0010À®\u0006\u0096]åîEC\u0007<z@\u001c|á·\u0007+]lû÷37\f1\u0005~(]Êø\u008b\u0093¶Ý\u0093\røÿ\u0015\u0083\u0085Ø³ øô¬@W\u000bÍØ\u008ea(\u0006&A=òÁ\tú\u008cB\u0096;\u0004½\u0013Ç\r?°À\u0017§¦BÒ\u0094Ç=d¤\u000b\u0010ÃêjÈað\u0099j\n5\n³\u0096Ñn\u0004÷\u0083v²l\u000b pü\u001c\n¯¨@a1T\u0005{\u0000½Bc\b\u00855\u0004\u000fç&ê\u0014\u00072Í\u0084\u001b|\u0092\u001c\t\u0094¡Lîï'ØØ\"\u0011\u0006ôøIR^%Û¾\u001b>G\u000f¢\u0083#~\u0007ëf#F\u000eok\u000e:$l0ª/^<a=\u0017!)ð\u0005\u0018\u008b\u008b¾À\rÐ\u0006ó\u00049\u0095Qÿ=3ïÊì\u0005Ãæ\u0006ø\n\u000bùL\u0012nì£v\u0018Æ\u009d`\tß¤xá]ÿ%\u0082\u0002\u0004>QS\u008e\u0006\fÂ\u001e\u008d\u0017\u008fJyr8ï;knöZSèK\u0093¢Å\u0013\u0099\u0017g!ðR\u0003\u0092nûl!Ý$\u0088%-2¬ÑM5åo\u001aíüR\u0092»Ôµ!¥7º+ë<¯lË\u0012X\r'\u0089\u0086¦¢ks3f\u007f.\u008e²\u0005\u0095\u0089*¥q\tÐ\u0011è\u0080+áOn\u0011\u0007`\u0002\u0088ô á\u001f\u000eù\u008c5ÆÄ;$[\u0010ôÂKÒá\u0007-õ\u008e\nödÉ\u0004s´¥\u0097\u000e\u000bpH\u0003\u0099®9\u0005Ó\u0015Ààé.\u0007$`\u0019W`À»\u0004k[L\u00ad\n¦áTDs\u0089g\u0087a¿\u000e¸\u0099&iöTJSãÐG\u009c#G\fÒêI9\u0095ügãRtê¸\bU \u001e½¤p\u0082Þ\u00055¹\u0089Ï\u0092\u000bvìZ·ÿÚ0\u000f\u0085[v\u0006ÓÑp~2D\u0010\u0088\u008bþT¯kS]¨Í\u0007Xß\f \u009c\u0005>\u0094YûÅ\u0012]ø\u0088ç.gö\u0093\u001e½öèÝs/@©I\nWÖÍÆ\u0006>su\u001ac\u0006\u0011a§¾~\u0014\r\u00ad<{Ï\fðVÌ\u0002J6\u008c&\rsÆ¸k!\u0095)\u008c\u000fÝ,Y¾\u0006Ç\táð{¤\t\u0010â%@\u0015ïË\u007f§\b)Õ,ø\u0084H'{\u0011qÿú0~j|HãÒCØ.\u001d\u0082\u0095\u009d\u0006~\u008c_çÔ]".length();
      char var17 = '\n';
      int var26 = -1;

      label91:
      while(true) {
         ++var26;
         String var10000 = var18.substring(var26, var26 + var17);
         int var10001 = -1;

         while(true) {
            char[] var46;
            label86: {
               char[] var31 = var10000.toCharArray();
               int var10003 = var31.length;
               int var22 = 0;
               var46 = var31;
               int var34 = var10003;
               char[] var58;
               int var10004;
               if (var10003 <= 1) {
                  var58 = var31;
                  var10004 = var22;
               } else {
                  var46 = var31;
                  var34 = var10003;
                  if (var10003 <= var22) {
                     break label86;
                  }

                  var58 = var31;
                  var10004 = var22;
               }

               while(true) {
                  char var10005 = var58[var10004];
                  byte var10006;
                  switch (var22 % 7) {
                     case 0 -> var10006 = 50;
                     case 1 -> var10006 = 92;
                     case 2 -> var10006 = 3;
                     case 3 -> var10006 = 101;
                     case 4 -> var10006 = 126;
                     case 5 -> var10006 = 70;
                     default -> var10006 = 80;
                  }

                  var58[var10004] = (char)(var10005 ^ var10006);
                  ++var22;
                  if (var34 == 0) {
                     var10004 = var34;
                     var58 = var46;
                  } else {
                     if (var34 <= var22) {
                        break;
                     }

                     var58 = var46;
                     var10004 = var22;
                  }
               }
            }

            String var65 = (new String(var46)).intern();
            switch (var10001) {
               case 0:
                  var21[var19++] = var65;
                  if ((var26 += var17) >= var20) {
                     a = var21;
                     b = new String[57];
                     long var8 = 8557579492040644090L;
                     long[] var14 = new long[61];
                     int var11 = 0;
                     String var12 = "ªbk·B·Æ®z5á\u007fÜª\u0001Ô\u0095ñ·4òd\u0019i@þÊ¾ßÑ§y\u0015¥=ãÈ\u001bx|-\u0007b\u0091Y|ð¹\u0090\u0090¥\u0088\u00917X)¹õüC\u0092\u0097U®/á?qûMÍ\u001eÑô\u0090\u009dëîý\u009bèHéRP\u0011¿g\u00038\u0099\u0001|Y*\u0004[¬+\u008dØÈ\u008bd¿]\u0089(_ÌÃ7ªe3\u0016¢÷Ì¯!WÔ\u008a\u001dì?.ó©ÁÕ§í Ã#Ár¢T\u008fXµO\u001bi£\u0014»\u009fÖ´JÒ\u0087ª¾7&\u0096É\u0098ý\u009a7à#,âIÀßøÓUù/ê1í\u001aõ°M\u0086ó¿\u00adÈEä:z£õÖ&Ù|TAS®\u0006ê\u0011±_¥ê$Ä\u0081\u0014©j\u008d)\u0098Ã\u009a9Ý\\\u0014\u000eº\u0097h?ö+³\u0002§IykÝì\u0087ÿÏ\u0081j\u009c'¬ä2®NóXê&·!zJM?í \u001cçÑ\u0010^\u0084\u008e«ÇYU$k\u0010\u0016´sãpÂí\u00ad©\"p\u0011\u0017s\u0018>ÍÕ£´Öcr3\u0099\u0000µz¼/¸D\u0007Â\u00823\u0099ãI\u001c\u001b\u0093e\t¹\u009e;c\u001fµÎÈÊ\u0080ö¤_\u00004\u0098\u008eØ\u0087]Q éh«[6Ûpý\f§9¶5¿C4â]Cþü\u0004ÑãT\u0013O²\u0015þþÉ\u0082A^q>\u009e\rØÉ\u0085Ì\u0081+vuo\u0011\b[Ué³\u001a\f\u0013â¿\u0082i\u0015Õ\u009e3\u0005\u0004Á\u008eù$.\u001a¯¿AP\u0015¿\u00853\u008eÈØ\b\u0012¦ÇMy¿°áÑ0\u007f±\u0017k,3ì\f\u009b\u0085mõ\u0097\fk\u0014O!K,²ð¥£ö\u0094«\u0003ÓE\u0098s";
                     int var13 = "ªbk·B·Æ®z5á\u007fÜª\u0001Ô\u0095ñ·4òd\u0019i@þÊ¾ßÑ§y\u0015¥=ãÈ\u001bx|-\u0007b\u0091Y|ð¹\u0090\u0090¥\u0088\u00917X)¹õüC\u0092\u0097U®/á?qûMÍ\u001eÑô\u0090\u009dëîý\u009bèHéRP\u0011¿g\u00038\u0099\u0001|Y*\u0004[¬+\u008dØÈ\u008bd¿]\u0089(_ÌÃ7ªe3\u0016¢÷Ì¯!WÔ\u008a\u001dì?.ó©ÁÕ§í Ã#Ár¢T\u008fXµO\u001bi£\u0014»\u009fÖ´JÒ\u0087ª¾7&\u0096É\u0098ý\u009a7à#,âIÀßøÓUù/ê1í\u001aõ°M\u0086ó¿\u00adÈEä:z£õÖ&Ù|TAS®\u0006ê\u0011±_¥ê$Ä\u0081\u0014©j\u008d)\u0098Ã\u009a9Ý\\\u0014\u000eº\u0097h?ö+³\u0002§IykÝì\u0087ÿÏ\u0081j\u009c'¬ä2®NóXê&·!zJM?í \u001cçÑ\u0010^\u0084\u008e«ÇYU$k\u0010\u0016´sãpÂí\u00ad©\"p\u0011\u0017s\u0018>ÍÕ£´Öcr3\u0099\u0000µz¼/¸D\u0007Â\u00823\u0099ãI\u001c\u001b\u0093e\t¹\u009e;c\u001fµÎÈÊ\u0080ö¤_\u00004\u0098\u008eØ\u0087]Q éh«[6Ûpý\f§9¶5¿C4â]Cþü\u0004ÑãT\u0013O²\u0015þþÉ\u0082A^q>\u009e\rØÉ\u0085Ì\u0081+vuo\u0011\b[Ué³\u001a\f\u0013â¿\u0082i\u0015Õ\u009e3\u0005\u0004Á\u008eù$.\u001a¯¿AP\u0015¿\u00853\u008eÈØ\b\u0012¦ÇMy¿°áÑ0\u007f±\u0017k,3ì\f\u009b\u0085mõ\u0097\fk\u0014O!K,²ð¥£ö\u0094«\u0003ÓE\u0098s".length();
                     int var10 = 0;

                     label62:
                     while(true) {
                        var10001 = var10;
                        var10 += 8;
                        byte[] var15 = var12.substring(var10001, var10).getBytes("ISO-8859-1");
                        long[] var28 = var14;
                        var10001 = var11++;
                        long var51 = ((long)var15[0] & 255L) << 56 | ((long)var15[1] & 255L) << 48 | ((long)var15[2] & 255L) << 40 | ((long)var15[3] & 255L) << 32 | ((long)var15[4] & 255L) << 24 | ((long)var15[5] & 255L) << 16 | ((long)var15[6] & 255L) << 8 | (long)var15[7] & 255L;
                        byte var66 = -1;

                        while(true) {
                           long var71 = var51 ^ var8;
                           switch (var66) {
                              case 0:
                                 var28[var10001] = var71;
                                 if (var10 >= var13) {
                                    c = var14;
                                    d = new Integer[61];
                                    SETTLED_TICKS = a(22963, 7015478430583713157L);
                                    HIT_TICKS = a(24332, 2201241249448848144L);
                                    MAX_TICKS = a(1330, 9223190929907036457L);
                                    FRESH_HIT_TICKS = a(16364, 3439952699628358641L);
                                    WAIT_CRYSTAL_TICKS = a(5869, 5179531577083699916L);
                                    BLAST2_AT = a(31362, 3612761133615074971L);
                                    BLAST3_AT = a(28028, 958751766444759360L);
                                    AIR_HIT_TICKS = a(26087, 2001334395356074483L);
                                    BLAST1_AT = a(16364, 3439952699628358641L);
                                    AIM_TICKS = a(22410, 7961068803774440328L);
                                    long var0 = 2602231563129619200L;
                                    long[] var6 = new long[4];
                                    int var3 = 0;
                                    String var4 = "\u0089\u008c/H¿ÌK\u0088\u0010\u0014Å\u0089<°¨?";
                                    int var5 = "\u0089\u008c/H¿ÌK\u0088\u0010\u0014Å\u0089<°¨?".length();
                                    int var2 = 0;

                                    label52:
                                    while(true) {
                                       var10001 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                                       var28 = var6;
                                       var10001 = var3++;
                                       var51 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                                       var66 = -1;

                                       while(true) {
                                          var71 = var51 ^ var0;
                                          switch (var66) {
                                             case 0:
                                                var28[var10001] = var71;
                                                if (var2 >= var5) {
                                                   e = var6;
                                                   f = new Long[4];
                                                   GAP_HIT_OBBY = new int[][]{{2, a(19181, 6671448691050315495L)}, {3, a(12756, 6594686533933663684L)}};
                                                   GAP_OBBY1_CRYSTAL = new int[][]{{2, 5}, {3, a(7946, 9188871553269902108L)}, {4, 1}};
                                                   GAP_OBBY2_CRYSTAL = new int[][]{{3, a(15850, 4885688231519652351L)}, {4, a(8206, 679065277369553981L)}};
                                                   GAP_SPAWN_BREAK = new int[][]{{0, a(358, 3100639999854196036L)}, {1, a(25318, 1133005548511090393L)}};
                                                   GAP_BREAK_AIR_HIT = new int[][]{{2, 1}, {3, a(29812, 7525384555601543233L)}, {4, a(13664, 5536656156115665224L)}};
                                                   GAP_AIR_HIT_OBBY = new int[][]{{2, 1}, {3, a(7722, 7455391609103657528L)}, {4, 1}};
                                                   GAP_BREAK_OBBY = new int[][]{{a(29326, 3231316307068110505L), a(30906, 1908331384626662544L)}, {a(15883, 5943494355447417387L), a(13664, 5536656156115665224L)}};
                                                   GAP_BREAK_CRYSTAL = new int[][]{{2, a(22737, 332557979877305552L)}, {3, a(32455, 688755695615003337L)}};
                                                   SWITCH_LEAD = new int[][]{{1, a(31112, 3703274827947658684L)}, {2, a(25711, 6154163891150016586L)}};
                                                   return;
                                                }
                                                break;
                                             default:
                                                var28[var10001] = var71;
                                                if (var2 < var5) {
                                                   continue label52;
                                                }

                                                var4 = "\u009aàÄ[)~(\u0088² d^q¢6§";
                                                var5 = "\u009aàÄ[)~(\u0088² d^q¢6§".length();
                                                var2 = 0;
                                          }

                                          var10001 = var2;
                                          var2 += 8;
                                          var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                                          var28 = var6;
                                          var10001 = var3++;
                                          var51 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                                          var66 = 0;
                                       }
                                    }
                                 }
                                 break;
                              default:
                                 var28[var10001] = var71;
                                 if (var10 < var13) {
                                    continue label62;
                                 }

                                 var12 = "h\u0018\u0010µ\u008b×\u0012PFómö®hß\u0010";
                                 var13 = "h\u0018\u0010µ\u008b×\u0012PFómö®hß\u0010".length();
                                 var10 = 0;
                           }

                           var10001 = var10;
                           var10 += 8;
                           var15 = var12.substring(var10001, var10).getBytes("ISO-8859-1");
                           var28 = var14;
                           var10001 = var11++;
                           var51 = ((long)var15[0] & 255L) << 56 | ((long)var15[1] & 255L) << 48 | ((long)var15[2] & 255L) << 40 | ((long)var15[3] & 255L) << 32 | ((long)var15[4] & 255L) << 24 | ((long)var15[5] & 255L) << 16 | ((long)var15[6] & 255L) << 8 | (long)var15[7] & 255L;
                           var66 = 0;
                        }
                     }
                  }

                  var17 = var18.charAt(var26);
                  break;
               default:
                  var21[var19++] = var65;
                  if ((var26 += var17) < var20) {
                     var17 = var18.charAt(var26);
                     continue label91;
                  }

                  var18 = "åÆìÄ\u0098~\u0004s\u0081i{";
                  var20 = "åÆìÄ\u0098~\u0004s\u0081i{".length();
                  var17 = 6;
                  var26 = -1;
            }

            ++var26;
            var10000 = var18.substring(var26, var26 + var17);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ -30841) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 130;
            case 1 -> var10000 = 91;
            case 2 -> var10000 = 64;
            case 3 -> var10000 = 239;
            case 4 -> var10000 = 9;
            case 5 -> var10000 = 98;
            case 6 -> var10000 = 128;
            case 7 -> var10000 = 67;
            case 8 -> var10000 = 189;
            case 9 -> var10000 = 155;
            case 10 -> var10000 = 246;
            case 11 -> var10000 = 71;
            case 12 -> var10000 = 117;
            case 13 -> var10000 = 59;
            case 14 -> var10000 = 102;
            case 15 -> var10000 = 1;
            case 16 -> var10000 = 186;
            case 17 -> var10000 = 157;
            case 18 -> var10000 = 146;
            case 19 -> var10000 = 118;
            case 20 -> var10000 = 193;
            case 21 -> var10000 = 207;
            case 22 -> var10000 = 73;
            case 23 -> var10000 = 25;
            case 24 -> var10000 = 162;
            case 25 -> var10000 = 52;
            case 26 -> var10000 = 101;
            case 27 -> var10000 = 170;
            case 28 -> var10000 = 127;
            case 29 -> var10000 = 74;
            case 30 -> var10000 = 84;
            case 31 -> var10000 = 103;
            case 32 -> var10000 = 142;
            case 33 -> var10000 = 242;
            case 34 -> var10000 = 141;
            case 35 -> var10000 = 140;
            case 36 -> var10000 = 148;
            case 37 -> var10000 = 241;
            case 38 -> var10000 = 251;
            case 39 -> var10000 = 72;
            case 40 -> var10000 = 243;
            case 41 -> var10000 = 88;
            case 42 -> var10000 = 32;
            case 43 -> var10000 = 92;
            case 44 -> var10000 = 87;
            case 45 -> var10000 = 126;
            case 46 -> var10000 = 210;
            case 47 -> var10000 = 120;
            case 48 -> var10000 = 22;
            case 49 -> var10000 = 76;
            case 50 -> var10000 = 93;
            case 51 -> var10000 = 18;
            case 52 -> var10000 = 26;
            case 53 -> var10000 = 167;
            case 54 -> var10000 = 86;
            case 55 -> var10000 = 79;
            case 56 -> var10000 = 218;
            case 57 -> var10000 = 54;
            case 58 -> var10000 = 194;
            case 59 -> var10000 = 248;
            case 60 -> var10000 = 139;
            case 61 -> var10000 = 41;
            case 62 -> var10000 = 179;
            case 63 -> var10000 = 46;
            case 64 -> var10000 = 110;
            case 65 -> var10000 = 99;
            case 66 -> var10000 = 192;
            case 67 -> var10000 = 175;
            case 68 -> var10000 = 252;
            case 69 -> var10000 = 197;
            case 70 -> var10000 = 58;
            case 71 -> var10000 = 123;
            case 72 -> var10000 = 228;
            case 73 -> var10000 = 244;
            case 74 -> var10000 = 13;
            case 75 -> var10000 = 165;
            case 76 -> var10000 = 47;
            case 77 -> var10000 = 143;
            case 78 -> var10000 = 161;
            case 79 -> var10000 = 27;
            case 80 -> var10000 = 202;
            case 81 -> var10000 = 217;
            case 82 -> var10000 = 34;
            case 83 -> var10000 = 10;
            case 84 -> var10000 = 19;
            case 85 -> var10000 = 95;
            case 86 -> var10000 = 158;
            case 87 -> var10000 = 135;
            case 88 -> var10000 = 116;
            case 89 -> var10000 = 247;
            case 90 -> var10000 = 38;
            case 91 -> var10000 = 12;
            case 92 -> var10000 = 35;
            case 93 -> var10000 = 152;
            case 94 -> var10000 = 29;
            case 95 -> var10000 = 5;
            case 96 -> var10000 = 151;
            case 97 -> var10000 = 240;
            case 98 -> var10000 = 3;
            case 99 -> var10000 = 249;
            case 100 -> var10000 = 11;
            case 101 -> var10000 = 8;
            case 102 -> var10000 = 145;
            case 103 -> var10000 = 231;
            case 104 -> var10000 = 2;
            case 105 -> var10000 = 108;
            case 106 -> var10000 = 232;
            case 107 -> var10000 = 20;
            case 108 -> var10000 = 169;
            case 109 -> var10000 = 51;
            case 110 -> var10000 = 149;
            case 111 -> var10000 = 89;
            case 112 -> var10000 = 235;
            case 113 -> var10000 = 187;
            case 114 -> var10000 = 78;
            case 115 -> var10000 = 136;
            case 116 -> var10000 = 205;
            case 117 -> var10000 = 221;
            case 118 -> var10000 = 97;
            case 119 -> var10000 = 49;
            case 120 -> var10000 = 183;
            case 121 -> var10000 = 154;
            case 122 -> var10000 = 191;
            case 123 -> var10000 = 105;
            case 124 -> var10000 = 31;
            case 125 -> var10000 = 225;
            case 126 -> var10000 = 159;
            case 127 -> var10000 = 17;
            case 128 -> var10000 = 171;
            case 129 -> var10000 = 21;
            case 130 -> var10000 = 255;
            case 131 -> var10000 = 109;
            case 132 -> var10000 = 180;
            case 133 -> var10000 = 6;
            case 134 -> var10000 = 230;
            case 135 -> var10000 = 114;
            case 136 -> var10000 = 195;
            case 137 -> var10000 = 107;
            case 138 -> var10000 = 115;
            case 139 -> var10000 = 150;
            case 140 -> var10000 = 100;
            case 141 -> var10000 = 14;
            case 142 -> var10000 = 112;
            case 143 -> var10000 = 43;
            case 144 -> var10000 = 90;
            case 145 -> var10000 = 237;
            case 146 -> var10000 = 216;
            case 147 -> var10000 = 62;
            case 148 -> var10000 = 111;
            case 149 -> var10000 = 174;
            case 150 -> var10000 = 75;
            case 151 -> var10000 = 40;
            case 152 -> var10000 = 24;
            case 153 -> var10000 = 245;
            case 154 -> var10000 = 83;
            case 155 -> var10000 = 77;
            case 156 -> var10000 = 30;
            case 157 -> var10000 = 190;
            case 158 -> var10000 = 81;
            case 159 -> var10000 = 65;
            case 160 -> var10000 = 56;
            case 161 -> var10000 = 173;
            case 162 -> var10000 = 94;
            case 163 -> var10000 = 63;
            case 164 -> var10000 = 104;
            case 165 -> var10000 = 201;
            case 166 -> var10000 = 44;
            case 167 -> var10000 = 57;
            case 168 -> var10000 = 122;
            case 169 -> var10000 = 212;
            case 170 -> var10000 = 133;
            case 171 -> var10000 = 113;
            case 172 -> var10000 = 45;
            case 173 -> var10000 = 200;
            case 174 -> var10000 = 96;
            case 175 -> var10000 = 106;
            case 176 -> var10000 = 223;
            case 177 -> var10000 = 28;
            case 178 -> var10000 = 176;
            case 179 -> var10000 = 185;
            case 180 -> var10000 = 184;
            case 181 -> var10000 = 39;
            case 182 -> var10000 = 82;
            case 183 -> var10000 = 7;
            case 184 -> var10000 = 4;
            case 185 -> var10000 = 254;
            case 186 -> var10000 = 42;
            case 187 -> var10000 = 208;
            case 188 -> var10000 = 236;
            case 189 -> var10000 = 23;
            case 190 -> var10000 = 68;
            case 191 -> var10000 = 50;
            case 192 -> var10000 = 234;
            case 193 -> var10000 = 131;
            case 194 -> var10000 = 196;
            case 195 -> var10000 = 166;
            case 196 -> var10000 = 215;
            case 197 -> var10000 = 168;
            case 198 -> var10000 = 66;
            case 199 -> var10000 = 204;
            case 200 -> var10000 = 147;
            case 201 -> var10000 = 224;
            case 202 -> var10000 = 209;
            case 203 -> var10000 = 134;
            case 204 -> var10000 = 220;
            case 205 -> var10000 = 178;
            case 206 -> var10000 = 53;
            case 207 -> var10000 = 124;
            case 208 -> var10000 = 61;
            case 209 -> var10000 = 164;
            case 210 -> var10000 = 203;
            case 211 -> var10000 = 33;
            case 212 -> var10000 = 206;
            case 213 -> var10000 = 119;
            case 214 -> var10000 = 233;
            case 215 -> var10000 = 182;
            case 216 -> var10000 = 181;
            case 217 -> var10000 = 55;
            case 218 -> var10000 = 69;
            case 219 -> var10000 = 219;
            case 220 -> var10000 = 137;
            case 221 -> var10000 = 36;
            case 222 -> var10000 = 227;
            case 223 -> var10000 = 177;
            case 224 -> var10000 = 70;
            case 225 -> var10000 = 138;
            case 226 -> var10000 = 250;
            case 227 -> var10000 = 226;
            case 228 -> var10000 = 214;
            case 229 -> var10000 = 253;
            case 230 -> var10000 = 229;
            case 231 -> var10000 = 198;
            case 232 -> var10000 = 199;
            case 233 -> var10000 = 144;
            case 234 -> var10000 = 163;
            case 235 -> var10000 = 213;
            case 236 -> var10000 = 172;
            case 237 -> var10000 = 15;
            case 238 -> var10000 = 188;
            case 239 -> var10000 = 48;
            case 240 -> var10000 = 211;
            case 241 -> var10000 = 129;
            case 242 -> var10000 = 238;
            case 243 -> var10000 = 16;
            case 244 -> var10000 = 121;
            case 245 -> var10000 = 37;
            case 246 -> var10000 = 153;
            case 247 -> var10000 = 160;
            case 248 -> var10000 = 80;
            case 249 -> var10000 = 85;
            case 250 -> var10000 = 60;
            case 251 -> var10000 = 125;
            case 252 -> var10000 = 156;
            case 253 -> var10000 = 0;
            case 254 -> var10000 = 132;
            default -> var10000 = 222;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 13362;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }

   private static long b(int var0, long var1) {
      int var3 = (var0 ^ (int)var1 ^ 6825) & 32767;
      if (f[var3] == null) {
         f[var3] = e[var3] ^ var1;
      }

      return f[var3];
   }

   private static record Plan(int x, int y, int z, boolean needsObby, double[][] obbyAims, double[][] crystalAims, double score) {
      private Plan(int var1, int var2, int var3, boolean var4, double[][] var5, double[][] var6, double var7) {
         this.x = var1;
         this.y = var2;
         this.z = var3;
         this.needsObby = var4;
         this.obbyAims = var5;
         this.crystalAims = var6;
         this.score = var7;
      }

      Object cell() {
         return MinecraftBridge.blockPos(this.x, this.y, this.z);
      }
   }

   private static enum Step {
      IDLE,
      HIT,
      OBBY1,
      CRYSTAL1,
      BREAK1,
      AIR_HIT,
      OBBY2,
      CRYSTAL2,
      BREAK2,
      CRYSTAL3,
      BREAK3;

      private static final long[] a;
      private static final Integer[] b;

      // $FF: synthetic method
      private static Step[] $values() {
         Step[] var10000 = new Step[a(30156, 1887626038245436723L)];
         var10000[0] = IDLE;
         var10000[1] = HIT;
         var10000[2] = OBBY1;
         var10000[3] = CRYSTAL1;
         var10000[4] = BREAK1;
         var10000[5] = AIR_HIT;
         var10000[a(26146, 7720027854299479774L)] = OBBY2;
         var10000[a(8197, 2327016605049059571L)] = CRYSTAL2;
         var10000[a(9135, 2381691593564420949L)] = BREAK2;
         var10000[a(4764, 5868743599949040226L)] = CRYSTAL3;
         var10000[a(8399, 4153566428231137330L)] = BREAK3;
         return var10000;
      }

      static {
         String[] var8 = new String[11];
         int var12 = 0;
         String var11 = "g'<\u0003Lw\u000e\u0016\u0006f' \u0011S\u0005\bg'<\u0003Lw\u000e\u0015\u0003l<1\u0004m1)\u0015\u0006f' \u0011S\u0007\bg'<\u0003Lw\u000e\u0017\u0007e<7\u000fP\u007f\u0016\u0005k7'\t*";
         int var13 = "g'<\u0003Lw\u000e\u0016\u0006f' \u0011S\u0005\bg'<\u0003Lw\u000e\u0015\u0003l<1\u0004m1)\u0015\u0006f' \u0011S\u0007\bg'<\u0003Lw\u000e\u0017\u0007e<7\u000fP\u007f\u0016\u0005k7'\t*".length();
         char var10 = '\b';
         int var17 = -1;

         label73:
         while(true) {
            ++var17;
            String var10000 = var11.substring(var17, var17 + var10);
            int var10001 = -1;

            while(true) {
               char[] var33;
               label68: {
                  char[] var21 = var10000.toCharArray();
                  int var10003 = var21.length;
                  int var14 = 0;
                  var33 = var21;
                  int var24 = var10003;
                  char[] var43;
                  int var10004;
                  if (var10003 <= 1) {
                     var43 = var21;
                     var10004 = var14;
                  } else {
                     var33 = var21;
                     var24 = var10003;
                     if (var10003 <= var14) {
                        break label68;
                     }

                     var43 = var21;
                     var10004 = var14;
                  }

                  while(true) {
                     char var10005 = var43[var10004];
                     byte var10006;
                     switch (var14 % 7) {
                        case 0 -> var10006 = 36;
                        case 1 -> var10006 = 117;
                        case 2 -> var10006 = 101;
                        case 3 -> var10006 = 80;
                        case 4 -> var10006 = 24;
                        case 5 -> var10006 = 54;
                        default -> var10006 = 66;
                     }

                     var43[var10004] = (char)(var10005 ^ var10006);
                     ++var14;
                     if (var24 == 0) {
                        var10004 = var24;
                        var43 = var33;
                     } else {
                        if (var24 <= var14) {
                           break;
                        }

                        var43 = var33;
                        var10004 = var14;
                     }
                  }
               }

               String var50 = (new String(var33)).intern();
               switch (var10001) {
                  case 0:
                     var8[var12++] = var50;
                     if ((var17 += var10) >= var13) {
                        long var0 = 6829769926017586677L;
                        long[] var6 = new long[11];
                        int var3 = 0;
                        String var4 = "ÿ¸ù\u0006¶H«-ÿÌ¨\u001e\u0010XíÍóJÆÜ1#ß\u009e1\u0085Û\u0019\u0097\u00898Í\u009aG=ÞÃðú zwÍ¹\u001cÏG\u0084\u0015h'\u0098W\u001cn¨T¤óïZMi\u001d\u000eýÅ`\u009eKG4";
                        int var5 = "ÿ¸ù\u0006¶H«-ÿÌ¨\u001e\u0010XíÍóJÆÜ1#ß\u009e1\u0085Û\u0019\u0097\u00898Í\u009aG=ÞÃðú zwÍ¹\u001cÏG\u0084\u0015h'\u0098W\u001cn¨T¤óïZMi\u001d\u000eýÅ`\u009eKG4".length();
                        int var2 = 0;

                        label44:
                        while(true) {
                           var10001 = var2;
                           var2 += 8;
                           byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                           long[] var19 = var6;
                           var10001 = var3++;
                           long var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                           byte var51 = -1;

                           while(true) {
                              long var54 = var38 ^ var0;
                              switch (var51) {
                                 case 0:
                                    var19[var10001] = var54;
                                    if (var2 >= var5) {
                                       a = var6;
                                       b = new Integer[11];
                                       IDLE = new Step(var8[4], 0);
                                       HIT = new Step(var8[3], 1);
                                       OBBY1 = new Step(var8[9], 2);
                                       CRYSTAL1 = new Step(var8[2], 3);
                                       BREAK1 = new Step(var8[5], 4);
                                       AIR_HIT = new Step(var8[7], 5);
                                       OBBY2 = new Step(var8[8], a(14251, 2291032412066180947L));
                                       CRYSTAL2 = new Step(var8[0], a(9236, 2302080530816040175L));
                                       BREAK2 = new Step(var8[10], a(2621, 6988690131002053321L));
                                       CRYSTAL3 = new Step(var8[6], a(6078, 7212417501353135947L));
                                       BREAK3 = new Step(var8[1], a(2690, 8767556082624352891L));
                                       return;
                                    }
                                    break;
                                 default:
                                    var19[var10001] = var54;
                                    if (var2 < var5) {
                                       continue label44;
                                    }

                                    var4 = "\bpl\u0006Â\u001aZ·²t\u0094=\u0013\u008eí\u0001";
                                    var5 = "\bpl\u0006Â\u001aZ·²t\u0094=\u0013\u008eí\u0001".length();
                                    var2 = 0;
                              }

                              var10001 = var2;
                              var2 += 8;
                              var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                              var19 = var6;
                              var10001 = var3++;
                              var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                              var51 = 0;
                           }
                        }
                     }

                     var10 = var11.charAt(var17);
                     break;
                  default:
                     var8[var12++] = var50;
                     if ((var17 += var10) < var13) {
                        var10 = var11.charAt(var17);
                        continue label73;
                     }

                     var11 = "k7'\t)\u0006f' \u0011S\u0004";
                     var13 = "k7'\t)\u0006f' \u0011S\u0004".length();
                     var10 = 5;
                     var17 = -1;
               }

               ++var17;
               var10000 = var11.substring(var17, var17 + var10);
               var10001 = 0;
            }
         }
      }

      private static int a(int var0, long var1) {
         int var3 = var0 ^ (int)(var1 & 32767L) ^ 22780;
         if (b[var3] == null) {
            b[var3] = (int)(a[var3] ^ var1);
         }

         return b[var3];
      }
   }
}
