package lol.wocky.feature.combat;

import java.util.concurrent.ThreadLocalRandom;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.ModuleManager;
import lol.wocky.core.module.property.EnumProperty;
import lol.wocky.core.module.property.KeyProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;

public class DoubleAnchor extends Module {
   private static final String ANCHOR;
   private static final String GLOWSTONE;
   private final EnumProperty<Mode> mode;
   private final EnumProperty<Activation> activation;
   private final KeyProperty activateKey;
   private final NumberProperty switchDelay;
   private final NumberProperty switchChance;
   private final NumberProperty explodeSlot;
   private Stage stage;
   private boolean activateWasDown;
   private int switchClock;
   private int actionCooldown;
   private int sequenceClock;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;

   public DoubleAnchor() {
      super(a(-31338, -4073), a(-31344, 18127), ModuleCategory.CPVP);
      this.mode = new EnumProperty<Mode>(a(-31336, 12598), DoubleAnchor.Mode.LEGIT);
      this.activation = new EnumProperty<Activation>(a(-31339, 4910), DoubleAnchor.Activation.HOLD);
      this.activateKey = new KeyProperty(a(-31340, -25766), 0);
      this.switchDelay = new NumberProperty(a(-31335, -27337), 0, 0, a(23362, 2671305265356275805L), 1);
      this.switchChance = new NumberProperty(a(-31343, 3780), a(18484, 8512866310889149225L), 0, a(13569, 7233879352383630879L), 1);
      this.explodeSlot = new NumberProperty(a(-31332, -8726), 1, 1, a(28346, 3676393726453822880L), 1);
      this.stage = DoubleAnchor.Stage.IDLE;
      this.switchDelay.hideIf(() -> this.mode.getValue() == DoubleAnchor.Mode.BLATANT);
      this.switchChance.hideIf(() -> this.mode.getValue() == DoubleAnchor.Mode.BLATANT);
      Property[] var10001 = new Property[a(17782, 3956689643131412078L)];
      var10001[0] = this.mode;
      var10001[1] = this.activation;
      var10001[2] = this.activateKey;
      var10001[3] = this.switchDelay;
      var10001[4] = this.switchChance;
      var10001[5] = this.explodeSlot;
      this.addProperties(var10001);
   }

   public static boolean isRunning() {
      DoubleAnchor var0 = (DoubleAnchor)ModuleManager.getByClass(DoubleAnchor.class);
      return var0 != null && var0.isEnabled() && var0.stage != DoubleAnchor.Stage.IDLE;
   }

   public void onEnable() {
      this.resetSequence();
      this.activateWasDown = false;
   }

   public void onDisable() {
      this.resetSequence();
      this.activateWasDown = false;
   }

   public void onTick() {
      boolean var1 = MinecraftBridge.getCurrentScreen() == null && this.activateKey.getKey() != 0 && this.activateKey.isDown();
      boolean var2 = var1 && !this.activateWasDown;
      this.activateWasDown = var1;
      if (MinecraftBridge.getCurrentScreen() != null) {
         this.resetSequence();
      } else {
         if (this.stage == DoubleAnchor.Stage.IDLE) {
            boolean var3 = this.activation.getValue() == DoubleAnchor.Activation.HOLD ? var1 : var2;
            if (var3 && this.hasBlockTarget()) {
               this.stage = DoubleAnchor.Stage.PLACE_FIRST;
            }
         } else if (this.activation.getValue() == DoubleAnchor.Activation.HOLD && !var1) {
            this.resetSequence();
            return;
         }

         if (this.stage != DoubleAnchor.Stage.IDLE) {
            ++this.sequenceClock;
            int var4 = this.mode.getValue() == DoubleAnchor.Mode.BLATANT ? a(26754, 3609234877983372187L) : a(26244, 7277516711813168536L) + this.switchDelay.intValue() * 4;
            if (this.sequenceClock > var4) {
               this.resetSequence();
            } else {
               MinecraftBridge.setUseKeyPressed(false);
               if (this.actionCooldown > 0) {
                  --this.actionCooldown;
               } else {
                  switch (this.stage.ordinal()) {
                     case 1 -> this.runItemAction(a(-31337, -15276), DoubleAnchor.Stage.CHARGE_FIRST, true);
                     case 2 -> this.runItemAction(a(-31330, -7747), DoubleAnchor.Stage.DETONATE_AND_PLACE_SECOND, true);
                     case 3 -> this.runDoubleAnchorAction();
                     case 4 -> this.runItemAction(a(-31334, 6004), DoubleAnchor.Stage.DETONATE_SECOND, false);
                     case 5 -> this.runSlotAction(this.explodeSlot.intValue() - 1);
                  }

               }
            }
         }
      }
   }

   private void runItemAction(String var1, Stage var2, boolean var3) {
      if (this.selectItem(var1, var3)) {
         if (this.rightClickTarget()) {
            this.advance(var2);
         }

      }
   }

   private void runDoubleAnchorAction() {
      if (this.selectItem(a(-31329, -23278), false)) {
         Object var1 = MinecraftBridge.getCrosshairTarget();
         if (MinecraftBridge.isBlockHit(var1)) {
            MinecraftBridge.interactBlock(var1, true);
            MinecraftBridge.interactBlockAgain(var1, true);
            this.advance(DoubleAnchor.Stage.CHARGE_SECOND);
         }
      }
   }

   private void runSlotAction(int var1) {
      Object var2 = MinecraftBridge.getCrosshairTarget();
      if (!MinecraftBridge.isBlockHit(var2)) {
         this.resetSequence();
      } else if (this.selectSlot(var1)) {
         MinecraftBridge.interactBlock(var2, true);
         this.resetSequence();
      }
   }

   private boolean selectItem(String var1, boolean var2) {
      if (MinecraftBridge.isHolding(var1)) {
         this.switchClock = 0;
         return true;
      } else if (this.mode.getValue() == DoubleAnchor.Mode.BLATANT) {
         this.switchClock = 0;
         return MinecraftBridge.selectHotbarItem(var1);
      } else if (!this.switchReady()) {
         return false;
      } else if (!this.passesSwitchChance()) {
         this.switchClock = 0;
         return false;
      } else {
         this.switchClock = 0;
         boolean var3 = MinecraftBridge.selectHotbarItem(var1);
         return var2 && var3;
      }
   }

   private boolean selectSlot(int var1) {
      if (MinecraftBridge.getSelectedSlot() == var1) {
         this.switchClock = 0;
         return true;
      } else if (this.mode.getValue() == DoubleAnchor.Mode.BLATANT) {
         this.switchClock = 0;
         MinecraftBridge.setSelectedSlot(var1);
         return MinecraftBridge.getSelectedSlot() == var1;
      } else if (!this.switchReady()) {
         return false;
      } else if (!this.passesSwitchChance()) {
         this.switchClock = 0;
         return false;
      } else {
         this.switchClock = 0;
         MinecraftBridge.setSelectedSlot(var1);
         return false;
      }
   }

   private boolean switchReady() {
      if (this.switchClock < this.switchDelay.intValue()) {
         ++this.switchClock;
         return false;
      } else {
         return true;
      }
   }

   private boolean passesSwitchChance() {
      return ThreadLocalRandom.current().nextInt(1, a(28991, 9173134670879828516L)) <= this.switchChance.intValue();
   }

   private boolean rightClickTarget() {
      Object var1 = MinecraftBridge.getCrosshairTarget();
      return MinecraftBridge.isBlockHit(var1) && MinecraftBridge.interactBlock(var1, true);
   }

   private boolean hasBlockTarget() {
      return MinecraftBridge.isBlockHit(MinecraftBridge.getCrosshairTarget());
   }

   private void advance(Stage var1) {
      this.stage = var1;
      this.switchClock = 0;
      this.actionCooldown = this.mode.getValue() == DoubleAnchor.Mode.BLATANT ? 0 : 1;
   }

   private void resetSequence() {
      this.stage = DoubleAnchor.Stage.IDLE;
      this.switchClock = 0;
      this.actionCooldown = 0;
      this.sequenceClock = 0;
   }

   static {
      String[] var13 = new String[14];
      int var11 = 0;
      String var10 = "\u0007¦\u0012\u0014\u0080;é\u0094U\fzBÄ\u0005ºq;\u0081rnNk\u000e´4Ïi¶p~¯\u00829(ß1g\tTqxîÍd@\u007f`\fZÚ\ràµÚ\u0012\u001d\u008c\u0015o\t\u00049\u0014±3\u000eÌsÀ\u0081WmB\f\u0005MØQ/¶\t(V÷\n<ø~ì§\n\u0080\u008d\u001b\u0081ÜAÜk\u0081Q\f¤M\u009f\u0099LBÎ\u0007\u008ct\u0086æ\u000eïb¤£Û)Ó\u00847\\\u009esçò\f\u000e\u0000n¶IÉ\u0002ùÅâ\u008ex";
      int var12 = "\u0007¦\u0012\u0014\u0080;é\u0094U\fzBÄ\u0005ºq;\u0081rnNk\u000e´4Ïi¶p~¯\u00829(ß1g\tTqxîÍd@\u007f`\fZÚ\ràµÚ\u0012\u001d\u008c\u0015o\t\u00049\u0014±3\u000eÌsÀ\u0081WmB\f\u0005MØQ/¶\t(V÷\n<ø~ì§\n\u0080\u008d\u001b\u0081ÜAÜk\u0081Q\f¤M\u009f\u0099LBÎ\u0007\u008ct\u0086æ\u000eïb¤£Û)Ó\u00847\\\u009esçò\f\u000e\u0000n¶IÉ\u0002ùÅâ\u008ex".length();
      char var9 = '\t';
      int var17 = -1;

      label73:
      while(true) {
         ++var17;
         String var10000 = var10.substring(var17, var17 + var9);
         int var10001 = -1;

         while(true) {
            char[] var33;
            label68: {
               char[] var21 = var10000.toCharArray();
               int var10003 = var21.length;
               int var14 = 0;
               var33 = var21;
               int var24 = var10003;
               char[] var43;
               int var10004;
               if (var10003 <= 1) {
                  var43 = var21;
                  var10004 = var14;
               } else {
                  var33 = var21;
                  var24 = var10003;
                  if (var10003 <= var14) {
                     break label68;
                  }

                  var43 = var21;
                  var10004 = var14;
               }

               while(true) {
                  char var10005 = var43[var10004];
                  byte var10006;
                  switch (var14 % 7) {
                     case 0 -> var10006 = 33;
                     case 1 -> var10006 = 43;
                     case 2 -> var10006 = 50;
                     case 3 -> var10006 = 51;
                     case 4 -> var10006 = 117;
                     case 5 -> var10006 = 50;
                     default -> var10006 = 37;
                  }

                  var43[var10004] = (char)(var10005 ^ var10006);
                  ++var14;
                  if (var24 == 0) {
                     var10004 = var24;
                     var43 = var33;
                  } else {
                     if (var24 <= var14) {
                        break;
                     }

                     var43 = var33;
                     var10004 = var14;
                  }
               }
            }

            String var50 = (new String(var33)).intern();
            switch (var10001) {
               case 0:
                  var13[var11++] = var50;
                  if ((var17 += var9) >= var12) {
                     a = var13;
                     b = new String[14];
                     ANCHOR = a(-31333, -25603);
                     GLOWSTONE = a(-31331, 27081);
                     long var0 = 1073708909181137414L;
                     long[] var6 = new long[8];
                     int var3 = 0;
                     String var4 = ")èítÌ(Ç¯\u000e\u009aY×ÕuXGÑ \u0003|2¹ln\u000bs²\u007fÖÏÁ\u0097Yó¹¢Ñ2\u001c}\u009e\u008c\u0015Û?ØòO";
                     int var5 = ")èítÌ(Ç¯\u000e\u009aY×ÕuXGÑ \u0003|2¹ln\u000bs²\u007fÖÏÁ\u0097Yó¹¢Ñ2\u001c}\u009e\u008c\u0015Û?ØòO".length();
                     int var2 = 0;

                     label44:
                     while(true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var19 = var6;
                        var10001 = var3++;
                        long var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                        byte var51 = -1;

                        while(true) {
                           long var54 = var38 ^ var0;
                           switch (var51) {
                              case 0:
                                 var19[var10001] = var54;
                                 if (var2 >= var5) {
                                    c = var6;
                                    d = new Integer[8];
                                    return;
                                 }
                                 break;
                              default:
                                 var19[var10001] = var54;
                                 if (var2 < var5) {
                                    continue label44;
                                 }

                                 var4 = ".\rée]~O\u008eeÇ9§ë\u0019áK";
                                 var5 = ".\rée]~O\u008eeÇ9§ë\u0019áK".length();
                                 var2 = 0;
                           }

                           var10001 = var2;
                           var2 += 8;
                           var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                           var19 = var6;
                           var10001 = var3++;
                           var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                           var51 = 0;
                        }
                     }
                  }

                  var9 = var10.charAt(var17);
                  break;
               default:
                  var13[var11++] = var50;
                  if ((var17 += var9) < var12) {
                     var9 = var10.charAt(var17);
                     continue label73;
                  }

                  var10 = "\u0003ç&GÐ.¾\u0084\u0014Ìß\u0084i+\u008e*±»\u0086__©/*U·y+êµ\u0003\u0086Ñ«\u009ep\u0017\u0085T4\u0095Á}Q\u0097·¡µ\u001d\u009em©G<\t¦\u0080";
                  var12 = "\u0003ç&GÐ.¾\u0084\u0014Ìß\u0084i+\u008e*±»\u0086__©/*U·y+êµ\u0003\u0086Ñ«\u009ep\u0017\u0085T4\u0095Á}Q\u0097·¡µ\u001d\u009em©G<\t¦\u0080".length();
                  var9 = '\r';
                  var17 = -1;
            }

            ++var17;
            var10000 = var10.substring(var17, var17 + var9);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ -31331) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 169;
            case 1 -> var10000 = 56;
            case 2 -> var10000 = 102;
            case 3 -> var10000 = 76;
            case 4 -> var10000 = 189;
            case 5 -> var10000 = 177;
            case 6 -> var10000 = 246;
            case 7 -> var10000 = 58;
            case 8 -> var10000 = 147;
            case 9 -> var10000 = 6;
            case 10 -> var10000 = 184;
            case 11 -> var10000 = 226;
            case 12 -> var10000 = 251;
            case 13 -> var10000 = 154;
            case 14 -> var10000 = 141;
            case 15 -> var10000 = 60;
            case 16 -> var10000 = 118;
            case 17 -> var10000 = 200;
            case 18 -> var10000 = 232;
            case 19 -> var10000 = 66;
            case 20 -> var10000 = 110;
            case 21 -> var10000 = 90;
            case 22 -> var10000 = 157;
            case 23 -> var10000 = 203;
            case 24 -> var10000 = 225;
            case 25 -> var10000 = 85;
            case 26 -> var10000 = 123;
            case 27 -> var10000 = 195;
            case 28 -> var10000 = 194;
            case 29 -> var10000 = 140;
            case 30 -> var10000 = 84;
            case 31 -> var10000 = 233;
            case 32 -> var10000 = 144;
            case 33 -> var10000 = 219;
            case 34 -> var10000 = 83;
            case 35 -> var10000 = 139;
            case 36 -> var10000 = 98;
            case 37 -> var10000 = 32;
            case 38 -> var10000 = 136;
            case 39 -> var10000 = 188;
            case 40 -> var10000 = 238;
            case 41 -> var10000 = 133;
            case 42 -> var10000 = 122;
            case 43 -> var10000 = 211;
            case 44 -> var10000 = 26;
            case 45 -> var10000 = 231;
            case 46 -> var10000 = 255;
            case 47 -> var10000 = 172;
            case 48 -> var10000 = 235;
            case 49 -> var10000 = 80;
            case 50 -> var10000 = 248;
            case 51 -> var10000 = 181;
            case 52 -> var10000 = 186;
            case 53 -> var10000 = 143;
            case 54 -> var10000 = 9;
            case 55 -> var10000 = 193;
            case 56 -> var10000 = 8;
            case 57 -> var10000 = 45;
            case 58 -> var10000 = 134;
            case 59 -> var10000 = 198;
            case 60 -> var10000 = 206;
            case 61 -> var10000 = 148;
            case 62 -> var10000 = 234;
            case 63 -> var10000 = 27;
            case 64 -> var10000 = 44;
            case 65 -> var10000 = 93;
            case 66 -> var10000 = 120;
            case 67 -> var10000 = 250;
            case 68 -> var10000 = 40;
            case 69 -> var10000 = 218;
            case 70 -> var10000 = 220;
            case 71 -> var10000 = 22;
            case 72 -> var10000 = 208;
            case 73 -> var10000 = 12;
            case 74 -> var10000 = 63;
            case 75 -> var10000 = 79;
            case 76 -> var10000 = 108;
            case 77 -> var10000 = 132;
            case 78 -> var10000 = 160;
            case 79 -> var10000 = 41;
            case 80 -> var10000 = 249;
            case 81 -> var10000 = 68;
            case 82 -> var10000 = 173;
            case 83 -> var10000 = 111;
            case 84 -> var10000 = 14;
            case 85 -> var10000 = 77;
            case 86 -> var10000 = 72;
            case 87 -> var10000 = 126;
            case 88 -> var10000 = 216;
            case 89 -> var10000 = 87;
            case 90 -> var10000 = 53;
            case 91 -> var10000 = 204;
            case 92 -> var10000 = 125;
            case 93 -> var10000 = 191;
            case 94 -> var10000 = 197;
            case 95 -> var10000 = 114;
            case 96 -> var10000 = 28;
            case 97 -> var10000 = 13;
            case 98 -> var10000 = 202;
            case 99 -> var10000 = 192;
            case 100 -> var10000 = 37;
            case 101 -> var10000 = 104;
            case 102 -> var10000 = 61;
            case 103 -> var10000 = 135;
            case 104 -> var10000 = 243;
            case 105 -> var10000 = 178;
            case 106 -> var10000 = 209;
            case 107 -> var10000 = 237;
            case 108 -> var10000 = 253;
            case 109 -> var10000 = 36;
            case 110 -> var10000 = 156;
            case 111 -> var10000 = 69;
            case 112 -> var10000 = 39;
            case 113 -> var10000 = 30;
            case 114 -> var10000 = 113;
            case 115 -> var10000 = 64;
            case 116 -> var10000 = 117;
            case 117 -> var10000 = 171;
            case 118 -> var10000 = 176;
            case 119 -> var10000 = 182;
            case 120 -> var10000 = 10;
            case 121 -> var10000 = 57;
            case 122 -> var10000 = 185;
            case 123 -> var10000 = 15;
            case 124 -> var10000 = 59;
            case 125 -> var10000 = 165;
            case 126 -> var10000 = 34;
            case 127 -> var10000 = 49;
            case 128 -> var10000 = 153;
            case 129 -> var10000 = 5;
            case 130 -> var10000 = 252;
            case 131 -> var10000 = 95;
            case 132 -> var10000 = 167;
            case 133 -> var10000 = 150;
            case 134 -> var10000 = 70;
            case 135 -> var10000 = 158;
            case 136 -> var10000 = 71;
            case 137 -> var10000 = 221;
            case 138 -> var10000 = 46;
            case 139 -> var10000 = 7;
            case 140 -> var10000 = 51;
            case 141 -> var10000 = 97;
            case 142 -> var10000 = 112;
            case 143 -> var10000 = 2;
            case 144 -> var10000 = 18;
            case 145 -> var10000 = 103;
            case 146 -> var10000 = 119;
            case 147 -> var10000 = 245;
            case 148 -> var10000 = 91;
            case 149 -> var10000 = 43;
            case 150 -> var10000 = 183;
            case 151 -> var10000 = 146;
            case 152 -> var10000 = 247;
            case 153 -> var10000 = 96;
            case 154 -> var10000 = 168;
            case 155 -> var10000 = 88;
            case 156 -> var10000 = 222;
            case 157 -> var10000 = 3;
            case 158 -> var10000 = 213;
            case 159 -> var10000 = 217;
            case 160 -> var10000 = 92;
            case 161 -> var10000 = 78;
            case 162 -> var10000 = 205;
            case 163 -> var10000 = 4;
            case 164 -> var10000 = 109;
            case 165 -> var10000 = 239;
            case 166 -> var10000 = 89;
            case 167 -> var10000 = 159;
            case 168 -> var10000 = 124;
            case 169 -> var10000 = 48;
            case 170 -> var10000 = 19;
            case 171 -> var10000 = 52;
            case 172 -> var10000 = 166;
            case 173 -> var10000 = 137;
            case 174 -> var10000 = 25;
            case 175 -> var10000 = 210;
            case 176 -> var10000 = 38;
            case 177 -> var10000 = 215;
            case 178 -> var10000 = 241;
            case 179 -> var10000 = 115;
            case 180 -> var10000 = 162;
            case 181 -> var10000 = 155;
            case 182 -> var10000 = 106;
            case 183 -> var10000 = 31;
            case 184 -> var10000 = 75;
            case 185 -> var10000 = 82;
            case 186 -> var10000 = 35;
            case 187 -> var10000 = 116;
            case 188 -> var10000 = 149;
            case 189 -> var10000 = 161;
            case 190 -> var10000 = 73;
            case 191 -> var10000 = 190;
            case 192 -> var10000 = 214;
            case 193 -> var10000 = 107;
            case 194 -> var10000 = 229;
            case 195 -> var10000 = 127;
            case 196 -> var10000 = 29;
            case 197 -> var10000 = 212;
            case 198 -> var10000 = 223;
            case 199 -> var10000 = 21;
            case 200 -> var10000 = 67;
            case 201 -> var10000 = 131;
            case 202 -> var10000 = 199;
            case 203 -> var10000 = 17;
            case 204 -> var10000 = 100;
            case 205 -> var10000 = 196;
            case 206 -> var10000 = 152;
            case 207 -> var10000 = 227;
            case 208 -> var10000 = 86;
            case 209 -> var10000 = 62;
            case 210 -> var10000 = 105;
            case 211 -> var10000 = 54;
            case 212 -> var10000 = 11;
            case 213 -> var10000 = 145;
            case 214 -> var10000 = 207;
            case 215 -> var10000 = 55;
            case 216 -> var10000 = 50;
            case 217 -> var10000 = 175;
            case 218 -> var10000 = 244;
            case 219 -> var10000 = 180;
            case 220 -> var10000 = 201;
            case 221 -> var10000 = 1;
            case 222 -> var10000 = 230;
            case 223 -> var10000 = 81;
            case 224 -> var10000 = 174;
            case 225 -> var10000 = 163;
            case 226 -> var10000 = 99;
            case 227 -> var10000 = 47;
            case 228 -> var10000 = 42;
            case 229 -> var10000 = 16;
            case 230 -> var10000 = 74;
            case 231 -> var10000 = 20;
            case 232 -> var10000 = 128;
            case 233 -> var10000 = 242;
            case 234 -> var10000 = 33;
            case 235 -> var10000 = 254;
            case 236 -> var10000 = 164;
            case 237 -> var10000 = 94;
            case 238 -> var10000 = 65;
            case 239 -> var10000 = 101;
            case 240 -> var10000 = 142;
            case 241 -> var10000 = 138;
            case 242 -> var10000 = 224;
            case 243 -> var10000 = 236;
            case 244 -> var10000 = 24;
            case 245 -> var10000 = 23;
            case 246 -> var10000 = 187;
            case 247 -> var10000 = 129;
            case 248 -> var10000 = 228;
            case 249 -> var10000 = 240;
            case 250 -> var10000 = 121;
            case 251 -> var10000 = 0;
            case 252 -> var10000 = 151;
            case 253 -> var10000 = 130;
            case 254 -> var10000 = 170;
            default -> var10000 = 179;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 23322;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }

   public static enum Activation {
      HOLD,
      CLICK;

      // $FF: synthetic method
      private static Activation[] $values() {
         return new Activation[]{HOLD, CLICK};
      }

      static {
         String[] var0 = new String[2];
         int var4 = 0;
         String var3 = "r\u0006?.\u0005y\u0005:)\f";
         int var5 = "r\u0006?.\u0005y\u0005:)\f".length();
         char var2 = 4;
         int var1 = -1;

         while(true) {
            char[] var16;
            label42: {
               ++var1;
               char[] var10001 = var3.substring(var1, var1 + var2).toCharArray();
               int var10003 = var10001.length;
               int var6 = 0;
               var16 = var10001;
               int var10 = var10003;
               char[] var23;
               int var10004;
               if (var10003 <= 1) {
                  var23 = var10001;
                  var10004 = var6;
               } else {
                  var16 = var10001;
                  var10 = var10003;
                  if (var10003 <= var6) {
                     break label42;
                  }

                  var23 = var10001;
                  var10004 = var6;
               }

               while(true) {
                  char var10005 = var23[var10004];
                  byte var10006;
                  switch (var6 % 7) {
                     case 0 -> var10006 = 58;
                     case 1 -> var10006 = 73;
                     case 2 -> var10006 = 115;
                     case 3 -> var10006 = 106;
                     case 4 -> var10006 = 71;
                     case 5 -> var10006 = 8;
                     default -> var10006 = 111;
                  }

                  var23[var10004] = (char)(var10005 ^ var10006);
                  ++var6;
                  if (var10 == 0) {
                     var10004 = var10;
                     var23 = var16;
                  } else {
                     if (var10 <= var6) {
                        break;
                     }

                     var23 = var16;
                     var10004 = var6;
                  }
               }
            }

            String var30 = (new String(var16)).intern();
            boolean var14 = true;
            var0[var4++] = var30;
            if ((var1 += var2) >= var5) {
               HOLD = new Activation(var0[0], 0);
               CLICK = new Activation(var0[1], 1);
               return;
            }

            var2 = var3.charAt(var1);
         }
      }
   }

   public static enum Mode {
      LEGIT,
      BLATANT;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{LEGIT, BLATANT};
      }

      static {
         String[] var0 = new String[2];
         int var4 = 0;
         String var3 = "wM|.%\u0007yDz30?_";
         int var5 = "wM|.%\u0007yDz30?_".length();
         char var2 = 5;
         int var1 = -1;

         while(true) {
            char[] var16;
            label42: {
               ++var1;
               char[] var10001 = var3.substring(var1, var1 + var2).toCharArray();
               int var10003 = var10001.length;
               int var6 = 0;
               var16 = var10001;
               int var10 = var10003;
               char[] var23;
               int var10004;
               if (var10003 <= 1) {
                  var23 = var10001;
                  var10004 = var6;
               } else {
                  var16 = var10001;
                  var10 = var10003;
                  if (var10003 <= var6) {
                     break label42;
                  }

                  var23 = var10001;
                  var10004 = var6;
               }

               while(true) {
                  char var10005 = var23[var10004];
                  byte var10006;
                  switch (var6 % 7) {
                     case 0 -> var10006 = 59;
                     case 1 -> var10006 = 8;
                     case 2 -> var10006 = 59;
                     case 3 -> var10006 = 103;
                     case 4 -> var10006 = 113;
                     case 5 -> var10006 = 113;
                     default -> var10006 = 11;
                  }

                  var23[var10004] = (char)(var10005 ^ var10006);
                  ++var6;
                  if (var10 == 0) {
                     var10004 = var10;
                     var23 = var16;
                  } else {
                     if (var10 <= var6) {
                        break;
                     }

                     var23 = var16;
                     var10004 = var6;
                  }
               }
            }

            String var30 = (new String(var16)).intern();
            boolean var14 = true;
            var0[var4++] = var30;
            if ((var1 += var2) >= var5) {
               LEGIT = new Mode(var0[0], 0);
               BLATANT = new Mode(var0[1], 1);
               return;
            }

            var2 = var3.charAt(var1);
         }
      }
   }

   private static enum Stage {
      IDLE,
      PLACE_FIRST,
      CHARGE_FIRST,
      DETONATE_AND_PLACE_SECOND,
      CHARGE_SECOND,
      DETONATE_SECOND;

      private static final long a;

      // $FF: synthetic method
      private static Stage[] $values() {
         Stage[] var10000 = new Stage[(int)a];
         var10000[0] = IDLE;
         var10000[1] = PLACE_FIRST;
         var10000[2] = CHARGE_FIRST;
         var10000[3] = DETONATE_AND_PLACE_SECOND;
         var10000[4] = CHARGE_SECOND;
         var10000[5] = DETONATE_SECOND;
         return var10000;
      }

      static {
         String[] var2 = new String[6];
         int var6 = 0;
         String var5 = "XWr:^D']Va;M\u0019_Zg'W@,^@r&]^(W^p-FR=XP},\u0004R[\u007f-\rXWr:^D'HZp'WE";
         int var7 = "XWr:^D']Va;M\u0019_Zg'W@,^@r&]^(W^p-FR=XP},\u0004R[\u007f-\rXWr:^D'HZp'WE".length();
         char var4 = '\f';
         int var10 = -1;

         label56:
         while(true) {
            ++var10;
            String var10000 = var5.substring(var10, var10 + var4);
            byte var10001 = -1;

            while(true) {
               char[] var23;
               label51: {
                  char[] var13 = var10000.toCharArray();
                  int var10003 = var13.length;
                  int var8 = 0;
                  var23 = var13;
                  int var16 = var10003;
                  char[] var32;
                  int var10004;
                  if (var10003 <= 1) {
                     var32 = var13;
                     var10004 = var8;
                  } else {
                     var23 = var13;
                     var16 = var10003;
                     if (var10003 <= var8) {
                        break label51;
                     }

                     var32 = var13;
                     var10004 = var8;
                  }

                  while(true) {
                     char var10005 = var32[var10004];
                     byte var10006;
                     switch (var8 % 7) {
                        case 0 -> var10006 = 27;
                        case 1 -> var10006 = 31;
                        case 2 -> var10006 = 51;
                        case 3 -> var10006 = 104;
                        case 4 -> var10006 = 25;
                        case 5 -> var10006 = 1;
                        default -> var10006 = 120;
                     }

                     var32[var10004] = (char)(var10005 ^ var10006);
                     ++var8;
                     if (var16 == 0) {
                        var10004 = var16;
                        var32 = var23;
                     } else {
                        if (var16 <= var8) {
                           break;
                        }

                        var32 = var23;
                        var10004 = var8;
                     }
                  }
               }

               String var39 = (new String(var23)).intern();
               switch (var10001) {
                  case 0:
                     var2[var6++] = var39;
                     if ((var10 += var4) >= var7) {
                        long var0 = 942215879031250395L;
                        long var28 = 8918451935659679197L ^ var0;
                        var10001 = -1;
                        a = var28;
                        IDLE = new Stage(var2[2], 0);
                        PLACE_FIRST = new Stage(var2[5], 1);
                        CHARGE_FIRST = new Stage(var2[0], 2);
                        DETONATE_AND_PLACE_SECOND = new Stage(var2[1], 3);
                        CHARGE_SECOND = new Stage(var2[3], 4);
                        DETONATE_SECOND = new Stage(var2[4], 5);
                        return;
                     }

                     var4 = var5.charAt(var10);
                     break;
                  default:
                     var2[var6++] = var39;
                     if ((var10 += var4) < var7) {
                        var4 = var5.charAt(var10);
                        continue label56;
                     }

                     var5 = "_Zg'W@,^@`-ZN6_\u000bKSr+\\^>RM`<";
                     var7 = "_Zg'W@,^@`-ZN6_\u000bKSr+\\^>RM`<".length();
                     var4 = 15;
                     var10 = -1;
               }

               ++var10;
               var10000 = var5.substring(var10, var10 + var4);
               var10001 = 0;
            }
         }
      }
   }
}
