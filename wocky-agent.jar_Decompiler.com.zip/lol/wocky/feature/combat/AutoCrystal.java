package lol.wocky.feature.combat;

import java.util.concurrent.ThreadLocalRandom;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.KeyProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.util.EncryptedString;

public class AutoCrystal extends Module {
   private final KeyProperty activateKey = new KeyProperty(EncryptedString.of(a(13461, -22065)), a(7757, 6948683223374767244L));
   private final NumberProperty placeDelay = new NumberProperty(EncryptedString.of(a(13460, -7195)), 0, 0, a(5231, 2741557490368982703L), 1);
   private final NumberProperty breakDelay = new NumberProperty(EncryptedString.of(a(13470, -8860)), 0, 0, a(8515, 8271412512291298184L), 1);
   private final NumberProperty placeChance = new NumberProperty(EncryptedString.of(a(13459, -29974)), a(19127, 7332724647275688063L), 0, a(18622, 6389836856079020657L), 1);
   private final NumberProperty breakChance = new NumberProperty(EncryptedString.of(a(13458, 8646)), a(18622, 6389836856079020657L), 0, a(18622, 6389836856079020657L), 1);
   private final BooleanProperty antiWeakness = new BooleanProperty(EncryptedString.of(a(13456, -21225)), true);
   private final BooleanProperty stopOnKill = new BooleanProperty(EncryptedString.of(a(13462, -2081)), false);
   public static final int NOTHING = 0;
   public static final int PLACED = 1;
   public static final int BROKE;
   private int placeClock = 0;
   private int breakClock = 0;
   private long lastRunTick;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;
   private static final long e;

   public AutoCrystal() {
      super(EncryptedString.of(a(13471, 27444)), EncryptedString.of(a(13463, -22109)), ModuleCategory.CPVP);
      this.lastRunTick = e;
      Property[] var10001 = new Property[a(26489, 4818155400005279155L)];
      var10001[0] = this.activateKey;
      var10001[1] = this.placeDelay;
      var10001[2] = this.breakDelay;
      var10001[3] = this.placeChance;
      var10001[4] = this.breakChance;
      var10001[5] = this.antiWeakness;
      var10001[a(19789, 4568967454939248513L)] = this.stopOnKill;
      this.addProperties(var10001);
   }

   public boolean isActivated() {
      int var1 = this.activateKey.getKey();
      return var1 == 0 ? MinecraftBridge.isKeyDown(a(13377, 5483627661880299144L)) : this.activateKey.isDown();
   }

   public boolean cancelsItemUse() {
      return this.isActivated() && MinecraftBridge.isHolding(a(13457, 16049));
   }

   public boolean cancelsAttack() {
      return this.isActivated() && MinecraftBridge.isHolding(a(13469, -29716));
   }

   public void onTick() {
      if (!this.isActivated()) {
         this.placeClock = 0;
         this.breakClock = 0;
      } else {
         this.doCrystalLogic();
      }
   }

   public int doCrystalLogic() {
      long var1 = MinecraftBridge.getTickCount();
      if (var1 == this.lastRunTick) {
         return 0;
      } else {
         this.lastRunTick = var1;
         if (MinecraftBridge.getCurrentScreen() != null) {
            return 0;
         } else {
            boolean var3 = this.placeClock == 0;
            boolean var4 = this.breakClock == 0;
            if (!var3) {
               --this.placeClock;
            }

            if (!var4) {
               --this.breakClock;
            }

            if ((Boolean)this.stopOnKill.getValue() && MinecraftBridge.isDeadPlayerNearby()) {
               return 0;
            } else if (!MinecraftBridge.isHolding(a(13457, 16049))) {
               return 0;
            } else {
               MinecraftBridge.refreshCrosshair();
               Object var5 = MinecraftBridge.getCrosshairTarget();
               if (MinecraftBridge.isBlockHit(var5)) {
                  if (var3 && roll(this.placeChance) && MinecraftBridge.canPlaceCrystal(MinecraftBridge.getHitBlockPos(var5))) {
                     boolean var10 = MinecraftBridge.interactBlock(var5, true);
                     this.placeClock = this.placeDelay.intValue();
                     if (var10) {
                        return 1;
                     }
                  }

                  return 0;
               } else {
                  Object var6 = MinecraftBridge.getHitEntity(var5);
                  if (MinecraftBridge.isEndCrystal(var6) && var4 && roll(this.breakChance)) {
                     int var7 = MinecraftBridge.getSelectedSlot();
                     boolean var8 = false;
                     if ((Boolean)this.antiWeakness.getValue() && MinecraftBridge.hasWeakness()) {
                        int var9 = MinecraftBridge.findSwordSlot();
                        if (var9 != -1) {
                           MinecraftBridge.setSelectedSlot(var9);
                           var8 = true;
                        }
                     }

                     boolean var11 = MinecraftBridge.attackEntity(var6, true);
                     this.breakClock = this.breakDelay.intValue();
                     if (var8) {
                        MinecraftBridge.setSelectedSlot(var7);
                     }

                     if (var11) {
                        return 2;
                     }
                  }

                  return 0;
               }
            }
         }
      }
   }

   private static boolean roll(NumberProperty var0) {
      int var1 = var0.intValue();
      return var1 >= a(18622, 6389836856079020657L) || var1 > 0 && ThreadLocalRandom.current().nextInt(1, a(26576, 5455212680705006878L)) <= var1;
   }

   public void onDisable() {
      this.placeClock = 0;
      this.breakClock = 0;
   }

   static {
      String[] var15 = new String[11];
      int var13 = 0;
      String var12 = "Ò²¢3î,\u009b=`Mh±mÒ4¡{õ\u0085Â²\u001f\u0084v\u0001\u00134±ÔQ\u0098§Í>\u0001¯e\u0086\u0000a\u00949\u001b^\fÉÔ¬÷¥ÙQ]\u009b%Ú\u001e\fÖ\u009c\u0004\u0012\u009eQ°Æ\u0095\u0099\u0014ú\u000b¢Ê¬</\u009eÇV\u0001¡_\f\u008e\u0080)u\u009f·Ö~É\u0007ð´\f[\u009eÇiÈvóFm\u0000dT\u000bÙ3U}³_¯`\u008e³ \r\u0094\u0093L_ÌÎÛÁ\u0080Ø\u0094Y\u001e\u000bÕêd\u000e§\u0007\tkZÒ:";
      int var14 = "Ò²¢3î,\u009b=`Mh±mÒ4¡{õ\u0085Â²\u001f\u0084v\u0001\u00134±ÔQ\u0098§Í>\u0001¯e\u0086\u0000a\u00949\u001b^\fÉÔ¬÷¥ÙQ]\u009b%Ú\u001e\fÖ\u009c\u0004\u0012\u009eQ°Æ\u0095\u0099\u0014ú\u000b¢Ê¬</\u009eÇV\u0001¡_\f\u008e\u0080)u\u009f·Ö~É\u0007ð´\f[\u009eÇiÈvóFm\u0000dT\u000bÙ3U}³_¯`\u008e³ \r\u0094\u0093L_ÌÎÛÁ\u0080Ø\u0094Y\u001e\u000bÕêd\u000e§\u0007\tkZÒ:".length();
      char var11 = ',';
      int var19 = -1;

      label73:
      while(true) {
         ++var19;
         String var10000 = var12.substring(var19, var19 + var11);
         int var10001 = -1;

         while(true) {
            char[] var36;
            label68: {
               char[] var23 = var10000.toCharArray();
               int var10003 = var23.length;
               int var16 = 0;
               var36 = var23;
               int var26 = var10003;
               char[] var47;
               int var10004;
               if (var10003 <= 1) {
                  var47 = var23;
                  var10004 = var16;
               } else {
                  var36 = var23;
                  var26 = var10003;
                  if (var10003 <= var16) {
                     break label68;
                  }

                  var47 = var23;
                  var10004 = var16;
               }

               while(true) {
                  char var10005 = var47[var10004];
                  byte var10006;
                  switch (var16 % 7) {
                     case 0 -> var10006 = 39;
                     case 1 -> var10006 = 117;
                     case 2 -> var10006 = 39;
                     case 3 -> var10006 = 73;
                     case 4 -> var10006 = 118;
                     case 5 -> var10006 = 31;
                     default -> var10006 = 97;
                  }

                  var47[var10004] = (char)(var10005 ^ var10006);
                  ++var16;
                  if (var26 == 0) {
                     var10004 = var26;
                     var47 = var36;
                  } else {
                     if (var26 <= var16) {
                        break;
                     }

                     var47 = var36;
                     var10004 = var16;
                  }
               }
            }

            String var54 = (new String(var36)).intern();
            switch (var10001) {
               case 0:
                  var15[var13++] = var54;
                  if ((var19 += var11) >= var14) {
                     a = var15;
                     b = new String[11];
                     long var2 = 539702978234194766L;
                     long[] var8 = new long[10];
                     int var5 = 0;
                     String var6 = "EK`ë\u0091@ëU¼\u0085P\u0080ß?\u0016,gõÈKÌ/FúR\u0015æ\u0087ä\u0006\u0080ÒõY\u0093\u001a\u0090'ìÉÏ\u0084\nâ\u008cíD±ÿÄ¡¦z~F5B®Z$Æ\u0097i[";
                     int var7 = "EK`ë\u0091@ëU¼\u0085P\u0080ß?\u0016,gõÈKÌ/FúR\u0015æ\u0087ä\u0006\u0080ÒõY\u0093\u001a\u0090'ìÉÏ\u0084\nâ\u008cíD±ÿÄ¡¦z~F5B®Z$Æ\u0097i[".length();
                     int var4 = 0;

                     label44:
                     while(true) {
                        var10001 = var4;
                        var4 += 8;
                        byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
                        long[] var21 = var8;
                        var10001 = var5++;
                        long var41 = ((long)var9[0] & 255L) << 56 | ((long)var9[1] & 255L) << 48 | ((long)var9[2] & 255L) << 40 | ((long)var9[3] & 255L) << 32 | ((long)var9[4] & 255L) << 24 | ((long)var9[5] & 255L) << 16 | ((long)var9[6] & 255L) << 8 | (long)var9[7] & 255L;
                        byte var55 = -1;

                        while(true) {
                           long var58 = var41 ^ var2;
                           switch (var55) {
                              case 0:
                                 var21[var10001] = var58;
                                 if (var4 >= var7) {
                                    c = var8;
                                    d = new Integer[10];
                                    BROKE = a(25904, 1314749954949111805L);
                                    long var0 = 6247819493653877178L;
                                    var41 = -6247819493653877179L ^ var0;
                                    var10001 = -1;
                                    e = var41;
                                    return;
                                 }
                                 break;
                              default:
                                 var21[var10001] = var58;
                                 if (var4 < var7) {
                                    continue label44;
                                 }

                                 var6 = "\u008eøñ\u0002Õ\u001fµõâx!/¼&¼(";
                                 var7 = "\u008eøñ\u0002Õ\u001fµõâx!/¼&¼(".length();
                                 var4 = 0;
                           }

                           var10001 = var4;
                           var4 += 8;
                           var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
                           var21 = var8;
                           var10001 = var5++;
                           var41 = ((long)var9[0] & 255L) << 56 | ((long)var9[1] & 255L) << 48 | ((long)var9[2] & 255L) << 40 | ((long)var9[3] & 255L) << 32 | ((long)var9[4] & 255L) << 24 | ((long)var9[5] & 255L) << 16 | ((long)var9[6] & 255L) << 8 | (long)var9[7] & 255L;
                           var55 = 0;
                        }
                     }
                  }

                  var11 = var12.charAt(var19);
                  break;
               default:
                  var15[var13++] = var54;
                  if ((var19 += var11) < var14) {
                     var11 = var12.charAt(var19);
                     continue label73;
                  }

                  var12 = "\u001eóoÄÝÃVý3Ô\u0019\u000btÎàÂ\u0005¨y\u009eTlû";
                  var14 = "\u001eóoÄÝÃVý3Ô\u0019\u000btÎàÂ\u0005¨y\u009eTlû".length();
                  var11 = 11;
                  var19 = -1;
            }

            ++var19;
            var10000 = var12.substring(var19, var19 + var11);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 13463) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 245;
            case 1 -> var10000 = 177;
            case 2 -> var10000 = 15;
            case 3 -> var10000 = 150;
            case 4 -> var10000 = 151;
            case 5 -> var10000 = 143;
            case 6 -> var10000 = 226;
            case 7 -> var10000 = 159;
            case 8 -> var10000 = 107;
            case 9 -> var10000 = 116;
            case 10 -> var10000 = 71;
            case 11 -> var10000 = 119;
            case 12 -> var10000 = 218;
            case 13 -> var10000 = 127;
            case 14 -> var10000 = 69;
            case 15 -> var10000 = 204;
            case 16 -> var10000 = 202;
            case 17 -> var10000 = 219;
            case 18 -> var10000 = 250;
            case 19 -> var10000 = 109;
            case 20 -> var10000 = 56;
            case 21 -> var10000 = 90;
            case 22 -> var10000 = 176;
            case 23 -> var10000 = 173;
            case 24 -> var10000 = 10;
            case 25 -> var10000 = 154;
            case 26 -> var10000 = 186;
            case 27 -> var10000 = 27;
            case 28 -> var10000 = 94;
            case 29 -> var10000 = 39;
            case 30 -> var10000 = 121;
            case 31 -> var10000 = 124;
            case 32 -> var10000 = 190;
            case 33 -> var10000 = 251;
            case 34 -> var10000 = 212;
            case 35 -> var10000 = 155;
            case 36 -> var10000 = 5;
            case 37 -> var10000 = 81;
            case 38 -> var10000 = 23;
            case 39 -> var10000 = 205;
            case 40 -> var10000 = 170;
            case 41 -> var10000 = 38;
            case 42 -> var10000 = 123;
            case 43 -> var10000 = 174;
            case 44 -> var10000 = 145;
            case 45 -> var10000 = 183;
            case 46 -> var10000 = 97;
            case 47 -> var10000 = 163;
            case 48 -> var10000 = 237;
            case 49 -> var10000 = 184;
            case 50 -> var10000 = 48;
            case 51 -> var10000 = 230;
            case 52 -> var10000 = 47;
            case 53 -> var10000 = 117;
            case 54 -> var10000 = 30;
            case 55 -> var10000 = 239;
            case 56 -> var10000 = 253;
            case 57 -> var10000 = 233;
            case 58 -> var10000 = 209;
            case 59 -> var10000 = 240;
            case 60 -> var10000 = 28;
            case 61 -> var10000 = 87;
            case 62 -> var10000 = 197;
            case 63 -> var10000 = 244;
            case 64 -> var10000 = 231;
            case 65 -> var10000 = 32;
            case 66 -> var10000 = 78;
            case 67 -> var10000 = 62;
            case 68 -> var10000 = 33;
            case 69 -> var10000 = 108;
            case 70 -> var10000 = 45;
            case 71 -> var10000 = 118;
            case 72 -> var10000 = 165;
            case 73 -> var10000 = 167;
            case 74 -> var10000 = 179;
            case 75 -> var10000 = 223;
            case 76 -> var10000 = 42;
            case 77 -> var10000 = 63;
            case 78 -> var10000 = 199;
            case 79 -> var10000 = 24;
            case 80 -> var10000 = 112;
            case 81 -> var10000 = 51;
            case 82 -> var10000 = 17;
            case 83 -> var10000 = 182;
            case 84 -> var10000 = 101;
            case 85 -> var10000 = 135;
            case 86 -> var10000 = 55;
            case 87 -> var10000 = 110;
            case 88 -> var10000 = 58;
            case 89 -> var10000 = 252;
            case 90 -> var10000 = 166;
            case 91 -> var10000 = 96;
            case 92 -> var10000 = 171;
            case 93 -> var10000 = 214;
            case 94 -> var10000 = 89;
            case 95 -> var10000 = 132;
            case 96 -> var10000 = 222;
            case 97 -> var10000 = 158;
            case 98 -> var10000 = 195;
            case 99 -> var10000 = 238;
            case 100 -> var10000 = 189;
            case 101 -> var10000 = 203;
            case 102 -> var10000 = 106;
            case 103 -> var10000 = 54;
            case 104 -> var10000 = 66;
            case 105 -> var10000 = 172;
            case 106 -> var10000 = 198;
            case 107 -> var10000 = 221;
            case 108 -> var10000 = 131;
            case 109 -> var10000 = 185;
            case 110 -> var10000 = 156;
            case 111 -> var10000 = 140;
            case 112 -> var10000 = 153;
            case 113 -> var10000 = 80;
            case 114 -> var10000 = 83;
            case 115 -> var10000 = 46;
            case 116 -> var10000 = 6;
            case 117 -> var10000 = 60;
            case 118 -> var10000 = 229;
            case 119 -> var10000 = 52;
            case 120 -> var10000 = 43;
            case 121 -> var10000 = 98;
            case 122 -> var10000 = 76;
            case 123 -> var10000 = 79;
            case 124 -> var10000 = 136;
            case 125 -> var10000 = 99;
            case 126 -> var10000 = 255;
            case 127 -> var10000 = 247;
            case 128 -> var10000 = 50;
            case 129 -> var10000 = 103;
            case 130 -> var10000 = 180;
            case 131 -> var10000 = 134;
            case 132 -> var10000 = 242;
            case 133 -> var10000 = 16;
            case 134 -> var10000 = 111;
            case 135 -> var10000 = 193;
            case 136 -> var10000 = 95;
            case 137 -> var10000 = 243;
            case 138 -> var10000 = 7;
            case 139 -> var10000 = 133;
            case 140 -> var10000 = 139;
            case 141 -> var10000 = 84;
            case 142 -> var10000 = 102;
            case 143 -> var10000 = 126;
            case 144 -> var10000 = 73;
            case 145 -> var10000 = 201;
            case 146 -> var10000 = 122;
            case 147 -> var10000 = 147;
            case 148 -> var10000 = 137;
            case 149 -> var10000 = 44;
            case 150 -> var10000 = 61;
            case 151 -> var10000 = 130;
            case 152 -> var10000 = 100;
            case 153 -> var10000 = 75;
            case 154 -> var10000 = 35;
            case 155 -> var10000 = 169;
            case 156 -> var10000 = 9;
            case 157 -> var10000 = 113;
            case 158 -> var10000 = 152;
            case 159 -> var10000 = 92;
            case 160 -> var10000 = 64;
            case 161 -> var10000 = 228;
            case 162 -> var10000 = 36;
            case 163 -> var10000 = 187;
            case 164 -> var10000 = 211;
            case 165 -> var10000 = 225;
            case 166 -> var10000 = 82;
            case 167 -> var10000 = 168;
            case 168 -> var10000 = 104;
            case 169 -> var10000 = 241;
            case 170 -> var10000 = 220;
            case 171 -> var10000 = 236;
            case 172 -> var10000 = 13;
            case 173 -> var10000 = 26;
            case 174 -> var10000 = 14;
            case 175 -> var10000 = 216;
            case 176 -> var10000 = 67;
            case 177 -> var10000 = 227;
            case 178 -> var10000 = 74;
            case 179 -> var10000 = 37;
            case 180 -> var10000 = 93;
            case 181 -> var10000 = 105;
            case 182 -> var10000 = 25;
            case 183 -> var10000 = 88;
            case 184 -> var10000 = 11;
            case 185 -> var10000 = 70;
            case 186 -> var10000 = 0;
            case 187 -> var10000 = 65;
            case 188 -> var10000 = 148;
            case 189 -> var10000 = 188;
            case 190 -> var10000 = 200;
            case 191 -> var10000 = 128;
            case 192 -> var10000 = 194;
            case 193 -> var10000 = 138;
            case 194 -> var10000 = 120;
            case 195 -> var10000 = 72;
            case 196 -> var10000 = 142;
            case 197 -> var10000 = 217;
            case 198 -> var10000 = 234;
            case 199 -> var10000 = 192;
            case 200 -> var10000 = 208;
            case 201 -> var10000 = 1;
            case 202 -> var10000 = 68;
            case 203 -> var10000 = 149;
            case 204 -> var10000 = 160;
            case 205 -> var10000 = 125;
            case 206 -> var10000 = 162;
            case 207 -> var10000 = 59;
            case 208 -> var10000 = 57;
            case 209 -> var10000 = 157;
            case 210 -> var10000 = 178;
            case 211 -> var10000 = 53;
            case 212 -> var10000 = 235;
            case 213 -> var10000 = 181;
            case 214 -> var10000 = 210;
            case 215 -> var10000 = 207;
            case 216 -> var10000 = 18;
            case 217 -> var10000 = 41;
            case 218 -> var10000 = 12;
            case 219 -> var10000 = 215;
            case 220 -> var10000 = 19;
            case 221 -> var10000 = 21;
            case 222 -> var10000 = 85;
            case 223 -> var10000 = 91;
            case 224 -> var10000 = 20;
            case 225 -> var10000 = 164;
            case 226 -> var10000 = 49;
            case 227 -> var10000 = 249;
            case 228 -> var10000 = 175;
            case 229 -> var10000 = 4;
            case 230 -> var10000 = 213;
            case 231 -> var10000 = 2;
            case 232 -> var10000 = 224;
            case 233 -> var10000 = 86;
            case 234 -> var10000 = 114;
            case 235 -> var10000 = 40;
            case 236 -> var10000 = 232;
            case 237 -> var10000 = 196;
            case 238 -> var10000 = 34;
            case 239 -> var10000 = 206;
            case 240 -> var10000 = 115;
            case 241 -> var10000 = 31;
            case 242 -> var10000 = 129;
            case 243 -> var10000 = 8;
            case 244 -> var10000 = 3;
            case 245 -> var10000 = 254;
            case 246 -> var10000 = 141;
            case 247 -> var10000 = 248;
            case 248 -> var10000 = 146;
            case 249 -> var10000 = 29;
            case 250 -> var10000 = 77;
            case 251 -> var10000 = 246;
            case 252 -> var10000 = 144;
            case 253 -> var10000 = 161;
            case 254 -> var10000 = 22;
            default -> var10000 = 191;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15048;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }
}
