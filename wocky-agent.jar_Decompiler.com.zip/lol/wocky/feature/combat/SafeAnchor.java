package lol.wocky.feature.combat;

import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.ModuleManager;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.KeyProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.render.Hud2D;

public class SafeAnchor extends Module {
   private static final String ANCHOR;
   private static final String GLOWSTONE;
   private static final int MAX_TICKS;
   private static final int CHARGE_GRACE_TICKS;
   private static final double GUARD_FRACTION = 0.53;
   private static final double GUARD_MIN = 0.3;
   private static final double GUARD_MAX = 0.65;
   private static final double GUARD_SIDE = (double)1.0F;
   private static final int GUARD_TICKS;
   private static final int SETTLED_TICKS;
   private static final int TURN_TICKS;
   private final KeyProperty activateKey = new KeyProperty(a(-5972, 4958), 0);
   private final NumberProperty rotationSpeed = new NumberProperty(a(-5975, 23087), (double)45.0F, (double)10.0F, (double)80.0F, (double)1.0F);
   private final NumberProperty delay = new NumberProperty(a(-5969, -30708), 0, 0, 5, 1);
   private final NumberProperty explodeSlot = new NumberProperty(a(-5977, 17342), 0, 0, a(12752, 1959927006069080793L), 1);
   private final BooleanProperty swapBack = new BooleanProperty(a(-5978, 211), true);
   private Step step;
   private boolean keyWasDown;
   private int totalTicks;
   private int previousSlot;
   private long lastActionTick;
   private int[] anchor;
   private int[] anchorBase;
   private int[] guard;
   private int guardTicks;
   private int[] chargedAnchor;
   private long chargedTick;
   private double[][] aims;
   private int aimIndex;
   private int settledTicks;
   private int turnTicks;
   private volatile double[] aimPoint;
   private volatile float aimError;
   private long lastFrame;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;
   private static final long[] e;
   private static final Long[] f;

   public SafeAnchor() {
      super(a(-5976, -23836), a(-5984, 15469), ModuleCategory.CPVP);
      this.step = SafeAnchor.Step.IDLE;
      this.previousSlot = -1;
      this.aimError = 180.0F;
      this.addProperties(new Property[]{this.activateKey, this.rotationSpeed, this.delay, this.explodeSlot, this.swapBack});
   }

   public static boolean isRunning() {
      SafeAnchor var0 = (SafeAnchor)ModuleManager.getByClass(SafeAnchor.class);
      return var0 != null && var0.isEnabled() && var0.step != SafeAnchor.Step.IDLE;
   }

   public boolean isExclusive() {
      return this.step != SafeAnchor.Step.IDLE;
   }

   public boolean cancelsItemUse() {
      return this.step != SafeAnchor.Step.IDLE;
   }

   public boolean cancelsAttack() {
      return this.step != SafeAnchor.Step.IDLE;
   }

   public void onTick() {
      boolean var1 = MinecraftBridge.getCurrentScreen() != null;
      boolean var2 = !var1 && this.activateKey.getKey() != 0 && this.activateKey.isDown();
      boolean var3 = var2 && !this.keyWasDown;
      this.keyWasDown = var2;
      if (this.step == SafeAnchor.Step.IDLE) {
         if (!var3) {
            return;
         }

         this.start();
         if (this.step == SafeAnchor.Step.IDLE) {
            return;
         }
      } else if (var3 || var1 || ++this.totalTicks > a(5885, 6110943182170547701L) || MinecraftBridge.isDead(MinecraftBridge.getPlayer())) {
         this.finish();
         return;
      }

      MinecraftBridge.refreshCrosshair();
      switch (this.step.ordinal()) {
         case 1 -> this.placeAnchor();
         case 2 -> this.charge();
         case 3 -> this.placeGuard();
         case 4 -> this.explode();
      }

   }

   private void start() {
      MinecraftBridge.refreshCrosshair();
      Object var1 = MinecraftBridge.getCrosshairTarget();
      if (MinecraftBridge.isBlockHit(var1)) {
         if (MinecraftBridge.findHotbarSlot(a(-5971, -4511)) != -1 && this.findExplodeSlot() != -1) {
            Object var2 = MinecraftBridge.getHitBlockPos(var1);
            int var3 = MinecraftBridge.anchorCharges(var2);
            if (var3 >= 0 || MinecraftBridge.findHotbarSlot(a(-5974, -18459)) != -1 && MinecraftBridge.canPlaceBlockAt(var1)) {
               this.previousSlot = MinecraftBridge.getSelectedSlot();
               this.totalTicks = 0;
               this.lastActionTick = MinecraftBridge.getTickCount() - b(18141, 3257280102123231936L);
               this.chargedAnchor = null;
               if (var3 >= 0) {
                  this.anchor = MinecraftBridge.coords(var2);
                  this.go(var3 == 0 ? SafeAnchor.Step.CHARGE : SafeAnchor.Step.GUARD);
               } else {
                  this.anchor = MinecraftBridge.coords(MinecraftBridge.getPlacementPos(var1));
                  this.anchorBase = MinecraftBridge.coords(var2);
                  this.go(SafeAnchor.Step.ANCHOR);
               }

               MinecraftBridge.setMouseLocked(true);
            }
         }
      }
   }

   private void finish() {
      if (this.step != SafeAnchor.Step.IDLE && (Boolean)this.swapBack.getValue() && this.previousSlot != -1) {
         MinecraftBridge.setSelectedSlot(this.previousSlot);
      }

      this.step = SafeAnchor.Step.IDLE;
      this.aimPoint = null;
      this.aims = null;
      this.anchor = this.anchorBase = this.chargedAnchor = this.guard = null;
      this.previousSlot = -1;
      MinecraftBridge.setMouseLocked(false);
   }

   private void go(Step var1) {
      this.step = var1;
      switch (var1.ordinal()) {
         case 1:
            this.setAims(new double[][]{same(this.anchor, this.anchorBase) ? new double[]{(double)this.anchor[0] + (double)0.5F, (double)this.anchor[1] + 0.05, (double)this.anchor[2] + (double)0.5F} : faceCenter(this.anchorBase, this.anchor)});
            break;
         case 2:
            this.setAims(new double[][]{this.anchorTop((double)0.0F, (double)0.0F), this.anchorSide((double)0.75F), this.anchorSide(0.4)});
            break;
         case 3:
            this.planGuard();
            this.guardTicks = 0;
            if (this.guard == null) {
               this.go(SafeAnchor.Step.EXPLODE);
               return;
            }

            int[] var2 = new int[]{this.guard[0], this.guard[1] - 1, this.guard[2]};
            this.setAims(new double[][]{faceCenter(var2, this.guard)});
            break;
         case 4:
            this.setAims(new double[][]{this.anchorTop((double)0.25F, (double)0.25F), this.anchorTop((double)0.0F, (double)0.0F), this.anchorTop((double)-0.25F, (double)0.0F), this.anchorSide(0.9)});
      }

   }

   private void placeAnchor() {
      if (this.ready(a(-5980, -10278))) {
         Object var1 = MinecraftBridge.getCrosshairTarget();
         if (MinecraftBridge.isBlockHit(var1) && same(MinecraftBridge.coords(MinecraftBridge.getPlacementPos(var1)), this.anchor)) {
            if (MinecraftBridge.interactBlock(var1, true)) {
               this.acted();
               this.go(SafeAnchor.Step.CHARGE);
            }

         } else {
            if (this.aimFailed()) {
               this.finish();
            }

         }
      }
   }

   private void charge() {
      if (MinecraftBridge.anchorCharges(cell(this.anchor)) < 0) {
         if (MinecraftBridge.getTickCount() - this.lastActionTick > b(23786, 1627934535684702453L)) {
            this.finish();
         }

      } else if (this.ready(a(-5971, -4511))) {
         if (!this.onAnchor()) {
            if (this.aimFailed()) {
               this.finish();
            }

         } else {
            if (MinecraftBridge.interactBlock(MinecraftBridge.getCrosshairTarget(), true)) {
               this.acted();
               this.chargedAnchor = this.anchor;
               this.chargedTick = MinecraftBridge.getTickCount();
               this.go(SafeAnchor.Step.GUARD);
            }

         }
      }
   }

   private void placeGuard() {
      if (MinecraftBridge.isReplaceable(cell(this.guard)) && ++this.guardTicks <= 4) {
         if (this.ready(a(-5971, -4511))) {
            Object var1 = MinecraftBridge.getCrosshairTarget();
            if (MinecraftBridge.isBlockHit(var1) && this.shields(MinecraftBridge.coords(MinecraftBridge.getPlacementPos(var1)))) {
               if (MinecraftBridge.interactBlock(var1, true)) {
                  this.acted();
               }

               this.go(SafeAnchor.Step.EXPLODE);
            }
         }
      } else {
         this.go(SafeAnchor.Step.EXPLODE);
      }
   }

   private boolean shields(int[] var1) {
      if (var1 != null && !same(var1, this.anchor)) {
         Object var2 = MinecraftBridge.getPlayer();
         double var3 = MinecraftBridge.getEntityX(var2);
         double var5 = MinecraftBridge.getEntityZ(var2);
         int var7 = (int)Math.floor(MinecraftBridge.getEntityY(var2) + 0.01);
         if (var1[1] >= var7 && var1[1] <= var7 + 1) {
            double var8 = (double)this.anchor[0] + (double)0.5F - var3;
            double var10 = (double)this.anchor[2] + (double)0.5F - var5;
            double var12 = Math.max(1.0E-6, Math.sqrt(var8 * var8 + var10 * var10));
            double var14 = (double)var1[0] + (double)0.5F - var3;
            double var16 = (double)var1[2] + (double)0.5F - var5;
            double var18 = (var14 * var8 + var16 * var10) / var12;
            double var20 = Math.abs(var14 * var10 - var16 * var8) / var12;
            if (!(var18 < var12 * 0.3) && !(var18 > var12 * 0.65) && !(var20 > (double)1.0F)) {
               Object var22 = cell(var1);
               return MinecraftBridge.isReplaceable(var22) && MinecraftBridge.isFreeForBlock(var22);
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void explode() {
      if (this.knownCharges() < 1) {
         if (MinecraftBridge.getTickCount() - this.chargedTick > b(13010, 3934704502052204236L)) {
            this.go(SafeAnchor.Step.CHARGE);
         }

      } else {
         if (MinecraftBridge.isHolding(a(-5983, 15987))) {
            int var1 = this.findExplodeSlot();
            if (var1 == -1) {
               this.finish();
               return;
            }

            MinecraftBridge.setSelectedSlot(var1);
            if (MinecraftBridge.isHolding(a(-5971, -4511))) {
               return;
            }
         }

         if (MinecraftBridge.getTickCount() - this.lastActionTick >= (long)this.delay.intValue()) {
            if (!this.onAnchor()) {
               if (this.aimFailed()) {
                  this.finish();
               }

            } else {
               if (MinecraftBridge.interactBlock(MinecraftBridge.getCrosshairTarget(), true)) {
                  this.finish();
               }

            }
         }
      }
   }

   private boolean ready(String var1) {
      if (MinecraftBridge.getTickCount() - this.lastActionTick < (long)this.delay.intValue()) {
         return false;
      } else {
         return MinecraftBridge.isHolding(var1) || MinecraftBridge.selectHotbarItem(var1);
      }
   }

   private void setAims(double[][] var1) {
      this.aims = var1;
      this.aimIndex = 0;
      this.settledTicks = 0;
      this.turnTicks = 0;
      this.aimError = 180.0F;
      this.aimPoint = var1[0];
   }

   private boolean aimFailed() {
      if (this.aimError > 1.5F && ++this.turnTicks < a(21399, 5639555255011647644L)) {
         return false;
      } else if (++this.settledTicks < 2) {
         return false;
      } else if (++this.aimIndex >= this.aims.length) {
         return true;
      } else {
         this.settledTicks = 0;
         this.turnTicks = 0;
         this.aimError = 180.0F;
         this.aimPoint = this.aims[this.aimIndex];
         return false;
      }
   }

   private void planGuard() {
      Object var1 = MinecraftBridge.getPlayer();
      double var2 = MinecraftBridge.getEntityX(var1);
      double var4 = MinecraftBridge.getEntityZ(var1);
      int var6 = (int)Math.floor(MinecraftBridge.getEntityY(var1) + 0.01);
      double var7 = (double)this.anchor[0] + (double)0.5F - var2;
      double var9 = (double)this.anchor[2] + (double)0.5F - var4;
      int var11 = (int)Math.floor(var2 + var7 * 0.53);
      int var12 = (int)Math.floor(var4 + var9 * 0.53);
      if (var11 == (int)Math.floor(var2) && var12 == (int)Math.floor(var4)) {
         if (Math.abs(var7) > Math.abs(var9)) {
            var11 += var7 > (double)0.0F ? 1 : -1;
         } else {
            var12 += var9 > (double)0.0F ? 1 : -1;
         }
      }

      if (var11 == this.anchor[0] && var12 == this.anchor[2]) {
         this.guard = null;
      } else {
         this.guard = new int[]{var11, var6, var12};
         if (!MinecraftBridge.isReplaceable(cell(this.guard))) {
            this.guard = null;
         }

      }
   }

   private void acted() {
      this.lastActionTick = MinecraftBridge.getTickCount();
   }

   private boolean onAnchor() {
      Object var1 = MinecraftBridge.getCrosshairTarget();
      return MinecraftBridge.isBlockHit(var1) && same(MinecraftBridge.coords(MinecraftBridge.getHitBlockPos(var1)), this.anchor);
   }

   private int knownCharges() {
      int var1 = MinecraftBridge.anchorCharges(cell(this.anchor));
      boolean var2 = same(this.chargedAnchor, this.anchor) && MinecraftBridge.getTickCount() - this.chargedTick <= b(23786, 1627934535684702453L);
      return var2 ? Math.max(var1, 1) : var1;
   }

   private double[] anchorTop(double var1, double var3) {
      Object var5 = MinecraftBridge.getPlayer();
      double var6 = MinecraftBridge.getEntityX(var5) - ((double)this.anchor[0] + (double)0.5F);
      double var8 = MinecraftBridge.getEntityZ(var5) - ((double)this.anchor[2] + (double)0.5F);
      double var10 = Math.max(1.0E-6, Math.sqrt(var6 * var6 + var8 * var8));
      var6 /= var10;
      var8 /= var10;
      return new double[]{(double)this.anchor[0] + (double)0.5F + var6 * var1 - var8 * var3, (double)(this.anchor[1] + 1), (double)this.anchor[2] + (double)0.5F + var8 * var1 + var6 * var3};
   }

   private double[] anchorSide(double var1) {
      Object var3 = MinecraftBridge.getPlayer();
      double var4 = MinecraftBridge.getEntityX(var3) - ((double)this.anchor[0] + (double)0.5F);
      double var6 = MinecraftBridge.getEntityZ(var3) - ((double)this.anchor[2] + (double)0.5F);
      double var8 = (double)this.anchor[1] + var1;
      return Math.abs(var4) > Math.abs(var6) ? new double[]{var4 > (double)0.0F ? (double)(this.anchor[0] + 1) : (double)this.anchor[0], var8, (double)this.anchor[2] + (double)0.5F} : new double[]{(double)this.anchor[0] + (double)0.5F, var8, var6 > (double)0.0F ? (double)(this.anchor[2] + 1) : (double)this.anchor[2]};
   }

   private static double[] faceCenter(int[] var0, int[] var1) {
      return new double[]{(double)var0[0] + (double)0.5F + (double)(var1[0] - var0[0]) * (double)0.5F, (double)var0[1] + (double)0.5F + (double)(var1[1] - var0[1]) * (double)0.5F, (double)var0[2] + (double)0.5F + (double)(var1[2] - var0[2]) * (double)0.5F};
   }

   private int findExplodeSlot() {
      int var1 = this.explodeSlot.intValue();
      if (var1 > 0) {
         return var1 - 1;
      } else {
         int var2 = MinecraftBridge.findHotbarSlot(a(-5979, -22168));
         if (var2 == -1) {
            var2 = MinecraftBridge.findSwordSlot();
         }

         for(int var3 = 0; var2 == -1 && var3 < a(11266, 3369316122535616270L); ++var3) {
            if (!MinecraftBridge.isItem(MinecraftBridge.getStackInSlot(var3), a(-5971, -4511))) {
               var2 = var3;
            }
         }

         return var2;
      }
   }

   private static Object cell(int[] var0) {
      return var0 == null ? null : MinecraftBridge.blockPos(var0[0], var0[1], var0[2]);
   }

   private static boolean same(int[] var0, int[] var1) {
      return var0 != null && var1 != null && var0[0] == var1[0] && var0[1] == var1[1] && var0[2] == var1[2];
   }

   public void onHudRender(Hud2D var1) {
      long var2 = System.nanoTime();
      float var4 = this.lastFrame == 0L ? 0.0F : Math.min(0.05F, (float)(var2 - this.lastFrame) / 1.0E9F);
      this.lastFrame = var2;
      double[] var5 = this.aimPoint;
      if (this.step != SafeAnchor.Step.IDLE && !(var4 <= 0.0F) && var5 != null) {
         double var6 = var5[0] - var1.camX();
         double var8 = var5[1] - var1.camY();
         double var10 = var5[2] - var1.camZ();
         float var12 = (float)Math.toDegrees(Math.atan2(var10, var6)) - 90.0F;
         float var13 = (float)(-Math.toDegrees(Math.atan2(var8, Math.sqrt(var6 * var6 + var10 * var10))));
         Object var14 = MinecraftBridge.getPlayer();
         float var15 = wrap(var12 - MinecraftBridge.getYaw(var14));
         float var16 = var13 - MinecraftBridge.getPitch(var14);
         float var17 = (float)Math.sqrt((double)(var15 * var15 + var16 * var16));
         this.aimError = var17;
         if (!(var17 < 0.05F)) {
            float var18 = 1.0F - (float)Math.exp(-this.rotationSpeed.doubleValue() * (double)var4);
            float var19 = Math.max(var17 * var18, Math.min(var17, 240.0F * var4));
            MinecraftBridge.turnPlayer(var15 * var19 / var17, var16 * var19 / var17);
         }
      }
   }

   private static float wrap(float var0) {
      var0 %= 360.0F;
      if (var0 >= 180.0F) {
         var0 -= 360.0F;
      }

      if (var0 < -180.0F) {
         var0 += 360.0F;
      }

      return var0;
   }

   public void onDisable() {
      this.finish();
      this.keyWasDown = false;
      this.lastFrame = 0L;
   }

   static {
      String[] var21 = new String[14];
      int var19 = 0;
      String var18 = "rýQÓ+b\u00ad>V\fÎ,?\u0019\u009bó\u0005°~otF\u0005¤\nÏ\u0013\u0091\tsöq²/N-»F\u000e>3P\u007ft>¡\u000b\u0092jüáq+\n¶1rôUÌ\u001a´'z\u000e\náõ\u007f2\u0013ßB=is\u0016ûo\u000eP\u0092¾\u0011[Þòû\u0098^Çðm³\u0010L\u001dü¾ø´\n¢\u0098p3AI\u0013÷E\u000e¹¦\u0083\u0097ü\u000e\u0006á\u0006\u001d\u0014\u0098\u0017¾\fËx\u001fî\u0002\u00ad\u001d\u009b=À\u000b}\txd¬\u009f\b:þÈý";
      int var20 = "rýQÓ+b\u00ad>V\fÎ,?\u0019\u009bó\u0005°~otF\u0005¤\nÏ\u0013\u0091\tsöq²/N-»F\u000e>3P\u007ft>¡\u000b\u0092jüáq+\n¶1rôUÌ\u001a´'z\u000e\náõ\u007f2\u0013ßB=is\u0016ûo\u000eP\u0092¾\u0011[Þòû\u0098^Çðm³\u0010L\u001dü¾ø´\n¢\u0098p3AI\u0013÷E\u000e¹¦\u0083\u0097ü\u000e\u0006á\u0006\u001d\u0014\u0098\u0017¾\fËx\u001fî\u0002\u00ad\u001d\u009b=À\u000b}\txd¬\u009f\b:þÈý".length();
      char var17 = '\t';
      int var25 = -1;

      label82:
      while(true) {
         ++var25;
         String var10000 = var18.substring(var25, var25 + var17);
         int var10001 = -1;

         while(true) {
            char[] var43;
            label77: {
               char[] var29 = var10000.toCharArray();
               int var10003 = var29.length;
               int var22 = 0;
               var43 = var29;
               int var32 = var10003;
               char[] var53;
               int var10004;
               if (var10003 <= 1) {
                  var53 = var29;
                  var10004 = var22;
               } else {
                  var43 = var29;
                  var32 = var10003;
                  if (var10003 <= var22) {
                     break label77;
                  }

                  var53 = var29;
                  var10004 = var22;
               }

               while(true) {
                  char var10005 = var53[var10004];
                  byte var10006;
                  switch (var22 % 7) {
                     case 0 -> var10006 = 36;
                     case 1 -> var10006 = 47;
                     case 2 -> var10006 = 127;
                     case 3 -> var10006 = 31;
                     case 4 -> var10006 = 31;
                     case 5 -> var10006 = 22;
                     default -> var10006 = 89;
                  }

                  var53[var10004] = (char)(var10005 ^ var10006);
                  ++var22;
                  if (var32 == 0) {
                     var10004 = var32;
                     var53 = var43;
                  } else {
                     if (var32 <= var22) {
                        break;
                     }

                     var53 = var43;
                     var10004 = var22;
                  }
               }
            }

            String var60 = (new String(var43)).intern();
            switch (var10001) {
               case 0:
                  var21[var19++] = var60;
                  if ((var25 += var17) >= var20) {
                     a = var21;
                     b = new String[14];
                     ANCHOR = a(-5973, -24752);
                     GLOWSTONE = a(-5970, -24035);
                     long var8 = 4259149471947667064L;
                     long[] var14 = new long[8];
                     int var11 = 0;
                     String var12 = "\u0088#Æ(®Êô¨Ã±©,\u0097eS¥]\u008fÄ\u001f\n\u0093\u0096âÀùZÕQdK»ç.^£U?\u009cµ¦E7´\u0083\u0000é\u007f";
                     int var13 = "\u0088#Æ(®Êô¨Ã±©,\u0097eS¥]\u008fÄ\u001f\n\u0093\u0096âÀùZÕQdK»ç.^£U?\u009cµ¦E7´\u0083\u0000é\u007f".length();
                     int var10 = 0;

                     label53:
                     while(true) {
                        var10001 = var10;
                        var10 += 8;
                        byte[] var15 = var12.substring(var10001, var10).getBytes("ISO-8859-1");
                        long[] var27 = var14;
                        var10001 = var11++;
                        long var48 = ((long)var15[0] & 255L) << 56 | ((long)var15[1] & 255L) << 48 | ((long)var15[2] & 255L) << 40 | ((long)var15[3] & 255L) << 32 | ((long)var15[4] & 255L) << 24 | ((long)var15[5] & 255L) << 16 | ((long)var15[6] & 255L) << 8 | (long)var15[7] & 255L;
                        byte var61 = -1;

                        while(true) {
                           long var65 = var48 ^ var8;
                           switch (var61) {
                              case 0:
                                 var27[var10001] = var65;
                                 if (var10 >= var13) {
                                    c = var14;
                                    d = new Integer[8];
                                    GUARD_TICKS = a(22980, 8761806747871750857L);
                                    TURN_TICKS = a(249, 2994263417511375862L);
                                    SETTLED_TICKS = a(3787, 3287922408536669633L);
                                    CHARGE_GRACE_TICKS = a(22980, 8761806747871750857L);
                                    MAX_TICKS = a(16372, 520993140382485754L);
                                    long var0 = 7929938054544672982L;
                                    long[] var6 = new long[3];
                                    int var3 = 0;
                                    String var4 = "x\u009bYp\u009aï\b'X\u0096,@\u0093\u000ff\u001eC8â[âü\u0012\u001c";
                                    int var5 = "x\u009bYp\u009aï\b'X\u0096,@\u0093\u000ff\u001eC8â[âü\u0012\u001c".length();
                                    int var2 = 0;

                                    do {
                                       var10001 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                                       var10001 = var3++;
                                       var65 = (((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L) ^ var0;
                                       var61 = -1;
                                       var6[var10001] = var65;
                                    } while(var2 < var5);

                                    e = var6;
                                    f = new Long[3];
                                    return;
                                 }
                                 break;
                              default:
                                 var27[var10001] = var65;
                                 if (var10 < var13) {
                                    continue label53;
                                 }

                                 var12 = "\u001dG\u0098¾<\rÅ\u0088\u0081\u008a«\u001eÎRzª";
                                 var13 = "\u001dG\u0098¾<\rÅ\u0088\u0081\u008a«\u001eÎRzª".length();
                                 var10 = 0;
                           }

                           var10001 = var10;
                           var10 += 8;
                           var15 = var12.substring(var10001, var10).getBytes("ISO-8859-1");
                           var27 = var14;
                           var10001 = var11++;
                           var48 = ((long)var15[0] & 255L) << 56 | ((long)var15[1] & 255L) << 48 | ((long)var15[2] & 255L) << 40 | ((long)var15[3] & 255L) << 32 | ((long)var15[4] & 255L) << 24 | ((long)var15[5] & 255L) << 16 | ((long)var15[6] & 255L) << 8 | (long)var15[7] & 255L;
                           var61 = 0;
                        }
                     }
                  }

                  var17 = var18.charAt(var25);
                  break;
               default:
                  var21[var19++] = var60;
                  if ((var25 += var17) < var20) {
                     var17 = var18.charAt(var25);
                     continue label82;
                  }

                  var18 = "õÂ¡45\u009en¡.H¥ÎEè8ÿ\u0013\u0005¨\u0013\u000b\u0004e×8j\u001b8z<½\u0085%º³Õ\u0017ç\u0087BGÆ\u0018\u0005\u0014\u0087\fJ!\u0007N¦\u008890\u0096Õ\u0085º\u001czû4ß\u001b\u009bN?s\u008b<tm\u0016s+Þr\u00adV\u0012±";
                  var20 = "õÂ¡45\u009en¡.H¥ÎEè8ÿ\u0013\u0005¨\u0013\u000b\u0004e×8j\u001b8z<½\u0085%º³Õ\u0017ç\u0087BGÆ\u0018\u0005\u0014\u0087\fJ!\u0007N¦\u008890\u0096Õ\u0085º\u001czû4ß\u001b\u009bN?s\u008b<tm\u0016s+Þr\u00adV\u0012±".length();
                  var17 = '\t';
                  var25 = -1;
            }

            ++var25;
            var10000 = var18.substring(var25, var25 + var17);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ -5971) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 123;
            case 1 -> var10000 = 133;
            case 2 -> var10000 = 45;
            case 3 -> var10000 = 67;
            case 4 -> var10000 = 193;
            case 5 -> var10000 = 191;
            case 6 -> var10000 = 216;
            case 7 -> var10000 = 241;
            case 8 -> var10000 = 131;
            case 9 -> var10000 = 202;
            case 10 -> var10000 = 204;
            case 11 -> var10000 = 138;
            case 12 -> var10000 = 51;
            case 13 -> var10000 = 9;
            case 14 -> var10000 = 236;
            case 15 -> var10000 = 11;
            case 16 -> var10000 = 251;
            case 17 -> var10000 = 197;
            case 18 -> var10000 = 206;
            case 19 -> var10000 = 214;
            case 20 -> var10000 = 192;
            case 21 -> var10000 = 7;
            case 22 -> var10000 = 22;
            case 23 -> var10000 = 240;
            case 24 -> var10000 = 27;
            case 25 -> var10000 = 96;
            case 26 -> var10000 = 231;
            case 27 -> var10000 = 230;
            case 28 -> var10000 = 132;
            case 29 -> var10000 = 140;
            case 30 -> var10000 = 62;
            case 31 -> var10000 = 75;
            case 32 -> var10000 = 50;
            case 33 -> var10000 = 36;
            case 34 -> var10000 = 31;
            case 35 -> var10000 = 71;
            case 36 -> var10000 = 250;
            case 37 -> var10000 = 44;
            case 38 -> var10000 = 162;
            case 39 -> var10000 = 169;
            case 40 -> var10000 = 33;
            case 41 -> var10000 = 228;
            case 42 -> var10000 = 186;
            case 43 -> var10000 = 118;
            case 44 -> var10000 = 151;
            case 45 -> var10000 = 219;
            case 46 -> var10000 = 244;
            case 47 -> var10000 = 158;
            case 48 -> var10000 = 94;
            case 49 -> var10000 = 18;
            case 50 -> var10000 = 153;
            case 51 -> var10000 = 139;
            case 52 -> var10000 = 70;
            case 53 -> var10000 = 64;
            case 54 -> var10000 = 47;
            case 55 -> var10000 = 142;
            case 56 -> var10000 = 145;
            case 57 -> var10000 = 150;
            case 58 -> var10000 = 172;
            case 59 -> var10000 = 233;
            case 60 -> var10000 = 54;
            case 61 -> var10000 = 102;
            case 62 -> var10000 = 105;
            case 63 -> var10000 = 200;
            case 64 -> var10000 = 92;
            case 65 -> var10000 = 146;
            case 66 -> var10000 = 26;
            case 67 -> var10000 = 232;
            case 68 -> var10000 = 29;
            case 69 -> var10000 = 185;
            case 70 -> var10000 = 79;
            case 71 -> var10000 = 90;
            case 72 -> var10000 = 225;
            case 73 -> var10000 = 136;
            case 74 -> var10000 = 57;
            case 75 -> var10000 = 53;
            case 76 -> var10000 = 21;
            case 77 -> var10000 = 239;
            case 78 -> var10000 = 37;
            case 79 -> var10000 = 252;
            case 80 -> var10000 = 238;
            case 81 -> var10000 = 212;
            case 82 -> var10000 = 242;
            case 83 -> var10000 = 52;
            case 84 -> var10000 = 119;
            case 85 -> var10000 = 174;
            case 86 -> var10000 = 48;
            case 87 -> var10000 = 237;
            case 88 -> var10000 = 39;
            case 89 -> var10000 = 182;
            case 90 -> var10000 = 66;
            case 91 -> var10000 = 143;
            case 92 -> var10000 = 196;
            case 93 -> var10000 = 195;
            case 94 -> var10000 = 207;
            case 95 -> var10000 = 126;
            case 96 -> var10000 = 63;
            case 97 -> var10000 = 141;
            case 98 -> var10000 = 226;
            case 99 -> var10000 = 246;
            case 100 -> var10000 = 128;
            case 101 -> var10000 = 24;
            case 102 -> var10000 = 38;
            case 103 -> var10000 = 127;
            case 104 -> var10000 = 76;
            case 105 -> var10000 = 74;
            case 106 -> var10000 = 122;
            case 107 -> var10000 = 6;
            case 108 -> var10000 = 80;
            case 109 -> var10000 = 40;
            case 110 -> var10000 = 217;
            case 111 -> var10000 = 42;
            case 112 -> var10000 = 101;
            case 113 -> var10000 = 86;
            case 114 -> var10000 = 78;
            case 115 -> var10000 = 221;
            case 116 -> var10000 = 223;
            case 117 -> var10000 = 224;
            case 118 -> var10000 = 55;
            case 119 -> var10000 = 130;
            case 120 -> var10000 = 245;
            case 121 -> var10000 = 165;
            case 122 -> var10000 = 160;
            case 123 -> var10000 = 203;
            case 124 -> var10000 = 177;
            case 125 -> var10000 = 188;
            case 126 -> var10000 = 171;
            case 127 -> var10000 = 84;
            case 128 -> var10000 = 72;
            case 129 -> var10000 = 173;
            case 130 -> var10000 = 15;
            case 131 -> var10000 = 121;
            case 132 -> var10000 = 10;
            case 133 -> var10000 = 255;
            case 134 -> var10000 = 14;
            case 135 -> var10000 = 213;
            case 136 -> var10000 = 25;
            case 137 -> var10000 = 28;
            case 138 -> var10000 = 181;
            case 139 -> var10000 = 110;
            case 140 -> var10000 = 60;
            case 141 -> var10000 = 210;
            case 142 -> var10000 = 156;
            case 143 -> var10000 = 69;
            case 144 -> var10000 = 85;
            case 145 -> var10000 = 208;
            case 146 -> var10000 = 35;
            case 147 -> var10000 = 5;
            case 148 -> var10000 = 61;
            case 149 -> var10000 = 125;
            case 150 -> var10000 = 194;
            case 151 -> var10000 = 209;
            case 152 -> var10000 = 56;
            case 153 -> var10000 = 68;
            case 154 -> var10000 = 124;
            case 155 -> var10000 = 100;
            case 156 -> var10000 = 30;
            case 157 -> var10000 = 235;
            case 158 -> var10000 = 227;
            case 159 -> var10000 = 222;
            case 160 -> var10000 = 199;
            case 161 -> var10000 = 176;
            case 162 -> var10000 = 184;
            case 163 -> var10000 = 135;
            case 164 -> var10000 = 218;
            case 165 -> var10000 = 164;
            case 166 -> var10000 = 144;
            case 167 -> var10000 = 129;
            case 168 -> var10000 = 58;
            case 169 -> var10000 = 215;
            case 170 -> var10000 = 198;
            case 171 -> var10000 = 116;
            case 172 -> var10000 = 13;
            case 173 -> var10000 = 17;
            case 174 -> var10000 = 170;
            case 175 -> var10000 = 1;
            case 176 -> var10000 = 187;
            case 177 -> var10000 = 107;
            case 178 -> var10000 = 77;
            case 179 -> var10000 = 99;
            case 180 -> var10000 = 19;
            case 181 -> var10000 = 229;
            case 182 -> var10000 = 175;
            case 183 -> var10000 = 168;
            case 184 -> var10000 = 190;
            case 185 -> var10000 = 114;
            case 186 -> var10000 = 157;
            case 187 -> var10000 = 87;
            case 188 -> var10000 = 93;
            case 189 -> var10000 = 3;
            case 190 -> var10000 = 98;
            case 191 -> var10000 = 147;
            case 192 -> var10000 = 152;
            case 193 -> var10000 = 82;
            case 194 -> var10000 = 49;
            case 195 -> var10000 = 137;
            case 196 -> var10000 = 234;
            case 197 -> var10000 = 59;
            case 198 -> var10000 = 115;
            case 199 -> var10000 = 117;
            case 200 -> var10000 = 120;
            case 201 -> var10000 = 8;
            case 202 -> var10000 = 113;
            case 203 -> var10000 = 16;
            case 204 -> var10000 = 65;
            case 205 -> var10000 = 178;
            case 206 -> var10000 = 248;
            case 207 -> var10000 = 205;
            case 208 -> var10000 = 88;
            case 209 -> var10000 = 189;
            case 210 -> var10000 = 163;
            case 211 -> var10000 = 148;
            case 212 -> var10000 = 104;
            case 213 -> var10000 = 23;
            case 214 -> var10000 = 91;
            case 215 -> var10000 = 103;
            case 216 -> var10000 = 111;
            case 217 -> var10000 = 243;
            case 218 -> var10000 = 46;
            case 219 -> var10000 = 73;
            case 220 -> var10000 = 183;
            case 221 -> var10000 = 220;
            case 222 -> var10000 = 89;
            case 223 -> var10000 = 180;
            case 224 -> var10000 = 155;
            case 225 -> var10000 = 81;
            case 226 -> var10000 = 112;
            case 227 -> var10000 = 211;
            case 228 -> var10000 = 95;
            case 229 -> var10000 = 249;
            case 230 -> var10000 = 161;
            case 231 -> var10000 = 154;
            case 232 -> var10000 = 247;
            case 233 -> var10000 = 167;
            case 234 -> var10000 = 179;
            case 235 -> var10000 = 106;
            case 236 -> var10000 = 253;
            case 237 -> var10000 = 41;
            case 238 -> var10000 = 97;
            case 239 -> var10000 = 20;
            case 240 -> var10000 = 43;
            case 241 -> var10000 = 2;
            case 242 -> var10000 = 4;
            case 243 -> var10000 = 0;
            case 244 -> var10000 = 134;
            case 245 -> var10000 = 149;
            case 246 -> var10000 = 201;
            case 247 -> var10000 = 12;
            case 248 -> var10000 = 159;
            case 249 -> var10000 = 83;
            case 250 -> var10000 = 254;
            case 251 -> var10000 = 108;
            case 252 -> var10000 = 166;
            case 253 -> var10000 = 34;
            case 254 -> var10000 = 109;
            default -> var10000 = 32;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 29449;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }

   private static long b(int var0, long var1) {
      int var3 = (var0 ^ (int)var1 ^ 7199) & 32767;
      if (f[var3] == null) {
         f[var3] = e[var3] ^ var1;
      }

      return f[var3];
   }

   private static enum Step {
      IDLE,
      ANCHOR,
      CHARGE,
      GUARD,
      EXPLODE;

      // $FF: synthetic method
      private static Step[] $values() {
         return new Step[]{IDLE, ANCHOR, CHARGE, GUARD, EXPLODE};
      }

      static {
         String[] var0 = new String[5];
         int var4 = 0;
         String var3 = "a+}vn`\u0004i!r{\u0005g0\u007fle";
         int var5 = "a+}vn`\u0004i!r{\u0005g0\u007fle".length();
         char var2 = 6;
         int var8 = -1;

         label56:
         while(true) {
            ++var8;
            String var10000 = var3.substring(var8, var8 + var2);
            byte var10001 = -1;

            while(true) {
               char[] var20;
               label51: {
                  char[] var11 = var10000.toCharArray();
                  int var10003 = var11.length;
                  int var6 = 0;
                  var20 = var11;
                  int var14 = var10003;
                  char[] var28;
                  int var10004;
                  if (var10003 <= 1) {
                     var28 = var11;
                     var10004 = var6;
                  } else {
                     var20 = var11;
                     var14 = var10003;
                     if (var10003 <= var6) {
                        break label51;
                     }

                     var28 = var11;
                     var10004 = var6;
                  }

                  while(true) {
                     char var10005 = var28[var10004];
                     byte var10006;
                     switch (var6 % 7) {
                        case 0 -> var10006 = 32;
                        case 1 -> var10006 = 101;
                        case 2 -> var10006 = 62;
                        case 3 -> var10006 = 62;
                        case 4 -> var10006 = 33;
                        case 5 -> var10006 = 50;
                        default -> var10006 = 127;
                     }

                     var28[var10004] = (char)(var10005 ^ var10006);
                     ++var6;
                     if (var14 == 0) {
                        var10004 = var14;
                        var28 = var20;
                     } else {
                        if (var14 <= var6) {
                           break;
                        }

                        var28 = var20;
                        var10004 = var6;
                     }
                  }
               }

               String var35 = (new String(var20)).intern();
               switch (var10001) {
                  case 0:
                     var0[var4++] = var35;
                     if ((var8 += var2) >= var5) {
                        IDLE = new Step(var0[1], 0);
                        ANCHOR = new Step(var0[0], 1);
                        CHARGE = new Step(var0[4], 2);
                        GUARD = new Step(var0[2], 3);
                        EXPLODE = new Step(var0[3], 4);
                        return;
                     }

                     var2 = var3.charAt(var8);
                     break;
                  default:
                     var0[var4++] = var35;
                     if ((var8 += var2) < var5) {
                        var2 = var3.charAt(var8);
                        continue label56;
                     }

                     var3 = "e=nrnv:\u0006c-\u007flfw";
                     var5 = "e=nrnv:\u0006c-\u007flfw".length();
                     var2 = 7;
                     var8 = -1;
               }

               ++var8;
               var10000 = var3.substring(var8, var8 + var2);
               var10001 = 0;
            }
         }
      }
   }
}
