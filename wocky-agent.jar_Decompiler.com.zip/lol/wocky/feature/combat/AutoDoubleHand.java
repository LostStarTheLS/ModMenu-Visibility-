package lol.wocky.feature.combat;

import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.util.EncryptedString;

public class AutoDoubleHand extends Module {
   private static final String TOTEM;
   private final BooleanProperty onPop = new BooleanProperty(EncryptedString.of(a(32016, 19687)), true);
   private final NumberProperty healthThreshold = new NumberProperty(EncryptedString.of(a(32023, 16143)), (double)10.0F, (double)0.0F, (double)20.0F, (double)0.5F);
   private final BooleanProperty swapBack = new BooleanProperty(EncryptedString.of(a(32021, 25148)), false);
   private boolean hadOffhandTotem = false;
   private boolean wasLow = false;
   private int previousSlot = -1;
   private static final String[] a;
   private static final String[] b;

   public AutoDoubleHand() {
      super(EncryptedString.of(a(32020, -18671)), EncryptedString.of(a(32022, 32428)), ModuleCategory.CPVP);
      this.addProperties(new Property[]{this.onPop, this.healthThreshold, this.swapBack});
   }

   public void onEnable() {
      this.hadOffhandTotem = MinecraftBridge.isItem(MinecraftBridge.getOffHandStack(), a(32019, 68));
      this.wasLow = false;
      this.previousSlot = -1;
   }

   public void onTick() {
      if (MinecraftBridge.getCurrentScreen() == null) {
         boolean var1 = MinecraftBridge.isItem(MinecraftBridge.getOffHandStack(), a(32017, -19638));
         boolean var2 = this.hadOffhandTotem && !var1;
         this.hadOffhandTotem = var1;
         double var3 = this.healthThreshold.doubleValue();
         boolean var5 = var3 > (double)0.0F && (double)MinecraftBridge.getPlayerHealth() <= var3;
         boolean var6 = var5 && !this.wasLow;
         this.wasLow = var5;
         if ((!(Boolean)this.onPop.getValue() || !var2) && !var6) {
            if ((Boolean)this.swapBack.getValue() && this.previousSlot != -1 && var1 && !var5) {
               MinecraftBridge.setSelectedSlot(this.previousSlot);
               this.previousSlot = -1;
            }
         } else if (!MinecraftBridge.isHolding(a(32017, -19638))) {
            if (this.previousSlot == -1) {
               this.previousSlot = MinecraftBridge.getSelectedSlot();
            }

            MinecraftBridge.selectHotbarItem(a(32017, -19638));
         }

      }
   }

   public void onDisable() {
      if ((Boolean)this.swapBack.getValue() && this.previousSlot != -1) {
         MinecraftBridge.setSelectedSlot(this.previousSlot);
      }

      this.previousSlot = -1;
   }

   static {
      String[] var5 = new String[8];
      int var3 = 0;
      String var2 = "¢$æùWi\u001f£8\u0090g\u008fx\u0094\t°¦áôd\u0019\u0085$úBÿ&}ë\b\u000e1«o\u00915ç\u0086ìÓ¹\u009ep\u0001\"\u0085\u009d\u0090àÐÀ{\u001f\"\u007f\u0010uuñ \u009bcõ&\u00174 \u000fÿ§\u0086\u008aeì\u009c\u0083j\u001b,\u0099Íøì9\u008e\u001e=ë¸Z.\u0010\u0003Öï¶ñä¨Ã5{o\u0015÷\u009c\u0099\u0019\u0006AÍ\u0001\u0083^á\u0010nÔì´?»\u0004Ë1\t5«Ç¸®X";
      int var4 = "¢$æùWi\u001f£8\u0090g\u008fx\u0094\t°¦áôd\u0019\u0085$úBÿ&}ë\b\u000e1«o\u00915ç\u0086ìÓ¹\u009ep\u0001\"\u0085\u009d\u0090àÐÀ{\u001f\"\u007f\u0010uuñ \u009bcõ&\u00174 \u000fÿ§\u0086\u008aeì\u009c\u0083j\u001b,\u0099Íøì9\u008e\u001e=ë¸Z.\u0010\u0003Öï¶ñä¨Ã5{o\u0015÷\u009c\u0099\u0019\u0006AÍ\u0001\u0083^á\u0010nÔì´?»\u0004Ë1\t5«Ç¸®X".length();
      char var1 = 14;
      int var8 = -1;

      label55:
      while(true) {
         ++var8;
         String var10000 = var2.substring(var8, var8 + var1);
         byte var10001 = -1;

         while(true) {
            char[] var20;
            label50: {
               char[] var11 = var10000.toCharArray();
               int var10003 = var11.length;
               int var6 = 0;
               var20 = var11;
               int var14 = var10003;
               char[] var28;
               int var10004;
               if (var10003 <= 1) {
                  var28 = var11;
                  var10004 = var6;
               } else {
                  var20 = var11;
                  var14 = var10003;
                  if (var10003 <= var6) {
                     break label50;
                  }

                  var28 = var11;
                  var10004 = var6;
               }

               while(true) {
                  char var10005 = var28[var10004];
                  byte var10006;
                  switch (var6 % 7) {
                     case 0 -> var10006 = 44;
                     case 1 -> var10006 = 36;
                     case 2 -> var10006 = 42;
                     case 3 -> var10006 = 77;
                     case 4 -> var10006 = 112;
                     case 5 -> var10006 = 18;
                     default -> var10006 = 66;
                  }

                  var28[var10004] = (char)(var10005 ^ var10006);
                  ++var6;
                  if (var14 == 0) {
                     var10004 = var14;
                     var28 = var20;
                  } else {
                     if (var14 <= var6) {
                        break;
                     }

                     var28 = var20;
                     var10004 = var6;
                  }
               }
            }

            String var35 = (new String(var20)).intern();
            switch (var10001) {
               case 0:
                  var5[var3++] = var35;
                  if ((var8 += var1) >= var4) {
                     a = var5;
                     b = new String[8];
                     TOTEM = a(32018, 15738);
                     return;
                  }

                  var1 = var2.charAt(var8);
                  break;
               default:
                  var5[var3++] = var35;
                  if ((var8 += var1) < var4) {
                     var1 = var2.charAt(var8);
                     continue label55;
                  }

                  var2 = "\u0001W\u0001Ä\u0082µ³\nÇ1ë¬\u001cXÕD\u0010 ÿ5Ñ\u0004\u0017c^Ý»¨ýtrØ\u0001";
                  var4 = "\u0001W\u0001Ä\u0082µ³\nÇ1ë¬\u001cXÕD\u0010 ÿ5Ñ\u0004\u0017c^Ý»¨ýtrØ\u0001".length();
                  var1 = 16;
                  var8 = -1;
            }

            ++var8;
            var10000 = var2.substring(var8, var8 + var1);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 32020) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 107;
            case 1 -> var10000 = 51;
            case 2 -> var10000 = 184;
            case 3 -> var10000 = 139;
            case 4 -> var10000 = 24;
            case 5 -> var10000 = 50;
            case 6 -> var10000 = 175;
            case 7 -> var10000 = 141;
            case 8 -> var10000 = 53;
            case 9 -> var10000 = 94;
            case 10 -> var10000 = 195;
            case 11 -> var10000 = 9;
            case 12 -> var10000 = 234;
            case 13 -> var10000 = 138;
            case 14 -> var10000 = 181;
            case 15 -> var10000 = 49;
            case 16 -> var10000 = 78;
            case 17 -> var10000 = 151;
            case 18 -> var10000 = 91;
            case 19 -> var10000 = 21;
            case 20 -> var10000 = 93;
            case 21 -> var10000 = 180;
            case 22 -> var10000 = 99;
            case 23 -> var10000 = 89;
            case 24 -> var10000 = 254;
            case 25 -> var10000 = 25;
            case 26 -> var10000 = 127;
            case 27 -> var10000 = 143;
            case 28 -> var10000 = 34;
            case 29 -> var10000 = 255;
            case 30 -> var10000 = 124;
            case 31 -> var10000 = 29;
            case 32 -> var10000 = 8;
            case 33 -> var10000 = 46;
            case 34 -> var10000 = 211;
            case 35 -> var10000 = 250;
            case 36 -> var10000 = 62;
            case 37 -> var10000 = 187;
            case 38 -> var10000 = 247;
            case 39 -> var10000 = 48;
            case 40 -> var10000 = 231;
            case 41 -> var10000 = 172;
            case 42 -> var10000 = 144;
            case 43 -> var10000 = 118;
            case 44 -> var10000 = 82;
            case 45 -> var10000 = 33;
            case 46 -> var10000 = 14;
            case 47 -> var10000 = 168;
            case 48 -> var10000 = 73;
            case 49 -> var10000 = 92;
            case 50 -> var10000 = 100;
            case 51 -> var10000 = 237;
            case 52 -> var10000 = 238;
            case 53 -> var10000 = 178;
            case 54 -> var10000 = 83;
            case 55 -> var10000 = 96;
            case 56 -> var10000 = 57;
            case 57 -> var10000 = 120;
            case 58 -> var10000 = 236;
            case 59 -> var10000 = 11;
            case 60 -> var10000 = 5;
            case 61 -> var10000 = 113;
            case 62 -> var10000 = 69;
            case 63 -> var10000 = 163;
            case 64 -> var10000 = 16;
            case 65 -> var10000 = 149;
            case 66 -> var10000 = 20;
            case 67 -> var10000 = 137;
            case 68 -> var10000 = 202;
            case 69 -> var10000 = 154;
            case 70 -> var10000 = 219;
            case 71 -> var10000 = 52;
            case 72 -> var10000 = 41;
            case 73 -> var10000 = 177;
            case 74 -> var10000 = 67;
            case 75 -> var10000 = 128;
            case 76 -> var10000 = 225;
            case 77 -> var10000 = 196;
            case 78 -> var10000 = 239;
            case 79 -> var10000 = 110;
            case 80 -> var10000 = 218;
            case 81 -> var10000 = 12;
            case 82 -> var10000 = 72;
            case 83 -> var10000 = 183;
            case 84 -> var10000 = 58;
            case 85 -> var10000 = 223;
            case 86 -> var10000 = 70;
            case 87 -> var10000 = 119;
            case 88 -> var10000 = 47;
            case 89 -> var10000 = 65;
            case 90 -> var10000 = 182;
            case 91 -> var10000 = 117;
            case 92 -> var10000 = 101;
            case 93 -> var10000 = 245;
            case 94 -> var10000 = 40;
            case 95 -> var10000 = 86;
            case 96 -> var10000 = 240;
            case 97 -> var10000 = 221;
            case 98 -> var10000 = 148;
            case 99 -> var10000 = 108;
            case 100 -> var10000 = 44;
            case 101 -> var10000 = 106;
            case 102 -> var10000 = 210;
            case 103 -> var10000 = 156;
            case 104 -> var10000 = 159;
            case 105 -> var10000 = 174;
            case 106 -> var10000 = 134;
            case 107 -> var10000 = 162;
            case 108 -> var10000 = 103;
            case 109 -> var10000 = 197;
            case 110 -> var10000 = 203;
            case 111 -> var10000 = 157;
            case 112 -> var10000 = 179;
            case 113 -> var10000 = 226;
            case 114 -> var10000 = 123;
            case 115 -> var10000 = 37;
            case 116 -> var10000 = 36;
            case 117 -> var10000 = 122;
            case 118 -> var10000 = 220;
            case 119 -> var10000 = 105;
            case 120 -> var10000 = 235;
            case 121 -> var10000 = 7;
            case 122 -> var10000 = 246;
            case 123 -> var10000 = 87;
            case 124 -> var10000 = 0;
            case 125 -> var10000 = 230;
            case 126 -> var10000 = 213;
            case 127 -> var10000 = 243;
            case 128 -> var10000 = 212;
            case 129 -> var10000 = 248;
            case 130 -> var10000 = 59;
            case 131 -> var10000 = 4;
            case 132 -> var10000 = 160;
            case 133 -> var10000 = 18;
            case 134 -> var10000 = 171;
            case 135 -> var10000 = 6;
            case 136 -> var10000 = 209;
            case 137 -> var10000 = 189;
            case 138 -> var10000 = 13;
            case 139 -> var10000 = 114;
            case 140 -> var10000 = 76;
            case 141 -> var10000 = 55;
            case 142 -> var10000 = 66;
            case 143 -> var10000 = 185;
            case 144 -> var10000 = 147;
            case 145 -> var10000 = 102;
            case 146 -> var10000 = 97;
            case 147 -> var10000 = 164;
            case 148 -> var10000 = 146;
            case 149 -> var10000 = 68;
            case 150 -> var10000 = 45;
            case 151 -> var10000 = 23;
            case 152 -> var10000 = 26;
            case 153 -> var10000 = 233;
            case 154 -> var10000 = 39;
            case 155 -> var10000 = 116;
            case 156 -> var10000 = 109;
            case 157 -> var10000 = 10;
            case 158 -> var10000 = 79;
            case 159 -> var10000 = 38;
            case 160 -> var10000 = 133;
            case 161 -> var10000 = 152;
            case 162 -> var10000 = 242;
            case 163 -> var10000 = 140;
            case 164 -> var10000 = 207;
            case 165 -> var10000 = 43;
            case 166 -> var10000 = 61;
            case 167 -> var10000 = 15;
            case 168 -> var10000 = 217;
            case 169 -> var10000 = 132;
            case 170 -> var10000 = 215;
            case 171 -> var10000 = 2;
            case 172 -> var10000 = 244;
            case 173 -> var10000 = 193;
            case 174 -> var10000 = 199;
            case 175 -> var10000 = 64;
            case 176 -> var10000 = 186;
            case 177 -> var10000 = 173;
            case 178 -> var10000 = 63;
            case 179 -> var10000 = 232;
            case 180 -> var10000 = 155;
            case 181 -> var10000 = 42;
            case 182 -> var10000 = 54;
            case 183 -> var10000 = 77;
            case 184 -> var10000 = 121;
            case 185 -> var10000 = 241;
            case 186 -> var10000 = 198;
            case 187 -> var10000 = 95;
            case 188 -> var10000 = 98;
            case 189 -> var10000 = 125;
            case 190 -> var10000 = 161;
            case 191 -> var10000 = 253;
            case 192 -> var10000 = 111;
            case 193 -> var10000 = 206;
            case 194 -> var10000 = 126;
            case 195 -> var10000 = 214;
            case 196 -> var10000 = 229;
            case 197 -> var10000 = 167;
            case 198 -> var10000 = 115;
            case 199 -> var10000 = 85;
            case 200 -> var10000 = 158;
            case 201 -> var10000 = 228;
            case 202 -> var10000 = 194;
            case 203 -> var10000 = 224;
            case 204 -> var10000 = 153;
            case 205 -> var10000 = 222;
            case 206 -> var10000 = 191;
            case 207 -> var10000 = 104;
            case 208 -> var10000 = 249;
            case 209 -> var10000 = 28;
            case 210 -> var10000 = 201;
            case 211 -> var10000 = 17;
            case 212 -> var10000 = 130;
            case 213 -> var10000 = 129;
            case 214 -> var10000 = 30;
            case 215 -> var10000 = 176;
            case 216 -> var10000 = 135;
            case 217 -> var10000 = 31;
            case 218 -> var10000 = 251;
            case 219 -> var10000 = 1;
            case 220 -> var10000 = 169;
            case 221 -> var10000 = 227;
            case 222 -> var10000 = 190;
            case 223 -> var10000 = 90;
            case 224 -> var10000 = 165;
            case 225 -> var10000 = 205;
            case 226 -> var10000 = 60;
            case 227 -> var10000 = 35;
            case 228 -> var10000 = 142;
            case 229 -> var10000 = 112;
            case 230 -> var10000 = 131;
            case 231 -> var10000 = 22;
            case 232 -> var10000 = 208;
            case 233 -> var10000 = 27;
            case 234 -> var10000 = 71;
            case 235 -> var10000 = 19;
            case 236 -> var10000 = 80;
            case 237 -> var10000 = 32;
            case 238 -> var10000 = 3;
            case 239 -> var10000 = 56;
            case 240 -> var10000 = 192;
            case 241 -> var10000 = 145;
            case 242 -> var10000 = 204;
            case 243 -> var10000 = 84;
            case 244 -> var10000 = 170;
            case 245 -> var10000 = 200;
            case 246 -> var10000 = 252;
            case 247 -> var10000 = 166;
            case 248 -> var10000 = 188;
            case 249 -> var10000 = 136;
            case 250 -> var10000 = 216;
            case 251 -> var10000 = 88;
            case 252 -> var10000 = 81;
            case 253 -> var10000 = 75;
            case 254 -> var10000 = 74;
            default -> var10000 = 150;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }
}
