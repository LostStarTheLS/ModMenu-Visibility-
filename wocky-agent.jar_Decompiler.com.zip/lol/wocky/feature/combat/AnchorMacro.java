package lol.wocky.feature.combat;

import java.util.Arrays;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.ModuleManager;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.KeyProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;

public class AnchorMacro extends Module {
   private static final String ANCHOR;
   private static final String GLOWSTONE;
   private static final int CHARGE_GRACE_TICKS;
   private static final double DOUBLE_CHARGE_CHANCE = 0.2;
   private static final double LATE_STEP_CHANCE = 0.35;
   private static final int STEP_SWITCH_GLOWSTONE = 0;
   private static final int STEP_CHARGE = 1;
   private static final int STEP_SWITCH_EXPLODE;
   private static final int STEP_EXPLODE;
   private final KeyProperty activateKey = new KeyProperty(a(-24485, 19205), a(4099, 5966187887949236561L));
   private final NumberProperty switchDelay = new NumberProperty(a(-24489, 5005), 0, 0, a(3409, 4540141232167146498L), 1);
   private final NumberProperty chargeDelay = new NumberProperty(a(-24494, 13998), 0, 0, a(3810, 338171948858562491L), 1);
   private final NumberProperty explodeDelay = new NumberProperty(a(-24488, 16217), 0, 0, a(3810, 338171948858562491L), 1);
   private final NumberProperty explodeSlot = new NumberProperty(a(-24496, -29520), 0, 0, a(17794, 1220276691436379346L), 1);
   private final BooleanProperty placeAnchor = new BooleanProperty(a(-24491, 26385), false);
   private final BooleanProperty swapBack = new BooleanProperty(a(-24482, 21446), true);
   private final BooleanProperty legit = new BooleanProperty(a(-24487, -7412), false);
   private int clock;
   private int previousSlot = -1;
   private boolean active;
   private int[] chargedPos;
   private long chargedTick;
   private int chargedCount;
   private int[] targetPos;
   private int wantCharges = 1;
   private int lateStep = -1;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;
   private static final long e;

   public AnchorMacro() {
      super(a(-24481, -28030), a(-24483, 29715), ModuleCategory.CPVP);
      Property[] var10001 = new Property[a(3281, 8766511485902738827L)];
      var10001[0] = this.activateKey;
      var10001[1] = this.switchDelay;
      var10001[2] = this.chargeDelay;
      var10001[3] = this.explodeDelay;
      var10001[4] = this.explodeSlot;
      var10001[5] = this.placeAnchor;
      var10001[a(2098, 7432460809199014243L)] = this.swapBack;
      var10001[a(22238, 7171994887483887496L)] = this.legit;
      this.addProperties(var10001);
   }

   public static boolean isHandling(Object var0) {
      AnchorMacro var1 = (AnchorMacro)ModuleManager.getByClass(AnchorMacro.class);
      return var1 != null && var1.isEnabled() && var1.isActivated() && MinecraftBridge.anchorCharges(var0) >= 0;
   }

   public boolean isActivated() {
      int var1 = this.activateKey.getKey();
      return var1 == 0 ? MinecraftBridge.isKeyDown(a(31769, 3646255286344820033L)) : this.activateKey.isDown();
   }

   public boolean cancelsItemUse() {
      if (!this.isActivated()) {
         return false;
      } else {
         Object var1 = MinecraftBridge.getCrosshairTarget();
         if (!MinecraftBridge.isBlockHit(var1)) {
            return false;
         } else {
            return MinecraftBridge.anchorCharges(MinecraftBridge.getHitBlockPos(var1)) >= 0 || (Boolean)this.placeAnchor.getValue() && MinecraftBridge.isHolding(a(-24495, 27502));
         }
      }
   }

   public void onTick() {
      if (MinecraftBridge.getCurrentScreen() == null && !DoubleAnchor.isRunning()) {
         if (!this.isActivated()) {
            if (this.active && (Boolean)this.swapBack.getValue() && this.previousSlot != -1) {
               MinecraftBridge.setSelectedSlot(this.previousSlot);
            }

            this.reset();
         } else if (this.clock > 0) {
            --this.clock;
         } else {
            Object var1 = MinecraftBridge.getCrosshairTarget();
            if (MinecraftBridge.isBlockHit(var1)) {
               Object var2 = MinecraftBridge.getHitBlockPos(var1);
               int var3 = MinecraftBridge.anchorCharges(var2);
               if (var3 < 0) {
                  if ((Boolean)this.placeAnchor.getValue() && MinecraftBridge.canPlaceBlockAt(var1)) {
                     this.place(var1);
                  }

               } else {
                  this.begin();
                  int[] var4 = MinecraftBridge.coords(var2);
                  if (!Arrays.equals(var4, this.targetPos)) {
                     this.targetPos = var4;
                     this.planVariation(var3);
                  }

                  if (this.knownCharges(var4, var3) < this.wantCharges) {
                     if (!MinecraftBridge.isHolding(a(-24490, -30943))) {
                        if (!MinecraftBridge.selectHotbarItem(a(-24486, -12800))) {
                           return;
                        }

                        this.clock = this.delay(this.switchDelay, 0);
                        if (this.clock > 0) {
                           return;
                        }
                     }

                     if (MinecraftBridge.interactBlock(var1, true)) {
                        int var6 = this.knownCharges(var4, var3);
                        this.chargedPos = var4;
                        this.chargedCount = var6 + 1;
                        this.chargedTick = MinecraftBridge.getTickCount();
                     }

                     this.clock = this.delay(this.chargeDelay, 1);
                  } else {
                     if (MinecraftBridge.isHolding(a(-24486, -12800))) {
                        int var5 = this.findExplodeSlot();
                        if (var5 == -1) {
                           return;
                        }

                        MinecraftBridge.setSelectedSlot(var5);
                        this.clock = this.delay(this.switchDelay, 2);
                        if (this.clock > 0 || MinecraftBridge.isHolding(a(-24486, -12800))) {
                           return;
                        }
                     }

                     if (MinecraftBridge.interactBlock(var1, true)) {
                        this.chargedPos = null;
                        this.targetPos = null;
                        this.clock = this.delay(this.explodeDelay, 3);
                     }
                  }
               }
            }
         }
      }
   }

   private void planVariation(int var1) {
      this.wantCharges = 1;
      this.lateStep = -1;
      if ((Boolean)this.legit.getValue()) {
         double var2 = Math.random();
         if (var1 == 0 && var2 < 0.2) {
            this.wantCharges = a(7503, 2131416668306359322L);
         } else if (var2 < 0.55) {
            this.lateStep = (int)(Math.random() * (double)4.0F);
         }

      }
   }

   private int delay(NumberProperty var1, int var2) {
      if (var2 != this.lateStep) {
         return var1.intValue();
      } else {
         this.lateStep = -1;
         return var1.intValue() + 1;
      }
   }

   private void place(Object var1) {
      this.begin();
      if (!MinecraftBridge.isHolding(a(-24484, -11506))) {
         if (!MinecraftBridge.selectHotbarItem(a(-24495, 27502))) {
            return;
         }

         this.clock = this.switchDelay.intValue();
         if (this.clock > 0) {
            return;
         }
      }

      if (MinecraftBridge.interactBlock(var1, true)) {
         this.clock = this.switchDelay.intValue();
      }

   }

   private void begin() {
      if (!this.active) {
         this.active = true;
         this.previousSlot = MinecraftBridge.getSelectedSlot();
      }
   }

   private int knownCharges(int[] var1, int var2) {
      boolean var3 = this.chargedPos != null && Arrays.equals(var1, this.chargedPos) && MinecraftBridge.getTickCount() - this.chargedTick <= e;
      return var3 ? Math.max(var2, this.chargedCount) : var2;
   }

   private int findExplodeSlot() {
      int var1 = this.explodeSlot.intValue();
      if (var1 > 0) {
         return var1 - 1;
      } else {
         int var2 = MinecraftBridge.findHotbarSlot(a(-24503, 9406));
         if (var2 == -1) {
            var2 = MinecraftBridge.findSwordSlot();
         }

         for(int var3 = 0; var2 == -1 && var3 < a(17230, 6823165743064226329L); ++var3) {
            if (!MinecraftBridge.isItem(MinecraftBridge.getStackInSlot(var3), a(-24486, -12800))) {
               var2 = var3;
            }
         }

         return var2;
      }
   }

   private void reset() {
      this.clock = 0;
      this.previousSlot = -1;
      this.active = false;
      this.chargedPos = null;
      this.targetPos = null;
      this.chargedCount = 0;
      this.lateStep = -1;
   }

   public void onDisable() {
      this.reset();
   }

   static {
      String[] var15 = new String[17];
      int var13 = 0;
      String var12 = "8\u0002\u0090q©\rñN\u0096C\u0087\u008a15ªÒd¶s\fk\u007fE\u0018`Aæ¬\u0007\"0[\t\u0084±A1\u009d¬ç\u00ad\u001a<8\u0098x\u0095a\u008còÔ#åÜ{p\b>¦f¦_\u009bD6æ²\u0002«[Zäók¥\u0007\u0018¦¸$>\u007fÏxÖ\u0082\u001aÕ\u0099Ýö.9ÍôéF\u0016q+\u008d\u0011_\u000eüZåc\u0084\u0002\u0095*qª\u0091Ú5j\u000bµÆ\u0089\u0082\u0015 Kõï´\f\t\u0093V\u001f²Ê\r:d`\u000e\u0015mØ\u0085#Þa±ïÙB´O§\f×ºRÝ\u001fY\"Oß\u0094<C\t`ÈÝ\u001e\u000eI\u0095\u0011T\f\u0004Ëÿÿ\u0091Á¿\u0019·¶Ï\n\fÂ(V\u0016¦\u008az·D\byR\u000e\u0084|ê§e\u009a©9öÈa\u0096+ã\f\u0091SW\u0016\u008978kGøÑÃ";
      int var14 = "8\u0002\u0090q©\rñN\u0096C\u0087\u008a15ªÒd¶s\fk\u007fE\u0018`Aæ¬\u0007\"0[\t\u0084±A1\u009d¬ç\u00ad\u001a<8\u0098x\u0095a\u008còÔ#åÜ{p\b>¦f¦_\u009bD6æ²\u0002«[Zäók¥\u0007\u0018¦¸$>\u007fÏxÖ\u0082\u001aÕ\u0099Ýö.9ÍôéF\u0016q+\u008d\u0011_\u000eüZåc\u0084\u0002\u0095*qª\u0091Ú5j\u000bµÆ\u0089\u0082\u0015 Kõï´\f\t\u0093V\u001f²Ê\r:d`\u000e\u0015mØ\u0085#Þa±ïÙB´O§\f×ºRÝ\u001fY\"Oß\u0094<C\t`ÈÝ\u001e\u000eI\u0095\u0011T\f\u0004Ëÿÿ\u0091Á¿\u0019·¶Ï\n\fÂ(V\u0016¦\u008az·D\byR\u000e\u0084|ê§e\u009a©9öÈa\u0096+ã\f\u0091SW\u0016\u008978kGøÑÃ".length();
      char var11 = 5;
      int var19 = -1;

      label73:
      while(true) {
         ++var19;
         String var10000 = var12.substring(var19, var19 + var11);
         int var10001 = -1;

         while(true) {
            char[] var36;
            label68: {
               char[] var23 = var10000.toCharArray();
               int var10003 = var23.length;
               int var16 = 0;
               var36 = var23;
               int var26 = var10003;
               char[] var47;
               int var10004;
               if (var10003 <= 1) {
                  var47 = var23;
                  var10004 = var16;
               } else {
                  var36 = var23;
                  var26 = var10003;
                  if (var10003 <= var16) {
                     break label68;
                  }

                  var47 = var23;
                  var10004 = var16;
               }

               while(true) {
                  char var10005 = var47[var10004];
                  byte var10006;
                  switch (var16 % 7) {
                     case 0 -> var10006 = 32;
                     case 1 -> var10006 = 76;
                     case 2 -> var10006 = 49;
                     case 3 -> var10006 = 24;
                     case 4 -> var10006 = 98;
                     case 5 -> var10006 = 100;
                     default -> var10006 = 106;
                  }

                  var47[var10004] = (char)(var10005 ^ var10006);
                  ++var16;
                  if (var26 == 0) {
                     var10004 = var26;
                     var47 = var36;
                  } else {
                     if (var26 <= var16) {
                        break;
                     }

                     var47 = var36;
                     var10004 = var16;
                  }
               }
            }

            String var54 = (new String(var36)).intern();
            switch (var10001) {
               case 0:
                  var15[var13++] = var54;
                  if ((var19 += var11) >= var14) {
                     a = var15;
                     b = new String[17];
                     GLOWSTONE = a(-24493, -25638);
                     ANCHOR = a(-24492, -28141);
                     long var2 = 1903946872647272327L;
                     long[] var8 = new long[13];
                     int var5 = 0;
                     String var6 = ",Ú\u000b´Ë(\u008d<Q~¯H\u008a6\u0013\u0091\u0018\u0006\u009e^W\u009a[\\Bu+tô\n\u0096â\u0015KÕ±8>H\b\u0018Å1¯a®]\u0097\u0083ºó¿0ú\f-Ò\u0017\u0084ã\u0011ä\u0003\u009f?\u00920Æ\u000bÆ\u0012\u0004}\u0084\u0002\u0086\u0017õAú©J[0é¢a,";
                     int var7 = ",Ú\u000b´Ë(\u008d<Q~¯H\u008a6\u0013\u0091\u0018\u0006\u009e^W\u009a[\\Bu+tô\n\u0096â\u0015KÕ±8>H\b\u0018Å1¯a®]\u0097\u0083ºó¿0ú\f-Ò\u0017\u0084ã\u0011ä\u0003\u009f?\u00920Æ\u000bÆ\u0012\u0004}\u0084\u0002\u0086\u0017õAú©J[0é¢a,".length();
                     int var4 = 0;

                     label44:
                     while(true) {
                        var10001 = var4;
                        var4 += 8;
                        byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
                        long[] var21 = var8;
                        var10001 = var5++;
                        long var41 = ((long)var9[0] & 255L) << 56 | ((long)var9[1] & 255L) << 48 | ((long)var9[2] & 255L) << 40 | ((long)var9[3] & 255L) << 32 | ((long)var9[4] & 255L) << 24 | ((long)var9[5] & 255L) << 16 | ((long)var9[6] & 255L) << 8 | (long)var9[7] & 255L;
                        byte var55 = -1;

                        while(true) {
                           long var58 = var41 ^ var2;
                           switch (var55) {
                              case 0:
                                 var21[var10001] = var58;
                                 if (var4 >= var7) {
                                    c = var8;
                                    d = new Integer[13];
                                    STEP_SWITCH_EXPLODE = a(4860, 5678381742011009960L);
                                    STEP_EXPLODE = a(24357, 1452443443206686334L);
                                    CHARGE_GRACE_TICKS = a(19408, 5011810423968010894L);
                                    long var0 = 1677345167760154944L;
                                    var41 = 1677345167760154948L ^ var0;
                                    var10001 = -1;
                                    e = var41;
                                    return;
                                 }
                                 break;
                              default:
                                 var21[var10001] = var58;
                                 if (var4 < var7) {
                                    continue label44;
                                 }

                                 var6 = "£ØàõSì\u0010( O\u0088\u001e5mÕ\r";
                                 var7 = "£ØàõSì\u0010( O\u0088\u001e5mÕ\r".length();
                                 var4 = 0;
                           }

                           var10001 = var4;
                           var4 += 8;
                           var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
                           var21 = var8;
                           var10001 = var5++;
                           var41 = ((long)var9[0] & 255L) << 56 | ((long)var9[1] & 255L) << 48 | ((long)var9[2] & 255L) << 40 | ((long)var9[3] & 255L) << 32 | ((long)var9[4] & 255L) << 24 | ((long)var9[5] & 255L) << 16 | ((long)var9[6] & 255L) << 8 | (long)var9[7] & 255L;
                           var55 = 0;
                        }
                     }
                  }

                  var11 = var12.charAt(var19);
                  break;
               default:
                  var15[var13++] = var54;
                  if ((var19 += var11) < var14) {
                     var11 = var12.charAt(var19);
                     continue label73;
                  }

                  var12 = "´yG(]\u008fÿÉ\u0019\u0010\u007f²T Yõ¢À\u0088òZ¥ö\u0013J@";
                  var14 = "´yG(]\u008fÿÉ\u0019\u0010\u007f²T Yõ¢À\u0088òZ¥ö\u0013J@".length();
                  var11 = '\t';
                  var19 = -1;
            }

            ++var19;
            var10000 = var12.substring(var19, var19 + var11);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ -24487) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 91;
            case 1 -> var10000 = 247;
            case 2 -> var10000 = 113;
            case 3 -> var10000 = 135;
            case 4 -> var10000 = 186;
            case 5 -> var10000 = 93;
            case 6 -> var10000 = 109;
            case 7 -> var10000 = 188;
            case 8 -> var10000 = 151;
            case 9 -> var10000 = 165;
            case 10 -> var10000 = 4;
            case 11 -> var10000 = 100;
            case 12 -> var10000 = 238;
            case 13 -> var10000 = 246;
            case 14 -> var10000 = 50;
            case 15 -> var10000 = 128;
            case 16 -> var10000 = 13;
            case 17 -> var10000 = 190;
            case 18 -> var10000 = 51;
            case 19 -> var10000 = 34;
            case 20 -> var10000 = 150;
            case 21 -> var10000 = 12;
            case 22 -> var10000 = 26;
            case 23 -> var10000 = 103;
            case 24 -> var10000 = 184;
            case 25 -> var10000 = 202;
            case 26 -> var10000 = 126;
            case 27 -> var10000 = 187;
            case 28 -> var10000 = 248;
            case 29 -> var10000 = 210;
            case 30 -> var10000 = 42;
            case 31 -> var10000 = 148;
            case 32 -> var10000 = 90;
            case 33 -> var10000 = 45;
            case 34 -> var10000 = 252;
            case 35 -> var10000 = 193;
            case 36 -> var10000 = 71;
            case 37 -> var10000 = 76;
            case 38 -> var10000 = 192;
            case 39 -> var10000 = 79;
            case 40 -> var10000 = 59;
            case 41 -> var10000 = 175;
            case 42 -> var10000 = 203;
            case 43 -> var10000 = 117;
            case 44 -> var10000 = 213;
            case 45 -> var10000 = 80;
            case 46 -> var10000 = 253;
            case 47 -> var10000 = 73;
            case 48 -> var10000 = 82;
            case 49 -> var10000 = 170;
            case 50 -> var10000 = 111;
            case 51 -> var10000 = 131;
            case 52 -> var10000 = 217;
            case 53 -> var10000 = 39;
            case 54 -> var10000 = 136;
            case 55 -> var10000 = 21;
            case 56 -> var10000 = 189;
            case 57 -> var10000 = 133;
            case 58 -> var10000 = 173;
            case 59 -> var10000 = 78;
            case 60 -> var10000 = 6;
            case 61 -> var10000 = 244;
            case 62 -> var10000 = 214;
            case 63 -> var10000 = 139;
            case 64 -> var10000 = 179;
            case 65 -> var10000 = 146;
            case 66 -> var10000 = 207;
            case 67 -> var10000 = 161;
            case 68 -> var10000 = 72;
            case 69 -> var10000 = 36;
            case 70 -> var10000 = 241;
            case 71 -> var10000 = 17;
            case 72 -> var10000 = 198;
            case 73 -> var10000 = 62;
            case 74 -> var10000 = 240;
            case 75 -> var10000 = 251;
            case 76 -> var10000 = 74;
            case 77 -> var10000 = 143;
            case 78 -> var10000 = 218;
            case 79 -> var10000 = 178;
            case 80 -> var10000 = 216;
            case 81 -> var10000 = 38;
            case 82 -> var10000 = 2;
            case 83 -> var10000 = 220;
            case 84 -> var10000 = 67;
            case 85 -> var10000 = 154;
            case 86 -> var10000 = 35;
            case 87 -> var10000 = 245;
            case 88 -> var10000 = 105;
            case 89 -> var10000 = 144;
            case 90 -> var10000 = 97;
            case 91 -> var10000 = 255;
            case 92 -> var10000 = 152;
            case 93 -> var10000 = 249;
            case 94 -> var10000 = 8;
            case 95 -> var10000 = 147;
            case 96 -> var10000 = 104;
            case 97 -> var10000 = 20;
            case 98 -> var10000 = 122;
            case 99 -> var10000 = 226;
            case 100 -> var10000 = 228;
            case 101 -> var10000 = 92;
            case 102 -> var10000 = 58;
            case 103 -> var10000 = 164;
            case 104 -> var10000 = 68;
            case 105 -> var10000 = 84;
            case 106 -> var10000 = 52;
            case 107 -> var10000 = 0;
            case 108 -> var10000 = 167;
            case 109 -> var10000 = 141;
            case 110 -> var10000 = 200;
            case 111 -> var10000 = 242;
            case 112 -> var10000 = 195;
            case 113 -> var10000 = 55;
            case 114 -> var10000 = 132;
            case 115 -> var10000 = 115;
            case 116 -> var10000 = 101;
            case 117 -> var10000 = 102;
            case 118 -> var10000 = 212;
            case 119 -> var10000 = 196;
            case 120 -> var10000 = 209;
            case 121 -> var10000 = 116;
            case 122 -> var10000 = 25;
            case 123 -> var10000 = 177;
            case 124 -> var10000 = 49;
            case 125 -> var10000 = 14;
            case 126 -> var10000 = 114;
            case 127 -> var10000 = 194;
            case 128 -> var10000 = 134;
            case 129 -> var10000 = 223;
            case 130 -> var10000 = 41;
            case 131 -> var10000 = 162;
            case 132 -> var10000 = 205;
            case 133 -> var10000 = 125;
            case 134 -> var10000 = 140;
            case 135 -> var10000 = 57;
            case 136 -> var10000 = 118;
            case 137 -> var10000 = 224;
            case 138 -> var10000 = 33;
            case 139 -> var10000 = 163;
            case 140 -> var10000 = 75;
            case 141 -> var10000 = 204;
            case 142 -> var10000 = 48;
            case 143 -> var10000 = 185;
            case 144 -> var10000 = 69;
            case 145 -> var10000 = 153;
            case 146 -> var10000 = 89;
            case 147 -> var10000 = 43;
            case 148 -> var10000 = 46;
            case 149 -> var10000 = 174;
            case 150 -> var10000 = 243;
            case 151 -> var10000 = 157;
            case 152 -> var10000 = 31;
            case 153 -> var10000 = 47;
            case 154 -> var10000 = 232;
            case 155 -> var10000 = 137;
            case 156 -> var10000 = 64;
            case 157 -> var10000 = 81;
            case 158 -> var10000 = 9;
            case 159 -> var10000 = 70;
            case 160 -> var10000 = 215;
            case 161 -> var10000 = 28;
            case 162 -> var10000 = 19;
            case 163 -> var10000 = 123;
            case 164 -> var10000 = 61;
            case 165 -> var10000 = 40;
            case 166 -> var10000 = 110;
            case 167 -> var10000 = 201;
            case 168 -> var10000 = 182;
            case 169 -> var10000 = 169;
            case 170 -> var10000 = 211;
            case 171 -> var10000 = 119;
            case 172 -> var10000 = 5;
            case 173 -> var10000 = 208;
            case 174 -> var10000 = 24;
            case 175 -> var10000 = 63;
            case 176 -> var10000 = 7;
            case 177 -> var10000 = 171;
            case 178 -> var10000 = 129;
            case 179 -> var10000 = 230;
            case 180 -> var10000 = 23;
            case 181 -> var10000 = 86;
            case 182 -> var10000 = 15;
            case 183 -> var10000 = 99;
            case 184 -> var10000 = 54;
            case 185 -> var10000 = 237;
            case 186 -> var10000 = 85;
            case 187 -> var10000 = 65;
            case 188 -> var10000 = 124;
            case 189 -> var10000 = 233;
            case 190 -> var10000 = 206;
            case 191 -> var10000 = 22;
            case 192 -> var10000 = 130;
            case 193 -> var10000 = 239;
            case 194 -> var10000 = 94;
            case 195 -> var10000 = 176;
            case 196 -> var10000 = 11;
            case 197 -> var10000 = 155;
            case 198 -> var10000 = 10;
            case 199 -> var10000 = 222;
            case 200 -> var10000 = 234;
            case 201 -> var10000 = 221;
            case 202 -> var10000 = 120;
            case 203 -> var10000 = 235;
            case 204 -> var10000 = 30;
            case 205 -> var10000 = 1;
            case 206 -> var10000 = 225;
            case 207 -> var10000 = 83;
            case 208 -> var10000 = 199;
            case 209 -> var10000 = 197;
            case 210 -> var10000 = 231;
            case 211 -> var10000 = 138;
            case 212 -> var10000 = 37;
            case 213 -> var10000 = 168;
            case 214 -> var10000 = 219;
            case 215 -> var10000 = 66;
            case 216 -> var10000 = 3;
            case 217 -> var10000 = 236;
            case 218 -> var10000 = 250;
            case 219 -> var10000 = 160;
            case 220 -> var10000 = 96;
            case 221 -> var10000 = 181;
            case 222 -> var10000 = 107;
            case 223 -> var10000 = 191;
            case 224 -> var10000 = 106;
            case 225 -> var10000 = 29;
            case 226 -> var10000 = 95;
            case 227 -> var10000 = 227;
            case 228 -> var10000 = 56;
            case 229 -> var10000 = 44;
            case 230 -> var10000 = 166;
            case 231 -> var10000 = 172;
            case 232 -> var10000 = 32;
            case 233 -> var10000 = 158;
            case 234 -> var10000 = 149;
            case 235 -> var10000 = 183;
            case 236 -> var10000 = 98;
            case 237 -> var10000 = 142;
            case 238 -> var10000 = 180;
            case 239 -> var10000 = 60;
            case 240 -> var10000 = 127;
            case 241 -> var10000 = 87;
            case 242 -> var10000 = 159;
            case 243 -> var10000 = 229;
            case 244 -> var10000 = 88;
            case 245 -> var10000 = 121;
            case 246 -> var10000 = 108;
            case 247 -> var10000 = 254;
            case 248 -> var10000 = 18;
            case 249 -> var10000 = 112;
            case 250 -> var10000 = 145;
            case 251 -> var10000 = 16;
            case 252 -> var10000 = 53;
            case 253 -> var10000 = 156;
            case 254 -> var10000 = 27;
            default -> var10000 = 77;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 22866;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }
}
