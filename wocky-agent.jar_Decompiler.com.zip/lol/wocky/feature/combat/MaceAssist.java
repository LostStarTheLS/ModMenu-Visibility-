package lol.wocky.feature.combat;

import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.KeyProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.render.Hud2D;

public class MaceAssist extends Module {
   private static final String MACE;
   private static final int SHIELD_DOWN_TICKS;
   private static final int LOOKAHEAD;
   private final KeyProperty aimKey = new KeyProperty(a(-6679, 5738), a(31766, 1297114832888837604L));
   private final NumberProperty aimSpeed = new NumberProperty(a(-6674, 365), (double)5.0F, (double)1.0F, (double)20.0F, (double)0.5F);
   private final NumberProperty aimFov = new NumberProperty(a(-6684, 7312), a(16021, 5235085537247819618L), a(4042, 4975830788945921594L), a(5923, 3783573219239714519L), 5);
   private final NumberProperty aimRange = new NumberProperty(a(-6673, 14180), (double)6.0F, (double)3.0F, (double)12.0F, (double)0.5F);
   private final NumberProperty minFall = new NumberProperty(a(-6683, 30246), (double)2.0F, (double)1.5F, (double)20.0F, (double)0.5F);
   private final BooleanProperty perfectTiming = new BooleanProperty(a(-6682, -23337), true);
   private final BooleanProperty stunSlam = new BooleanProperty(a(-6685, 9158), true);
   private final BooleanProperty autoSwitch = new BooleanProperty(a(-6676, -12601), true);
   private final BooleanProperty swapBack = new BooleanProperty(a(-6681, 8761), true);
   private int previousSlot = -1;
   private boolean smashed;
   private Object shieldBroken;
   private long shieldBrokenTick;
   private long lastFrame;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;
   private static final long e;

   public MaceAssist() {
      super(a(-6678, -57), a(-6675, 9427), ModuleCategory.COMBAT);
      Property[] var10001 = new Property[a(28174, 7736080598699354109L)];
      var10001[0] = this.aimKey;
      var10001[1] = this.aimSpeed;
      var10001[2] = this.aimFov;
      var10001[3] = this.aimRange;
      var10001[4] = this.minFall;
      var10001[5] = this.perfectTiming;
      var10001[a(15080, 4715845229382038301L)] = this.stunSlam;
      var10001[a(30912, 7122865375860207933L)] = this.autoSwitch;
      var10001[a(20748, 6573827472161249533L)] = this.swapBack;
      this.addProperties(var10001);
   }

   public void onTick() {
      Object var1 = MinecraftBridge.getPlayer();
      if (MinecraftBridge.getCurrentScreen() == null) {
         if (!MinecraftBridge.isFreeFalling(var1)) {
            this.smashed = false;
            this.restore();
         } else if (!this.smashed && !(MinecraftBridge.getFallDistance(var1) <= this.minFall.doubleValue())) {
            Object var2 = MinecraftBridge.getHitEntity(MinecraftBridge.getCrosshairTarget());
            if (this.isTarget(var2, var1)) {
               if ((Boolean)this.stunSlam.getValue() && this.shieldUp(var2)) {
                  int var4 = MinecraftBridge.findAxeSlot();
                  if (var4 != -1) {
                     this.select(var4);
                     if (MinecraftBridge.attackEntity(var2, true)) {
                        this.shieldBroken = var2;
                        this.shieldBrokenTick = MinecraftBridge.getTickCount();
                     }

                  }
               } else if (!(Boolean)this.perfectTiming.getValue() || this.ticksLeft(var1, var2) <= 0) {
                  if (!MinecraftBridge.isHolding(a(-6680, 30378))) {
                     int var3 = MinecraftBridge.findHotbarSlot(a(-6677, -24665));
                     if (!(Boolean)this.autoSwitch.getValue() || var3 == -1) {
                        return;
                     }

                     this.select(var3);
                  }

                  if (MinecraftBridge.attackEntity(var2, true)) {
                     this.smashed = true;
                     this.restore();
                  }

               }
            }
         }
      }
   }

   private boolean isTarget(Object var1, Object var2) {
      return var1 != null && var1 != var2 && MinecraftBridge.isPlayer(var1) && !MinecraftBridge.isDead(var1) && !MinecraftBridge.isEntityRemoved(var1);
   }

   private boolean shieldUp(Object var1) {
      return var1 == this.shieldBroken && MinecraftBridge.getTickCount() - this.shieldBrokenTick <= e ? false : MinecraftBridge.shieldBlocksUs(var1);
   }

   public boolean isHandlingFall() {
      Object var1 = MinecraftBridge.getPlayer();
      return this.isEnabled() && !this.smashed && MinecraftBridge.isFreeFalling(var1) && MinecraftBridge.getFallDistance(var1) > (double)1.5F && (MinecraftBridge.isHolding(a(-6677, -24665)) || (Boolean)this.autoSwitch.getValue() && MinecraftBridge.findHotbarSlot(a(-6677, -24665)) != -1);
   }

   private int ticksLeft(Object var1, Object var2) {
      double[] var3 = MinecraftBridge.getVelocity(var1);
      double var4 = var3[0];
      double var6 = var3[1];
      double var8 = var3[2];
      double[] var10 = new double[]{MinecraftBridge.getEntityX(var2), MinecraftBridge.getEntityY(var2), MinecraftBridge.getEntityZ(var2)};
      double[] var11 = MinecraftBridge.getLastPos(var2);
      double var12 = var10[0] - var11[0];
      double var14 = var10[1] - var11[1];
      double var16 = var10[2] - var11[2];
      double[] var18 = MinecraftBridge.getBoundingBox(var2);
      if (var18 == null) {
         return 0;
      } else {
         double var19 = MinecraftBridge.getEntityX(var1);
         double var21 = MinecraftBridge.getEyeY(var1);
         double var23 = MinecraftBridge.getEntityZ(var1);
         double var25 = MinecraftBridge.getEntityInteractionRange() - 0.05;
         double var27 = (double)0.0F;
         double var29 = (double)0.0F;
         double var31 = (double)0.0F;

         for(int var33 = 0; var33 < 3; ++var33) {
            int var34 = Math.max(1, (int)Math.ceil(Math.abs(var6) / (double)0.5F));

            for(int var35 = 1; var35 <= var34; ++var35) {
               double var36 = (double)var35 / (double)var34;
               if (!MinecraftBridge.canPlayerMoveBy(var27 + var4 * var36, var29 + var6 * var36, var31 + var8 * var36)) {
                  return var33;
               }
            }

            var27 += var4;
            var29 += var6;
            var31 += var8;
            var6 = (var6 - 0.08) * 0.98;
            var4 *= 0.91;
            var8 *= 0.91;
            int var38 = var33 + 1;
            double var39 = distanceToBox(var19 + var27, var21 + var29, var23 + var31, var18, var12 * (double)var38, var14 * (double)var38, var16 * (double)var38);
            if (var39 > var25) {
               return var33;
            }
         }

         return 3;
      }
   }

   private static double distanceToBox(double var0, double var2, double var4, double[] var6, double var7, double var9, double var11) {
      double var13 = Math.max(var6[0] + var7, Math.min(var0, var6[3] + var7));
      double var15 = Math.max(var6[1] + var9, Math.min(var2, var6[4] + var9));
      double var17 = Math.max(var6[2] + var11, Math.min(var4, var6[5] + var11));
      return Math.sqrt((var0 - var13) * (var0 - var13) + (var2 - var15) * (var2 - var15) + (var4 - var17) * (var4 - var17));
   }

   private void select(int var1) {
      if (this.previousSlot == -1) {
         this.previousSlot = MinecraftBridge.getSelectedSlot();
      }

      MinecraftBridge.setSelectedSlot(var1);
   }

   private void restore() {
      if (this.previousSlot != -1 && (Boolean)this.swapBack.getValue()) {
         MinecraftBridge.setSelectedSlot(this.previousSlot);
      }

      this.previousSlot = -1;
   }

   public void onHudRender(Hud2D var1) {
      long var2 = System.nanoTime();
      float var4 = this.lastFrame == 0L ? 0.0F : Math.min(0.05F, (float)(var2 - this.lastFrame) / 1.0E9F);
      this.lastFrame = var2;
      Object var5 = MinecraftBridge.getPlayer();
      if (!MinecraftBridge.isMouseLocked()) {
         if (!(var4 <= 0.0F) && this.aimKey.isDown() && MinecraftBridge.getCurrentScreen() == null && MinecraftBridge.isFreeFalling(var5)) {
            if (MinecraftBridge.isHolding(a(-6677, -24665)) || (Boolean)this.autoSwitch.getValue() && MinecraftBridge.findHotbarSlot(a(-6677, -24665)) != -1) {
               Object var6 = MinecraftBridge.getHitEntity(MinecraftBridge.getCrosshairTarget());
               if (!this.isTarget(var6, var5)) {
                  double var7 = var1.camX();
                  double var9 = var1.camY();
                  double var11 = var1.camZ();
                  float var13 = MinecraftBridge.getYaw(var5);
                  float var14 = MinecraftBridge.getPitch(var5);
                  float var15 = this.aimFov.floatValue() / 2.0F;
                  double var16 = this.aimRange.doubleValue();
                  float var18 = 0.0F;
                  float var19 = 0.0F;
                  float var20 = Float.MAX_VALUE;

                  for(Object var22 : MinecraftBridge.getPlayers()) {
                     if (this.isTarget(var22, var5)) {
                        double[] var23 = MinecraftBridge.getBoundingBox(var22);
                        double[] var24 = MinecraftBridge.getLerpedPos(var22, var1.tickDelta());
                        if (var23 != null && var24 != null) {
                           double var25 = var24[0] - MinecraftBridge.getEntityX(var22);
                           double var27 = var24[1] - MinecraftBridge.getEntityY(var22);
                           double var29 = var24[2] - MinecraftBridge.getEntityZ(var22);
                           double var31 = clamp(var7, var23[0] + var25 + 0.15, var23[3] + var25 - 0.15);
                           double var33 = clamp(var9, var23[1] + var27 + 0.2, var23[4] + var27 - 0.1);
                           double var35 = clamp(var11, var23[2] + var29 + 0.15, var23[5] + var29 - 0.15);
                           double var37 = var31 - var7;
                           double var39 = var33 - var9;
                           double var41 = var35 - var11;
                           double var43 = Math.sqrt(var37 * var37 + var39 * var39 + var41 * var41);
                           if (!(var43 > var16) && !(var43 < 0.001)) {
                              float var45 = (float)Math.toDegrees(Math.atan2(var41, var37)) - 90.0F;
                              float var46 = (float)(-Math.toDegrees(Math.atan2(var39, Math.sqrt(var37 * var37 + var41 * var41))));
                              float var47 = wrap(var45 - var13);
                              float var48 = var46 - var14;
                              float var49 = (float)Math.sqrt((double)(var47 * var47 + var48 * var48));
                              if (!(var49 > var15) && !(var49 >= var20)) {
                                 var20 = var49;
                                 var18 = var47;
                                 var19 = var48;
                              }
                           }
                        }
                     }
                  }

                  if (var20 != Float.MAX_VALUE) {
                     float var50 = 1.0F - (float)Math.exp(-this.aimSpeed.doubleValue() * (double)var4);
                     MinecraftBridge.turnPlayer(var18 * var50, var19 * var50);
                  }
               }
            }
         }
      }
   }

   private static double clamp(double var0, double var2, double var4) {
      return var2 > var4 ? (var2 + var4) / (double)2.0F : Math.max(var2, Math.min(var4, var0));
   }

   private static float wrap(float var0) {
      var0 %= 360.0F;
      if (var0 >= 180.0F) {
         var0 -= 360.0F;
      }

      if (var0 < -180.0F) {
         var0 += 360.0F;
      }

      return var0;
   }

   public void onDisable() {
      this.restore();
      this.smashed = false;
      this.shieldBroken = null;
      this.lastFrame = 0L;
   }

   static {
      String[] var15 = new String[14];
      int var13 = 0;
      String var12 = "\u0093\u0015`RÓñ÷`Ù\tû:m·s\\ÉäuM|Å±\u0083\"G\u0002ÿ\"(ò\u00057z6GU9Dñ\\ð#tCæî1LúE\u009b\u008d\u0019±\u0087\u009f\u009aës\"ß\u0019\u0099¼£ðË\u0000°.\u009f\u0090\u0016¡\u0019$cÅÆ\u0081Hû@\u0013R\u0006\u000e\u001fû8Û×Î?¨?\u000b\u0010@\t(¶*~aÃ\u001d~\u0004¶ÿcC\n:#ÖØÙ_ÚëÔ[\u0007âëN\u008d\u000f\u000eA\u0004ÖëoÁ\t\u0088ú_\"Ë\u0086ÇÍ?\u000eMV\u0097ñæ\t\u009az\u001c\u0014¤âÄ\u0084\bõ|\"\u007fìT\u0084ß\u0007¤E\u0086X\u001b\u009e@";
      int var14 = "\u0093\u0015`RÓñ÷`Ù\tû:m·s\\ÉäuM|Å±\u0083\"G\u0002ÿ\"(ò\u00057z6GU9Dñ\\ð#tCæî1LúE\u009b\u008d\u0019±\u0087\u009f\u009aës\"ß\u0019\u0099¼£ðË\u0000°.\u009f\u0090\u0016¡\u0019$cÅÆ\u0081Hû@\u0013R\u0006\u000e\u001fû8Û×Î?¨?\u000b\u0010@\t(¶*~aÃ\u001d~\u0004¶ÿcC\n:#ÖØÙ_ÚëÔ[\u0007âëN\u008d\u000f\u000eA\u0004ÖëoÁ\t\u0088ú_\"Ë\u0086ÇÍ?\u000eMV\u0097ñæ\t\u009az\u001c\u0014¤âÄ\u0084\bõ|\"\u007fìT\u0084ß\u0007¤E\u0086X\u001b\u009e@".length();
      char var11 = '\t';
      int var19 = -1;

      label73:
      while(true) {
         ++var19;
         String var10000 = var12.substring(var19, var19 + var11);
         int var10001 = -1;

         while(true) {
            char[] var36;
            label68: {
               char[] var23 = var10000.toCharArray();
               int var10003 = var23.length;
               int var16 = 0;
               var36 = var23;
               int var26 = var10003;
               char[] var47;
               int var10004;
               if (var10003 <= 1) {
                  var47 = var23;
                  var10004 = var16;
               } else {
                  var36 = var23;
                  var26 = var10003;
                  if (var10003 <= var16) {
                     break label68;
                  }

                  var47 = var23;
                  var10004 = var16;
               }

               while(true) {
                  char var10005 = var47[var10004];
                  byte var10006;
                  switch (var16 % 7) {
                     case 0 -> var10006 = 122;
                     case 1 -> var10006 = 7;
                     case 2 -> var10006 = 89;
                     case 3 -> var10006 = 116;
                     case 4 -> var10006 = 102;
                     case 5 -> var10006 = 112;
                     default -> var10006 = 55;
                  }

                  var47[var10004] = (char)(var10005 ^ var10006);
                  ++var16;
                  if (var26 == 0) {
                     var10004 = var26;
                     var47 = var36;
                  } else {
                     if (var26 <= var16) {
                        break;
                     }

                     var47 = var36;
                     var10004 = var16;
                  }
               }
            }

            String var54 = (new String(var36)).intern();
            switch (var10001) {
               case 0:
                  var15[var13++] = var54;
                  if ((var19 += var11) >= var14) {
                     a = var15;
                     b = new String[14];
                     MACE = a(-6686, 16187);
                     long var2 = 6729532206783153439L;
                     long[] var8 = new long[10];
                     int var5 = 0;
                     String var6 = "V8\u0081\u0084\u0010Õ6\u0004ÑñwøÃª\u009b|\u007f\u0005~ \t¬²;Ü1I1¢xê\u001aÔÇ5\u008d\u00ad<]ê¥ù?æ|N\u0083/;a\u0000\"\u0016\u0098bë¬r,\u008e^æó\u0012";
                     int var7 = "V8\u0081\u0084\u0010Õ6\u0004ÑñwøÃª\u009b|\u007f\u0005~ \t¬²;Ü1I1¢xê\u001aÔÇ5\u008d\u00ad<]ê¥ù?æ|N\u0083/;a\u0000\"\u0016\u0098bë¬r,\u008e^æó\u0012".length();
                     int var4 = 0;

                     label44:
                     while(true) {
                        var10001 = var4;
                        var4 += 8;
                        byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
                        long[] var21 = var8;
                        var10001 = var5++;
                        long var41 = ((long)var9[0] & 255L) << 56 | ((long)var9[1] & 255L) << 48 | ((long)var9[2] & 255L) << 40 | ((long)var9[3] & 255L) << 32 | ((long)var9[4] & 255L) << 24 | ((long)var9[5] & 255L) << 16 | ((long)var9[6] & 255L) << 8 | (long)var9[7] & 255L;
                        byte var55 = -1;

                        while(true) {
                           long var58 = var41 ^ var2;
                           switch (var55) {
                              case 0:
                                 var21[var10001] = var58;
                                 if (var4 >= var7) {
                                    c = var8;
                                    d = new Integer[10];
                                    LOOKAHEAD = a(26352, 4816819251008810758L);
                                    SHIELD_DOWN_TICKS = a(8207, 6661872552522770931L);
                                    long var0 = 2381170379605955696L;
                                    var41 = 2381170379605955684L ^ var0;
                                    var10001 = -1;
                                    e = var41;
                                    return;
                                 }
                                 break;
                              default:
                                 var21[var10001] = var58;
                                 if (var4 < var7) {
                                    continue label44;
                                 }

                                 var6 = "dÄo\u0014.Ïô%\b4\u00071i×,ø";
                                 var7 = "dÄo\u0014.Ïô%\b4\u00071i×,ø".length();
                                 var4 = 0;
                           }

                           var10001 = var4;
                           var4 += 8;
                           var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
                           var21 = var8;
                           var10001 = var5++;
                           var41 = ((long)var9[0] & 255L) << 56 | ((long)var9[1] & 255L) << 48 | ((long)var9[2] & 255L) << 40 | ((long)var9[3] & 255L) << 32 | ((long)var9[4] & 255L) << 24 | ((long)var9[5] & 255L) << 16 | ((long)var9[6] & 255L) << 8 | (long)var9[7] & 255L;
                           var55 = 0;
                        }
                     }
                  }

                  var11 = var12.charAt(var19);
                  break;
               default:
                  var15[var13++] = var54;
                  if ((var19 += var11) < var14) {
                     var11 = var12.charAt(var19);
                     continue label73;
                  }

                  var12 = "çX¦\u000bboÿÁ\u0092\u0004Þ«nÉ";
                  var14 = "çX¦\u000bboÿÁ\u0092\u0004Þ«nÉ".length();
                  var11 = '\t';
                  var19 = -1;
            }

            ++var19;
            var10000 = var12.substring(var19, var19 + var11);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ -6673) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 210;
            case 1 -> var10000 = 146;
            case 2 -> var10000 = 161;
            case 3 -> var10000 = 78;
            case 4 -> var10000 = 130;
            case 5 -> var10000 = 153;
            case 6 -> var10000 = 125;
            case 7 -> var10000 = 91;
            case 8 -> var10000 = 38;
            case 9 -> var10000 = 118;
            case 10 -> var10000 = 97;
            case 11 -> var10000 = 50;
            case 12 -> var10000 = 103;
            case 13 -> var10000 = 119;
            case 14 -> var10000 = 171;
            case 15 -> var10000 = 75;
            case 16 -> var10000 = 160;
            case 17 -> var10000 = 218;
            case 18 -> var10000 = 29;
            case 19 -> var10000 = 122;
            case 20 -> var10000 = 178;
            case 21 -> var10000 = 35;
            case 22 -> var10000 = 40;
            case 23 -> var10000 = 13;
            case 24 -> var10000 = 11;
            case 25 -> var10000 = 227;
            case 26 -> var10000 = 219;
            case 27 -> var10000 = 184;
            case 28 -> var10000 = 139;
            case 29 -> var10000 = 134;
            case 30 -> var10000 = 197;
            case 31 -> var10000 = 44;
            case 32 -> var10000 = 177;
            case 33 -> var10000 = 140;
            case 34 -> var10000 = 166;
            case 35 -> var10000 = 51;
            case 36 -> var10000 = 246;
            case 37 -> var10000 = 1;
            case 38 -> var10000 = 25;
            case 39 -> var10000 = 206;
            case 40 -> var10000 = 98;
            case 41 -> var10000 = 24;
            case 42 -> var10000 = 174;
            case 43 -> var10000 = 106;
            case 44 -> var10000 = 203;
            case 45 -> var10000 = 32;
            case 46 -> var10000 = 158;
            case 47 -> var10000 = 226;
            case 48 -> var10000 = 194;
            case 49 -> var10000 = 190;
            case 50 -> var10000 = 17;
            case 51 -> var10000 = 183;
            case 52 -> var10000 = 223;
            case 53 -> var10000 = 216;
            case 54 -> var10000 = 65;
            case 55 -> var10000 = 112;
            case 56 -> var10000 = 111;
            case 57 -> var10000 = 167;
            case 58 -> var10000 = 26;
            case 59 -> var10000 = 15;
            case 60 -> var10000 = 157;
            case 61 -> var10000 = 137;
            case 62 -> var10000 = 60;
            case 63 -> var10000 = 110;
            case 64 -> var10000 = 186;
            case 65 -> var10000 = 54;
            case 66 -> var10000 = 215;
            case 67 -> var10000 = 247;
            case 68 -> var10000 = 120;
            case 69 -> var10000 = 93;
            case 70 -> var10000 = 200;
            case 71 -> var10000 = 192;
            case 72 -> var10000 = 21;
            case 73 -> var10000 = 68;
            case 74 -> var10000 = 108;
            case 75 -> var10000 = 4;
            case 76 -> var10000 = 250;
            case 77 -> var10000 = 191;
            case 78 -> var10000 = 49;
            case 79 -> var10000 = 61;
            case 80 -> var10000 = 58;
            case 81 -> var10000 = 240;
            case 82 -> var10000 = 231;
            case 83 -> var10000 = 208;
            case 84 -> var10000 = 9;
            case 85 -> var10000 = 159;
            case 86 -> var10000 = 212;
            case 87 -> var10000 = 232;
            case 88 -> var10000 = 169;
            case 89 -> var10000 = 249;
            case 90 -> var10000 = 209;
            case 91 -> var10000 = 180;
            case 92 -> var10000 = 18;
            case 93 -> var10000 = 14;
            case 94 -> var10000 = 90;
            case 95 -> var10000 = 143;
            case 96 -> var10000 = 5;
            case 97 -> var10000 = 207;
            case 98 -> var10000 = 77;
            case 99 -> var10000 = 214;
            case 100 -> var10000 = 155;
            case 101 -> var10000 = 63;
            case 102 -> var10000 = 79;
            case 103 -> var10000 = 189;
            case 104 -> var10000 = 84;
            case 105 -> var10000 = 254;
            case 106 -> var10000 = 156;
            case 107 -> var10000 = 81;
            case 108 -> var10000 = 162;
            case 109 -> var10000 = 55;
            case 110 -> var10000 = 42;
            case 111 -> var10000 = 229;
            case 112 -> var10000 = 2;
            case 113 -> var10000 = 147;
            case 114 -> var10000 = 46;
            case 115 -> var10000 = 193;
            case 116 -> var10000 = 235;
            case 117 -> var10000 = 82;
            case 118 -> var10000 = 104;
            case 119 -> var10000 = 64;
            case 120 -> var10000 = 41;
            case 121 -> var10000 = 195;
            case 122 -> var10000 = 12;
            case 123 -> var10000 = 163;
            case 124 -> var10000 = 62;
            case 125 -> var10000 = 239;
            case 126 -> var10000 = 185;
            case 127 -> var10000 = 22;
            case 128 -> var10000 = 187;
            case 129 -> var10000 = 173;
            case 130 -> var10000 = 128;
            case 131 -> var10000 = 224;
            case 132 -> var10000 = 73;
            case 133 -> var10000 = 238;
            case 134 -> var10000 = 228;
            case 135 -> var10000 = 8;
            case 136 -> var10000 = 23;
            case 137 -> var10000 = 176;
            case 138 -> var10000 = 43;
            case 139 -> var10000 = 136;
            case 140 -> var10000 = 96;
            case 141 -> var10000 = 201;
            case 142 -> var10000 = 225;
            case 143 -> var10000 = 100;
            case 144 -> var10000 = 71;
            case 145 -> var10000 = 237;
            case 146 -> var10000 = 109;
            case 147 -> var10000 = 105;
            case 148 -> var10000 = 85;
            case 149 -> var10000 = 28;
            case 150 -> var10000 = 116;
            case 151 -> var10000 = 101;
            case 152 -> var10000 = 145;
            case 153 -> var10000 = 222;
            case 154 -> var10000 = 150;
            case 155 -> var10000 = 87;
            case 156 -> var10000 = 72;
            case 157 -> var10000 = 248;
            case 158 -> var10000 = 69;
            case 159 -> var10000 = 211;
            case 160 -> var10000 = 236;
            case 161 -> var10000 = 34;
            case 162 -> var10000 = 124;
            case 163 -> var10000 = 33;
            case 164 -> var10000 = 114;
            case 165 -> var10000 = 234;
            case 166 -> var10000 = 59;
            case 167 -> var10000 = 144;
            case 168 -> var10000 = 170;
            case 169 -> var10000 = 132;
            case 170 -> var10000 = 204;
            case 171 -> var10000 = 47;
            case 172 -> var10000 = 233;
            case 173 -> var10000 = 242;
            case 174 -> var10000 = 89;
            case 175 -> var10000 = 10;
            case 176 -> var10000 = 251;
            case 177 -> var10000 = 154;
            case 178 -> var10000 = 213;
            case 179 -> var10000 = 243;
            case 180 -> var10000 = 3;
            case 181 -> var10000 = 255;
            case 182 -> var10000 = 36;
            case 183 -> var10000 = 217;
            case 184 -> var10000 = 117;
            case 185 -> var10000 = 202;
            case 186 -> var10000 = 16;
            case 187 -> var10000 = 0;
            case 188 -> var10000 = 164;
            case 189 -> var10000 = 141;
            case 190 -> var10000 = 138;
            case 191 -> var10000 = 135;
            case 192 -> var10000 = 168;
            case 193 -> var10000 = 149;
            case 194 -> var10000 = 196;
            case 195 -> var10000 = 129;
            case 196 -> var10000 = 99;
            case 197 -> var10000 = 20;
            case 198 -> var10000 = 182;
            case 199 -> var10000 = 94;
            case 200 -> var10000 = 148;
            case 201 -> var10000 = 39;
            case 202 -> var10000 = 27;
            case 203 -> var10000 = 76;
            case 204 -> var10000 = 6;
            case 205 -> var10000 = 56;
            case 206 -> var10000 = 142;
            case 207 -> var10000 = 151;
            case 208 -> var10000 = 179;
            case 209 -> var10000 = 165;
            case 210 -> var10000 = 57;
            case 211 -> var10000 = 252;
            case 212 -> var10000 = 30;
            case 213 -> var10000 = 133;
            case 214 -> var10000 = 88;
            case 215 -> var10000 = 102;
            case 216 -> var10000 = 48;
            case 217 -> var10000 = 131;
            case 218 -> var10000 = 74;
            case 219 -> var10000 = 53;
            case 220 -> var10000 = 181;
            case 221 -> var10000 = 175;
            case 222 -> var10000 = 241;
            case 223 -> var10000 = 221;
            case 224 -> var10000 = 52;
            case 225 -> var10000 = 230;
            case 226 -> var10000 = 80;
            case 227 -> var10000 = 199;
            case 228 -> var10000 = 86;
            case 229 -> var10000 = 123;
            case 230 -> var10000 = 115;
            case 231 -> var10000 = 70;
            case 232 -> var10000 = 198;
            case 233 -> var10000 = 188;
            case 234 -> var10000 = 95;
            case 235 -> var10000 = 45;
            case 236 -> var10000 = 19;
            case 237 -> var10000 = 67;
            case 238 -> var10000 = 205;
            case 239 -> var10000 = 121;
            case 240 -> var10000 = 92;
            case 241 -> var10000 = 127;
            case 242 -> var10000 = 152;
            case 243 -> var10000 = 172;
            case 244 -> var10000 = 220;
            case 245 -> var10000 = 244;
            case 246 -> var10000 = 83;
            case 247 -> var10000 = 7;
            case 248 -> var10000 = 66;
            case 249 -> var10000 = 107;
            case 250 -> var10000 = 253;
            case 251 -> var10000 = 245;
            case 252 -> var10000 = 31;
            case 253 -> var10000 = 113;
            case 254 -> var10000 = 37;
            default -> var10000 = 126;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 18933;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }
}
