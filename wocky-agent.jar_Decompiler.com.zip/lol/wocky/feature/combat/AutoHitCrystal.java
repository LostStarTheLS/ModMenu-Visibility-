package lol.wocky.feature.combat;

import java.util.concurrent.ThreadLocalRandom;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.ModuleManager;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.KeyProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.util.BlockUtils;

public class AutoHitCrystal extends Module {
   private final KeyProperty activateKey = new KeyProperty(a(11253, -24817), a(19160, 5670800991491028484L));
   private final BooleanProperty checkPlace = new BooleanProperty(a(11249, -27732), false);
   private final NumberProperty switchDelay = new NumberProperty(a(11259, 6588), 0, 0, a(18002, 4808235763828718213L), 1);
   private final NumberProperty switchChance = new NumberProperty(a(11260, -15067), a(25202, 3748096400704560807L), 0, a(12736, 8943858256419130653L), 1);
   private final NumberProperty placeDelay = new NumberProperty(a(11257, -19403), 0, 0, a(13583, 7962738060385454544L), 1);
   private final NumberProperty placeChance = new NumberProperty(a(11234, 31148), a(12736, 8943858256419130653L), 0, a(12736, 8943858256419130653L), 1);
   private final BooleanProperty workWithTotem = new BooleanProperty(a(11252, 295), false);
   private final BooleanProperty workWithCrystal = new BooleanProperty(a(11248, 17786), true);
   private final BooleanProperty swordOnObsidian = new BooleanProperty(a(11254, 981), true);
   private final BooleanProperty autoSwapBack = new BooleanProperty(a(11262, -4521), true);
   private final NumberProperty crystalDelay = new NumberProperty(a(11261, -19602), 2, 0, a(17137, 148438440979791407L), 1);
   private final NumberProperty breakDelay = new NumberProperty(a(11250, 3366), 0, 0, a(17849, 5866804936009906530L), 1);
   private boolean active;
   private int placeClock;
   private int switchClock;
   private int previousSlot = -1;
   private int crystalClock;
   private int crystalTicks;
   private Object seenCrystal;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;

   public AutoHitCrystal() {
      super(a(11232, -23843), a(11258, -24764), ModuleCategory.CPVP);
      Property[] var10001 = new Property[a(4968, 5408222320388288432L)];
      var10001[0] = this.activateKey;
      var10001[1] = this.checkPlace;
      var10001[2] = this.switchDelay;
      var10001[3] = this.switchChance;
      var10001[4] = this.placeDelay;
      var10001[5] = this.placeChance;
      var10001[a(26111, 5944599113330972965L)] = this.workWithTotem;
      var10001[a(1865, 1288341180925262749L)] = this.workWithCrystal;
      var10001[a(29902, 8553900868034938908L)] = this.swordOnObsidian;
      var10001[a(14882, 6731559791128446708L)] = this.autoSwapBack;
      var10001[a(17849, 5866804936009906530L)] = this.crystalDelay;
      var10001[a(17260, 3909821218989473725L)] = this.breakDelay;
      this.addProperties(var10001);
   }

   public boolean isActivated() {
      int var1 = this.activateKey.getKey();
      return var1 == 0 ? MinecraftBridge.isKeyDown(a(10888, 1962702391140324955L)) : this.activateKey.isDown();
   }

   public boolean cancelsItemUse() {
      if (!this.isActivated()) {
         return false;
      } else if (this.isSwordOnObsidian()) {
         return true;
      } else {
         return this.active && (MinecraftBridge.isHolding(a(11255, -20152)) || MinecraftBridge.isHolding(a(11263, 22346)));
      }
   }

   public boolean cancelsAttack() {
      return this.isActivated() && MinecraftBridge.isHolding(a(11251, 438));
   }

   private boolean isSwordOnObsidian() {
      if ((Boolean)this.swordOnObsidian.getValue() && MinecraftBridge.isHoldingSword()) {
         Object var1 = MinecraftBridge.getCrosshairTarget();
         return MinecraftBridge.isBlockHit(var1) && BlockUtils.isCrystalBase(MinecraftBridge.getHitBlockPos(var1));
      } else {
         return false;
      }
   }

   public void onTick() {
      if (MinecraftBridge.getCurrentScreen() == null) {
         if (!this.isActivated()) {
            if (this.active && (Boolean)this.autoSwapBack.getValue() && this.previousSlot != -1) {
               MinecraftBridge.setSelectedSlot(this.previousSlot);
            }

            this.reset();
         } else {
            Object var1 = MinecraftBridge.getCrosshairTarget();
            Object var2 = MinecraftBridge.isBlockHit(var1) ? MinecraftBridge.getHitBlockPos(var1) : null;
            if (this.active || this.start(var2)) {
               if (this.crystalClock > 0) {
                  --this.crystalClock;
               }

               if (var2 != null && !isObsidian(var2)) {
                  this.placeObsidian(var1, var2);
               } else if (var2 != null || MinecraftBridge.isEndCrystal(MinecraftBridge.getHitEntity(var1))) {
                  this.crystals();
               }
            }
         }
      }
   }

   private static boolean isObsidian(Object var0) {
      return var0 != null && BlockUtils.isBlock(var0, a(11235, 5974));
   }

   private boolean start(Object var1) {
      boolean var2 = MinecraftBridge.isHolding(a(11255, -20152));
      boolean var3 = MinecraftBridge.isHoldingSword() || (Boolean)this.workWithTotem.getValue() && MinecraftBridge.isHolding(a(11256, 19570)) || (Boolean)this.workWithCrystal.getValue() && var2;
      if (!var3) {
         return false;
      } else {
         if ((Boolean)this.checkPlace.getValue() && var1 != null && !isObsidian(var1)) {
            Object var4 = MinecraftBridge.up(var1);
            if (!MinecraftBridge.isAir(var4) || !MinecraftBridge.isFreeForBlock(var4)) {
               return false;
            }
         }

         this.previousSlot = MinecraftBridge.getSelectedSlot();
         this.active = true;
         return true;
      }
   }

   private void placeObsidian(Object var1, Object var2) {
      if (!BlockUtils.isChargedAnchor(var2) && !AnchorMacro.isHandling(var2) && !DoubleAnchor.isRunning() && MinecraftBridge.canPlaceBlockAt(var1)) {
         MinecraftBridge.setUseKeyPressed(false);
         if (!MinecraftBridge.isHolding(a(11263, 22346))) {
            if (this.switchClock > 0) {
               --this.switchClock;
               return;
            }

            if (!roll(this.switchChance) || !MinecraftBridge.selectHotbarItem(a(11263, 22346))) {
               return;
            }

            this.placeClock = Math.max(this.placeClock, this.switchDelay.intValue());
         }

         if (this.placeClock > 0) {
            --this.placeClock;
         } else if (roll(this.placeChance)) {
            MinecraftBridge.interactBlock(var1, true);
            this.placeClock = this.placeDelay.intValue();
         }
      }
   }

   private void crystals() {
      if (!MinecraftBridge.isHolding(a(11255, -20152))) {
         if (this.switchClock > 0) {
            --this.switchClock;
            return;
         }

         if (!roll(this.switchChance) || !MinecraftBridge.selectHotbarItem(a(11255, -20152))) {
            return;
         }

         this.switchClock = this.switchDelay.intValue();
         if (this.switchClock > 0) {
            return;
         }
      } else if (this.switchClock > 0) {
         --this.switchClock;
         return;
      }

      AutoCrystal var1 = (AutoCrystal)ModuleManager.getByClass(AutoCrystal.class);
      if (var1 != null) {
         MinecraftBridge.refreshCrosshair();
         Object var2 = MinecraftBridge.getHitEntity(MinecraftBridge.getCrosshairTarget());
         if (MinecraftBridge.isEndCrystal(var2)) {
            if (var2 != this.seenCrystal) {
               this.seenCrystal = var2;
               this.crystalTicks = 0;
            }

            if (this.crystalTicks++ < this.breakDelay.intValue()) {
               return;
            }
         } else if (this.crystalClock > 0) {
            return;
         }

         if (var1.doCrystalLogic() == 2) {
            this.crystalClock = this.crystalDelay.intValue();
         }

      }
   }

   private static boolean roll(NumberProperty var0) {
      int var1 = var0.intValue();
      return var1 >= a(12736, 8943858256419130653L) || var1 > 0 && ThreadLocalRandom.current().nextInt(1, a(12087, 2997703302650631150L)) <= var1;
   }

   private void reset() {
      this.placeClock = 0;
      this.switchClock = 0;
      this.crystalClock = 0;
      this.crystalTicks = 0;
      this.seenCrystal = null;
      this.active = false;
      this.previousSlot = -1;
   }

   public void onDisable() {
      this.reset();
   }

   static {
      String[] var13 = new String[19];
      int var11 = 0;
      String var10 = "O\fÊ°Q Öe×H\u000e\u000bî6<V¦×\u001c\u0085\f\u0080{\u0011Ì§\u001aqõ¤Mm(;O\u009b`\u0082\u001e\u0081\u0019\u000b\u0004(\u0082oX\u0019ã[ê¥\u0019\u0011\u00adç¯{¹¨.oîM÷Öb\u001dQ\u0087L\u000bÕy[¿Jê\u0081\"¿t\r\u000f\u000fñb»úý¬F\u0014^ß*\u008a\u001cö\f\u0094>ÃÍ^G¹ð@Ð%ë6¼=àI\u009e\u008e\u0084\u0093{ÏD*~rÕ\u0082uáHx¼ÖúÀEýQ}\u008c<\u0010ÖvM\u0080\u0090\u009c\u009fO\u0012\u0011^¡-q/E¢Zû£\u0091Yç\f\u008fÐí\u009b0:\u0097V\u001e&\u0007ö\u0010 ÅÆ3å+\u00ad\u0087Åc\u000eyÀ\u0010\u0010\u008c\u000b·\u0014\u0081l²ye^¡/À\u000eÓV+\u0012\u0015HOa\u00ad\råN\u000eQ\bcEÑ\u0083é\u0086\nÊ\r |\b\u000e\u008c\u0088\u0000\u0007áæ[Xv\rcñr\u001dÆ\u0004ðÝ\u0016¶\u000eÔ\u0082\fZ1<È\u0005í\u0094Áu\u007fì\u0083";
      int var12 = "O\fÊ°Q Öe×H\u000e\u000bî6<V¦×\u001c\u0085\f\u0080{\u0011Ì§\u001aqõ¤Mm(;O\u009b`\u0082\u001e\u0081\u0019\u000b\u0004(\u0082oX\u0019ã[ê¥\u0019\u0011\u00adç¯{¹¨.oîM÷Öb\u001dQ\u0087L\u000bÕy[¿Jê\u0081\"¿t\r\u000f\u000fñb»úý¬F\u0014^ß*\u008a\u001cö\f\u0094>ÃÍ^G¹ð@Ð%ë6¼=àI\u009e\u008e\u0084\u0093{ÏD*~rÕ\u0082uáHx¼ÖúÀEýQ}\u008c<\u0010ÖvM\u0080\u0090\u009c\u009fO\u0012\u0011^¡-q/E¢Zû£\u0091Yç\f\u008fÐí\u009b0:\u0097V\u001e&\u0007ö\u0010 ÅÆ3å+\u00ad\u0087Åc\u000eyÀ\u0010\u0010\u008c\u000b·\u0014\u0081l²ye^¡/À\u000eÓV+\u0012\u0015HOa\u00ad\råN\u000eQ\bcEÑ\u0083é\u0086\nÊ\r |\b\u000e\u008c\u0088\u0000\u0007áæ[Xv\rcñr\u001dÆ\u0004ðÝ\u0016¶\u000eÔ\u0082\fZ1<È\u0005í\u0094Áu\u007fì\u0083".length();
      char var9 = 11;
      int var17 = -1;

      label73:
      while(true) {
         ++var17;
         String var10000 = var10.substring(var17, var17 + var9);
         int var10001 = -1;

         while(true) {
            char[] var33;
            label68: {
               char[] var21 = var10000.toCharArray();
               int var10003 = var21.length;
               int var14 = 0;
               var33 = var21;
               int var24 = var10003;
               char[] var43;
               int var10004;
               if (var10003 <= 1) {
                  var43 = var21;
                  var10004 = var14;
               } else {
                  var33 = var21;
                  var24 = var10003;
                  if (var10003 <= var14) {
                     break label68;
                  }

                  var43 = var21;
                  var10004 = var14;
               }

               while(true) {
                  char var10005 = var43[var10004];
                  byte var10006;
                  switch (var14 % 7) {
                     case 0 -> var10006 = 91;
                     case 1 -> var10006 = 67;
                     case 2 -> var10006 = 39;
                     case 3 -> var10006 = 4;
                     case 4 -> var10006 = 78;
                     case 5 -> var10006 = 91;
                     default -> var10006 = 119;
                  }

                  var43[var10004] = (char)(var10005 ^ var10006);
                  ++var14;
                  if (var24 == 0) {
                     var10004 = var24;
                     var43 = var33;
                  } else {
                     if (var24 <= var14) {
                        break;
                     }

                     var43 = var33;
                     var10004 = var14;
                  }
               }
            }

            String var50 = (new String(var33)).intern();
            switch (var10001) {
               case 0:
                  var13[var11++] = var50;
                  if ((var17 += var9) >= var12) {
                     a = var13;
                     b = new String[19];
                     long var0 = 7897985232988116887L;
                     long[] var6 = new long[15];
                     int var3 = 0;
                     String var4 = "\u0096_I\u009a\u0085K\u009eSæ·f\u0001\u009c\u0015i²\u00adyjPÊÇ\u001aî\u0014hóy¼HâyB)\u0084\u0083,énÿäkú¾\u008f¸N´öf\u001a\u001a-\b\u0004\u001c\u000bAô\u001b¼\u009c¸+\\\u001d4\u008bæßm\u0006+]\u0082Ä«\n\u0011jç\u0010]9.cÉTOc\u008c3;\u0007,\r ]·IZ3\u0002&";
                     int var5 = "\u0096_I\u009a\u0085K\u009eSæ·f\u0001\u009c\u0015i²\u00adyjPÊÇ\u001aî\u0014hóy¼HâyB)\u0084\u0083,énÿäkú¾\u008f¸N´öf\u001a\u001a-\b\u0004\u001c\u000bAô\u001b¼\u009c¸+\\\u001d4\u008bæßm\u0006+]\u0082Ä«\n\u0011jç\u0010]9.cÉTOc\u008c3;\u0007,\r ]·IZ3\u0002&".length();
                     int var2 = 0;

                     label44:
                     while(true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var19 = var6;
                        var10001 = var3++;
                        long var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                        byte var51 = -1;

                        while(true) {
                           long var54 = var38 ^ var0;
                           switch (var51) {
                              case 0:
                                 var19[var10001] = var54;
                                 if (var2 >= var5) {
                                    c = var6;
                                    d = new Integer[15];
                                    return;
                                 }
                                 break;
                              default:
                                 var19[var10001] = var54;
                                 if (var2 < var5) {
                                    continue label44;
                                 }

                                 var4 = "_ã\u009f\u0016\u0086©_\u0083j\u008a@Ý ¯h!";
                                 var5 = "_ã\u009f\u0016\u0086©_\u0083j\u008a@Ý ¯h!".length();
                                 var2 = 0;
                           }

                           var10001 = var2;
                           var2 += 8;
                           var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                           var19 = var6;
                           var10001 = var3++;
                           var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                           var51 = 0;
                        }
                     }
                  }

                  var9 = var10.charAt(var17);
                  break;
               default:
                  var13[var11++] = var50;
                  if ((var17 += var9) < var12) {
                     var9 = var10.charAt(var17);
                     continue label73;
                  }

                  var10 = "à´¡½çAË2\u000eÊ£\b¬\u0019¥¨\u00830n%E\u0003\u0080";
                  var12 = "à´¡½çAË2\u000eÊ£\b¬\u0019¥¨\u00830n%E\u0003\u0080".length();
                  var9 = '\b';
                  var17 = -1;
            }

            ++var17;
            var10000 = var10.substring(var17, var17 + var9);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 11250) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 78;
            case 1 -> var10000 = 91;
            case 2 -> var10000 = 17;
            case 3 -> var10000 = 167;
            case 4 -> var10000 = 249;
            case 5 -> var10000 = 65;
            case 6 -> var10000 = 194;
            case 7 -> var10000 = 45;
            case 8 -> var10000 = 236;
            case 9 -> var10000 = 75;
            case 10 -> var10000 = 70;
            case 11 -> var10000 = 108;
            case 12 -> var10000 = 203;
            case 13 -> var10000 = 136;
            case 14 -> var10000 = 25;
            case 15 -> var10000 = 135;
            case 16 -> var10000 = 147;
            case 17 -> var10000 = 188;
            case 18 -> var10000 = 148;
            case 19 -> var10000 = 205;
            case 20 -> var10000 = 208;
            case 21 -> var10000 = 90;
            case 22 -> var10000 = 26;
            case 23 -> var10000 = 166;
            case 24 -> var10000 = 115;
            case 25 -> var10000 = 178;
            case 26 -> var10000 = 42;
            case 27 -> var10000 = 164;
            case 28 -> var10000 = 229;
            case 29 -> var10000 = 184;
            case 30 -> var10000 = 100;
            case 31 -> var10000 = 163;
            case 32 -> var10000 = 98;
            case 33 -> var10000 = 12;
            case 34 -> var10000 = 127;
            case 35 -> var10000 = 223;
            case 36 -> var10000 = 18;
            case 37 -> var10000 = 228;
            case 38 -> var10000 = 213;
            case 39 -> var10000 = 5;
            case 40 -> var10000 = 209;
            case 41 -> var10000 = 109;
            case 42 -> var10000 = 159;
            case 43 -> var10000 = 81;
            case 44 -> var10000 = 119;
            case 45 -> var10000 = 196;
            case 46 -> var10000 = 198;
            case 47 -> var10000 = 211;
            case 48 -> var10000 = 168;
            case 49 -> var10000 = 197;
            case 50 -> var10000 = 254;
            case 51 -> var10000 = 122;
            case 52 -> var10000 = 193;
            case 53 -> var10000 = 82;
            case 54 -> var10000 = 19;
            case 55 -> var10000 = 158;
            case 56 -> var10000 = 243;
            case 57 -> var10000 = 217;
            case 58 -> var10000 = 113;
            case 59 -> var10000 = 56;
            case 60 -> var10000 = 172;
            case 61 -> var10000 = 79;
            case 62 -> var10000 = 224;
            case 63 -> var10000 = 152;
            case 64 -> var10000 = 106;
            case 65 -> var10000 = 92;
            case 66 -> var10000 = 137;
            case 67 -> var10000 = 33;
            case 68 -> var10000 = 182;
            case 69 -> var10000 = 118;
            case 70 -> var10000 = 221;
            case 71 -> var10000 = 162;
            case 72 -> var10000 = 71;
            case 73 -> var10000 = 49;
            case 74 -> var10000 = 103;
            case 75 -> var10000 = 133;
            case 76 -> var10000 = 60;
            case 77 -> var10000 = 237;
            case 78 -> var10000 = 7;
            case 79 -> var10000 = 246;
            case 80 -> var10000 = 170;
            case 81 -> var10000 = 29;
            case 82 -> var10000 = 202;
            case 83 -> var10000 = 58;
            case 84 -> var10000 = 36;
            case 85 -> var10000 = 2;
            case 86 -> var10000 = 116;
            case 87 -> var10000 = 89;
            case 88 -> var10000 = 107;
            case 89 -> var10000 = 238;
            case 90 -> var10000 = 105;
            case 91 -> var10000 = 242;
            case 92 -> var10000 = 200;
            case 93 -> var10000 = 232;
            case 94 -> var10000 = 3;
            case 95 -> var10000 = 144;
            case 96 -> var10000 = 190;
            case 97 -> var10000 = 191;
            case 98 -> var10000 = 9;
            case 99 -> var10000 = 235;
            case 100 -> var10000 = 173;
            case 101 -> var10000 = 101;
            case 102 -> var10000 = 20;
            case 103 -> var10000 = 154;
            case 104 -> var10000 = 67;
            case 105 -> var10000 = 138;
            case 106 -> var10000 = 16;
            case 107 -> var10000 = 183;
            case 108 -> var10000 = 112;
            case 109 -> var10000 = 134;
            case 110 -> var10000 = 87;
            case 111 -> var10000 = 117;
            case 112 -> var10000 = 27;
            case 113 -> var10000 = 192;
            case 114 -> var10000 = 24;
            case 115 -> var10000 = 185;
            case 116 -> var10000 = 61;
            case 117 -> var10000 = 57;
            case 118 -> var10000 = 68;
            case 119 -> var10000 = 59;
            case 120 -> var10000 = 38;
            case 121 -> var10000 = 195;
            case 122 -> var10000 = 244;
            case 123 -> var10000 = 99;
            case 124 -> var10000 = 40;
            case 125 -> var10000 = 157;
            case 126 -> var10000 = 250;
            case 127 -> var10000 = 43;
            case 128 -> var10000 = 69;
            case 129 -> var10000 = 171;
            case 130 -> var10000 = 6;
            case 131 -> var10000 = 139;
            case 132 -> var10000 = 255;
            case 133 -> var10000 = 251;
            case 134 -> var10000 = 174;
            case 135 -> var10000 = 219;
            case 136 -> var10000 = 142;
            case 137 -> var10000 = 239;
            case 138 -> var10000 = 210;
            case 139 -> var10000 = 176;
            case 140 -> var10000 = 22;
            case 141 -> var10000 = 201;
            case 142 -> var10000 = 93;
            case 143 -> var10000 = 74;
            case 144 -> var10000 = 124;
            case 145 -> var10000 = 13;
            case 146 -> var10000 = 189;
            case 147 -> var10000 = 140;
            case 148 -> var10000 = 218;
            case 149 -> var10000 = 231;
            case 150 -> var10000 = 216;
            case 151 -> var10000 = 186;
            case 152 -> var10000 = 52;
            case 153 -> var10000 = 35;
            case 154 -> var10000 = 4;
            case 155 -> var10000 = 126;
            case 156 -> var10000 = 104;
            case 157 -> var10000 = 241;
            case 158 -> var10000 = 180;
            case 159 -> var10000 = 28;
            case 160 -> var10000 = 233;
            case 161 -> var10000 = 62;
            case 162 -> var10000 = 131;
            case 163 -> var10000 = 240;
            case 164 -> var10000 = 66;
            case 165 -> var10000 = 155;
            case 166 -> var10000 = 50;
            case 167 -> var10000 = 96;
            case 168 -> var10000 = 8;
            case 169 -> var10000 = 32;
            case 170 -> var10000 = 30;
            case 171 -> var10000 = 54;
            case 172 -> var10000 = 248;
            case 173 -> var10000 = 47;
            case 174 -> var10000 = 177;
            case 175 -> var10000 = 120;
            case 176 -> var10000 = 181;
            case 177 -> var10000 = 114;
            case 178 -> var10000 = 199;
            case 179 -> var10000 = 37;
            case 180 -> var10000 = 46;
            case 181 -> var10000 = 230;
            case 182 -> var10000 = 111;
            case 183 -> var10000 = 11;
            case 184 -> var10000 = 222;
            case 185 -> var10000 = 88;
            case 186 -> var10000 = 215;
            case 187 -> var10000 = 130;
            case 188 -> var10000 = 0;
            case 189 -> var10000 = 161;
            case 190 -> var10000 = 102;
            case 191 -> var10000 = 41;
            case 192 -> var10000 = 225;
            case 193 -> var10000 = 80;
            case 194 -> var10000 = 187;
            case 195 -> var10000 = 212;
            case 196 -> var10000 = 207;
            case 197 -> var10000 = 97;
            case 198 -> var10000 = 83;
            case 199 -> var10000 = 160;
            case 200 -> var10000 = 51;
            case 201 -> var10000 = 110;
            case 202 -> var10000 = 34;
            case 203 -> var10000 = 55;
            case 204 -> var10000 = 214;
            case 205 -> var10000 = 95;
            case 206 -> var10000 = 10;
            case 207 -> var10000 = 129;
            case 208 -> var10000 = 156;
            case 209 -> var10000 = 14;
            case 210 -> var10000 = 64;
            case 211 -> var10000 = 15;
            case 212 -> var10000 = 53;
            case 213 -> var10000 = 63;
            case 214 -> var10000 = 175;
            case 215 -> var10000 = 220;
            case 216 -> var10000 = 169;
            case 217 -> var10000 = 146;
            case 218 -> var10000 = 252;
            case 219 -> var10000 = 39;
            case 220 -> var10000 = 143;
            case 221 -> var10000 = 77;
            case 222 -> var10000 = 72;
            case 223 -> var10000 = 245;
            case 224 -> var10000 = 128;
            case 225 -> var10000 = 247;
            case 226 -> var10000 = 227;
            case 227 -> var10000 = 153;
            case 228 -> var10000 = 150;
            case 229 -> var10000 = 253;
            case 230 -> var10000 = 145;
            case 231 -> var10000 = 141;
            case 232 -> var10000 = 44;
            case 233 -> var10000 = 179;
            case 234 -> var10000 = 123;
            case 235 -> var10000 = 94;
            case 236 -> var10000 = 121;
            case 237 -> var10000 = 76;
            case 238 -> var10000 = 151;
            case 239 -> var10000 = 165;
            case 240 -> var10000 = 206;
            case 241 -> var10000 = 31;
            case 242 -> var10000 = 21;
            case 243 -> var10000 = 1;
            case 244 -> var10000 = 149;
            case 245 -> var10000 = 132;
            case 246 -> var10000 = 48;
            case 247 -> var10000 = 84;
            case 248 -> var10000 = 85;
            case 249 -> var10000 = 23;
            case 250 -> var10000 = 234;
            case 251 -> var10000 = 125;
            case 252 -> var10000 = 204;
            case 253 -> var10000 = 86;
            case 254 -> var10000 = 73;
            default -> var10000 = 226;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15583;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }
}
