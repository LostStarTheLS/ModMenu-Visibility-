package lol.wocky.feature.combat;

import java.util.concurrent.ThreadLocalRandom;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.render.Hud2D;
import lol.wocky.core.util.EncryptedString;

public class HoverTotem extends Module {
   private static final String TOTEM;
   private static final int OFFHAND_BUTTON;
   private final NumberProperty delay = new NumberProperty(EncryptedString.of(a(3881, -15580)), 1, 0, a(14100, 3410828369083764996L), 1);
   private final BooleanProperty hotbar = new BooleanProperty(EncryptedString.of(a(3879, 26797)), true);
   private final NumberProperty totemSlot = new NumberProperty(EncryptedString.of(a(3885, -28815)), a(31446, 944824216240282817L), 1, a(32412, 9004650042683709578L), 1);
   private final BooleanProperty autoSwitch = new BooleanProperty(EncryptedString.of(a(3884, 8943)), false);
   private final BooleanProperty legit = new BooleanProperty(a(3886, -22316), false);
   private int clock = 0;
   private long nextAt;
   private Object lastHovered;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;
   private static final long[] e;
   private static final Long[] f;

   public HoverTotem() {
      super(EncryptedString.of(a(3882, -23392)), EncryptedString.of(a(3883, 18114)), ModuleCategory.CPVP);
      this.addProperties(new Property[]{this.delay, this.hotbar, this.totemSlot, this.autoSwitch, this.legit});
   }

   public void onTick() {
      if ((Boolean)this.legit.getValue()) {
         this.legitStep();
      } else if (!MinecraftBridge.isInventoryScreenOpen()) {
         this.clock = 0;
      } else if (this.clock > 0) {
         --this.clock;
      } else {
         if (this.act(MinecraftBridge.getFocusedSlot())) {
            this.clock = this.delay.intValue();
         }

      }
   }

   public void onHudRender(Hud2D var1) {
      if ((Boolean)this.legit.getValue()) {
         this.legitStep();
      }

   }

   private void legitStep() {
      if (!MinecraftBridge.isInventoryScreenOpen()) {
         this.lastHovered = null;
         this.nextAt = 0L;
      } else {
         long var1 = System.currentTimeMillis();
         Object var3 = MinecraftBridge.getFocusedSlot();
         if (var3 != this.lastHovered) {
            this.lastHovered = var3;
            this.nextAt = Math.max(this.nextAt, var1 + jitterMs());
         }

         if (var1 >= this.nextAt) {
            if (this.act(var3)) {
               this.nextAt = var1 + (long)this.delay.intValue() * b(27180, 4959659929182735348L) + jitterMs();
            }

         }
      }
   }

   private static long jitterMs() {
      ThreadLocalRandom var0 = ThreadLocalRandom.current();
      return b(28828, 1492423600093073733L) + Math.round((var0.nextDouble() + var0.nextDouble()) / (double)2.0F * (double)40.0F);
   }

   private boolean act(Object var1) {
      Object var2 = MinecraftBridge.getSlotStack(var1);
      if (!MinecraftBridge.isItem(var2, a(3880, -24108))) {
         return false;
      } else {
         Object var3 = MinecraftBridge.getOffHandStack();
         if (var2 == var3) {
            return false;
         } else {
            int var4 = MinecraftBridge.getScreenSyncId();
            int var5 = MinecraftBridge.getSlotId(var1);
            if (var4 >= 0 && var5 >= 0) {
               if (!MinecraftBridge.isItem(var3, a(3887, -31431))) {
                  return MinecraftBridge.clickSlot(var4, var5, a(19146, 4584721467236314335L), true);
               } else {
                  int var6 = this.totemSlot.intValue() - 1;
                  if ((Boolean)this.hotbar.getValue()) {
                     Object var7 = MinecraftBridge.getStackInSlot(var6);
                     if (!MinecraftBridge.isItem(var7, a(3887, -31431))) {
                        return MinecraftBridge.clickSlot(var4, var5, var6, true);
                     }
                  }

                  if ((Boolean)this.autoSwitch.getValue()) {
                     MinecraftBridge.setSelectedSlot(var6);
                  }

                  return false;
               }
            } else {
               return false;
            }
         }
      }
   }

   public void onDisable() {
      this.clock = 0;
      this.nextAt = 0L;
      this.lastHovered = null;
   }

   static {
      String[] var21 = new String[10];
      int var19 = 0;
      String var18 = "ajbÅ+\b\u0093®\u0094Ê'\u0016\u0018\u001aF[\u0005Å\u009cÚ\\T\nÈ¡s¼\tXë>\u0010\u0092\u000b²\u0007\u008b;[\u0090a?ú\u0000¢6\u008cxÉVbÛKs\u0019½«\u008dÿ°k¬çÈÊé½\u008c\u0004ªó\u0087\u0013'øHe\u0086(¼l&lé )ð·häNto\nàw6Î2u\nð\u0097éz\u0007ôêI\u0081~\u0005\u009f\u0093\u0093µ\u001a\u0010ú`\u0011\u0084E ^«-j\u0010\u0002þ\u0098\u009a\u000b";
      int var20 = "ajbÅ+\b\u0093®\u0094Ê'\u0016\u0018\u001aF[\u0005Å\u009cÚ\\T\nÈ¡s¼\tXë>\u0010\u0092\u000b²\u0007\u008b;[\u0090a?ú\u0000¢6\u008cxÉVbÛKs\u0019½«\u008dÿ°k¬çÈÊé½\u008c\u0004ªó\u0087\u0013'øHe\u0086(¼l&lé )ð·häNto\nàw6Î2u\nð\u0097éz\u0007ôêI\u0081~\u0005\u009f\u0093\u0093µ\u001a\u0010ú`\u0011\u0084E ^«-j\u0010\u0002þ\u0098\u009a\u000b".length();
      char var17 = 16;
      int var25 = -1;

      label82:
      while(true) {
         ++var25;
         String var10000 = var18.substring(var25, var25 + var17);
         int var10001 = -1;

         while(true) {
            char[] var43;
            label77: {
               char[] var29 = var10000.toCharArray();
               int var10003 = var29.length;
               int var22 = 0;
               var43 = var29;
               int var32 = var10003;
               char[] var53;
               int var10004;
               if (var10003 <= 1) {
                  var53 = var29;
                  var10004 = var22;
               } else {
                  var43 = var29;
                  var32 = var10003;
                  if (var10003 <= var22) {
                     break label77;
                  }

                  var53 = var29;
                  var10004 = var22;
               }

               while(true) {
                  char var10005 = var53[var10004];
                  byte var10006;
                  switch (var22 % 7) {
                     case 0 -> var10006 = 60;
                     case 1 -> var10006 = 112;
                     case 2 -> var10006 = 71;
                     case 3 -> var10006 = 97;
                     case 4 -> var10006 = 24;
                     case 5 -> var10006 = 10;
                     default -> var10006 = 90;
                  }

                  var53[var10004] = (char)(var10005 ^ var10006);
                  ++var22;
                  if (var32 == 0) {
                     var10004 = var32;
                     var53 = var43;
                  } else {
                     if (var32 <= var22) {
                        break;
                     }

                     var53 = var43;
                     var10004 = var22;
                  }
               }
            }

            String var60 = (new String(var43)).intern();
            switch (var10001) {
               case 0:
                  var21[var19++] = var60;
                  if ((var25 += var17) >= var20) {
                     a = var21;
                     b = new String[10];
                     TOTEM = a(3878, -27744);
                     long var8 = 1768314010329237493L;
                     long[] var14 = new long[5];
                     int var11 = 0;
                     String var12 = "\u007f\u0014Ø:Æ\\\u000f4\u0097,½\u0007\u0005¿+\u0002\u001b\u008fHðeÛ\u001fv";
                     int var13 = "\u007f\u0014Ø:Æ\\\u000f4\u0097,½\u0007\u0005¿+\u0002\u001b\u008fHðeÛ\u001fv".length();
                     int var10 = 0;

                     label53:
                     while(true) {
                        var10001 = var10;
                        var10 += 8;
                        byte[] var15 = var12.substring(var10001, var10).getBytes("ISO-8859-1");
                        long[] var27 = var14;
                        var10001 = var11++;
                        long var48 = ((long)var15[0] & 255L) << 56 | ((long)var15[1] & 255L) << 48 | ((long)var15[2] & 255L) << 40 | ((long)var15[3] & 255L) << 32 | ((long)var15[4] & 255L) << 24 | ((long)var15[5] & 255L) << 16 | ((long)var15[6] & 255L) << 8 | (long)var15[7] & 255L;
                        byte var61 = -1;

                        while(true) {
                           long var65 = var48 ^ var8;
                           switch (var61) {
                              case 0:
                                 var27[var10001] = var65;
                                 if (var10 >= var13) {
                                    c = var14;
                                    d = new Integer[5];
                                    OFFHAND_BUTTON = a(28413, 9211854506312681705L);
                                    long var0 = 8504516913936233994L;
                                    long[] var6 = new long[2];
                                    int var3 = 0;
                                    String var4 = "b°:H`\u008dgJ2Ò]~\u0094Õ}Ì";
                                    int var5 = "b°:H`\u008dgJ2Ò]~\u0094Õ}Ì".length();
                                    int var2 = 0;

                                    do {
                                       var10001 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                                       var10001 = var3++;
                                       var65 = (((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L) ^ var0;
                                       var61 = -1;
                                       var6[var10001] = var65;
                                    } while(var2 < var5);

                                    e = var6;
                                    f = new Long[2];
                                    return;
                                 }
                                 break;
                              default:
                                 var27[var10001] = var65;
                                 if (var10 < var13) {
                                    continue label53;
                                 }

                                 var12 = "\u0018pw\u0007]5\u001b=ÉÞ\u0019\u0090¤\u0015Vå";
                                 var13 = "\u0018pw\u0007]5\u001b=ÉÞ\u0019\u0090¤\u0015Vå".length();
                                 var10 = 0;
                           }

                           var10001 = var10;
                           var10 += 8;
                           var15 = var12.substring(var10001, var10).getBytes("ISO-8859-1");
                           var27 = var14;
                           var10001 = var11++;
                           var48 = ((long)var15[0] & 255L) << 56 | ((long)var15[1] & 255L) << 48 | ((long)var15[2] & 255L) << 40 | ((long)var15[3] & 255L) << 32 | ((long)var15[4] & 255L) << 24 | ((long)var15[5] & 255L) << 16 | ((long)var15[6] & 255L) << 8 | (long)var15[7] & 255L;
                           var61 = 0;
                        }
                     }
                  }

                  var17 = var18.charAt(var25);
                  break;
               default:
                  var21[var19++] = var60;
                  if ((var25 += var17) < var20) {
                     var17 = var18.charAt(var25);
                     continue label82;
                  }

                  var18 = "[õ\u009e1¸\\\u0010\f(Ï\u008d\u009e\u0001%\u008fBîý\u0092C\u008a-I";
                  var20 = "[õ\u009e1¸\\\u0010\f(Ï\u008d\u009e\u0001%\u008fBîý\u0092C\u008a-I".length();
                  var17 = 6;
                  var25 = -1;
            }

            ++var25;
            var10000 = var18.substring(var25, var25 + var17);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 3887) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 251;
            case 1 -> var10000 = 43;
            case 2 -> var10000 = 83;
            case 3 -> var10000 = 74;
            case 4 -> var10000 = 186;
            case 5 -> var10000 = 176;
            case 6 -> var10000 = 235;
            case 7 -> var10000 = 58;
            case 8 -> var10000 = 180;
            case 9 -> var10000 = 192;
            case 10 -> var10000 = 227;
            case 11 -> var10000 = 181;
            case 12 -> var10000 = 118;
            case 13 -> var10000 = 178;
            case 14 -> var10000 = 97;
            case 15 -> var10000 = 1;
            case 16 -> var10000 = 73;
            case 17 -> var10000 = 119;
            case 18 -> var10000 = 130;
            case 19 -> var10000 = 220;
            case 20 -> var10000 = 252;
            case 21 -> var10000 = 96;
            case 22 -> var10000 = 173;
            case 23 -> var10000 = 122;
            case 24 -> var10000 = 64;
            case 25 -> var10000 = 208;
            case 26 -> var10000 = 99;
            case 27 -> var10000 = 202;
            case 28 -> var10000 = 161;
            case 29 -> var10000 = 62;
            case 30 -> var10000 = 219;
            case 31 -> var10000 = 147;
            case 32 -> var10000 = 207;
            case 33 -> var10000 = 7;
            case 34 -> var10000 = 90;
            case 35 -> var10000 = 137;
            case 36 -> var10000 = 10;
            case 37 -> var10000 = 19;
            case 38 -> var10000 = 230;
            case 39 -> var10000 = 223;
            case 40 -> var10000 = 195;
            case 41 -> var10000 = 59;
            case 42 -> var10000 = 155;
            case 43 -> var10000 = 95;
            case 44 -> var10000 = 13;
            case 45 -> var10000 = 128;
            case 46 -> var10000 = 84;
            case 47 -> var10000 = 42;
            case 48 -> var10000 = 92;
            case 49 -> var10000 = 44;
            case 50 -> var10000 = 218;
            case 51 -> var10000 = 69;
            case 52 -> var10000 = 2;
            case 53 -> var10000 = 206;
            case 54 -> var10000 = 184;
            case 55 -> var10000 = 165;
            case 56 -> var10000 = 36;
            case 57 -> var10000 = 82;
            case 58 -> var10000 = 213;
            case 59 -> var10000 = 182;
            case 60 -> var10000 = 88;
            case 61 -> var10000 = 183;
            case 62 -> var10000 = 117;
            case 63 -> var10000 = 238;
            case 64 -> var10000 = 142;
            case 65 -> var10000 = 134;
            case 66 -> var10000 = 231;
            case 67 -> var10000 = 129;
            case 68 -> var10000 = 187;
            case 69 -> var10000 = 224;
            case 70 -> var10000 = 71;
            case 71 -> var10000 = 29;
            case 72 -> var10000 = 102;
            case 73 -> var10000 = 242;
            case 74 -> var10000 = 108;
            case 75 -> var10000 = 91;
            case 76 -> var10000 = 193;
            case 77 -> var10000 = 228;
            case 78 -> var10000 = 167;
            case 79 -> var10000 = 169;
            case 80 -> var10000 = 41;
            case 81 -> var10000 = 50;
            case 82 -> var10000 = 55;
            case 83 -> var10000 = 226;
            case 84 -> var10000 = 38;
            case 85 -> var10000 = 104;
            case 86 -> var10000 = 222;
            case 87 -> var10000 = 60;
            case 88 -> var10000 = 12;
            case 89 -> var10000 = 171;
            case 90 -> var10000 = 111;
            case 91 -> var10000 = 234;
            case 92 -> var10000 = 110;
            case 93 -> var10000 = 16;
            case 94 -> var10000 = 164;
            case 95 -> var10000 = 188;
            case 96 -> var10000 = 132;
            case 97 -> var10000 = 51;
            case 98 -> var10000 = 100;
            case 99 -> var10000 = 54;
            case 100 -> var10000 = 86;
            case 101 -> var10000 = 40;
            case 102 -> var10000 = 9;
            case 103 -> var10000 = 126;
            case 104 -> var10000 = 79;
            case 105 -> var10000 = 121;
            case 106 -> var10000 = 17;
            case 107 -> var10000 = 76;
            case 108 -> var10000 = 201;
            case 109 -> var10000 = 87;
            case 110 -> var10000 = 204;
            case 111 -> var10000 = 114;
            case 112 -> var10000 = 162;
            case 113 -> var10000 = 53;
            case 114 -> var10000 = 27;
            case 115 -> var10000 = 249;
            case 116 -> var10000 = 143;
            case 117 -> var10000 = 250;
            case 118 -> var10000 = 65;
            case 119 -> var10000 = 145;
            case 120 -> var10000 = 33;
            case 121 -> var10000 = 46;
            case 122 -> var10000 = 246;
            case 123 -> var10000 = 240;
            case 124 -> var10000 = 75;
            case 125 -> var10000 = 66;
            case 126 -> var10000 = 49;
            case 127 -> var10000 = 210;
            case 128 -> var10000 = 136;
            case 129 -> var10000 = 105;
            case 130 -> var10000 = 232;
            case 131 -> var10000 = 8;
            case 132 -> var10000 = 39;
            case 133 -> var10000 = 21;
            case 134 -> var10000 = 194;
            case 135 -> var10000 = 4;
            case 136 -> var10000 = 89;
            case 137 -> var10000 = 25;
            case 138 -> var10000 = 237;
            case 139 -> var10000 = 107;
            case 140 -> var10000 = 245;
            case 141 -> var10000 = 211;
            case 142 -> var10000 = 32;
            case 143 -> var10000 = 253;
            case 144 -> var10000 = 168;
            case 145 -> var10000 = 160;
            case 146 -> var10000 = 239;
            case 147 -> var10000 = 11;
            case 148 -> var10000 = 68;
            case 149 -> var10000 = 236;
            case 150 -> var10000 = 135;
            case 151 -> var10000 = 15;
            case 152 -> var10000 = 244;
            case 153 -> var10000 = 221;
            case 154 -> var10000 = 199;
            case 155 -> var10000 = 0;
            case 156 -> var10000 = 18;
            case 157 -> var10000 = 133;
            case 158 -> var10000 = 23;
            case 159 -> var10000 = 247;
            case 160 -> var10000 = 101;
            case 161 -> var10000 = 196;
            case 162 -> var10000 = 243;
            case 163 -> var10000 = 61;
            case 164 -> var10000 = 37;
            case 165 -> var10000 = 172;
            case 166 -> var10000 = 113;
            case 167 -> var10000 = 116;
            case 168 -> var10000 = 125;
            case 169 -> var10000 = 120;
            case 170 -> var10000 = 190;
            case 171 -> var10000 = 225;
            case 172 -> var10000 = 72;
            case 173 -> var10000 = 148;
            case 174 -> var10000 = 159;
            case 175 -> var10000 = 56;
            case 176 -> var10000 = 205;
            case 177 -> var10000 = 6;
            case 178 -> var10000 = 157;
            case 179 -> var10000 = 140;
            case 180 -> var10000 = 215;
            case 181 -> var10000 = 20;
            case 182 -> var10000 = 45;
            case 183 -> var10000 = 254;
            case 184 -> var10000 = 198;
            case 185 -> var10000 = 48;
            case 186 -> var10000 = 149;
            case 187 -> var10000 = 94;
            case 188 -> var10000 = 138;
            case 189 -> var10000 = 3;
            case 190 -> var10000 = 124;
            case 191 -> var10000 = 177;
            case 192 -> var10000 = 103;
            case 193 -> var10000 = 185;
            case 194 -> var10000 = 233;
            case 195 -> var10000 = 197;
            case 196 -> var10000 = 200;
            case 197 -> var10000 = 52;
            case 198 -> var10000 = 34;
            case 199 -> var10000 = 14;
            case 200 -> var10000 = 85;
            case 201 -> var10000 = 214;
            case 202 -> var10000 = 47;
            case 203 -> var10000 = 144;
            case 204 -> var10000 = 28;
            case 205 -> var10000 = 93;
            case 206 -> var10000 = 78;
            case 207 -> var10000 = 22;
            case 208 -> var10000 = 67;
            case 209 -> var10000 = 109;
            case 210 -> var10000 = 5;
            case 211 -> var10000 = 154;
            case 212 -> var10000 = 26;
            case 213 -> var10000 = 191;
            case 214 -> var10000 = 203;
            case 215 -> var10000 = 189;
            case 216 -> var10000 = 175;
            case 217 -> var10000 = 255;
            case 218 -> var10000 = 174;
            case 219 -> var10000 = 70;
            case 220 -> var10000 = 57;
            case 221 -> var10000 = 131;
            case 222 -> var10000 = 30;
            case 223 -> var10000 = 127;
            case 224 -> var10000 = 115;
            case 225 -> var10000 = 35;
            case 226 -> var10000 = 229;
            case 227 -> var10000 = 152;
            case 228 -> var10000 = 179;
            case 229 -> var10000 = 80;
            case 230 -> var10000 = 163;
            case 231 -> var10000 = 170;
            case 232 -> var10000 = 156;
            case 233 -> var10000 = 151;
            case 234 -> var10000 = 77;
            case 235 -> var10000 = 81;
            case 236 -> var10000 = 158;
            case 237 -> var10000 = 24;
            case 238 -> var10000 = 241;
            case 239 -> var10000 = 98;
            case 240 -> var10000 = 166;
            case 241 -> var10000 = 212;
            case 242 -> var10000 = 112;
            case 243 -> var10000 = 123;
            case 244 -> var10000 = 209;
            case 245 -> var10000 = 106;
            case 246 -> var10000 = 216;
            case 247 -> var10000 = 63;
            case 248 -> var10000 = 146;
            case 249 -> var10000 = 31;
            case 250 -> var10000 = 139;
            case 251 -> var10000 = 141;
            case 252 -> var10000 = 150;
            case 253 -> var10000 = 153;
            case 254 -> var10000 = 248;
            default -> var10000 = 217;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 9748;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }

   private static long b(int var0, long var1) {
      int var3 = (var0 ^ (int)var1 ^ 25049) & 32767;
      if (f[var3] == null) {
         f[var3] = e[var3] ^ var1;
      }

      return f[var3];
   }
}
