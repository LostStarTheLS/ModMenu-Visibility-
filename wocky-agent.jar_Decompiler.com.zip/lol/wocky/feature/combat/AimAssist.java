package lol.wocky.feature.combat;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.NameListProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.render.Hud2D;

public class AimAssist extends Module {
   private static final long CLICK_WINDOW_NS;
   private static final float VERTICAL_SHARE = 0.5F;
   private final BooleanProperty clickOnly = new BooleanProperty(a(19521, -8830), true);
   private final NumberProperty speed = new NumberProperty(a(19522, 13662), (double)6.0F, (double)1.0F, (double)20.0F, (double)0.5F);
   private final BooleanProperty vertical = new BooleanProperty(a(19527, 8107), true);
   private final NumberProperty randomize = new NumberProperty(a(19524, -13539), a(25496, 3166638243435708168L), 0, a(9341, 3484493502955043048L), 5);
   private final NumberProperty fov = new NumberProperty(a(19525, 28532), a(2836, 1053353411332609925L), a(13119, 6541637339994992556L), a(31658, 7677329465646376755L), 5);
   private final NumberProperty range = new NumberProperty(a(19528, 10690), (double)4.5F, (double)3.0F, (double)8.0F, 0.1);
   private final BooleanProperty weaponsOnly = new BooleanProperty(a(19526, -7477), true);
   private final BooleanProperty mobs = new BooleanProperty(a(19530, 27766), false);
   private final BooleanProperty showFov = new BooleanProperty(a(19531, -5529), false);
   private final NameListProperty whitelist = new NameListProperty(a(19529, -1711));
   private final List<Object> candidates = new ArrayList();
   private Object target;
   private long lastFrame;
   private long lastClick;
   private double offX;
   private double offY;
   private double offZ;
   private double wantOffX;
   private double wantOffY;
   private double wantOffZ;
   private float speedNoise;
   private float wantSpeedNoise;
   private int noiseTicks;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;
   private static final long[] e;
   private static final Long[] f;

   public AimAssist() {
      super(a(19520, 4910), a(19523, -28616), ModuleCategory.COMBAT);
      Property[] var10001 = new Property[a(8535, 8739799363138567631L)];
      var10001[0] = this.clickOnly;
      var10001[1] = this.speed;
      var10001[2] = this.vertical;
      var10001[3] = this.randomize;
      var10001[4] = this.fov;
      var10001[5] = this.range;
      var10001[a(14777, 4033024325783823650L)] = this.weaponsOnly;
      var10001[a(32138, 8058569613951066392L)] = this.mobs;
      var10001[a(10786, 5312323950237071032L)] = this.showFov;
      var10001[a(21496, 5095631382029389671L)] = this.whitelist;
      this.addProperties(var10001);
   }

   public void onTick() {
      this.candidates.clear();
      Object var1 = MinecraftBridge.getPlayer();
      double var2 = this.range.doubleValue() + (double)1.0F;
      double var4 = MinecraftBridge.getEntityX(var1);
      double var6 = MinecraftBridge.getEntityY(var1);
      double var8 = MinecraftBridge.getEntityZ(var1);

      for(Object var12 : (Boolean)this.mobs.getValue() ? MinecraftBridge.getEntities() : MinecraftBridge.getPlayers()) {
         if (this.isValid(var12, var1)) {
            double var13 = MinecraftBridge.getEntityX(var12) - var4;
            double var15 = MinecraftBridge.getEntityY(var12) - var6;
            double var17 = MinecraftBridge.getEntityZ(var12) - var8;
            if (var13 * var13 + var15 * var15 + var17 * var17 <= var2 * var2) {
               this.candidates.add(var12);
            }
         }
      }

      if (this.target != null && !this.candidates.contains(this.target)) {
         this.target = null;
      }

      this.tickNoise();
   }

   private boolean isValid(Object var1, Object var2) {
      if (var1 != null && var1 != var2 && !MinecraftBridge.isEntityRemoved(var1) && !MinecraftBridge.isDead(var1)) {
         if (MinecraftBridge.isPlayer(var1)) {
            if (this.whitelist.contains(MinecraftBridge.getEntityName(var1)) || MinecraftBridge.isTeammate(var1)) {
               return false;
            }
         } else if (!(Boolean)this.mobs.getValue() || !MinecraftBridge.isLiving(var1)) {
            return false;
         }

         return !MinecraftBridge.isInvisible(var1) && MinecraftBridge.canSee(var1);
      } else {
         return false;
      }
   }

   private void tickNoise() {
      if (--this.noiseTicks <= 0) {
         ThreadLocalRandom var1 = ThreadLocalRandom.current();
         this.noiseTicks = var1.nextInt(4, a(32429, 5497705913549349425L));
         double var2 = this.randomize.doubleValue() / (double)100.0F;
         this.wantOffX = var1.nextDouble(-0.3, 0.3) * var2;
         this.wantOffY = var1.nextDouble(-0.3, 0.3) * var2;
         this.wantOffZ = var1.nextDouble(-0.3, 0.3) * var2;
         this.wantSpeedNoise = (float)(var1.nextDouble((double)-0.5F, (double)0.5F) * var2);
      }
   }

   public void onHudRender(Hud2D var1) {
      long var2 = System.nanoTime();
      float var4 = this.lastFrame == 0L ? 0.0F : Math.min(0.05F, (float)(var2 - this.lastFrame) / 1.0E9F);
      this.lastFrame = var2;
      if (MinecraftBridge.isKeyDown(a(23756, 3163119484868149336L))) {
         this.lastClick = var2;
      }

      if ((Boolean)this.showFov.getValue() && MinecraftBridge.getCurrentScreen() == null) {
         this.drawFov(var1);
      }

      if (!(var4 <= 0.0F) && this.shouldAim(var2)) {
         float var5 = 1.0F - (float)Math.exp((double)-8.0F * (double)var4);
         this.offX += (this.wantOffX - this.offX) * (double)var5;
         this.offY += (this.wantOffY - this.offY) * (double)var5;
         this.offZ += (this.wantOffZ - this.offZ) * (double)var5;
         this.speedNoise += (this.wantSpeedNoise - this.speedNoise) * var5;
         Object var6 = MinecraftBridge.getPlayer();
         float var7 = MinecraftBridge.getYaw(var6);
         float var8 = MinecraftBridge.getPitch(var6);
         double var9 = var1.camX();
         double var11 = var1.camY();
         double var13 = var1.camZ();
         float var15 = this.fov.floatValue() / 2.0F;
         double var16 = this.range.doubleValue();
         float[] var18 = this.target != null ? this.turnTo(this.target, var1, var9, var11, var13, var7, var8, var16, var15) : null;
         if (var18 == null) {
            this.target = null;

            for(Object var20 : this.candidates) {
               float[] var21 = this.turnTo(var20, var1, var9, var11, var13, var7, var8, var16, var15);
               if (var21 != null && (var18 == null || var21[2] < var18[2])) {
                  this.target = var20;
                  var18 = var21;
               }
            }
         }

         if (var18 != null) {
            if (MinecraftBridge.getHitEntity(MinecraftBridge.getCrosshairTarget()) != this.target) {
               float var22 = this.speed.floatValue() * (1.0F + this.speedNoise);
               float var23 = ease(var18[0], var22, var4);
               float var24 = (Boolean)this.vertical.getValue() ? ease(var18[1], var22 * 0.5F, var4) : 0.0F;
               if (var23 != 0.0F || var24 != 0.0F) {
                  MinecraftBridge.turnPlayer(var23, var24);
               }

            }
         }
      }
   }

   private boolean shouldAim(long var1) {
      if (MinecraftBridge.isInGame() && MinecraftBridge.getCurrentScreen() == null) {
         if (MinecraftBridge.isMouseLocked()) {
            return false;
         } else if ((Boolean)this.clickOnly.getValue() && var1 - this.lastClick >= b(29668, 221745798176763251L)) {
            return false;
         } else if ((Boolean)this.weaponsOnly.getValue() && !TriggerBot.isWeapon(MinecraftBridge.itemId(MinecraftBridge.getMainHandStack()))) {
            return false;
         } else {
            return !MinecraftBridge.isBreakingBlock();
         }
      } else {
         return false;
      }
   }

   private float[] turnTo(Object var1, Hud2D var2, double var3, double var5, double var7, float var9, float var10, double var11, float var13) {
      double[] var14 = MinecraftBridge.getBoundingBox(var1);
      double[] var15 = MinecraftBridge.getLerpedPos(var1, var2.tickDelta());
      if (var14 != null && var15 != null) {
         double var16 = var15[0] - MinecraftBridge.getEntityX(var1);
         double var18 = var15[1] - MinecraftBridge.getEntityY(var1);
         double var20 = var15[2] - MinecraftBridge.getEntityZ(var1);
         double var22 = var14[0] + var16;
         double var24 = var14[1] + var18;
         double var26 = var14[2] + var20;
         double var28 = var14[3] + var16;
         double var30 = var14[4] + var18;
         double var32 = var14[5] + var20;
         double var34 = var28 - var22;
         double var36 = var30 - var24;
         double var38 = var32 - var26;
         double var40 = clamp(var3, var22 + var34 * (double)0.25F, var28 - var34 * (double)0.25F);
         double var42 = clamp(var5, var24 + var36 * 0.15, var30 - var36 * 0.1);
         double var44 = clamp(var7, var26 + var38 * (double)0.25F, var32 - var38 * (double)0.25F);
         var40 = clamp(var40 + this.offX * var34, var22 + var34 * 0.1, var28 - var34 * 0.1);
         var42 = clamp(var42 + this.offY * var36, var24 + var36 * 0.05, var30 - var36 * 0.05);
         var44 = clamp(var44 + this.offZ * var38, var26 + var38 * 0.1, var32 - var38 * 0.1);
         double var46 = var40 - var3;
         double var48 = var42 - var5;
         double var50 = var44 - var7;
         double var52 = Math.sqrt(var46 * var46 + var48 * var48 + var50 * var50);
         if (!(var52 > var11) && !(var52 < 0.001)) {
            float var54 = (float)Math.toDegrees(Math.atan2(var50, var46)) - 90.0F;
            float var55 = (float)(-Math.toDegrees(Math.atan2(var48, Math.sqrt(var46 * var46 + var50 * var50))));
            float var56 = wrap(var54 - var9);
            float var57 = var55 - var10;
            float var58 = (float)Math.sqrt((double)(var56 * var56 + var57 * var57));
            return var58 > var13 ? null : new float[]{var56, var57, var58};
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private static float ease(float var0, float var1, float var2) {
      return var0 * (1.0F - (float)Math.exp((double)(-var1 * var2)));
   }

   private void drawFov(Hud2D var1) {
      float var2 = this.fov.floatValue() / 2.0F;
      if (!(var2 >= 85.0F)) {
         Object var3 = MinecraftBridge.getPlayer();
         double var4 = Math.toRadians((double)MinecraftBridge.getYaw(var3));
         double var6 = Math.toRadians((double)MinecraftBridge.getPitch(var3));
         double var8 = -Math.sin(var4) * Math.cos(var6);
         double var10 = -Math.sin(var6);
         double var12 = Math.cos(var4) * Math.cos(var6);
         double var14 = -Math.cos(var4);
         double var16 = -Math.sin(var4);
         double var18 = -Math.sin(var4) * Math.sin(var6);
         double var20 = Math.cos(var6);
         double var22 = Math.cos(var4) * Math.sin(var6);
         double var24 = Math.cos(Math.toRadians((double)var2));
         double var26 = Math.sin(Math.toRadians((double)var2));
         int var28 = Math.max(2, var1.guiScale());
         float[] var29 = new float[2];

         for(int var30 = 0; var30 < a(11302, 5121620662525931707L); ++var30) {
            double var31 = (double)var30 * Math.PI * (double)2.0F / (double)72.0F;
            double var33 = Math.cos(var31) * var26;
            double var35 = Math.sin(var31) * var26;
            double var37 = var1.camX() + var8 * var24 + var14 * var33 + var18 * var35;
            double var39 = var1.camY() + var10 * var24 + var20 * var35;
            double var41 = var1.camZ() + var12 * var24 + var16 * var33 + var22 * var35;
            if (var1.project(var37, var39, var41, var29)) {
               int var43 = Math.round(var29[0]);
               int var44 = Math.round(var29[1]);
               var1.fill(var43 - var28 / 2, var44 - var28 / 2, var43 - var28 / 2 + var28, var44 - var28 / 2 + var28, a(6893, 5830878689920419443L));
            }
         }

      }
   }

   private static double clamp(double var0, double var2, double var4) {
      return var2 > var4 ? (var2 + var4) / (double)2.0F : Math.max(var2, Math.min(var4, var0));
   }

   private static float wrap(float var0) {
      var0 %= 360.0F;
      if (var0 >= 180.0F) {
         var0 -= 360.0F;
      }

      if (var0 < -180.0F) {
         var0 += 360.0F;
      }

      return var0;
   }

   public void onDisable() {
      this.candidates.clear();
      this.target = null;
      this.lastFrame = 0L;
      this.offX = this.offY = this.offZ = this.wantOffX = this.wantOffY = this.wantOffZ = (double)0.0F;
      this.speedNoise = this.wantSpeedNoise = 0.0F;
      this.noiseTicks = 0;
   }

   static {
      String[] var21 = new String[12];
      int var19 = 0;
      String var18 = "Ð²\u008eµ}+°\u000e\u0088\u0096æÿ\u000f\u009d{]Æ¸¨Àª'Ö?+Û}HÔ¥Íÿ\u0088vµy?\u0015]J«9\b§æm3Ì¢\tòÍ\u0092DàU-ºÎ\nbÀÆbö¤Ò Ë\u0006\f÷\u0006ê\u0081~ç{\u0001f¢þ\u008f\f;´AÓ|$ï\u0099Ë[Ìn\tÌy'þ)\u009d\u008bw\u000b\u0003\n4Q\u0004ÂÞ\u0016Ò\b»'é\u000e\u009eÙý\u009d";
      int var20 = "Ð²\u008eµ}+°\u000e\u0088\u0096æÿ\u000f\u009d{]Æ¸¨Àª'Ö?+Û}HÔ¥Íÿ\u0088vµy?\u0015]J«9\b§æm3Ì¢\tòÍ\u0092DàU-ºÎ\nbÀÆbö¤Ò Ë\u0006\f÷\u0006ê\u0081~ç{\u0001f¢þ\u008f\f;´AÓ|$ï\u0099Ë[Ìn\tÌy'þ)\u009d\u008bw\u000b\u0003\n4Q\u0004ÂÞ\u0016Ò\b»'é\u000e\u009eÙý\u009d".length();
      char var17 = 5;
      int var25 = -1;

      label82:
      while(true) {
         ++var25;
         String var10000 = var18.substring(var25, var25 + var17);
         int var10001 = -1;

         while(true) {
            char[] var43;
            label77: {
               char[] var29 = var10000.toCharArray();
               int var10003 = var29.length;
               int var22 = 0;
               var43 = var29;
               int var32 = var10003;
               char[] var53;
               int var10004;
               if (var10003 <= 1) {
                  var53 = var29;
                  var10004 = var22;
               } else {
                  var43 = var29;
                  var32 = var10003;
                  if (var10003 <= var22) {
                     break label77;
                  }

                  var53 = var29;
                  var10004 = var22;
               }

               while(true) {
                  char var10005 = var53[var10004];
                  byte var10006;
                  switch (var22 % 7) {
                     case 0 -> var10006 = 94;
                     case 1 -> var10006 = 118;
                     case 2 -> var10006 = 3;
                     case 3 -> var10006 = 54;
                     case 4 -> var10006 = 97;
                     case 5 -> var10006 = 1;
                     default -> var10006 = 105;
                  }

                  var53[var10004] = (char)(var10005 ^ var10006);
                  ++var22;
                  if (var32 == 0) {
                     var10004 = var32;
                     var53 = var43;
                  } else {
                     if (var32 <= var22) {
                        break;
                     }

                     var53 = var43;
                     var10004 = var22;
                  }
               }
            }

            String var60 = (new String(var43)).intern();
            switch (var10001) {
               case 0:
                  var21[var19++] = var60;
                  if ((var25 += var17) >= var20) {
                     a = var21;
                     b = new String[12];
                     long var8 = 4467315319756693029L;
                     long[] var14 = new long[14];
                     int var11 = 0;
                     String var12 = "ÿ\u000fÉ¼mÍ#à\u0012\u0094M\u0086J¿ø~×j¥§ìl(\u0095\u0011ø|\u0000é\u0018»\u0001D¿èå5n|\u001f\u0089$%b%ê®Ö£Ø\u0083S¥'b\u0090¥\u001b\u0091JÍóÑK7M\u009dê=äá3øXà \u008c¯\tú°\u0007\u009a h\u008d\u007f:xG>Å&\u00171\u0083";
                     int var13 = "ÿ\u000fÉ¼mÍ#à\u0012\u0094M\u0086J¿ø~×j¥§ìl(\u0095\u0011ø|\u0000é\u0018»\u0001D¿èå5n|\u001f\u0089$%b%ê®Ö£Ø\u0083S¥'b\u0090¥\u001b\u0091JÍóÑK7M\u009dê=äá3øXà \u008c¯\tú°\u0007\u009a h\u008d\u007f:xG>Å&\u00171\u0083".length();
                     int var10 = 0;

                     label53:
                     while(true) {
                        var10001 = var10;
                        var10 += 8;
                        byte[] var15 = var12.substring(var10001, var10).getBytes("ISO-8859-1");
                        long[] var27 = var14;
                        var10001 = var11++;
                        long var48 = ((long)var15[0] & 255L) << 56 | ((long)var15[1] & 255L) << 48 | ((long)var15[2] & 255L) << 40 | ((long)var15[3] & 255L) << 32 | ((long)var15[4] & 255L) << 24 | ((long)var15[5] & 255L) << 16 | ((long)var15[6] & 255L) << 8 | (long)var15[7] & 255L;
                        byte var61 = -1;

                        while(true) {
                           long var65 = var48 ^ var8;
                           switch (var61) {
                              case 0:
                                 var27[var10001] = var65;
                                 if (var10 >= var13) {
                                    c = var14;
                                    d = new Integer[14];
                                    long var0 = 2146567987632954125L;
                                    long[] var6 = new long[2];
                                    int var3 = 0;
                                    String var4 = "\u0004{ù\u008bþ\nÜ\u0014\u001eÙè\u0096Î5\u0015~";
                                    int var5 = "\u0004{ù\u008bþ\nÜ\u0014\u001eÙè\u0096Î5\u0015~".length();
                                    int var2 = 0;

                                    do {
                                       var10001 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                                       var10001 = var3++;
                                       var65 = (((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L) ^ var0;
                                       var61 = -1;
                                       var6[var10001] = var65;
                                    } while(var2 < var5);

                                    e = var6;
                                    f = new Long[2];
                                    CLICK_WINDOW_NS = b(14991, 1851504729318564889L);
                                    return;
                                 }
                                 break;
                              default:
                                 var27[var10001] = var65;
                                 if (var10 < var13) {
                                    continue label53;
                                 }

                                 var12 = "\u008czã\u0087ÐlÝ\u0094ëüÎ©T\b¦©";
                                 var13 = "\u008czã\u0087ÐlÝ\u0094ëüÎ©T\b¦©".length();
                                 var10 = 0;
                           }

                           var10001 = var10;
                           var10 += 8;
                           var15 = var12.substring(var10001, var10).getBytes("ISO-8859-1");
                           var27 = var14;
                           var10001 = var11++;
                           var48 = ((long)var15[0] & 255L) << 56 | ((long)var15[1] & 255L) << 48 | ((long)var15[2] & 255L) << 40 | ((long)var15[3] & 255L) << 32 | ((long)var15[4] & 255L) << 24 | ((long)var15[5] & 255L) << 16 | ((long)var15[6] & 255L) << 8 | (long)var15[7] & 255L;
                           var61 = 0;
                        }
                     }
                  }

                  var17 = var18.charAt(var25);
                  break;
               default:
                  var21[var19++] = var60;
                  if ((var25 += var17) < var20) {
                     var17 = var18.charAt(var25);
                     continue label82;
                  }

                  var18 = "aÃ\u0092ª\u0095\tIö57\u0086·5\u001aÍ";
                  var20 = "aÃ\u0092ª\u0095\tIö57\u0086·5\u001aÍ".length();
                  var17 = 5;
                  var25 = -1;
            }

            ++var25;
            var10000 = var18.substring(var25, var25 + var17);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 19522) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 101;
            case 1 -> var10000 = 212;
            case 2 -> var10000 = 56;
            case 3 -> var10000 = 62;
            case 4 -> var10000 = 26;
            case 5 -> var10000 = 162;
            case 6 -> var10000 = 54;
            case 7 -> var10000 = 49;
            case 8 -> var10000 = 111;
            case 9 -> var10000 = 31;
            case 10 -> var10000 = 78;
            case 11 -> var10000 = 238;
            case 12 -> var10000 = 43;
            case 13 -> var10000 = 12;
            case 14 -> var10000 = 23;
            case 15 -> var10000 = 138;
            case 16 -> var10000 = 71;
            case 17 -> var10000 = 134;
            case 18 -> var10000 = 60;
            case 19 -> var10000 = 252;
            case 20 -> var10000 = 110;
            case 21 -> var10000 = 42;
            case 22 -> var10000 = 236;
            case 23 -> var10000 = 17;
            case 24 -> var10000 = 104;
            case 25 -> var10000 = 38;
            case 26 -> var10000 = 224;
            case 27 -> var10000 = 251;
            case 28 -> var10000 = 46;
            case 29 -> var10000 = 16;
            case 30 -> var10000 = 27;
            case 31 -> var10000 = 48;
            case 32 -> var10000 = 59;
            case 33 -> var10000 = 22;
            case 34 -> var10000 = 114;
            case 35 -> var10000 = 143;
            case 36 -> var10000 = 217;
            case 37 -> var10000 = 164;
            case 38 -> var10000 = 185;
            case 39 -> var10000 = 116;
            case 40 -> var10000 = 32;
            case 41 -> var10000 = 196;
            case 42 -> var10000 = 15;
            case 43 -> var10000 = 41;
            case 44 -> var10000 = 245;
            case 45 -> var10000 = 154;
            case 46 -> var10000 = 193;
            case 47 -> var10000 = 115;
            case 48 -> var10000 = 18;
            case 49 -> var10000 = 52;
            case 50 -> var10000 = 144;
            case 51 -> var10000 = 127;
            case 52 -> var10000 = 216;
            case 53 -> var10000 = 107;
            case 54 -> var10000 = 160;
            case 55 -> var10000 = 237;
            case 56 -> var10000 = 39;
            case 57 -> var10000 = 147;
            case 58 -> var10000 = 184;
            case 59 -> var10000 = 88;
            case 60 -> var10000 = 3;
            case 61 -> var10000 = 163;
            case 62 -> var10000 = 195;
            case 63 -> var10000 = 85;
            case 64 -> var10000 = 109;
            case 65 -> var10000 = 202;
            case 66 -> var10000 = 169;
            case 67 -> var10000 = 214;
            case 68 -> var10000 = 249;
            case 69 -> var10000 = 91;
            case 70 -> var10000 = 40;
            case 71 -> var10000 = 4;
            case 72 -> var10000 = 173;
            case 73 -> var10000 = 218;
            case 74 -> var10000 = 191;
            case 75 -> var10000 = 180;
            case 76 -> var10000 = 100;
            case 77 -> var10000 = 6;
            case 78 -> var10000 = 61;
            case 79 -> var10000 = 97;
            case 80 -> var10000 = 92;
            case 81 -> var10000 = 33;
            case 82 -> var10000 = 209;
            case 83 -> var10000 = 113;
            case 84 -> var10000 = 98;
            case 85 -> var10000 = 231;
            case 86 -> var10000 = 149;
            case 87 -> var10000 = 232;
            case 88 -> var10000 = 64;
            case 89 -> var10000 = 90;
            case 90 -> var10000 = 13;
            case 91 -> var10000 = 155;
            case 92 -> var10000 = 183;
            case 93 -> var10000 = 229;
            case 94 -> var10000 = 254;
            case 95 -> var10000 = 241;
            case 96 -> var10000 = 166;
            case 97 -> var10000 = 103;
            case 98 -> var10000 = 14;
            case 99 -> var10000 = 69;
            case 100 -> var10000 = 8;
            case 101 -> var10000 = 120;
            case 102 -> var10000 = 121;
            case 103 -> var10000 = 128;
            case 104 -> var10000 = 213;
            case 105 -> var10000 = 83;
            case 106 -> var10000 = 170;
            case 107 -> var10000 = 142;
            case 108 -> var10000 = 122;
            case 109 -> var10000 = 239;
            case 110 -> var10000 = 253;
            case 111 -> var10000 = 228;
            case 112 -> var10000 = 11;
            case 113 -> var10000 = 96;
            case 114 -> var10000 = 244;
            case 115 -> var10000 = 230;
            case 116 -> var10000 = 192;
            case 117 -> var10000 = 240;
            case 118 -> var10000 = 190;
            case 119 -> var10000 = 126;
            case 120 -> var10000 = 105;
            case 121 -> var10000 = 226;
            case 122 -> var10000 = 139;
            case 123 -> var10000 = 99;
            case 124 -> var10000 = 221;
            case 125 -> var10000 = 55;
            case 126 -> var10000 = 19;
            case 127 -> var10000 = 81;
            case 128 -> var10000 = 199;
            case 129 -> var10000 = 118;
            case 130 -> var10000 = 135;
            case 131 -> var10000 = 1;
            case 132 -> var10000 = 30;
            case 133 -> var10000 = 132;
            case 134 -> var10000 = 250;
            case 135 -> var10000 = 102;
            case 136 -> var10000 = 171;
            case 137 -> var10000 = 161;
            case 138 -> var10000 = 95;
            case 139 -> var10000 = 66;
            case 140 -> var10000 = 53;
            case 141 -> var10000 = 44;
            case 142 -> var10000 = 129;
            case 143 -> var10000 = 112;
            case 144 -> var10000 = 21;
            case 145 -> var10000 = 28;
            case 146 -> var10000 = 93;
            case 147 -> var10000 = 124;
            case 148 -> var10000 = 175;
            case 149 -> var10000 = 187;
            case 150 -> var10000 = 153;
            case 151 -> var10000 = 223;
            case 152 -> var10000 = 194;
            case 153 -> var10000 = 234;
            case 154 -> var10000 = 74;
            case 155 -> var10000 = 174;
            case 156 -> var10000 = 165;
            case 157 -> var10000 = 167;
            case 158 -> var10000 = 247;
            case 159 -> var10000 = 140;
            case 160 -> var10000 = 51;
            case 161 -> var10000 = 67;
            case 162 -> var10000 = 204;
            case 163 -> var10000 = 157;
            case 164 -> var10000 = 10;
            case 165 -> var10000 = 255;
            case 166 -> var10000 = 197;
            case 167 -> var10000 = 58;
            case 168 -> var10000 = 246;
            case 169 -> var10000 = 205;
            case 170 -> var10000 = 178;
            case 171 -> var10000 = 130;
            case 172 -> var10000 = 65;
            case 173 -> var10000 = 75;
            case 174 -> var10000 = 182;
            case 175 -> var10000 = 181;
            case 176 -> var10000 = 25;
            case 177 -> var10000 = 222;
            case 178 -> var10000 = 176;
            case 179 -> var10000 = 36;
            case 180 -> var10000 = 207;
            case 181 -> var10000 = 158;
            case 182 -> var10000 = 57;
            case 183 -> var10000 = 146;
            case 184 -> var10000 = 168;
            case 185 -> var10000 = 73;
            case 186 -> var10000 = 148;
            case 187 -> var10000 = 37;
            case 188 -> var10000 = 2;
            case 189 -> var10000 = 141;
            case 190 -> var10000 = 151;
            case 191 -> var10000 = 84;
            case 192 -> var10000 = 188;
            case 193 -> var10000 = 159;
            case 194 -> var10000 = 20;
            case 195 -> var10000 = 5;
            case 196 -> var10000 = 235;
            case 197 -> var10000 = 45;
            case 198 -> var10000 = 24;
            case 199 -> var10000 = 150;
            case 200 -> var10000 = 79;
            case 201 -> var10000 = 87;
            case 202 -> var10000 = 106;
            case 203 -> var10000 = 0;
            case 204 -> var10000 = 172;
            case 205 -> var10000 = 145;
            case 206 -> var10000 = 136;
            case 207 -> var10000 = 47;
            case 208 -> var10000 = 131;
            case 209 -> var10000 = 29;
            case 210 -> var10000 = 108;
            case 211 -> var10000 = 9;
            case 212 -> var10000 = 77;
            case 213 -> var10000 = 225;
            case 214 -> var10000 = 219;
            case 215 -> var10000 = 179;
            case 216 -> var10000 = 208;
            case 217 -> var10000 = 82;
            case 218 -> var10000 = 34;
            case 219 -> var10000 = 152;
            case 220 -> var10000 = 94;
            case 221 -> var10000 = 76;
            case 222 -> var10000 = 248;
            case 223 -> var10000 = 227;
            case 224 -> var10000 = 86;
            case 225 -> var10000 = 203;
            case 226 -> var10000 = 215;
            case 227 -> var10000 = 233;
            case 228 -> var10000 = 201;
            case 229 -> var10000 = 177;
            case 230 -> var10000 = 220;
            case 231 -> var10000 = 68;
            case 232 -> var10000 = 198;
            case 233 -> var10000 = 50;
            case 234 -> var10000 = 242;
            case 235 -> var10000 = 119;
            case 236 -> var10000 = 200;
            case 237 -> var10000 = 35;
            case 238 -> var10000 = 123;
            case 239 -> var10000 = 137;
            case 240 -> var10000 = 133;
            case 241 -> var10000 = 80;
            case 242 -> var10000 = 156;
            case 243 -> var10000 = 211;
            case 244 -> var10000 = 72;
            case 245 -> var10000 = 210;
            case 246 -> var10000 = 117;
            case 247 -> var10000 = 89;
            case 248 -> var10000 = 243;
            case 249 -> var10000 = 206;
            case 250 -> var10000 = 70;
            case 251 -> var10000 = 189;
            case 252 -> var10000 = 125;
            case 253 -> var10000 = 63;
            case 254 -> var10000 = 186;
            default -> var10000 = 7;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 7320;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }

   private static long b(int var0, long var1) {
      int var3 = (var0 ^ (int)var1 ^ 7830) & 32767;
      if (f[var3] == null) {
         f[var3] = e[var3] ^ var1;
      }

      return f[var3];
   }
}
