package lol.wocky.feature.combat;

import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;

public class ShieldBreaker extends Module {
   private final NumberProperty swapDelay = new NumberProperty(a(6268, 17912), 0, 0, a(6115, 1619066738164221067L), 1);
   private final NumberProperty cooldown = new NumberProperty(a(6264, 187), a(2673, 7826074338663389466L), 0, a(18365, 6129465246959047892L), 1);
   private final BooleanProperty swapBack = new BooleanProperty(a(6267, 18298), true);
   private final BooleanProperty checkFacing = new BooleanProperty(a(6269, 13505), true);
   private final BooleanProperty onlyWithWeapon = new BooleanProperty(a(6270, 3886), true);
   private int clock;
   private int cooldownClock;
   private int previousSlot = -1;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;

   public ShieldBreaker() {
      super(a(6265, 845), a(6266, -93), ModuleCategory.COMBAT);
      this.addProperties(new Property[]{this.swapDelay, this.cooldown, this.swapBack, this.checkFacing, this.onlyWithWeapon});
   }

   public void onTick() {
      if (this.cooldownClock > 0) {
         --this.cooldownClock;
      }

      if (MinecraftBridge.getCurrentScreen() != null) {
         this.restore();
      } else {
         Object var1 = MinecraftBridge.getHitEntity(MinecraftBridge.getCrosshairTarget());
         if (!this.isShielding(var1)) {
            this.restore();
         } else if (this.cooldownClock <= 0) {
            if (!MinecraftBridge.isAxe(MinecraftBridge.getMainHandStack())) {
               if ((Boolean)this.onlyWithWeapon.getValue() && this.previousSlot == -1 && !MinecraftBridge.isHoldingSword()) {
                  return;
               }

               int var2 = MinecraftBridge.findAxeSlot();
               if (var2 == -1) {
                  return;
               }

               if (this.previousSlot == -1) {
                  this.previousSlot = MinecraftBridge.getSelectedSlot();
               }

               MinecraftBridge.setSelectedSlot(var2);
               this.clock = this.swapDelay.intValue();
               if (this.clock > 0) {
                  return;
               }
            }

            if (this.clock > 0) {
               --this.clock;
            } else if (MinecraftBridge.attackEntity(var1, true)) {
               this.cooldownClock = this.cooldown.intValue();
               this.restore();
            }
         }
      }
   }

   private boolean isShielding(Object var1) {
      if (MinecraftBridge.isPlayer(var1) && var1 != MinecraftBridge.getPlayer()) {
         if (!MinecraftBridge.isDead(var1) && MinecraftBridge.isBlocking(var1)) {
            return !(Boolean)this.checkFacing.getValue() || MinecraftBridge.shieldBlocksUs(var1);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void restore() {
      if (this.previousSlot != -1 && (Boolean)this.swapBack.getValue()) {
         MinecraftBridge.setSelectedSlot(this.previousSlot);
      }

      this.previousSlot = -1;
      this.clock = 0;
   }

   public void onDisable() {
      this.restore();
      this.cooldownClock = 0;
   }

   static {
      String[] var13 = new String[7];
      int var11 = 0;
      String var10 = "\u009f\u0018Ñ%Å9\u0082\u009e\r2%pl?3á©O\u000e\u0083ð\u00179\u0019òp¡ÍXT\u001f\u0014l,üµ¹\u0018cz<~°Ð_lÀ¨-Ü\u0004\u0084ñ4ª·\u0011î<\u001b\u0007æbê\u0096)\u0085\u0082Å\u00054\thY$¯éæ°$\tÛTE«ÜZ{wU\n\t\u0086\u001fñ\u0097\u0017\u0016\u0017v\u001c";
      int var12 = "\u009f\u0018Ñ%Å9\u0082\u009e\r2%pl?3á©O\u000e\u0083ð\u00179\u0019òp¡ÍXT\u001f\u0014l,üµ¹\u0018cz<~°Ð_lÀ¨-Ü\u0004\u0084ñ4ª·\u0011î<\u001b\u0007æbê\u0096)\u0085\u0082Å\u00054\thY$¯éæ°$\tÛTE«ÜZ{wU\n\t\u0086\u001fñ\u0097\u0017\u0016\u0017v\u001c".length();
      char var9 = '\b';
      int var16 = -1;

      label64:
      while(true) {
         ++var16;
         String var10000 = var10.substring(var16, var16 + var9);
         int var10001 = -1;

         while(true) {
            char[] var30;
            label59: {
               char[] var19 = var10000.toCharArray();
               int var10003 = var19.length;
               int var14 = 0;
               var30 = var19;
               int var22 = var10003;
               char[] var38;
               int var10004;
               if (var10003 <= 1) {
                  var38 = var19;
                  var10004 = var14;
               } else {
                  var30 = var19;
                  var22 = var10003;
                  if (var10003 <= var14) {
                     break label59;
                  }

                  var38 = var19;
                  var10004 = var14;
               }

               while(true) {
                  char var10005 = var38[var10004];
                  byte var10006;
                  switch (var14 % 7) {
                     case 0 -> var10006 = 58;
                     case 1 -> var10006 = 92;
                     case 2 -> var10006 = 33;
                     case 3 -> var10006 = 67;
                     case 4 -> var10006 = 61;
                     case 5 -> var10006 = 123;
                     default -> var10006 = 2;
                  }

                  var38[var10004] = (char)(var10005 ^ var10006);
                  ++var14;
                  if (var22 == 0) {
                     var10004 = var22;
                     var38 = var30;
                  } else {
                     if (var22 <= var14) {
                        break;
                     }

                     var38 = var30;
                     var10004 = var14;
                  }
               }
            }

            String var45 = (new String(var30)).intern();
            switch (var10001) {
               case 0:
                  var13[var11++] = var45;
                  if ((var16 += var9) >= var12) {
                     a = var13;
                     b = new String[7];
                     long var0 = 3151420682089807611L;
                     long[] var6 = new long[3];
                     int var3 = 0;
                     String var4 = "yÏ\nAaÐª\u0007×Jq\u0001\u0016%úz\tÖtãX\u001cçë";
                     int var5 = "yÏ\nAaÐª\u0007×Jq\u0001\u0016%úz\tÖtãX\u001cçë".length();
                     int var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var47 = (((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L) ^ var0;
                        boolean var46 = true;
                        var6[var10001] = var47;
                     } while(var2 < var5);

                     c = var6;
                     d = new Integer[3];
                     return;
                  }

                  var9 = var10.charAt(var16);
                  break;
               default:
                  var13[var11++] = var45;
                  if ((var16 += var9) < var12) {
                     var9 = var10.charAt(var16);
                     continue label64;
                  }

                  var10 = "¸\u0000?Î\\ån¬<×.À\u0010\u008cè=\u000f\u007fó\u0007âÐààDÓ\u0094\r\u009e";
                  var12 = "¸\u0000?Î\\ån¬<×.À\u0010\u008cè=\u000f\u007fó\u0007âÐààDÓ\u0094\r\u009e".length();
                  var9 = '\f';
                  var16 = -1;
            }

            ++var16;
            var10000 = var10.substring(var16, var16 + var9);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 6264) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 5;
            case 1 -> var10000 = 181;
            case 2 -> var10000 = 102;
            case 3 -> var10000 = 153;
            case 4 -> var10000 = 158;
            case 5 -> var10000 = 193;
            case 6 -> var10000 = 255;
            case 7 -> var10000 = 22;
            case 8 -> var10000 = 242;
            case 9 -> var10000 = 89;
            case 10 -> var10000 = 178;
            case 11 -> var10000 = 207;
            case 12 -> var10000 = 119;
            case 13 -> var10000 = 45;
            case 14 -> var10000 = 231;
            case 15 -> var10000 = 164;
            case 16 -> var10000 = 74;
            case 17 -> var10000 = 23;
            case 18 -> var10000 = 28;
            case 19 -> var10000 = 57;
            case 20 -> var10000 = 33;
            case 21 -> var10000 = 219;
            case 22 -> var10000 = 238;
            case 23 -> var10000 = 19;
            case 24 -> var10000 = 80;
            case 25 -> var10000 = 185;
            case 26 -> var10000 = 156;
            case 27 -> var10000 = 223;
            case 28 -> var10000 = 150;
            case 29 -> var10000 = 47;
            case 30 -> var10000 = 138;
            case 31 -> var10000 = 221;
            case 32 -> var10000 = 184;
            case 33 -> var10000 = 67;
            case 34 -> var10000 = 202;
            case 35 -> var10000 = 56;
            case 36 -> var10000 = 139;
            case 37 -> var10000 = 225;
            case 38 -> var10000 = 94;
            case 39 -> var10000 = 106;
            case 40 -> var10000 = 142;
            case 41 -> var10000 = 21;
            case 42 -> var10000 = 27;
            case 43 -> var10000 = 253;
            case 44 -> var10000 = 144;
            case 45 -> var10000 = 65;
            case 46 -> var10000 = 222;
            case 47 -> var10000 = 128;
            case 48 -> var10000 = 244;
            case 49 -> var10000 = 41;
            case 50 -> var10000 = 96;
            case 51 -> var10000 = 152;
            case 52 -> var10000 = 36;
            case 53 -> var10000 = 232;
            case 54 -> var10000 = 116;
            case 55 -> var10000 = 215;
            case 56 -> var10000 = 226;
            case 57 -> var10000 = 168;
            case 58 -> var10000 = 160;
            case 59 -> var10000 = 206;
            case 60 -> var10000 = 111;
            case 61 -> var10000 = 176;
            case 62 -> var10000 = 236;
            case 63 -> var10000 = 120;
            case 64 -> var10000 = 75;
            case 65 -> var10000 = 133;
            case 66 -> var10000 = 86;
            case 67 -> var10000 = 2;
            case 68 -> var10000 = 141;
            case 69 -> var10000 = 126;
            case 70 -> var10000 = 230;
            case 71 -> var10000 = 26;
            case 72 -> var10000 = 76;
            case 73 -> var10000 = 180;
            case 74 -> var10000 = 78;
            case 75 -> var10000 = 61;
            case 76 -> var10000 = 145;
            case 77 -> var10000 = 44;
            case 78 -> var10000 = 229;
            case 79 -> var10000 = 205;
            case 80 -> var10000 = 130;
            case 81 -> var10000 = 87;
            case 82 -> var10000 = 157;
            case 83 -> var10000 = 115;
            case 84 -> var10000 = 143;
            case 85 -> var10000 = 166;
            case 86 -> var10000 = 29;
            case 87 -> var10000 = 48;
            case 88 -> var10000 = 14;
            case 89 -> var10000 = 59;
            case 90 -> var10000 = 162;
            case 91 -> var10000 = 195;
            case 92 -> var10000 = 161;
            case 93 -> var10000 = 104;
            case 94 -> var10000 = 38;
            case 95 -> var10000 = 55;
            case 96 -> var10000 = 123;
            case 97 -> var10000 = 84;
            case 98 -> var10000 = 43;
            case 99 -> var10000 = 49;
            case 100 -> var10000 = 39;
            case 101 -> var10000 = 7;
            case 102 -> var10000 = 146;
            case 103 -> var10000 = 70;
            case 104 -> var10000 = 159;
            case 105 -> var10000 = 155;
            case 106 -> var10000 = 177;
            case 107 -> var10000 = 198;
            case 108 -> var10000 = 1;
            case 109 -> var10000 = 175;
            case 110 -> var10000 = 209;
            case 111 -> var10000 = 11;
            case 112 -> var10000 = 190;
            case 113 -> var10000 = 228;
            case 114 -> var10000 = 98;
            case 115 -> var10000 = 10;
            case 116 -> var10000 = 110;
            case 117 -> var10000 = 112;
            case 118 -> var10000 = 122;
            case 119 -> var10000 = 52;
            case 120 -> var10000 = 58;
            case 121 -> var10000 = 101;
            case 122 -> var10000 = 66;
            case 123 -> var10000 = 97;
            case 124 -> var10000 = 182;
            case 125 -> var10000 = 50;
            case 126 -> var10000 = 217;
            case 127 -> var10000 = 240;
            case 128 -> var10000 = 163;
            case 129 -> var10000 = 220;
            case 130 -> var10000 = 0;
            case 131 -> var10000 = 81;
            case 132 -> var10000 = 15;
            case 133 -> var10000 = 127;
            case 134 -> var10000 = 8;
            case 135 -> var10000 = 108;
            case 136 -> var10000 = 171;
            case 137 -> var10000 = 199;
            case 138 -> var10000 = 82;
            case 139 -> var10000 = 224;
            case 140 -> var10000 = 208;
            case 141 -> var10000 = 92;
            case 142 -> var10000 = 68;
            case 143 -> var10000 = 247;
            case 144 -> var10000 = 4;
            case 145 -> var10000 = 83;
            case 146 -> var10000 = 197;
            case 147 -> var10000 = 72;
            case 148 -> var10000 = 154;
            case 149 -> var10000 = 216;
            case 150 -> var10000 = 63;
            case 151 -> var10000 = 51;
            case 152 -> var10000 = 237;
            case 153 -> var10000 = 188;
            case 154 -> var10000 = 100;
            case 155 -> var10000 = 31;
            case 156 -> var10000 = 93;
            case 157 -> var10000 = 17;
            case 158 -> var10000 = 170;
            case 159 -> var10000 = 85;
            case 160 -> var10000 = 203;
            case 161 -> var10000 = 245;
            case 162 -> var10000 = 136;
            case 163 -> var10000 = 233;
            case 164 -> var10000 = 246;
            case 165 -> var10000 = 213;
            case 166 -> var10000 = 105;
            case 167 -> var10000 = 32;
            case 168 -> var10000 = 6;
            case 169 -> var10000 = 227;
            case 170 -> var10000 = 252;
            case 171 -> var10000 = 95;
            case 172 -> var10000 = 187;
            case 173 -> var10000 = 131;
            case 174 -> var10000 = 71;
            case 175 -> var10000 = 118;
            case 176 -> var10000 = 117;
            case 177 -> var10000 = 3;
            case 178 -> var10000 = 194;
            case 179 -> var10000 = 77;
            case 180 -> var10000 = 179;
            case 181 -> var10000 = 46;
            case 182 -> var10000 = 53;
            case 183 -> var10000 = 69;
            case 184 -> var10000 = 234;
            case 185 -> var10000 = 134;
            case 186 -> var10000 = 88;
            case 187 -> var10000 = 91;
            case 188 -> var10000 = 148;
            case 189 -> var10000 = 103;
            case 190 -> var10000 = 124;
            case 191 -> var10000 = 243;
            case 192 -> var10000 = 42;
            case 193 -> var10000 = 40;
            case 194 -> var10000 = 191;
            case 195 -> var10000 = 37;
            case 196 -> var10000 = 73;
            case 197 -> var10000 = 172;
            case 198 -> var10000 = 174;
            case 199 -> var10000 = 12;
            case 200 -> var10000 = 173;
            case 201 -> var10000 = 239;
            case 202 -> var10000 = 99;
            case 203 -> var10000 = 34;
            case 204 -> var10000 = 149;
            case 205 -> var10000 = 250;
            case 206 -> var10000 = 79;
            case 207 -> var10000 = 167;
            case 208 -> var10000 = 9;
            case 209 -> var10000 = 137;
            case 210 -> var10000 = 214;
            case 211 -> var10000 = 186;
            case 212 -> var10000 = 212;
            case 213 -> var10000 = 147;
            case 214 -> var10000 = 211;
            case 215 -> var10000 = 218;
            case 216 -> var10000 = 192;
            case 217 -> var10000 = 129;
            case 218 -> var10000 = 16;
            case 219 -> var10000 = 235;
            case 220 -> var10000 = 30;
            case 221 -> var10000 = 135;
            case 222 -> var10000 = 169;
            case 223 -> var10000 = 251;
            case 224 -> var10000 = 254;
            case 225 -> var10000 = 200;
            case 226 -> var10000 = 64;
            case 227 -> var10000 = 132;
            case 228 -> var10000 = 62;
            case 229 -> var10000 = 35;
            case 230 -> var10000 = 18;
            case 231 -> var10000 = 183;
            case 232 -> var10000 = 125;
            case 233 -> var10000 = 189;
            case 234 -> var10000 = 60;
            case 235 -> var10000 = 248;
            case 236 -> var10000 = 196;
            case 237 -> var10000 = 165;
            case 238 -> var10000 = 54;
            case 239 -> var10000 = 114;
            case 240 -> var10000 = 140;
            case 241 -> var10000 = 241;
            case 242 -> var10000 = 151;
            case 243 -> var10000 = 113;
            case 244 -> var10000 = 109;
            case 245 -> var10000 = 201;
            case 246 -> var10000 = 121;
            case 247 -> var10000 = 249;
            case 248 -> var10000 = 210;
            case 249 -> var10000 = 25;
            case 250 -> var10000 = 107;
            case 251 -> var10000 = 90;
            case 252 -> var10000 = 13;
            case 253 -> var10000 = 24;
            case 254 -> var10000 = 204;
            default -> var10000 = 20;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 21353;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }
}
