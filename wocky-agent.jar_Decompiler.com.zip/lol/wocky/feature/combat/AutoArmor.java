package lol.wocky.feature.combat;

import java.util.Map;
import lol.wocky.core.MinecraftBridge;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleCategory;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;

public class AutoArmor extends Module {
   private static final int[] ARMOR_SCREEN_SLOTS;
   private static final int HOTBAR_SCREEN_START;
   private static final int[] ARMOR_INV_SLOTS;
   private static final String[] SUFFIX;
   private final NumberProperty delay = new NumberProperty(a(18015, -11058), 2, 0, a(15457, 2900596176489244176L), 1);
   private final BooleanProperty blastPriority = new BooleanProperty(a(17985, -23079), false);
   private final BooleanProperty keepElytra = new BooleanProperty(a(18006, 10071), true);
   private final BooleanProperty inventoryOnly = new BooleanProperty(a(17991, 31967), false);
   private int clock;
   private int[] plan;
   private int step;
   private boolean closeAfter;
   private static final String[] a;
   private static final String[] b;
   private static final long[] c;
   private static final Integer[] d;

   public AutoArmor() {
      super(a(18009, 12761), a(17995, -3579), ModuleCategory.COMBAT);
      this.addProperties(new Property[]{this.delay, this.blastPriority, this.keepElytra, this.inventoryOnly});
   }

   public void onTick() {
      if (this.clock > 0) {
         --this.clock;
      } else {
         boolean var1 = MinecraftBridge.isInventoryScreenOpen();
         boolean var2 = (Boolean)this.inventoryOnly.getValue() ? var1 : MinecraftBridge.getCurrentScreen() == null || var1;
         if (this.plan != null) {
            this.continueSwap(var2, var1, false);
         } else if (var2) {
            if (MinecraftBridge.isCursorEmpty()) {
               for(int var3 = 0; var3 < 4; ++var3) {
                  Object var4 = MinecraftBridge.getStackInSlot(ARMOR_INV_SLOTS[var3]);
                  String var5 = MinecraftBridge.itemId(var4);
                  if ((var5.isEmpty() || !MinecraftBridge.getEnchantments(var4).containsKey(a(18008, -22769))) && (var3 != 1 || !(Boolean)this.keepElytra.getValue() || !var5.equals(a(17992, 3663)))) {
                     double var6 = var5.isEmpty() ? (double)0.0F : this.score(var4, var3);
                     int var8 = -1;

                     for(int var9 = 0; var9 < a(28640, 4553376835711841693L); ++var9) {
                        Object var10 = MinecraftBridge.getStackInSlot(var9);
                        if (fits(MinecraftBridge.itemId(var10), var3)) {
                           double var11 = this.score(var10, var3);
                           if (var11 > var6) {
                              var6 = var11;
                              var8 = var9;
                           }
                        }
                     }

                     if (var8 != -1) {
                        int var13 = var8 < a(5400, 7969233260856266593L) ? a(28640, 4553376835711841693L) + var8 : var8;
                        int var14 = ARMOR_SCREEN_SLOTS[var3];
                        this.plan = var5.isEmpty() ? new int[]{var13, var14} : new int[]{var13, var14, var13};
                        this.step = 0;
                        this.closeAfter = !var1;
                        this.continueSwap(true, var1, false);
                        return;
                     }
                  }
               }

            }
         }
      }
   }

   private void continueSwap(boolean var1, boolean var2, boolean var3) {
      if (!var1) {
         this.plan = null;
      } else {
         if (var2) {
            this.closeAfter = false;
         }

         if (var3) {
            MinecraftBridge.clickSlotNow(0, this.plan[this.step], 0, false);
         } else if (!MinecraftBridge.clickSlot(0, this.plan[this.step], 0, false)) {
            return;
         }

         ++this.step;
         this.clock = this.delay.intValue();
         if (this.step >= this.plan.length) {
            this.plan = null;
            if (this.closeAfter && MinecraftBridge.getCurrentScreen() == null) {
               MinecraftBridge.sendCloseInventory();
            }

         }
      }
   }

   private static boolean fits(String var0, int var1) {
      if (var0.isEmpty()) {
         return false;
      } else {
         return var0.endsWith(SUFFIX[var1]) || var1 == 0 && var0.equals(a(18000, 4202));
      }
   }

   private double score(Object var1, int var2) {
      String var3 = MinecraftBridge.itemId(var1);
      if (var3.equals(a(18011, -7499))) {
         return (double)1.0F;
      } else {
         double var4 = (double)(tier(var3) * a(29514, 8019207898277718334L));
         Map var6 = MinecraftBridge.getEnchantments(var1);
         var4 += (double)(Integer)var6.getOrDefault(a(17994, -24599), 0) * (double)2.0F;
         var4 += (double)(Integer)var6.getOrDefault(a(18004, 26260), 0) * ((Boolean)this.blastPriority.getValue() ? (double)3.0F : (double)1.0F);
         var4 += (double)(Integer)var6.getOrDefault(a(17984, 11885), 0) * (double)0.5F + (double)(Integer)var6.getOrDefault(a(18002, -30535), 0) * (double)0.5F;
         var4 += (double)(Integer)var6.getOrDefault(a(17988, -8466), 0) * 0.1 + (double)(Integer)var6.getOrDefault(a(18013, -10766), 0) * 0.1;
         int var7 = MinecraftBridge.getMaxDamage(var1);
         if (var7 > 0 && (double)MinecraftBridge.getDamage(var1) >= (double)var7 * 0.95) {
            var4 -= (double)25.0F;
         }

         return var4;
      }
   }

   private static int tier(String var0) {
      if (var0.startsWith(a(18001, 28898))) {
         return a(32055, 4433634940629133135L);
      } else if (var0.startsWith(a(18014, 10770))) {
         return a(15294, 5173319729318420937L);
      } else if (var0.startsWith(a(18005, 16996))) {
         return 5;
      } else if (var0.startsWith(a(17987, 1402))) {
         return 4;
      } else if (var0.startsWith(a(17990, -20907))) {
         return 3;
      } else if (var0.startsWith(a(18010, -31337))) {
         return 2;
      } else {
         return var0.startsWith(a(18007, -20333)) ? 3 : 1;
      }
   }

   public void onDisable() {
      while(this.plan != null && MinecraftBridge.isInGame()) {
         this.continueSwap(true, MinecraftBridge.isInventoryScreenOpen(), true);
      }

      this.plan = null;
      this.clock = 0;
   }

   static {
      String[] var13 = new String[27];
      int var11 = 0;
      String var10 = "s©ä\u008dÍ\u009f\u008cÝæ\u0001\u008c/=|§\u0089öb\u000e³c\u0007¡û~\u0098Ýý\u0087\r³ÁeyJÚ\u007f²ßÄ±ªè\n\u0011¡n{ä\u0012´BVv\u000b%Rx\u001dPòÊ\u0082-ïÐ\u0007=ÅC¤Åò¦\u0010=\fsýá\u0097>|7\\ï¤*z\u0098\u0084\u0007Ü2\u0088\u0007÷\u0015È\u0007=.ÛÍIU7\u0006ß\u008aÐ*\u0088´\r\u0007\u00ad;{\u001b\u0083ÈÄ\u0010Â\u0091F\u0001\t\rè'Gér±Ue\b\u009e¢Á\u0093¬¶ûb\u0005 \u000e?\u0087É\u0006{`/£¥ï\u0007±\u0093\u00031\u001cÊ(\u000bËÍ>=gp\tÐß\u0014=\u0005\u001a½ó\u000b\u0015\u000frµ\rytüÀÆ±¤A\u009f$îæ\u000e\u009a\u0089£Mûþ]Áyð÷CÜÝ\n\tÒÔ¸\u000fT«kµí\u000e[\u0090æ:¼\u0090ÓÒ`ÝûGßº\n\u001c~¡ðÉ)\u0013Ië\u0091\t\u001a\u0010\tj9ÅJÓx\n\u0083Âúþ\u000e,ô«êÄ";
      int var12 = "s©ä\u008dÍ\u009f\u008cÝæ\u0001\u008c/=|§\u0089öb\u000e³c\u0007¡û~\u0098Ýý\u0087\r³ÁeyJÚ\u007f²ßÄ±ªè\n\u0011¡n{ä\u0012´BVv\u000b%Rx\u001dPòÊ\u0082-ïÐ\u0007=ÅC¤Åò¦\u0010=\fsýá\u0097>|7\\ï¤*z\u0098\u0084\u0007Ü2\u0088\u0007÷\u0015È\u0007=.ÛÍIU7\u0006ß\u008aÐ*\u0088´\r\u0007\u00ad;{\u001b\u0083ÈÄ\u0010Â\u0091F\u0001\t\rè'Gér±Ue\b\u009e¢Á\u0093¬¶ûb\u0005 \u000e?\u0087É\u0006{`/£¥ï\u0007±\u0093\u00031\u001cÊ(\u000bËÍ>=gp\tÐß\u0014=\u0005\u001a½ó\u000b\u0015\u000frµ\rytüÀÆ±¤A\u009f$îæ\u000e\u009a\u0089£Mûþ]Áyð÷CÜÝ\n\tÒÔ¸\u000fT«kµí\u000e[\u0090æ:¼\u0090ÓÒ`ÝûGßº\n\u001c~¡ðÉ)\u0013Ië\u0091\t\u001a\u0010\tj9ÅJÓx\n\u0083Âúþ\u000e,ô«êÄ".length();
      char var9 = 21;
      int var17 = -1;

      label73:
      while(true) {
         ++var17;
         String var10000 = var10.substring(var17, var17 + var9);
         int var10001 = -1;

         while(true) {
            char[] var33;
            label68: {
               char[] var21 = var10000.toCharArray();
               int var10003 = var21.length;
               int var14 = 0;
               var33 = var21;
               int var24 = var10003;
               char[] var43;
               int var10004;
               if (var10003 <= 1) {
                  var43 = var21;
                  var10004 = var14;
               } else {
                  var33 = var21;
                  var24 = var10003;
                  if (var10003 <= var14) {
                     break label68;
                  }

                  var43 = var21;
                  var10004 = var14;
               }

               while(true) {
                  char var10005 = var43[var10004];
                  byte var10006;
                  switch (var14 % 7) {
                     case 0 -> var10006 = 44;
                     case 1 -> var10006 = 37;
                     case 2 -> var10006 = 30;
                     case 3 -> var10006 = 74;
                     case 4 -> var10006 = 117;
                     case 5 -> var10006 = 35;
                     default -> var10006 = 38;
                  }

                  var43[var10004] = (char)(var10005 ^ var10006);
                  ++var14;
                  if (var24 == 0) {
                     var10004 = var24;
                     var43 = var33;
                  } else {
                     if (var24 <= var14) {
                        break;
                     }

                     var43 = var33;
                     var10004 = var14;
                  }
               }
            }

            String var50 = (new String(var33)).intern();
            switch (var10001) {
               case 0:
                  var13[var11++] = var50;
                  if ((var17 += var9) >= var12) {
                     a = var13;
                     b = new String[27];
                     long var0 = 4664245162926982745L;
                     long[] var6 = new long[14];
                     int var3 = 0;
                     String var4 = "Võ\u0001\u0088»å\u0095\u0000¢\u0016\r\u0016±ç ]WZ\u009a|\u0089\t\u0086O\bY\u0088\u0004h?\u0084\u000bÄû+SýAomøÎ]Þ\u0000\u0007\u0089°'\u0013\u007f\u0086\bâÕ^\u0012LÑ±\u0016\u0013§\u0096KX\u0018q\u0082ma\u0011\"õÛ\u008dü\b\t1×=7ç}ª\u0086\u0091\tôi\u0082\u0092L[\u000f";
                     int var5 = "Võ\u0001\u0088»å\u0095\u0000¢\u0016\r\u0016±ç ]WZ\u009a|\u0089\t\u0086O\bY\u0088\u0004h?\u0084\u000bÄû+SýAomøÎ]Þ\u0000\u0007\u0089°'\u0013\u007f\u0086\bâÕ^\u0012LÑ±\u0016\u0013§\u0096KX\u0018q\u0082ma\u0011\"õÛ\u008dü\b\t1×=7ç}ª\u0086\u0091\tôi\u0082\u0092L[\u000f".length();
                     int var2 = 0;

                     label44:
                     while(true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var19 = var6;
                        var10001 = var3++;
                        long var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                        byte var51 = -1;

                        while(true) {
                           long var54 = var38 ^ var0;
                           switch (var51) {
                              case 0:
                                 var19[var10001] = var54;
                                 if (var2 >= var5) {
                                    c = var6;
                                    d = new Integer[14];
                                    HOTBAR_SCREEN_START = a(14798, 6336780736955081650L);
                                    ARMOR_SCREEN_SLOTS = new int[]{5, a(5530, 6566828014772899823L), a(2350, 5595833406395863902L), a(18809, 8445702209189581583L)};
                                    ARMOR_INV_SLOTS = new int[]{a(6723, 8566537070335574065L), a(18187, 2013644237426695536L), a(6807, 2036034718661755117L), a(6149, 565976935132775030L)};
                                    SUFFIX = new String[]{a(18003, 15191), a(17986, -23086), a(17989, 29828), a(18012, 14618)};
                                    return;
                                 }
                                 break;
                              default:
                                 var19[var10001] = var54;
                                 if (var2 < var5) {
                                    continue label44;
                                 }

                                 var4 = "ÝÿÒ\u0017Ü&%Ï»\u0000\u008b\t\u0004\u0080sà";
                                 var5 = "ÝÿÒ\u0017Ü&%Ï»\u0000\u008b\t\u0004\u0080sà".length();
                                 var2 = 0;
                           }

                           var10001 = var2;
                           var2 += 8;
                           var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                           var19 = var6;
                           var10001 = var3++;
                           var38 = ((long)var7[0] & 255L) << 56 | ((long)var7[1] & 255L) << 48 | ((long)var7[2] & 255L) << 40 | ((long)var7[3] & 255L) << 32 | ((long)var7[4] & 255L) << 24 | ((long)var7[5] & 255L) << 16 | ((long)var7[6] & 255L) << 8 | (long)var7[7] & 255L;
                           var51 = 0;
                        }
                     }
                  }

                  var9 = var10.charAt(var17);
                  break;
               default:
                  var13[var11++] = var50;
                  if ((var17 += var9) < var12) {
                     var9 = var10.charAt(var17);
                     continue label73;
                  }

                  var10 = "à\"\u001f\u009cþÎ\tø\u008c\u001b:~l\u001ax\u009f\u000fKwPÔà!Ñ\u000fÝ)\u008a&\u0093¯g\u0016Ìx\u00178Ä%¦5\u0006\t¶\n\u00adÓD";
                  var12 = "à\"\u001f\u009cþÎ\tø\u008c\u001b:~l\u001ax\u009f\u000fKwPÔà!Ñ\u000fÝ)\u008a&\u0093¯g\u0016Ìx\u00178Ä%¦5\u0006\t¶\n\u00adÓD".length();
                  var9 = ')';
                  var17 = -1;
            }

            ++var17;
            var10000 = var10.substring(var17, var17 + var9);
            var10001 = 0;
         }
      }
   }

   private static String a(int var0, int var1) {
      int var2 = (var0 ^ 18002) & '\uffff';
      if (b[var2] == null) {
         char[] var3 = a[var2].toCharArray();
         short var10000;
         switch (var3[0] & 255) {
            case 0 -> var10000 = 186;
            case 1 -> var10000 = 185;
            case 2 -> var10000 = 28;
            case 3 -> var10000 = 52;
            case 4 -> var10000 = 3;
            case 5 -> var10000 = 203;
            case 6 -> var10000 = 132;
            case 7 -> var10000 = 243;
            case 8 -> var10000 = 184;
            case 9 -> var10000 = 21;
            case 10 -> var10000 = 177;
            case 11 -> var10000 = 83;
            case 12 -> var10000 = 134;
            case 13 -> var10000 = 79;
            case 14 -> var10000 = 136;
            case 15 -> var10000 = 61;
            case 16 -> var10000 = 158;
            case 17 -> var10000 = 33;
            case 18 -> var10000 = 219;
            case 19 -> var10000 = 236;
            case 20 -> var10000 = 164;
            case 21 -> var10000 = 107;
            case 22 -> var10000 = 223;
            case 23 -> var10000 = 252;
            case 24 -> var10000 = 20;
            case 25 -> var10000 = 78;
            case 26 -> var10000 = 32;
            case 27 -> var10000 = 91;
            case 28 -> var10000 = 39;
            case 29 -> var10000 = 189;
            case 30 -> var10000 = 102;
            case 31 -> var10000 = 221;
            case 32 -> var10000 = 238;
            case 33 -> var10000 = 121;
            case 34 -> var10000 = 37;
            case 35 -> var10000 = 97;
            case 36 -> var10000 = 204;
            case 37 -> var10000 = 15;
            case 38 -> var10000 = 151;
            case 39 -> var10000 = 235;
            case 40 -> var10000 = 50;
            case 41 -> var10000 = 206;
            case 42 -> var10000 = 112;
            case 43 -> var10000 = 198;
            case 44 -> var10000 = 172;
            case 45 -> var10000 = 188;
            case 46 -> var10000 = 241;
            case 47 -> var10000 = 167;
            case 48 -> var10000 = 169;
            case 49 -> var10000 = 41;
            case 50 -> var10000 = 249;
            case 51 -> var10000 = 225;
            case 52 -> var10000 = 90;
            case 53 -> var10000 = 210;
            case 54 -> var10000 = 27;
            case 55 -> var10000 = 84;
            case 56 -> var10000 = 140;
            case 57 -> var10000 = 182;
            case 58 -> var10000 = 66;
            case 59 -> var10000 = 228;
            case 60 -> var10000 = 14;
            case 61 -> var10000 = 143;
            case 62 -> var10000 = 62;
            case 63 -> var10000 = 16;
            case 64 -> var10000 = 71;
            case 65 -> var10000 = 181;
            case 66 -> var10000 = 116;
            case 67 -> var10000 = 211;
            case 68 -> var10000 = 157;
            case 69 -> var10000 = 72;
            case 70 -> var10000 = 218;
            case 71 -> var10000 = 233;
            case 72 -> var10000 = 101;
            case 73 -> var10000 = 100;
            case 74 -> var10000 = 199;
            case 75 -> var10000 = 205;
            case 76 -> var10000 = 200;
            case 77 -> var10000 = 244;
            case 78 -> var10000 = 232;
            case 79 -> var10000 = 128;
            case 80 -> var10000 = 130;
            case 81 -> var10000 = 59;
            case 82 -> var10000 = 75;
            case 83 -> var10000 = 29;
            case 84 -> var10000 = 170;
            case 85 -> var10000 = 227;
            case 86 -> var10000 = 103;
            case 87 -> var10000 = 18;
            case 88 -> var10000 = 12;
            case 89 -> var10000 = 160;
            case 90 -> var10000 = 208;
            case 91 -> var10000 = 253;
            case 92 -> var10000 = 44;
            case 93 -> var10000 = 115;
            case 94 -> var10000 = 53;
            case 95 -> var10000 = 138;
            case 96 -> var10000 = 156;
            case 97 -> var10000 = 119;
            case 98 -> var10000 = 0;
            case 99 -> var10000 = 117;
            case 100 -> var10000 = 165;
            case 101 -> var10000 = 163;
            case 102 -> var10000 = 73;
            case 103 -> var10000 = 212;
            case 104 -> var10000 = 19;
            case 105 -> var10000 = 6;
            case 106 -> var10000 = 99;
            case 107 -> var10000 = 77;
            case 108 -> var10000 = 149;
            case 109 -> var10000 = 76;
            case 110 -> var10000 = 247;
            case 111 -> var10000 = 49;
            case 112 -> var10000 = 139;
            case 113 -> var10000 = 68;
            case 114 -> var10000 = 178;
            case 115 -> var10000 = 173;
            case 116 -> var10000 = 106;
            case 117 -> var10000 = 231;
            case 118 -> var10000 = 67;
            case 119 -> var10000 = 161;
            case 120 -> var10000 = 118;
            case 121 -> var10000 = 40;
            case 122 -> var10000 = 197;
            case 123 -> var10000 = 120;
            case 124 -> var10000 = 242;
            case 125 -> var10000 = 89;
            case 126 -> var10000 = 30;
            case 127 -> var10000 = 25;
            case 128 -> var10000 = 7;
            case 129 -> var10000 = 251;
            case 130 -> var10000 = 9;
            case 131 -> var10000 = 54;
            case 132 -> var10000 = 154;
            case 133 -> var10000 = 95;
            case 134 -> var10000 = 234;
            case 135 -> var10000 = 4;
            case 136 -> var10000 = 22;
            case 137 -> var10000 = 193;
            case 138 -> var10000 = 147;
            case 139 -> var10000 = 166;
            case 140 -> var10000 = 190;
            case 141 -> var10000 = 133;
            case 142 -> var10000 = 96;
            case 143 -> var10000 = 51;
            case 144 -> var10000 = 123;
            case 145 -> var10000 = 196;
            case 146 -> var10000 = 65;
            case 147 -> var10000 = 24;
            case 148 -> var10000 = 92;
            case 149 -> var10000 = 109;
            case 150 -> var10000 = 250;
            case 151 -> var10000 = 246;
            case 152 -> var10000 = 175;
            case 153 -> var10000 = 105;
            case 154 -> var10000 = 86;
            case 155 -> var10000 = 174;
            case 156 -> var10000 = 213;
            case 157 -> var10000 = 2;
            case 158 -> var10000 = 104;
            case 159 -> var10000 = 127;
            case 160 -> var10000 = 216;
            case 161 -> var10000 = 98;
            case 162 -> var10000 = 17;
            case 163 -> var10000 = 137;
            case 164 -> var10000 = 36;
            case 165 -> var10000 = 114;
            case 166 -> var10000 = 108;
            case 167 -> var10000 = 34;
            case 168 -> var10000 = 45;
            case 169 -> var10000 = 215;
            case 170 -> var10000 = 46;
            case 171 -> var10000 = 245;
            case 172 -> var10000 = 254;
            case 173 -> var10000 = 5;
            case 174 -> var10000 = 230;
            case 175 -> var10000 = 10;
            case 176 -> var10000 = 239;
            case 177 -> var10000 = 207;
            case 178 -> var10000 = 60;
            case 179 -> var10000 = 129;
            case 180 -> var10000 = 55;
            case 181 -> var10000 = 122;
            case 182 -> var10000 = 229;
            case 183 -> var10000 = 43;
            case 184 -> var10000 = 180;
            case 185 -> var10000 = 23;
            case 186 -> var10000 = 153;
            case 187 -> var10000 = 195;
            case 188 -> var10000 = 63;
            case 189 -> var10000 = 131;
            case 190 -> var10000 = 171;
            case 191 -> var10000 = 146;
            case 192 -> var10000 = 1;
            case 193 -> var10000 = 237;
            case 194 -> var10000 = 226;
            case 195 -> var10000 = 155;
            case 196 -> var10000 = 179;
            case 197 -> var10000 = 176;
            case 198 -> var10000 = 142;
            case 199 -> var10000 = 58;
            case 200 -> var10000 = 48;
            case 201 -> var10000 = 148;
            case 202 -> var10000 = 168;
            case 203 -> var10000 = 187;
            case 204 -> var10000 = 124;
            case 205 -> var10000 = 255;
            case 206 -> var10000 = 42;
            case 207 -> var10000 = 64;
            case 208 -> var10000 = 202;
            case 209 -> var10000 = 35;
            case 210 -> var10000 = 110;
            case 211 -> var10000 = 159;
            case 212 -> var10000 = 88;
            case 213 -> var10000 = 85;
            case 214 -> var10000 = 135;
            case 215 -> var10000 = 94;
            case 216 -> var10000 = 141;
            case 217 -> var10000 = 38;
            case 218 -> var10000 = 111;
            case 219 -> var10000 = 87;
            case 220 -> var10000 = 217;
            case 221 -> var10000 = 144;
            case 222 -> var10000 = 8;
            case 223 -> var10000 = 82;
            case 224 -> var10000 = 93;
            case 225 -> var10000 = 70;
            case 226 -> var10000 = 191;
            case 227 -> var10000 = 201;
            case 228 -> var10000 = 47;
            case 229 -> var10000 = 220;
            case 230 -> var10000 = 56;
            case 231 -> var10000 = 26;
            case 232 -> var10000 = 57;
            case 233 -> var10000 = 13;
            case 234 -> var10000 = 74;
            case 235 -> var10000 = 126;
            case 236 -> var10000 = 194;
            case 237 -> var10000 = 240;
            case 238 -> var10000 = 152;
            case 239 -> var10000 = 113;
            case 240 -> var10000 = 224;
            case 241 -> var10000 = 192;
            case 242 -> var10000 = 222;
            case 243 -> var10000 = 31;
            case 244 -> var10000 = 80;
            case 245 -> var10000 = 145;
            case 246 -> var10000 = 69;
            case 247 -> var10000 = 248;
            case 248 -> var10000 = 150;
            case 249 -> var10000 = 81;
            case 250 -> var10000 = 162;
            case 251 -> var10000 = 209;
            case 252 -> var10000 = 183;
            case 253 -> var10000 = 11;
            case 254 -> var10000 = 125;
            default -> var10000 = 214;
         }

         short var4 = var10000;
         int var5 = (var1 & 255) - var4;
         if (var5 < 0) {
            var5 += 256;
         }

         int var6 = ((var1 & '\uffff') >>> 8) - var4;
         if (var6 < 0) {
            var6 += 256;
         }

         for(int var7 = 0; var7 < var3.length; ++var7) {
            int var8 = var7 % 2;
            char var10002 = var3[var7];
            if (var8 == 0) {
               var3[var7] = (char)(var10002 ^ var5);
               var5 = ((var5 >>> 3 | var5 << 5) ^ var3[var7]) & 255;
            } else {
               var3[var7] = (char)(var10002 ^ var6);
               var6 = ((var6 >>> 3 | var6 << 5) ^ var3[var7]) & 255;
            }
         }

         b[var2] = (new String(var3)).intern();
      }

      return b[var2];
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 23152;
      if (d[var3] == null) {
         d[var3] = (int)(c[var3] ^ var1);
      }

      return d[var3];
   }
}
