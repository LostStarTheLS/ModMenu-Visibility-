package lol.wocky.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.File;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import lol.wocky.core.module.ModuleManager;

public final class ConfigProfiles {
   public static final int MAX_NAME = 32;
   public static final int MAX_TAGS = 6;
   public static final int MAX_TAG = 14;
   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();

   private ConfigProfiles() {
   }

   private static File dir() {
      return new File(ModuleManager.configDir(), "configs");
   }

   private static File file(String id) {
      return new File(dir(), id + ".json");
   }

   private static File activeFile() {
      return new File(dir(), ".active");
   }

   static String list() {
      JsonArray out = new JsonArray();
      String active = readActive();
      JsonElement live = null;
      List<JsonObject> all = readAll();
      all.sort((a, b) -> Long.compare(num(b, "updated"), num(a, "updated")));

      for(JsonObject c : all) {
         JsonObject o = new JsonObject();
         String id = str(c, "id");

         for(String k : new String[]{"id", "name", "created", "updated"}) {
            if (c.has(k)) {
               o.add(k, c.get(k));
            }
         }

         o.add("tags", (JsonElement)(c.has("tags") ? c.get("tags") : new JsonArray()));
         if (c.has("server")) {
            o.add("server", c.get("server"));
         }

         o.addProperty("modules", (Number)countEnabled(c.getAsJsonObject("modules")));
         boolean isActive = id.equals(active);
         o.addProperty("active", isActive);
         if (isActive) {
            if (live == null) {
               live = normalize(ModuleManager.snapshot());
            }

            o.addProperty("modified", !normalize(c.getAsJsonObject("modules")).equals(live));
         }

         out.add((JsonElement)o);
      }

      return out.toString();
   }

   static String save(String id, String name, List<String> tags) {
      JsonObject c = id != null ? read(id) : null;
      if (id != null && c == null) {
         return "ERR:NOT_FOUND";
      } else {
         long now = System.currentTimeMillis();
         if (c == null) {
            String clean = cleanName(name);
            if (clean.isEmpty()) {
               return "ERR:NAME";
            }

            if (nameTaken(clean, (String)null)) {
               return "ERR:NAME_TAKEN";
            }

            c = new JsonObject();
            id = newId(clean);
            c.addProperty("id", id);
            c.addProperty("name", clean);
            c.add("tags", tagArray(tags));
            c.addProperty("created", (Number)now);
         }

         if (!c.has("server") || c.get("server").isJsonNull()) {
            JsonObject server = currentServer();
            if (server != null) {
               c.add("server", server);
            }
         }

         c.addProperty("updated", (Number)now);
         c.add("modules", ModuleManager.snapshot());
         if (!write(id, c)) {
            return "ERR:WRITE";
         } else {
            writeActive(id);
            return id;
         }
      }
   }

   static String load(String id) {
      JsonObject c = read(id);
      if (c != null) {
         JsonElement var3 = c.get("modules");
         if (var3 instanceof JsonObject) {
            JsonObject modules = (JsonObject)var3;
            ModuleManager.apply(modules, true);
            ModuleManager.saveConfig();
            writeActive(id);
            return "OK";
         }
      }

      return "ERR:NOT_FOUND";
   }

   static String edit(String id, String name, List<String> tags) {
      JsonObject c = read(id);
      if (c == null) {
         return "ERR:NOT_FOUND";
      } else {
         if (name != null) {
            String clean = cleanName(name);
            if (clean.isEmpty()) {
               return "ERR:NAME";
            }

            if (nameTaken(clean, id)) {
               return "ERR:NAME_TAKEN";
            }

            c.addProperty("name", clean);
         }

         if (tags != null) {
            c.add("tags", tagArray(tags));
         }

         return write(id, c) ? "OK" : "ERR:WRITE";
      }
   }

   static String duplicate(String id) {
      JsonObject c = read(id);
      if (c == null) {
         return "ERR:NOT_FOUND";
      } else {
         String base = str(c, "name");
         String name = base;

         for(int n = 2; nameTaken(name, (String)null); ++n) {
            String suffix = " " + n;
            String var10000 = base.length() + suffix.length() > 32 ? base.substring(0, 32 - suffix.length()) : base;
            name = var10000 + suffix;
         }

         JsonObject copy = c.deepCopy();
         String newId = newId(name);
         long now = System.currentTimeMillis();
         copy.addProperty("id", newId);
         copy.addProperty("name", name);
         copy.addProperty("created", (Number)now);
         copy.addProperty("updated", (Number)now);
         return write(newId, copy) ? newId : "ERR:WRITE";
      }
   }

   static String delete(String id) {
      File f = file(id);
      if (f.exists() && f.delete()) {
         if (id.equals(readActive())) {
            activeFile().delete();
         }

         return "OK";
      } else {
         return "ERR:NOT_FOUND";
      }
   }

   private static JsonObject currentServer() {
      if (!MinecraftBridge.isInGame()) {
         return null;
      } else {
         JsonObject s = new JsonObject();
         if (MinecraftBridge.isSingleplayer()) {
            s.addProperty("singleplayer", true);
            return s;
         } else {
            String address = MinecraftBridge.getServerAddress();
            if (address.isEmpty()) {
               return null;
            } else {
               s.addProperty("address", address);
               s.addProperty("name", MinecraftBridge.getServerName());
               byte[] icon = MinecraftBridge.getServerFavicon();
               if (icon != null && icon.length > 0) {
                  s.addProperty("icon", Base64.getEncoder().encodeToString(icon));
               }

               return s;
            }
         }
      }
   }

   private static String cleanName(String name) {
      String n = name == null ? "" : name.replaceAll("[\\p{Cntrl}|]", "").trim();
      return n.length() > 32 ? n.substring(0, 32).trim() : n;
   }

   static JsonArray tagArray(List<String> tags) {
      Set<String> clean = new LinkedHashSet();
      if (tags != null) {
         for(String t : tags) {
            String tag = t == null ? "" : t.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9+\\-]", "");
            if (tag.length() > 14) {
               tag = tag.substring(0, 14);
            }

            if (!tag.isEmpty() && clean.size() < 6) {
               clean.add(tag);
            }
         }
      }

      JsonArray a = new JsonArray();
      Objects.requireNonNull(a);
      clean.forEach(a::add);
      return a;
   }

   private static boolean nameTaken(String name, String exceptId) {
      for(JsonObject c : readAll()) {
         if (str(c, "name").equalsIgnoreCase(name) && !str(c, "id").equals(exceptId)) {
            return true;
         }
      }

      return false;
   }

   private static String newId(String name) {
      String slug = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-").replaceAll("(^-|-$)", "");
      if (slug.length() > 20) {
         slug = slug.substring(0, 20);
      }

      String suffix = UUID.randomUUID().toString().substring(0, 6);
      return slug.isEmpty() ? suffix : slug + "-" + suffix;
   }

   private static int countEnabled(JsonObject modules) {
      int n = 0;
      if (modules == null) {
         return 0;
      } else {
         for(Map.Entry<String, JsonElement> e : modules.entrySet()) {
            Object var5 = e.getValue();
            if (var5 instanceof JsonObject) {
               JsonObject m = (JsonObject)var5;
               if (m.has("enabled") && m.get("enabled").getAsBoolean()) {
                  ++n;
               }
            }
         }

         return n;
      }
   }

   private static JsonElement normalize(JsonObject o) {
      if (o == null) {
         return new JsonObject();
      } else {
         JsonObject copy = JsonParser.parseString(o.toString()).getAsJsonObject();
         ModuleManager.migrateNames(copy);
         return copy;
      }
   }

   private static List<JsonObject> readAll() {
      List<JsonObject> out = new ArrayList();
      File[] files = dir().listFiles((d, n) -> n.endsWith(".json"));
      if (files == null) {
         return out;
      } else {
         for(File f : files) {
            JsonObject c = read(f.getName().substring(0, f.getName().length() - 5));
            if (c != null) {
               out.add(c);
            }
         }

         return out;
      }
   }

   private static JsonObject read(String id) {
      if (id != null && id.matches("[a-z0-9\\-]+")) {
         File f = file(id);
         if (!f.exists()) {
            return null;
         } else {
            try {
               JsonObject c = JsonParser.parseString(Files.readString(f.toPath(), StandardCharsets.UTF_8)).getAsJsonObject();
               c.addProperty("id", id);
               return c;
            } catch (Throwable t) {
               PrintStream var10000 = System.err;
               String var10001 = String.valueOf(f);
               var10000.println("[Wocky] Unreadable config " + var10001 + ": " + String.valueOf(t));
               return null;
            }
         }
      } else {
         return null;
      }
   }

   private static boolean write(String id, JsonObject c) {
      try {
         dir().mkdirs();
         File tmp = new File(dir(), id + ".json.tmp");
         Files.writeString(tmp.toPath(), GSON.toJson((JsonElement)c), StandardCharsets.UTF_8);
         Files.move(tmp.toPath(), file(id).toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
         return true;
      } catch (Throwable t) {
         System.err.println("[Wocky] Failed to save config " + id + ": " + String.valueOf(t));
         return false;
      }
   }

   private static String readActive() {
      try {
         return activeFile().exists() ? Files.readString(activeFile().toPath()).trim() : "";
      } catch (Throwable var1) {
         return "";
      }
   }

   private static void writeActive(String id) {
      try {
         dir().mkdirs();
         Files.writeString(activeFile().toPath(), id);
      } catch (Throwable var2) {
      }

   }

   private static String str(JsonObject o, String k) {
      JsonElement e = o.get(k);
      return e != null && e.isJsonPrimitive() ? e.getAsString() : "";
   }

   private static long num(JsonObject o, String k) {
      JsonElement e = o.get(k);
      return e != null && e.isJsonPrimitive() ? e.getAsLong() : 0L;
   }
}
