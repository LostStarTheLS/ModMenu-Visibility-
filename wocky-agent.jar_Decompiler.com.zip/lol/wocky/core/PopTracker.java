package lol.wocky.core;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PopTracker {
   private static final byte TOTEM_POP = 35;
   private static final byte DEATH = 3;
   private static final Map<UUID, Integer> pops = new ConcurrentHashMap();

   private PopTracker() {
   }

   static void onEntityStatus(Object packet) {
      int status = MinecraftBridge.entityStatus(packet);
      if (status == 35 || status == 3) {
         Object entity = MinecraftBridge.entityStatusEntity(packet);
         if (MinecraftBridge.isPlayer(entity)) {
            UUID id = MinecraftBridge.getUuid(entity);
            if (id != null) {
               if (status == 35) {
                  pops.merge(id, 1, Integer::sum);
               } else {
                  pops.remove(id);
               }

            }
         }
      }
   }

   static void tick() {
      if (!pops.isEmpty()) {
         for(Object p : MinecraftBridge.getPlayers()) {
            if (MinecraftBridge.isDead(p)) {
               UUID id = MinecraftBridge.getUuid(p);
               if (id != null) {
                  pops.remove(id);
               }
            }
         }

      }
   }

   public static int get(UUID player) {
      return player == null ? 0 : (Integer)pops.getOrDefault(player, 0);
   }

   static void clear() {
      pops.clear();
   }
}
