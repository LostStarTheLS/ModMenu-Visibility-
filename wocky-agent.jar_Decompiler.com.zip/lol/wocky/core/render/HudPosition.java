package lol.wocky.core.render;

import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;

public final class HudPosition {
   private final NumberProperty x = hidden("Hud X", (double)-1.0F);
   private final NumberProperty y = hidden("Hud Y", (double)-1.0F);
   private final NumberProperty right = hidden("Hud Right", (double)0.0F);
   private final NumberProperty bottom = hidden("Hud Bottom", (double)0.0F);

   private static NumberProperty hidden(String name, double def) {
      NumberProperty p = new NumberProperty(name, def, (double)-1.0F, (double)1.0F, 1.0E-4);
      p.hideIf(() -> true);
      return p;
   }

   public Property<?>[] properties() {
      return new Property[]{this.x, this.y, this.right, this.bottom};
   }

   public float[] spec() {
      return this.x.doubleValue() < (double)0.0F ? null : new float[]{this.x.floatValue(), this.y.floatValue(), this.right.floatValue(), this.bottom.floatValue()};
   }

   public void place(float x1, float y1, float w, float h, float screenW, float screenH) {
      boolean anchorRight = x1 + w / 2.0F > screenW / 2.0F;
      boolean anchorBottom = y1 + h / 2.0F > screenH / 2.0F;
      this.x.setValue((Number)((double)((anchorRight ? x1 + w : x1) / screenW)));
      this.y.setValue((Number)((double)((anchorBottom ? y1 + h : y1) / screenH)));
      this.right.setValue((Number)(anchorRight ? (double)1.0F : (double)0.0F));
      this.bottom.setValue((Number)(anchorBottom ? (double)1.0F : (double)0.0F));
   }

   public void reset() {
      this.x.setValue((Number)(double)-1.0F);
      this.y.setValue((Number)(double)-1.0F);
      this.right.setValue((Number)(double)0.0F);
      this.bottom.setValue((Number)(double)0.0F);
   }
}
