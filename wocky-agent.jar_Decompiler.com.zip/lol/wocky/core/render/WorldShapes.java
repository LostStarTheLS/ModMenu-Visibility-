package lol.wocky.core.render;

import java.util.Arrays;
import lol.wocky.core.GlOverlay;

public final class WorldShapes {
   private static final float NEAR = 0.05F;
   private static final int[][] FACES = new int[][]{{0, 2, 6, 4}, {1, 3, 7, 5}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 1, 3, 2}, {4, 5, 7, 6}};
   private float[] lines = new float[1024];
   private int[] lineColors = new int[512];
   private int lineCount;
   private float[] tris = new float[1536];
   private int[] triColors = new int[256];
   private int triCount;
   private Hud2D hud;
   private final float[][] corners = new float[8][4];
   private final float[] pa = new float[4];
   private final float[] pb = new float[4];
   private final float[] sa = new float[2];
   private final float[] sb = new float[2];
   private final float[][] poly = new float[8][4];
   private final float[][] clipped = new float[8][4];

   public void begin(Hud2D hud) {
      this.hud = hud;
      this.lineCount = 0;
      this.triCount = 0;
   }

   public boolean isEmpty() {
      return this.lineCount == 0 && this.triCount == 0;
   }

   public void submit(float lineWidth) {
      GlOverlay.shapes(this.lines, this.lineColors, this.lineCount, lineWidth, this.tris, this.triColors, this.triCount);
   }

   public void line2d(float x1, float y1, float x2, float y2, int from, int to) {
      if (this.lineCount * 4 + 4 > this.lines.length) {
         this.lines = Arrays.copyOf(this.lines, this.lines.length * 2);
         this.lineColors = Arrays.copyOf(this.lineColors, this.lineColors.length * 2);
      }

      int i = this.lineCount++;
      this.lines[i * 4] = x1;
      this.lines[i * 4 + 1] = y1;
      this.lines[i * 4 + 2] = x2;
      this.lines[i * 4 + 3] = y2;
      this.lineColors[i * 2] = from;
      this.lineColors[i * 2 + 1] = to;
   }

   public void tracer(double x, double y, double z, int from, int to) {
      float cx = (float)this.hud.width() / 2.0F;
      float cy = (float)this.hud.height() / 2.0F;
      this.hud.clip(x, y, z, this.pa);
      if (this.pa[3] > 0.05F) {
         this.toScreen(this.pa, this.sa);
         this.line2d(cx, cy, this.sa[0], this.sa[1], from, to);
      } else {
         float dx = this.pa[0];
         float dy = -this.pa[1];
         float len = (float)Math.sqrt((double)(dx * dx + dy * dy));
         if (len < 1.0E-4F) {
            dx = 0.0F;
            dy = 1.0F;
            len = 1.0F;
         }

         float far = (float)(this.hud.width() + this.hud.height());
         this.line2d(cx, cy, cx + dx / len * far, cy + dy / len * far, from, to);
      }
   }

   public void box(double x1, double y1, double z1, double x2, double y2, double z2, int edge, int fill) {
      int inFront = 0;
      float minX = Float.MAX_VALUE;
      float minY = Float.MAX_VALUE;
      float maxX = -Float.MAX_VALUE;
      float maxY = -Float.MAX_VALUE;

      for(int i = 0; i < 8; ++i) {
         float[] c = this.corners[i];
         this.hud.clip((i & 1) == 0 ? x1 : x2, (i & 2) == 0 ? y1 : y2, (i & 4) == 0 ? z1 : z2, c);
         if (c[3] > 0.05F) {
            ++inFront;
            this.toScreen(c, this.sa);
            minX = Math.min(minX, this.sa[0]);
            minY = Math.min(minY, this.sa[1]);
            maxX = Math.max(maxX, this.sa[0]);
            maxY = Math.max(maxY, this.sa[1]);
         }
      }

      if (inFront != 0) {
         if (inFront != 8 || !(maxX < 0.0F) && !(maxY < 0.0F) && !(minX > (float)this.hud.width()) && !(minY > (float)this.hud.height())) {
            if (fill >>> 24 != 0) {
               boolean[] visible = new boolean[]{this.hud.camX() < x1, this.hud.camX() > x2, this.hud.camY() < y1, this.hud.camY() > y2, this.hud.camZ() < z1, this.hud.camZ() > z2};

               for(int f = 0; f < 6; ++f) {
                  if (visible[f]) {
                     this.face(FACES[f], fill);
                  }
               }
            }

            if (edge >>> 24 != 0) {
               for(int i = 0; i < 8; ++i) {
                  for(int bit = 1; bit <= 4; bit <<= 1) {
                     if ((i & bit) == 0) {
                        this.clipLine(this.corners[i], this.corners[i | bit], edge);
                     }
                  }
               }
            }

         }
      }
   }

   private void clipLine(float[] a, float[] b, int color) {
      boolean ina = a[3] > 0.05F;
      boolean inb = b[3] > 0.05F;
      if (ina || inb) {
         float[] p = a;
         float[] q = b;
         if (!ina || !inb) {
            float t = (0.05F - a[3]) / (b[3] - a[3]);
            float[] cut = ina ? this.pb : this.pa;

            for(int k = 0; k < 4; ++k) {
               cut[k] = a[k] + (b[k] - a[k]) * t;
            }

            if (ina) {
               q = cut;
            } else {
               p = cut;
            }
         }

         this.toScreen(p, this.sa);
         this.toScreen(q, this.sb);
         this.line2d(this.sa[0], this.sa[1], this.sb[0], this.sb[1], color, color);
      }
   }

   private void face(int[] idx, int color) {
      int n = 0;

      for(int i = 0; i < 4; ++i) {
         float[] a = this.corners[idx[i]];
         float[] b = this.corners[idx[(i + 1) % 4]];
         boolean ina = a[3] >= 0.05F;
         boolean inb = b[3] >= 0.05F;
         if (ina) {
            System.arraycopy(a, 0, this.poly[n++], 0, 4);
         }

         if (ina != inb) {
            float t = (0.05F - a[3]) / (b[3] - a[3]);
            float[] o = this.poly[n++];

            for(int k = 0; k < 4; ++k) {
               o[k] = a[k] + (b[k] - a[k]) * t;
            }
         }
      }

      if (n >= 3) {
         for(int i = 0; i < n; ++i) {
            this.toScreen(this.poly[i], this.clipped[i]);
         }

         for(int i = 1; i + 1 < n; ++i) {
            this.triangle(this.clipped[0][0], this.clipped[0][1], this.clipped[i][0], this.clipped[i][1], this.clipped[i + 1][0], this.clipped[i + 1][1], color);
         }

      }
   }

   private void triangle(float x1, float y1, float x2, float y2, float x3, float y3, int color) {
      if (this.triCount * 6 + 6 > this.tris.length) {
         this.tris = Arrays.copyOf(this.tris, this.tris.length * 2);
         this.triColors = Arrays.copyOf(this.triColors, this.triColors.length * 2);
      }

      int i = this.triCount++;
      this.tris[i * 6] = x1;
      this.tris[i * 6 + 1] = y1;
      this.tris[i * 6 + 2] = x2;
      this.tris[i * 6 + 3] = y2;
      this.tris[i * 6 + 4] = x3;
      this.tris[i * 6 + 5] = y3;
      this.triColors[i] = color;
   }

   private void toScreen(float[] c, float[] out) {
      out[0] = (c[0] / c[3] * 0.5F + 0.5F) * (float)this.hud.width();
      out[1] = (1.0F - (c[1] / c[3] * 0.5F + 0.5F)) * (float)this.hud.height();
   }
}
