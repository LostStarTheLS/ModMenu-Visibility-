package lol.wocky.core.render;

public interface HudElement {
   String getName();

   HudPosition hudPosition();
}
