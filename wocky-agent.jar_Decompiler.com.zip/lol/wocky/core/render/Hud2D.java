package lol.wocky.core.render;

import lol.wocky.core.MinecraftBridge;

public final class Hud2D {
   private Object ctx;
   private MinecraftBridge.Frame frame;
   private int scale;
   private int width;
   private int height;
   private final float[] v = new float[4];

   public void begin(Object drawContext, MinecraftBridge.Frame frame, int guiScale, int fbWidth, int fbHeight) {
      this.ctx = drawContext;
      this.frame = frame;
      this.scale = guiScale;
      this.width = fbWidth;
      this.height = fbHeight;
      MinecraftBridge.pushDrawScale(this.ctx, 1.0F / (float)guiScale);
   }

   public void end() {
      MinecraftBridge.popDrawScale(this.ctx);
      this.ctx = null;
   }

   public int guiScale() {
      return this.scale;
   }

   public int width() {
      return this.width;
   }

   public int height() {
      return this.height;
   }

   public float tickDelta() {
      return this.frame.tickDelta;
   }

   public double camX() {
      return this.frame.camX;
   }

   public double camY() {
      return this.frame.camY;
   }

   public double camZ() {
      return this.frame.camZ;
   }

   public boolean project(double x, double y, double z, float[] out) {
      float px = (float)(x - this.frame.camX);
      float py = (float)(y - this.frame.camY);
      float pz = (float)(z - this.frame.camZ);
      this.mul(this.frame.view, px, py, pz, 1.0F);
      this.mul(this.frame.projection, this.v[0], this.v[1], this.v[2], this.v[3]);
      float w = this.v[3];
      if (w <= 0.05F) {
         return false;
      } else {
         out[0] = (this.v[0] / w * 0.5F + 0.5F) * (float)this.width;
         out[1] = (1.0F - (this.v[1] / w * 0.5F + 0.5F)) * (float)this.height;
         return true;
      }
   }

   public void clip(double x, double y, double z, float[] out) {
      float px = (float)(x - this.frame.camX);
      float py = (float)(y - this.frame.camY);
      float pz = (float)(z - this.frame.camZ);
      this.mul(this.frame.view, px, py, pz, 1.0F);
      this.mul(this.frame.projection, this.v[0], this.v[1], this.v[2], this.v[3]);
      System.arraycopy(this.v, 0, out, 0, 4);
   }

   private void mul(float[] m, float x, float y, float z, float w) {
      float rx = m[0] * x + m[4] * y + m[8] * z + m[12] * w;
      float ry = m[1] * x + m[5] * y + m[9] * z + m[13] * w;
      float rz = m[2] * x + m[6] * y + m[10] * z + m[14] * w;
      float rw = m[3] * x + m[7] * y + m[11] * z + m[15] * w;
      this.v[0] = rx;
      this.v[1] = ry;
      this.v[2] = rz;
      this.v[3] = rw;
   }

   public void fill(int x1, int y1, int x2, int y2, int argb) {
      if (x2 > x1 && y2 > y1 && argb >>> 24 != 0) {
         MinecraftBridge.drawFill(this.ctx, x1, y1, x2, y2, argb);
      }
   }

   public void outline(int x1, int y1, int x2, int y2, int t, int argb) {
      this.fill(x1, y1, x2, y1 + t, argb);
      this.fill(x1, y2 - t, x2, y2, argb);
      this.fill(x1, y1 + t, x1 + t, y2 - t, argb);
      this.fill(x2 - t, y1 + t, x2, y2 - t, argb);
   }

   public void roundedRect(int x1, int y1, int x2, int y2, int r, int argb) {
      r = Math.max(0, Math.min(r, Math.min((x2 - x1) / 2, (y2 - y1) / 2)));

      for(int i = 0; i < r; ++i) {
         int inset = cornerInset(r, i);
         this.fill(x1 + inset, y1 + i, x2 - inset, y1 + i + 1, argb);
         this.fill(x1 + inset, y2 - i - 1, x2 - inset, y2 - i, argb);
      }

      this.fill(x1, y1 + r, x2, y2 - r, argb);
   }

   public void roundedOutline(int x1, int y1, int x2, int y2, int r, int argb) {
      r = Math.max(0, Math.min(r, Math.min((x2 - x1) / 2, (y2 - y1) / 2)));
      if (r <= 1) {
         this.outline(x1, y1, x2, y2, 1, argb);
      } else {
         for(int i = 0; i < r; ++i) {
            int outer = cornerInset(r, i);
            if (i == 0) {
               this.fill(x1 + outer, y1, x2 - outer, y1 + 1, argb);
               this.fill(x1 + outer, y2 - 1, x2 - outer, y2, argb);
            } else {
               int inner = Math.max(outer + 1, 1 + cornerInset(r - 1, i - 1));
               this.fill(x1 + outer, y1 + i, x1 + inner, y1 + i + 1, argb);
               this.fill(x2 - inner, y1 + i, x2 - outer, y1 + i + 1, argb);
               this.fill(x1 + outer, y2 - i - 1, x1 + inner, y2 - i, argb);
               this.fill(x2 - inner, y2 - i - 1, x2 - outer, y2 - i, argb);
            }
         }

         this.fill(x1, y1 + r, x1 + 1, y2 - r, argb);
         this.fill(x2 - 1, y1 + r, x2, y2 - r, argb);
      }
   }

   private static int cornerInset(int r, int row) {
      double dy = (double)(r - row) - (double)0.5F;
      return (int)Math.round((double)r - Math.sqrt(Math.max((double)0.0F, (double)(r * r) - dy * dy)));
   }

   public void text(String s, int px, int py, int argb, boolean shadow) {
      MinecraftBridge.pushDrawScale(this.ctx, (float)this.scale);
      MinecraftBridge.drawText(this.ctx, s, Math.round((float)px / (float)this.scale), Math.round((float)py / (float)this.scale), argb, shadow);
      MinecraftBridge.popDrawScale(this.ctx);
   }

   public int textWidth(String s) {
      return MinecraftBridge.textWidth(s) * this.scale;
   }

   public int fontHeight() {
      return MinecraftBridge.fontHeight() * this.scale;
   }
}
