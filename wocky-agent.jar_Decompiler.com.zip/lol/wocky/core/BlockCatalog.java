package lol.wocky.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public final class BlockCatalog {
   private static final Set<String> SKIP = Set.of("air", "cave_air", "void_air");
   private static final String[] TOP = new String[]{"up", "top", "end", "all", "texture", "particle"};
   private static final String[] LEFT = new String[]{"front", "north", "south", "side", "all", "texture", "particle"};
   private static final String[] RIGHT = new String[]{"east", "side", "west", "all", "texture", "particle"};
   private static final String[] FLAT = new String[]{"layer0", "cross", "plant", "crop", "texture", "torch", "rail", "all", "side", "particle"};
   private static final int GRASS = 9551193;
   private static final int FOLIAGE = 7842607;
   private static final int WATER = 4159204;
   private static volatile String json;
   private static boolean building;
   private static final Map<String, Model> models = new HashMap();
   private static final Map<String, String> textures = new LinkedHashMap();

   private BlockCatalog() {
   }

   static String get() {
      String done = json;
      if (done != null) {
         return done;
      } else {
         synchronized(BlockCatalog.class) {
            if (!building) {
               building = true;
               Thread t = new Thread(BlockCatalog::build, "Wocky-BlockCatalog");
               t.setDaemon(true);
               t.start();
            }

            return null;
         }
      }
   }

   private static void build() {
      long start = System.nanoTime();
      JsonArray blocks = new JsonArray();

      try {
         for(Object block : MinecraftBridge.getAllBlocks()) {
            String id = MinecraftBridge.blockIdOf(block);
            if (!id.isEmpty() && !SKIP.contains(id)) {
               JsonObject o = new JsonObject();
               o.addProperty("id", id);
               o.addProperty("name", MinecraftBridge.blockName(block));

               try {
                  describeIcon(id, o);
               } catch (Throwable var8) {
                  o.addProperty("kind", "none");
               }

               blocks.add((JsonElement)o);
            }
         }
      } catch (Throwable t) {
         System.err.println("[Wocky] Block catalog failed: " + String.valueOf(t));
      }

      JsonObject tex = new JsonObject();

      for(Map.Entry<String, String> e : textures.entrySet()) {
         if (e.getValue() != null) {
            tex.addProperty((String)e.getKey(), (String)e.getValue());
         }
      }

      JsonObject root = new JsonObject();
      root.add("blocks", blocks);
      root.add("textures", tex);
      json = root.toString();
      models.clear();
      textures.clear();
      System.out.printf("[Wocky] Block catalog: %d blocks, %d KB, %d ms%n", blocks.size(), json.length() / 1024, (System.nanoTime() - start) / 1000000L);
   }

   private static void describeIcon(String id, JsonObject out) {
      int tint = -1;
      String modelName = null;
      JsonObject special = null;
      JsonObject item = readJson("assets/minecraft/items/" + id + ".json");
      if (item != null) {
         JsonObject leaf = item.get("model");
         if (leaf instanceof JsonObject) {
            JsonObject m = leaf;
            leaf = pickModel(m);
            if (leaf != null) {
               String type = str(leaf, "type");
               if (type.endsWith("special")) {
                  JsonElement var10 = leaf.get("model");
                  JsonObject var10000;
                  if (var10 instanceof JsonObject) {
                     JsonObject s = (JsonObject)var10;
                     var10000 = s;
                  } else {
                     var10000 = null;
                  }

                  special = var10000;
                  modelName = str(leaf, "base");
               } else {
                  modelName = str(leaf, "model");
                  tint = tintOf(leaf);
               }
            }
         }
      }

      if (special == null || !specialIcon(special, out)) {
         if (special != null && path(modelName).startsWith("item/template_")) {
            fallbackIcon(id, out);
         } else {
            if (modelName == null || modelName.isEmpty()) {
               modelName = blockstateModel(id);
            }

            if (id.equals("water") || id.equals("bubble_column")) {
               tint = 4159204;
            }

            if (modelName != null && !modelName.isEmpty()) {
               Model model = model(modelName, 0);
               boolean generated = model.chain.contains("item/generated") || model.chain.contains("item/handheld") || model.chain.contains("builtin/generated");
               boolean slab = model.chain.contains("block/slab") || model.chain.contains("block/slab_top");
               boolean cube = !generated && (slab || model.chain.contains("block/cube") || has(model, "top") && has(model, "side") || model.textures.containsKey("all"));
               if (cube) {
                  String[] top = resolveVar(model, TOP);
                  String[] left = resolveVar(model, LEFT);
                  String[] right = resolveVar(model, RIGHT);
                  if (top != null && left != null && right != null && texture(top[1]) && texture(left[1]) && texture(right[1])) {
                     out.addProperty("kind", slab ? "slab" : "cube");
                     out.addProperty("t", top[1]);
                     out.addProperty("l", left[1]);
                     out.addProperty("r", right[1]);
                     if (tint != -1) {
                        int mask = (model.tinted.contains(top[0]) ? 1 : 0) | (model.tinted.contains(left[0]) ? 2 : 0) | (model.tinted.contains(right[0]) ? 4 : 0);
                        if (mask != 0) {
                           out.addProperty("tint", (Number)tint);
                           out.addProperty("tm", (Number)mask);
                        }
                     }

                     return;
                  }
               }

               String[] flat = resolveVar(model, FLAT);
               if (flat != null && texture(flat[1])) {
                  out.addProperty("kind", "flat");
                  out.addProperty("t", flat[1]);
                  if (tint != -1 && (generated || model.tinted.contains(flat[0]) || model.tinted.isEmpty())) {
                     out.addProperty("tint", (Number)tint);
                     out.addProperty("tm", (int)1);
                  }

               } else {
                  fallbackIcon(id, out);
               }
            } else {
               fallbackIcon(id, out);
            }
         }
      }
   }

   private static boolean specialIcon(JsonObject special, JsonObject out) {
      String type = str(special, "type");
      String name = path(str(special, "texture"));
      String kind;
      String dir;
      if (type.endsWith(":chest")) {
         kind = "chest";
         dir = "entity/chest/";
      } else {
         if (!type.endsWith(":shulker_box")) {
            return false;
         }

         kind = "shulker";
         dir = "entity/shulker/";
      }

      if (!name.isEmpty() && texture(dir + name)) {
         out.addProperty("kind", kind);
         out.addProperty("t", dir + name);
         return true;
      } else {
         return false;
      }
   }

   private static void fallbackIcon(String id, JsonObject out) {
      for(String candidate : new String[]{"block/" + id, "item/" + id, "block/" + id + "_still", "block/" + id + "_side", "block/" + id + "_front", "block/" + id + "_top"}) {
         if (texture(candidate)) {
            out.addProperty("kind", "flat");
            out.addProperty("t", candidate);
            if (id.equals("water") || id.equals("bubble_column")) {
               out.addProperty("tint", (Number)4159204);
               out.addProperty("tm", (int)1);
            }

            return;
         }
      }

      out.addProperty("kind", "none");
   }

   private static JsonObject pickModel(JsonObject m) {
      int depth = 0;

      while(true) {
         if (m != null && depth < 8) {
            String type = str(m, "type");
            if (!type.endsWith(":model") && !type.endsWith(":special")) {
               JsonElement next = null;
               if (!type.endsWith(":select") && !type.endsWith(":range_dispatch")) {
                  if (type.endsWith(":condition")) {
                     next = m.has("on_false") ? m.get("on_false") : m.get("on_true");
                  } else if (type.endsWith(":composite")) {
                     JsonElement var9 = m.get("models");
                     if (var9 instanceof JsonArray) {
                        JsonArray a = (JsonArray)var9;
                        if (!a.isEmpty()) {
                           next = a.get(0);
                        }
                     }
                  }
               } else {
                  next = m.get("fallback");
                  if (next == null) {
                     JsonElement var7 = m.get(type.endsWith(":select") ? "cases" : "entries");
                     if (var7 instanceof JsonArray) {
                        JsonArray a = (JsonArray)var7;
                        if (!a.isEmpty()) {
                           var7 = a.get(0);
                           if (var7 instanceof JsonObject) {
                              JsonObject first = (JsonObject)var7;
                              next = first.get("model");
                           }
                        }
                     }
                  }
               }

               JsonObject var10000;
               if (next instanceof JsonObject) {
                  JsonObject o = (JsonObject)next;
                  var10000 = o;
               } else {
                  var10000 = null;
               }

               m = var10000;
               ++depth;
               continue;
            }

            return m;
         }

         return null;
      }
   }

   private static int tintOf(JsonObject modelLeaf) {
      JsonElement var3 = modelLeaf.get("tints");
      if (var3 instanceof JsonArray tints) {
         if (!tints.isEmpty()) {
            var3 = tints.get(0);
            if (var3 instanceof JsonObject) {
               JsonObject t = (JsonObject)var3;
               String type = str(t, "type");
               if (type.endsWith(":constant") && t.has("value")) {
                  return t.get("value").getAsInt() & 16777215;
               }

               if (type.endsWith(":grass")) {
                  return 9551193;
               }

               if (!type.endsWith(":foliage") && !type.endsWith(":dry_foliage")) {
                  return -1;
               }

               return 7842607;
            }
         }
      }

      return -1;
   }

   private static String blockstateModel(String id) {
      JsonObject bs = readJson("assets/minecraft/blockstates/" + id + ".json");
      if (bs == null) {
         return null;
      } else {
         JsonElement var3 = bs.get("variants");
         if (var3 instanceof JsonObject) {
            JsonObject variants = (JsonObject)var3;

            for(Map.Entry<String, JsonElement> e : variants.entrySet()) {
               JsonElement v = (JsonElement)e.getValue();
               if (v instanceof JsonArray) {
                  JsonArray a = (JsonArray)v;
                  if (!a.isEmpty()) {
                     v = a.get(0);
                  }
               }

               if (v instanceof JsonObject) {
                  JsonObject o = (JsonObject)v;
                  if (o.has("model")) {
                     return str(o, "model");
                  }
               }
            }
         }

         var3 = bs.get("multipart");
         if (var3 instanceof JsonArray) {
            for(JsonElement p : (JsonArray)var3) {
               if (p instanceof JsonObject) {
                  JsonObject po = (JsonObject)p;
                  JsonElement apply = po.get("apply");
                  if (apply instanceof JsonArray) {
                     JsonArray a = (JsonArray)apply;
                     if (!a.isEmpty()) {
                        apply = a.get(0);
                     }
                  }

                  if (apply instanceof JsonObject) {
                     JsonObject o = (JsonObject)apply;
                     if (o.has("model")) {
                        return str(o, "model");
                     }
                  }
               }
            }
         }

         return null;
      }
   }

   private static Model model(String name, int depth) {
      String key = path(name);
      Model cached = (Model)models.get(key);
      if (cached != null) {
         return cached;
      } else {
         Map<String, String> tex = new HashMap();
         Set<String> chain = new HashSet();
         Set<String> tinted = new HashSet();
         chain.add(key);
         JsonObject var10000;
         if (key.startsWith("builtin/")) {
            var10000 = null;
         } else {
            String var15 = namespace(name);
            var10000 = readJson("assets/" + var15 + "/models/" + key + ".json");
         }

         JsonObject json = var10000;
         if (json != null) {
            JsonElement var9 = json.get("textures");
            if (var9 instanceof JsonObject) {
               JsonObject t = (JsonObject)var9;

               for(Map.Entry<String, JsonElement> e : t.entrySet()) {
                  if (((JsonElement)e.getValue()).isJsonPrimitive()) {
                     tex.put((String)e.getKey(), ((JsonElement)e.getValue()).getAsString());
                  }
               }
            }

            boolean hasElements = json.get("elements") instanceof JsonArray;
            if (hasElements) {
               collectTinted(json.getAsJsonArray("elements"), tinted);
            }

            if (json.has("parent") && depth < 16) {
               Model parent = model(str(json, "parent"), depth + 1);
               Map var16 = parent.textures;
               Objects.requireNonNull(tex);
               var16.forEach(tex::putIfAbsent);
               chain.addAll(parent.chain);
               if (!hasElements) {
                  tinted.addAll(parent.tinted);
               }
            }
         }

         Model m = new Model(tex, chain, tinted);
         models.put(key, m);
         return m;
      }
   }

   private static void collectTinted(JsonArray elements, Set<String> out) {
      for(JsonElement el : elements) {
         if (el instanceof JsonObject e) {
            JsonElement var6 = e.get("faces");
            if (var6 instanceof JsonObject faces) {
               for(Map.Entry<String, JsonElement> f : faces.entrySet()) {
                  Object var9 = f.getValue();
                  if (var9 instanceof JsonObject face) {
                     if (face.has("tintindex") && face.has("texture")) {
                        String t = str(face, "texture");
                        out.add(t.startsWith("#") ? t.substring(1) : t);
                     }
                  }
               }
            }
         }
      }

   }

   private static boolean has(Model m, String var) {
      return m.textures.containsKey(var);
   }

   private static String[] resolveVar(Model m, String[] vars) {
      for(String var : vars) {
         String v = (String)m.textures.get(var);

         for(int i = 0; v != null && v.startsWith("#") && i < 8; ++i) {
            String ref = v.substring(1);
            if (m.tinted.contains(ref)) {
               m.tinted.add(var);
            }

            v = (String)m.textures.get(ref);
         }

         if (v != null && !v.startsWith("#")) {
            return new String[]{var, textureKey(v)};
         }
      }

      return null;
   }

   private static String textureKey(String ref) {
      return namespace(ref).equals("minecraft") ? path(ref) : namespace(ref) + ":" + path(ref);
   }

   private static boolean texture(String key) {
      if (textures.containsKey(key)) {
         return textures.get(key) != null;
      } else {
         String var10000 = namespace(key);
         byte[] png = MinecraftBridge.getGameResource("assets/" + var10000 + "/textures/" + path(key) + ".png");
         textures.put(key, png == null ? null : Base64.getEncoder().encodeToString(png));
         return png != null;
      }
   }

   private static JsonObject readJson(String path) {
      byte[] bytes = MinecraftBridge.getGameResource(path);
      if (bytes == null) {
         return null;
      } else {
         try {
            JsonElement e = JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8));
            JsonObject var10000;
            if (e instanceof JsonObject) {
               JsonObject o = (JsonObject)e;
               var10000 = o;
            } else {
               var10000 = null;
            }

            return var10000;
         } catch (Throwable var4) {
            return null;
         }
      }
   }

   private static String namespace(String id) {
      int c = id.indexOf(58);
      return c > 0 ? id.substring(0, c) : "minecraft";
   }

   private static String path(String id) {
      int c = id.indexOf(58);
      return c >= 0 ? id.substring(c + 1) : id;
   }

   private static String str(JsonObject o, String key) {
      JsonElement e = o.get(key);
      return e != null && e.isJsonPrimitive() ? e.getAsString() : "";
   }

   private static record Model(Map<String, String> textures, Set<String> chain, Set<String> tinted) {
   }
}
