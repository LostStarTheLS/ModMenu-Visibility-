package lol.wocky.core.util;

import lol.wocky.core.MinecraftBridge;

public final class BlockUtils {
   private BlockUtils() {
   }

   public static boolean isBlock(Object pos, String id) {
      return MinecraftBridge.blockId(pos).equals(id);
   }

   public static boolean isCrystalBase(Object pos) {
      String id = MinecraftBridge.blockId(pos);
      return id.equals("obsidian") || id.equals("bedrock");
   }

   public static boolean isChargedAnchor(Object pos) {
      if (!isBlock(pos, "respawn_anchor")) {
         return false;
      } else {
         String state = MinecraftBridge.blockStateString(pos);
         return state.contains("charges=") && !state.contains("charges=0");
      }
   }
}
