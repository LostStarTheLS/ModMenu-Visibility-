package lol.wocky.core;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class Refl {
   private static final List<String> missing = Collections.synchronizedList(new ArrayList());

   private Refl() {
   }

   static List<String> missing() {
      return missing;
   }

   static Class<?> cls(ClassLoader cl, String intermediary, String named) {
      for(String n : new String[]{"net.minecraft." + intermediary, named}) {
         try {
            return Class.forName(n, false, cl);
         } catch (Throwable var8) {
         }
      }

      missing.add("class " + intermediary + " (" + named + ")");
      return null;
   }

   static Method method(Class<?> owner, String intermediary, String named, Class<?>... params) {
      if (owner != null && !containsNull(params)) {
         for(String n : new String[]{intermediary, named}) {
            Method m = findMethod(owner, n, params);
            if (m != null) {
               try {
                  m.setAccessible(true);
               } catch (Throwable var10) {
               }

               return m;
            }
         }
      }

      missing.add("method " + describe(owner) + "." + intermediary + " (" + named + ")");
      return null;
   }

   static Field field(Class<?> owner, String intermediary, String named) {
      if (owner != null) {
         for(String n : new String[]{intermediary, named}) {
            for(Class<?> c = owner; c != null; c = c.getSuperclass()) {
               try {
                  Field f = c.getDeclaredField(n);
                  f.setAccessible(true);
                  return f;
               }
            }
         }
      }

      missing.add("field " + describe(owner) + "." + intermediary + " (" + named + ")");
      return null;
   }

   static Object staticValue(Field f) {
      try {
         return f != null ? f.get((Object)null) : null;
      } catch (Throwable var2) {
         return null;
      }
   }

   static Object enumConstant(Class<?> enumClass, String name) {
      if (enumClass != null && enumClass.isEnum()) {
         for(Object c : enumClass.getEnumConstants()) {
            if (((Enum)c).name().equals(name)) {
               return c;
            }
         }
      }

      List var10000 = missing;
      String var10001 = describe(enumClass);
      var10000.add("enum constant " + var10001 + "." + name);
      return null;
   }

   private static Method findMethod(Class<?> owner, String name, Class<?>[] params) {
      try {
         return owner.getMethod(name, params);
      } catch (Throwable var6) {
         for(Class<?> c = owner; c != null; c = c.getSuperclass()) {
            try {
               return c.getDeclaredMethod(name, params);
            }
         }

         return null;
      }
   }

   private static boolean containsNull(Class<?>[] params) {
      for(Class<?> p : params) {
         if (p == null) {
            return true;
         }
      }

      return false;
   }

   private static String describe(Class<?> c) {
      return c == null ? "<unresolved>" : c.getName();
   }
}
