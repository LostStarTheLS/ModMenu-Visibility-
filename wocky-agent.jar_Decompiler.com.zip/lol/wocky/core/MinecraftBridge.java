package lol.wocky.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleManager;
import lol.wocky.core.render.Hud2D;
import lol.wocky.core.render.HudElement;
import lol.wocky.feature.combat.CrystalOptimizer;
import lol.wocky.feature.movement.InvWalk;
import lol.wocky.feature.render.ArrayListHud;
import lol.wocky.feature.render.PlayerESP;
import lol.wocky.feature.render.StatusEffectsHud;
import lol.wocky.feature.render.TargetHud;
import lol.wocky.feature.render.Watermark;

public final class MinecraftBridge {
   private static volatile boolean initialized = false;
   private static long tickCount = 0L;
   private static Object lastWorld;
   private static ClassLoader mcLoader;
   private static Object mc;
   private static Class<?> cMinecraftClient;
   private static Class<?> cPlayerEntity;
   private static Class<?> cLivingEntity;
   private static Class<?> cEntity;
   private static Class<?> cInventory;
   private static Class<?> cInteractionManager;
   private static Class<?> cClientPlayer;
   private static Class<?> cWorld;
   private static Class<?> cItemStack;
   private static Class<?> cBlockState;
   private static Class<?> cBlockPos;
   private static Class<?> cHand;
   private static Class<?> cSlotActionType;
   private static Class<?> cHitResult;
   private static Class<?> cBlockHitResult;
   private static Class<?> cEntityHitResult;
   private static Class<?> cEndCrystal;
   private static Class<?> cItemEntity;
   private static Class<?> cExperienceOrb;
   private static Class<?> cBox;
   private static Class<?> cHandledScreen;
   private static Class<?> cCreativeScreen;
   private static Class<?> cScreenHandler;
   private static Class<?> cSlot;
   private static Class<?> cRegistryEntry;
   private static Class<?> cKeyBinding;
   private static Field fPlayer;
   private static Field fWorld;
   private static Field fInteractionManager;
   private static Field fCrosshairTarget;
   private static Field fCurrentScreen;
   private static Field fOptions;
   private static Field fItemUseCooldown;
   private static Field fGameRenderer;
   private static Method mUpdateCrosshair;
   private static long crosshairRefreshTick = -1L;
   private static Method mGetWindow;
   private static Method mWindowHandle;
   private static Method mGetSession;
   private static Method mSessionUsername;
   private static Method mSessionUuid;
   private static Method mGetServerEntry;
   private static Method mIsSingleplayer;
   private static Method mGetCurrentFps;
   private static Method mGetNetworkHandler;
   private static Method mGetPlayerListEntry;
   private static Method mGetLatency;
   private static Field fServerAddress;
   private static Field fServerName;
   private static Method mServerFavicon;
   private static Method mCameraPos;
   private static Method mTickProgress;
   private static Method mLerpedPos;
   private static Method mGetPlayers;
   private static Method mGetName;
   private static Method mTextGetString;
   private static Method mGetPerspective;
   private static Method mIsFirstPerson;
   private static Method mGetCameraEntity;
   private static Method mScaleFactor;
   private static Method mFbWidth;
   private static Method mFbHeight;
   private static Method mDrawFill;
   private static Method mDrawText;
   private static Method mDrawGetMatrices;
   private static Method mTextWidth;
   private static Field fVecX;
   private static Field fVecY;
   private static Field fVecZ;
   private static Field fBoxMinX;
   private static Field fBoxMinY;
   private static Field fBoxMinZ;
   private static Field fBoxMaxX;
   private static Field fBoxMaxY;
   private static Field fBoxMaxZ;
   private static Field fTextRenderer;
   private static Field fFontHeight;
   private static Method mGetRootVehicle;
   private static Method mGetFramebuffer;
   private static Method mColorAttachment;
   private static Method mTextureGlId;
   private static Method mTextureWidth;
   private static Method mTextureHeight;
   private static Method mGetStatusEffects;
   private static Method mEffectType;
   private static Method mEffectAmplifier;
   private static Method mEffectDuration;
   private static Method mEffectInfinite;
   private static Method mEffectShowIcon;
   private static Method mEffectName;
   private static Method mEntryId;
   private static Method mEntryValue;
   private static Class<?> cTextDisplay;
   private static Class<?> cArmorStand;
   private static Class<?> cChatScreen;
   private static Method mMatrix4fGet;
   private static Method mStackPush;
   private static Method mStackPop;
   private static Method mStackScale;
   private static Method mGlfwGetKey;
   private static Method mGlfwGetMouseButton;
   private static Method mGlfwGetWindowPos;
   private static Method mGlfwGetWindowSize;
   private static Field fPauseOnLostFocus;
   private static Method mGetInventory;
   private static Method mGetMainHandStack;
   private static Method mGetOffHandStack;
   private static Method mSwingHand;
   private static Method mGetHealth;
   private static Method mHasStatusEffect;
   private static Method mIsDead;
   private static Method mGetX;
   private static Method mGetY;
   private static Method mGetZ;
   private static Method mIsRemoved;
   private static Method mDiscard;
   private static Method mGetBoundingBox;
   private static Object weaknessEffect;
   private static Object blindnessEffect;
   private static Method mInvGetStack;
   private static Method mInvGetSelectedSlot;
   private static Method mInvSetSelectedSlot;
   private static Method mStackGetItem;
   private static Method mStackIsEmpty;
   private static Method mInteractBlock;
   private static Method mInteractItem;
   private static Method mAttackEntity;
   private static Method mClickSlot;
   private static Method mSyncSelectedSlot;
   private static Method mIsAccepted;
   private static Object handMain;
   private static Object actionSwap;
   private static Object actionPickup;
   private static Method mGetBlockState;
   private static Method mIsAir;
   private static Method mGetBlock;
   private static Method mGetEntities;
   private static Method mGetOtherEntities;
   private static Method mPosUp;
   private static Method mPosX;
   private static Method mPosY;
   private static Method mPosZ;
   private static Constructor<?> ctorBlockPos;
   private static Constructor<?> ctorBox;
   private static Method mHitType;
   private static Method mHitBlockPos;
   private static Method mHitEntity;
   private static Method mHitSide;
   private static Method mPosOffset;
   private static Object hitTypeBlock;
   private static Field fFocusedSlot;
   private static Field fScreenHandler;
   private static Field fSyncId;
   private static Field fSlotId;
   private static Method mSlotGetStack;
   private static Field fUseKey;
   private static Field fOptionValue;
   private static Method mSetPressed;
   private static Method mGetGamma;
   private static Class<?> cClientPlayerLike;
   private static Class<?> cInventoryScreen;
   private static Method mIsBlocking;
   private static Method mGetMaxHealth;
   private static Method mGetAbsorption;
   private static Method mGetUuid;
   private static Method mGetYaw;
   private static Method mGetSkin;
   private static Method mSkinBody;
   private static Method mAssetTexturePath;
   private static Method mGetTextureManager;
   private static Method mGetTexture;
   private static Method mGetGlTexture;
   private static Field fHurtTime;
   private static Field fCurrentScreenHandler;
   private static Method mStackDamage;
   private static Method mStackMaxDamage;
   private static Method mStackEnchantments;
   private static Method mEnchantmentEntries;
   private static Method mGetCursorStack;
   private static Method mWorldGetChunk;
   private static Method mChunkSections;
   private static Method mSectionIsEmpty;
   private static Method mSectionHasAny;
   private static Method mSectionGetState;
   private static Method mBottomSectionCoord;
   private static Method mBlockName;
   private static Method mDefaultState;
   private static Method mMapColor;
   private static Field fMapColorValue;
   private static Object blockRegistry;
   private static Object originPos;
   private static Method mStatusGetStatus;
   private static Method mStatusGetEntity;
   private static Class<?> cActionSuccess;
   private static Method mIsUsingItem;
   private static Method mIsRiding;
   private static Method mBelowMinAttackCharge;
   private static Method mIsBreakingBlock;
   private static Method mSwingSource;
   private static Method mSendPacket;
   private static Object swingClient;
   private static Constructor<?> ctorCloseScreenPacket;
   private static Method mGetVelocity;
   private static Method mIsOnGround;
   private static Method mIsGliding;
   private static Method mIsTouchingWater;
   private static Method mIsInLava;
   private static Method mIsClimbing;
   private static Method mHasVehicle;
   private static Method mGetPitch;
   private static Method mChangeLook;
   private static Method mGetEyeY;
   private static Method mInteractionRange;
   private static Method mIsSpaceEmpty;
   private static Method mBoxOffset;
   private static Method mAttackCooldown;
   private static Method mIsSprinting;
   private static Field fFallDistance;
   private static Field fLastX;
   private static Field fLastY;
   private static Field fLastZ;
   private static Field fMouseDeltaX;
   private static Field fMouseDeltaY;
   private static Method mIsReplaceable;
   private static Method mBlockRange;
   private static volatile boolean mouseLocked;
   private static Field fForwardKey;
   private static Field fBackKey;
   private static Field fLeftKey;
   private static Field fRightKey;
   private static Field fJumpKey;
   private static Field fSneakKey;
   private static Field fSprintKey;
   private static Field fBoundKey;
   private static Field fKeyPressed;
   private static Method mKeyCode;
   private static Method mKeyCategory;
   private static Object inputTypeMouse;
   private static Field fJumpingCooldown;
   private static Field fRecipeBook;
   private static Field fRecipeSearch;
   private static Method mSetPitch;
   private static Method mGetFocused;
   private static Method mIsFocused;
   private static Method mIsSneaking;
   private static Class<?> cRecipeBookScreen;
   private static Class<?> cTextField;
   private static Method mCanSee;
   private static Method mIsInvisible;
   private static Method mIsTeammate;
   private static Method mCancelBlockBreaking;
   private static final Map<Object, String> itemIds = new ConcurrentHashMap();
   private static final Map<Object, String> blockIds = new ConcurrentHashMap();
   private static boolean inModuleTick;
   private static final Frame frame = new Frame();
   private static final Hud2D hud = new Hud2D();
   private static PlayerESP esp;
   private static StatusEffectsHud effectsHud;
   private static InvWalk invWalk;
   private static volatile boolean hudEditing;
   private static Boolean savedPauseOnLostFocus;
   private static final Class<?>[] HUD_SLOTS = new Class[]{Watermark.class, StatusEffectsHud.class, ArrayListHud.class, TargetHud.class};
   private static long actionTick = -1L;
   private static boolean attackedThisTick;
   private static boolean usedThisTick;
   private static int pendingSlot = -1;
   private static boolean replayingClick;
   private static boolean movementHalted;
   private static boolean movementOverride;

   private MinecraftBridge() {
   }

   public static synchronized boolean init(Instrumentation inst) {
      if (initialized) {
         return true;
      } else {
         for(Class<?> c : inst.getAllLoadedClasses()) {
            String n = c.getName();
            if (n.equals("net.minecraft.class_310") || n.equals("net.minecraft.client.MinecraftClient")) {
               cMinecraftClient = c;
               mcLoader = c.getClassLoader();
               break;
            }
         }

         if (cMinecraftClient == null) {
            System.err.println("[Wocky] MinecraftClient is not loaded; is this a Minecraft 1.21.11 client?");
            return false;
         } else {
            resolveClasses();
            resolveMembers();

            try {
               Method getInstance = Refl.method(cMinecraftClient, "method_1551", "getInstance");
               mc = getInstance != null ? getInstance.invoke((Object)null) : null;
            } catch (Throwable t) {
               System.err.println("[Wocky] MinecraftClient.getInstance() failed: " + String.valueOf(t));
            }

            List<String> missing = Refl.missing();
            if (mc == null) {
               System.err.println("[Wocky] MinecraftClient instance is not available");
            }

            if (missing.isEmpty()) {
               System.out.println("[Wocky] Bridge ready: all mappings resolved");
            } else {
               System.err.println("[Wocky] Bridge is missing " + missing.size() + " mapping(s); affected features will not work:");
               synchronized(missing) {
                  for(String m : missing) {
                     System.err.println("[Wocky]   - " + m);
                  }
               }
            }

            initialized = mc != null;
            return initialized;
         }
      }
   }

   private static void resolveClasses() {
      ClassLoader cl = mcLoader;
      cPlayerEntity = Refl.cls(cl, "class_1657", "net.minecraft.entity.player.PlayerEntity");
      cClientPlayer = Refl.cls(cl, "class_746", "net.minecraft.client.network.ClientPlayerEntity");
      cLivingEntity = Refl.cls(cl, "class_1309", "net.minecraft.entity.LivingEntity");
      cEntity = Refl.cls(cl, "class_1297", "net.minecraft.entity.Entity");
      cInventory = Refl.cls(cl, "class_1661", "net.minecraft.entity.player.PlayerInventory");
      cInteractionManager = Refl.cls(cl, "class_636", "net.minecraft.client.network.ClientPlayerInteractionManager");
      cWorld = Refl.cls(cl, "class_1937", "net.minecraft.world.World");
      cItemStack = Refl.cls(cl, "class_1799", "net.minecraft.item.ItemStack");
      cBlockState = Refl.cls(cl, "class_2680", "net.minecraft.block.BlockState");
      cBlockPos = Refl.cls(cl, "class_2338", "net.minecraft.util.math.BlockPos");
      cHand = Refl.cls(cl, "class_1268", "net.minecraft.util.Hand");
      cSlotActionType = Refl.cls(cl, "class_1713", "net.minecraft.screen.slot.SlotActionType");
      cHitResult = Refl.cls(cl, "class_239", "net.minecraft.util.hit.HitResult");
      cBlockHitResult = Refl.cls(cl, "class_3965", "net.minecraft.util.hit.BlockHitResult");
      cEntityHitResult = Refl.cls(cl, "class_3966", "net.minecraft.util.hit.EntityHitResult");
      cEndCrystal = Refl.cls(cl, "class_1511", "net.minecraft.entity.decoration.EndCrystalEntity");
      cItemEntity = Refl.cls(cl, "class_1542", "net.minecraft.entity.ItemEntity");
      cExperienceOrb = Refl.cls(cl, "class_1303", "net.minecraft.entity.ExperienceOrbEntity");
      cBox = Refl.cls(cl, "class_238", "net.minecraft.util.math.Box");
      cHandledScreen = Refl.cls(cl, "class_465", "net.minecraft.client.gui.screen.ingame.HandledScreen");
      cCreativeScreen = Refl.cls(cl, "class_481", "net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen");
      cScreenHandler = Refl.cls(cl, "class_1703", "net.minecraft.screen.ScreenHandler");
      cSlot = Refl.cls(cl, "class_1735", "net.minecraft.screen.slot.Slot");
      cRegistryEntry = Refl.cls(cl, "class_6880", "net.minecraft.registry.entry.RegistryEntry");
      cKeyBinding = Refl.cls(cl, "class_304", "net.minecraft.client.option.KeyBinding");
   }

   private static void resolveMembers() {
      ClassLoader cl = mcLoader;
      Class<?> cWindow = Refl.cls(cl, "class_1041", "net.minecraft.client.util.Window");
      Class<?> cOptions = Refl.cls(cl, "class_315", "net.minecraft.client.option.GameOptions");
      Class<?> cActionResult = Refl.cls(cl, "class_1269", "net.minecraft.util.ActionResult");
      Class<?> cStatusEffects = Refl.cls(cl, "class_1294", "net.minecraft.entity.effect.StatusEffects");
      Class<?> cHitType = Refl.cls(cl, "class_239$class_240", "net.minecraft.util.hit.HitResult$Type");
      fPlayer = Refl.field(cMinecraftClient, "field_1724", "player");
      fWorld = Refl.field(cMinecraftClient, "field_1687", "world");
      fInteractionManager = Refl.field(cMinecraftClient, "field_1761", "interactionManager");
      fCrosshairTarget = Refl.field(cMinecraftClient, "field_1765", "crosshairTarget");
      fCurrentScreen = Refl.field(cMinecraftClient, "field_1755", "currentScreen");
      fOptions = Refl.field(cMinecraftClient, "field_1690", "options");
      fItemUseCooldown = Refl.field(cMinecraftClient, "field_1752", "itemUseCooldown");
      fGameRenderer = Refl.field(cMinecraftClient, "field_1773", "gameRenderer");
      mUpdateCrosshair = Refl.method(Refl.cls(cl, "class_757", "net.minecraft.client.render.GameRenderer"), "method_3190", "updateCrosshairTarget", Float.TYPE);
      mGetWindow = Refl.method(cMinecraftClient, "method_22683", "getWindow");
      mWindowHandle = Refl.method(cWindow, "method_4490", "getHandle");
      Class<?> cSession = Refl.cls(cl, "class_320", "net.minecraft.client.session.Session");
      Class<?> cServerInfo = Refl.cls(cl, "class_642", "net.minecraft.client.network.ServerInfo");
      Class<?> cNetworkHandler = Refl.cls(cl, "class_634", "net.minecraft.client.network.ClientPlayNetworkHandler");
      Class<?> cPlayerListEntry = Refl.cls(cl, "class_640", "net.minecraft.client.network.PlayerListEntry");
      mGetSession = Refl.method(cMinecraftClient, "method_1548", "getSession");
      mSessionUsername = Refl.method(cSession, "method_1676", "getUsername");
      mSessionUuid = Refl.method(cSession, "method_44717", "getUuidOrNull");
      mGetServerEntry = Refl.method(cMinecraftClient, "method_1558", "getCurrentServerEntry");
      mIsSingleplayer = Refl.method(cMinecraftClient, "method_1542", "isInSingleplayer");
      mGetCurrentFps = Refl.method(cMinecraftClient, "method_47599", "getCurrentFps");
      mGetNetworkHandler = Refl.method(cMinecraftClient, "method_1562", "getNetworkHandler");
      mGetPlayerListEntry = Refl.method(cNetworkHandler, "method_2871", "getPlayerListEntry", UUID.class);
      mGetLatency = Refl.method(cPlayerListEntry, "method_2959", "getLatency");
      fServerAddress = Refl.field(cServerInfo, "field_3761", "address");
      fServerName = Refl.field(cServerInfo, "field_3752", "name");
      mServerFavicon = Refl.method(cServerInfo, "method_49306", "getFavicon");
      Class<?> cCamera = Refl.cls(cl, "class_4184", "net.minecraft.client.render.Camera");
      Class<?> cTickCounter = Refl.cls(cl, "class_9779", "net.minecraft.client.render.RenderTickCounter");
      Class<?> cVec3d = Refl.cls(cl, "class_243", "net.minecraft.util.math.Vec3d");
      Class<?> cText = Refl.cls(cl, "class_2561", "net.minecraft.text.Text");
      Class<?> cPerspective = Refl.cls(cl, "class_5498", "net.minecraft.client.option.Perspective");
      Class<?> cDrawContext = Refl.cls(cl, "class_332", "net.minecraft.client.gui.DrawContext");
      Class<?> cTextRenderer = Refl.cls(cl, "class_327", "net.minecraft.client.font.TextRenderer");
      mCameraPos = Refl.method(cCamera, "method_71156", "getCameraPos");
      mTickProgress = Refl.method(cTickCounter, "method_60637", "getTickProgress", Boolean.TYPE);
      mLerpedPos = Refl.method(cEntity, "method_30950", "getLerpedPos", Float.TYPE);
      mGetPlayers = Refl.method(Refl.cls(cl, "class_638", "net.minecraft.client.world.ClientWorld"), "method_18456", "getPlayers");
      mGetName = Refl.method(cEntity, "method_5477", "getName");
      mTextGetString = Refl.method(cText, "getString", "getString");
      mGetPerspective = Refl.method(cOptions, "method_31044", "getPerspective");
      fPauseOnLostFocus = Refl.field(cOptions, "field_1837", "pauseOnLostFocus");
      mIsFirstPerson = Refl.method(cPerspective, "method_31034", "isFirstPerson");
      mGetCameraEntity = Refl.method(cMinecraftClient, "method_1560", "getCameraEntity");
      mScaleFactor = Refl.method(cWindow, "method_4495", "getScaleFactor");
      mFbWidth = Refl.method(cWindow, "method_4489", "getFramebufferWidth");
      mFbHeight = Refl.method(cWindow, "method_4506", "getFramebufferHeight");
      mDrawFill = Refl.method(cDrawContext, "method_25294", "fill", Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE);
      mDrawText = Refl.method(cDrawContext, "method_51433", "drawText", cTextRenderer, String.class, Integer.TYPE, Integer.TYPE, Integer.TYPE, Boolean.TYPE);
      mDrawGetMatrices = Refl.method(cDrawContext, "method_51448", "getMatrices");
      mTextWidth = Refl.method(cTextRenderer, "method_1727", "getWidth", String.class);
      fTextRenderer = Refl.field(cMinecraftClient, "field_1772", "textRenderer");
      fFontHeight = Refl.field(cTextRenderer, "field_2000", "fontHeight");
      fVecX = Refl.field(cVec3d, "field_1352", "x");
      fVecY = Refl.field(cVec3d, "field_1351", "y");
      fVecZ = Refl.field(cVec3d, "field_1350", "z");
      fBoxMinX = Refl.field(cBox, "field_1323", "minX");
      fBoxMinY = Refl.field(cBox, "field_1322", "minY");
      fBoxMinZ = Refl.field(cBox, "field_1321", "minZ");
      fBoxMaxX = Refl.field(cBox, "field_1320", "maxX");
      fBoxMaxY = Refl.field(cBox, "field_1325", "maxY");
      fBoxMaxZ = Refl.field(cBox, "field_1324", "maxZ");
      mGetRootVehicle = Refl.method(cEntity, "method_5668", "getRootVehicle");
      Class<?> cFramebuffer = Refl.cls(cl, "class_276", "net.minecraft.client.gl.Framebuffer");
      Class<?> cGlTexture = Refl.cls(cl, "class_10868", "net.minecraft.client.texture.GlTexture");
      mGetFramebuffer = Refl.method(cMinecraftClient, "method_1522", "getFramebuffer");
      mColorAttachment = Refl.method(cFramebuffer, "method_30277", "getColorAttachment");
      mTextureGlId = Refl.method(cGlTexture, "method_68427", "getGlId");
      mTextureWidth = Refl.method(cGlTexture, "getWidth", "getWidth", Integer.TYPE);
      mTextureHeight = Refl.method(cGlTexture, "getHeight", "getHeight", Integer.TYPE);
      Class<?> cEffectInstance = Refl.cls(cl, "class_1293", "net.minecraft.entity.effect.StatusEffectInstance");
      Class<?> cEffect = Refl.cls(cl, "class_1291", "net.minecraft.entity.effect.StatusEffect");
      mGetStatusEffects = Refl.method(cLivingEntity, "method_6026", "getStatusEffects");
      mEffectType = Refl.method(cEffectInstance, "method_5579", "getEffectType");
      mEffectAmplifier = Refl.method(cEffectInstance, "method_5578", "getAmplifier");
      mEffectDuration = Refl.method(cEffectInstance, "method_5584", "getDuration");
      mEffectInfinite = Refl.method(cEffectInstance, "method_48559", "isInfinite");
      mEffectShowIcon = Refl.method(cEffectInstance, "method_5592", "shouldShowIcon");
      mEffectName = Refl.method(cEffect, "method_5560", "getName");
      mEntryId = Refl.method(cRegistryEntry, "method_55840", "getIdAsString");
      mEntryValue = Refl.method(cRegistryEntry, "comp_349", "value");
      cTextDisplay = Refl.cls(cl, "class_8113$class_8123", "net.minecraft.entity.decoration.DisplayEntity$TextDisplayEntity");
      cArmorStand = Refl.cls(cl, "class_1531", "net.minecraft.entity.decoration.ArmorStandEntity");
      cChatScreen = Refl.cls(cl, "class_408", "net.minecraft.client.gui.screen.ChatScreen");

      try {
         Class<?> glfw = Class.forName("org.lwjgl.glfw.GLFW", false, cl);
         mGlfwGetKey = glfw.getMethod("glfwGetKey", Long.TYPE, Integer.TYPE);
         mGlfwGetMouseButton = glfw.getMethod("glfwGetMouseButton", Long.TYPE, Integer.TYPE);
         mGlfwGetWindowPos = glfw.getMethod("glfwGetWindowPos", Long.TYPE, int[].class, int[].class);
         mGlfwGetWindowSize = glfw.getMethod("glfwGetWindowSize", Long.TYPE, int[].class, int[].class);
      } catch (Throwable var48) {
         Refl.missing().add("class org.lwjgl.glfw.GLFW");
      }

      mGetInventory = Refl.method(cPlayerEntity, "method_31548", "getInventory");
      mGetMainHandStack = Refl.method(cLivingEntity, "method_6047", "getMainHandStack");
      mGetOffHandStack = Refl.method(cLivingEntity, "method_6079", "getOffHandStack");
      mSwingHand = Refl.method(cLivingEntity, "method_6104", "swingHand", cHand);
      mGetHealth = Refl.method(cLivingEntity, "method_6032", "getHealth");
      mIsDead = Refl.method(cLivingEntity, "method_29504", "isDead");
      mHasStatusEffect = Refl.method(cLivingEntity, "method_6059", "hasStatusEffect", cRegistryEntry);
      weaknessEffect = Refl.staticValue(Refl.field(cStatusEffects, "field_5911", "WEAKNESS"));
      blindnessEffect = Refl.staticValue(Refl.field(cStatusEffects, "field_5919", "BLINDNESS"));
      mGetX = Refl.method(cEntity, "method_23317", "getX");
      mGetY = Refl.method(cEntity, "method_23318", "getY");
      mGetZ = Refl.method(cEntity, "method_23321", "getZ");
      mIsRemoved = Refl.method(cEntity, "method_31481", "isRemoved");
      mDiscard = Refl.method(cEntity, "method_31472", "discard");
      mGetBoundingBox = Refl.method(cEntity, "method_5829", "getBoundingBox");
      mInvGetStack = Refl.method(cInventory, "method_5438", "getStack", Integer.TYPE);
      mInvGetSelectedSlot = Refl.method(cInventory, "method_67532", "getSelectedSlot");
      mInvSetSelectedSlot = Refl.method(cInventory, "method_61496", "setSelectedSlot", Integer.TYPE);
      mStackGetItem = Refl.method(cItemStack, "method_7909", "getItem");
      mStackIsEmpty = Refl.method(cItemStack, "method_7960", "isEmpty");
      mInteractBlock = Refl.method(cInteractionManager, "method_2896", "interactBlock", cClientPlayer, cHand, cBlockHitResult);
      mInteractItem = Refl.method(cInteractionManager, "method_2919", "interactItem", cPlayerEntity, cHand);
      mAttackEntity = Refl.method(cInteractionManager, "method_2918", "attackEntity", cPlayerEntity, cEntity);
      mClickSlot = Refl.method(cInteractionManager, "method_2906", "clickSlot", Integer.TYPE, Integer.TYPE, Integer.TYPE, cSlotActionType, cPlayerEntity);
      mSyncSelectedSlot = Refl.method(cInteractionManager, "method_2911", "syncSelectedSlot");
      mIsAccepted = Refl.method(cActionResult, "method_23665", "isAccepted");
      handMain = Refl.enumConstant(cHand, "MAIN_HAND");
      actionSwap = Refl.enumConstant(cSlotActionType, "SWAP");
      actionPickup = Refl.enumConstant(cSlotActionType, "PICKUP");
      mGetBlockState = Refl.method(cWorld, "method_8320", "getBlockState", cBlockPos);
      mIsAir = Refl.method(cWorld, "method_22347", "isAir", cBlockPos);
      mGetBlock = Refl.method(cBlockState, "method_26204", "getBlock");
      mGetOtherEntities = Refl.method(cWorld, "method_8335", "getOtherEntities", cEntity, cBox);
      Class<?> cClientWorld = Refl.cls(cl, "class_638", "net.minecraft.client.world.ClientWorld");
      mGetEntities = Refl.method(cClientWorld, "method_18112", "getEntities");
      mPosUp = Refl.method(cBlockPos, "method_10084", "up");
      mPosX = Refl.method(cBlockPos, "method_10263", "getX");
      mPosY = Refl.method(cBlockPos, "method_10264", "getY");
      mPosZ = Refl.method(cBlockPos, "method_10260", "getZ");
      ctorBlockPos = constructor(cBlockPos, Integer.TYPE, Integer.TYPE, Integer.TYPE);
      ctorBox = constructor(cBox, Double.TYPE, Double.TYPE, Double.TYPE, Double.TYPE, Double.TYPE, Double.TYPE);
      mHitType = Refl.method(cHitResult, "method_17783", "getType");
      hitTypeBlock = Refl.enumConstant(cHitType, "BLOCK");
      mHitBlockPos = Refl.method(cBlockHitResult, "method_17777", "getBlockPos");
      mHitEntity = Refl.method(cEntityHitResult, "method_17782", "getEntity");
      mHitSide = Refl.method(cBlockHitResult, "method_17780", "getSide");
      Class<?> cDirection = Refl.cls(cl, "class_2350", "net.minecraft.util.math.Direction");
      mPosOffset = Refl.method(cBlockPos, "method_10093", "offset", cDirection);
      fFocusedSlot = Refl.field(cHandledScreen, "field_2787", "focusedSlot");
      fScreenHandler = Refl.field(cHandledScreen, "field_2797", "handler");
      fSyncId = Refl.field(cScreenHandler, "field_7763", "syncId");
      fSlotId = Refl.field(cSlot, "field_7874", "id");
      mSlotGetStack = Refl.method(cSlot, "method_7677", "getStack");
      fUseKey = Refl.field(cOptions, "field_1904", "useKey");
      mSetPressed = Refl.method(cKeyBinding, "method_23481", "setPressed", Boolean.TYPE);
      Class<?> cSimpleOption = Refl.cls(cl, "class_7172", "net.minecraft.client.option.SimpleOption");
      mGetGamma = Refl.method(cOptions, "method_42473", "getGamma");
      fOptionValue = Refl.field(cSimpleOption, "field_37868", "value");
      Class<?> cSkinTextures = Refl.cls(cl, "class_8685", "net.minecraft.entity.player.SkinTextures");
      Class<?> cTextureAsset = Refl.cls(cl, "class_12079$class_12081", "net.minecraft.util.AssetInfo$TextureAsset");
      Class<?> cIdentifier = Refl.cls(cl, "class_2960", "net.minecraft.util.Identifier");
      Class<?> cTextureManager = Refl.cls(cl, "class_1060", "net.minecraft.client.texture.TextureManager");
      Class<?> cAbstractTexture = Refl.cls(cl, "class_1044", "net.minecraft.client.texture.AbstractTexture");
      cClientPlayerLike = Refl.cls(cl, "class_11901", "net.minecraft.client.network.ClientPlayerLikeEntity");
      cInventoryScreen = Refl.cls(cl, "class_490", "net.minecraft.client.gui.screen.ingame.InventoryScreen");
      mIsBlocking = Refl.method(cLivingEntity, "method_6039", "isBlocking");
      mGetMaxHealth = Refl.method(cLivingEntity, "method_6063", "getMaxHealth");
      mGetAbsorption = Refl.method(cLivingEntity, "method_6067", "getAbsorptionAmount");
      fHurtTime = Refl.field(cLivingEntity, "field_6235", "hurtTime");
      mGetUuid = Refl.method(cEntity, "method_5667", "getUuid");
      mGetYaw = Refl.method(cEntity, "method_36454", "getYaw");
      mGetSkin = Refl.method(cClientPlayerLike, "method_52814", "getSkin");
      mSkinBody = Refl.method(cSkinTextures, "comp_1626", "body");
      mAssetTexturePath = Refl.method(cTextureAsset, "comp_3627", "texturePath");
      mGetTextureManager = Refl.method(cMinecraftClient, "method_1531", "getTextureManager");
      mGetTexture = Refl.method(cTextureManager, "method_4619", "getTexture", cIdentifier);
      mGetGlTexture = Refl.method(cAbstractTexture, "method_68004", "getGlTexture");
      Class<?> cItemEnchantments = Refl.cls(cl, "class_9304", "net.minecraft.component.type.ItemEnchantmentsComponent");
      mStackDamage = Refl.method(cItemStack, "method_7919", "getDamage");
      mStackMaxDamage = Refl.method(cItemStack, "method_7936", "getMaxDamage");
      mStackEnchantments = Refl.method(cItemStack, "method_58657", "getEnchantments");
      mEnchantmentEntries = Refl.method(cItemEnchantments, "method_57539", "getEnchantmentEntries");
      fCurrentScreenHandler = Refl.field(cPlayerEntity, "field_7512", "currentScreenHandler");
      mGetCursorStack = Refl.method(cScreenHandler, "method_34255", "getCursorStack");
      Class<?> cChunk = Refl.cls(cl, "class_2791", "net.minecraft.world.chunk.Chunk");
      Class<?> cChunkSection = Refl.cls(cl, "class_2826", "net.minecraft.world.chunk.ChunkSection");
      Class<?> cHeightLimitView = Refl.cls(cl, "class_5539", "net.minecraft.world.HeightLimitView");
      Class<?> cBlock = Refl.cls(cl, "class_2248", "net.minecraft.block.Block");
      Class<?> cMapColor = Refl.cls(cl, "class_3620", "net.minecraft.block.MapColor");
      Class<?> cBlockView = Refl.cls(cl, "class_1922", "net.minecraft.world.BlockView");
      Class<?> cRegistries = Refl.cls(cl, "class_7923", "net.minecraft.registry.Registries");
      mWorldGetChunk = Refl.method(cWorld, "method_8497", "getChunk", Integer.TYPE, Integer.TYPE);
      mChunkSections = Refl.method(cChunk, "method_12006", "getSectionArray");
      mSectionIsEmpty = Refl.method(cChunkSection, "method_38292", "isEmpty");
      mSectionHasAny = Refl.method(cChunkSection, "method_19523", "hasAny", Predicate.class);
      mSectionGetState = Refl.method(cChunkSection, "method_12254", "getBlockState", Integer.TYPE, Integer.TYPE, Integer.TYPE);
      mBottomSectionCoord = Refl.method(cHeightLimitView, "method_32891", "getBottomSectionCoord");
      mBlockName = Refl.method(cBlock, "method_9518", "getName");
      mDefaultState = Refl.method(cBlock, "method_9564", "getDefaultState");
      mMapColor = Refl.method(cBlockState, "method_26205", "getMapColor", cBlockView, cBlockPos);
      fMapColorValue = Refl.field(cMapColor, "field_16011", "color");
      blockRegistry = Refl.staticValue(Refl.field(cRegistries, "field_41175", "BLOCK"));
      originPos = Refl.staticValue(Refl.field(cBlockPos, "field_10980", "ORIGIN"));
      Class<?> cStatusPacket = Refl.cls(cl, "class_2663", "net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket");
      mStatusGetStatus = Refl.method(cStatusPacket, "method_11470", "getStatus");
      mStatusGetEntity = Refl.method(cStatusPacket, "method_11469", "getEntity", cWorld);
      cActionSuccess = Refl.cls(cl, "class_1269$class_9860", "net.minecraft.util.ActionResult$Success");
      Class<?> cSwingSource = Refl.cls(cl, "class_1269$class_9861", "net.minecraft.util.ActionResult$SwingSource");
      Class<?> cPacket = Refl.cls(cl, "class_2596", "net.minecraft.network.packet.Packet");
      Class<?> cCloseScreenPacket = Refl.cls(cl, "class_2815", "net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket");
      mIsUsingItem = Refl.method(cLivingEntity, "method_6115", "isUsingItem");
      mIsRiding = Refl.method(cClientPlayer, "method_3144", "isRiding");
      mBelowMinAttackCharge = Refl.method(cPlayerEntity, "method_75202", "isBelowMinimumAttackCharge", cItemStack, Integer.TYPE);
      mIsBreakingBlock = Refl.method(cInteractionManager, "method_2923", "isBreakingBlock");
      mSwingSource = Refl.method(cActionSuccess, "comp_2909", "swingSource");
      swingClient = Refl.staticValue(Refl.field(cSwingSource, "field_52427", "CLIENT"));
      mSendPacket = Refl.method(cNetworkHandler, "method_52787", "sendPacket", cPacket);
      ctorCloseScreenPacket = constructor(cCloseScreenPacket, Integer.TYPE);
      Class<?> cCollisionView = Refl.cls(cl, "class_1941", "net.minecraft.world.CollisionView");
      mGetVelocity = Refl.method(cEntity, "method_18798", "getVelocity");
      mIsOnGround = Refl.method(cEntity, "method_24828", "isOnGround");
      mIsGliding = Refl.method(cLivingEntity, "method_6128", "isGliding");
      mIsTouchingWater = Refl.method(cEntity, "method_5799", "isTouchingWater");
      mIsInLava = Refl.method(cEntity, "method_5771", "isInLava");
      mIsClimbing = Refl.method(cLivingEntity, "method_6101", "isClimbing");
      mHasVehicle = Refl.method(cEntity, "method_5765", "hasVehicle");
      mGetPitch = Refl.method(cEntity, "method_36455", "getPitch");
      mChangeLook = Refl.method(cEntity, "method_5872", "changeLookDirection", Double.TYPE, Double.TYPE);
      mGetEyeY = Refl.method(cEntity, "method_23320", "getEyeY");
      mInteractionRange = Refl.method(cPlayerEntity, "method_55755", "getEntityInteractionRange");
      mIsSpaceEmpty = Refl.method(cCollisionView, "method_8587", "isSpaceEmpty", cEntity, cBox);
      mBoxOffset = Refl.method(cBox, "method_989", "offset", Double.TYPE, Double.TYPE, Double.TYPE);
      mAttackCooldown = Refl.method(cPlayerEntity, "method_7261", "getAttackCooldownProgress", Float.TYPE);
      mIsSprinting = Refl.method(cEntity, "method_5624", "isSprinting");
      fFallDistance = Refl.field(cEntity, "field_6017", "fallDistance");
      fLastX = Refl.field(cEntity, "field_6014", "lastX");
      fLastY = Refl.field(cEntity, "field_6036", "lastY");
      fLastZ = Refl.field(cEntity, "field_5969", "lastZ");
      Class<?> cMouse = Refl.cls(cl, "class_312", "net.minecraft.client.Mouse");
      fMouseDeltaX = Refl.field(cMouse, "field_1789", "cursorDeltaX");
      fMouseDeltaY = Refl.field(cMouse, "field_1787", "cursorDeltaY");
      mIsReplaceable = Refl.method(cBlockState, "method_45474", "isReplaceable");
      mBlockRange = Refl.method(cPlayerEntity, "method_55754", "getBlockInteractionRange");
      Class<?> cInputKey = Refl.cls(cl, "class_3675$class_306", "net.minecraft.client.util.InputUtil$Key");
      Class<?> cInputType = Refl.cls(cl, "class_3675$class_307", "net.minecraft.client.util.InputUtil$Type");
      fForwardKey = Refl.field(cOptions, "field_1894", "forwardKey");
      fBackKey = Refl.field(cOptions, "field_1881", "backKey");
      fLeftKey = Refl.field(cOptions, "field_1913", "leftKey");
      fRightKey = Refl.field(cOptions, "field_1849", "rightKey");
      fJumpKey = Refl.field(cOptions, "field_1903", "jumpKey");
      fSneakKey = Refl.field(cOptions, "field_1832", "sneakKey");
      fSprintKey = Refl.field(cOptions, "field_1867", "sprintKey");
      fBoundKey = Refl.field(cKeyBinding, "field_1655", "boundKey");
      fKeyPressed = Refl.field(cKeyBinding, "field_1653", "pressed");
      mKeyCode = Refl.method(cInputKey, "method_1444", "getCode");
      mKeyCategory = Refl.method(cInputKey, "method_1442", "getCategory");
      inputTypeMouse = Refl.staticValue(Refl.field(cInputType, "field_1672", "MOUSE"));
      Class<?> cParentElement = Refl.cls(cl, "class_4069", "net.minecraft.client.gui.ParentElement");
      Class<?> cElement = Refl.cls(cl, "class_364", "net.minecraft.client.gui.Element");
      Class<?> cRecipeBookWidget = Refl.cls(cl, "class_507", "net.minecraft.client.gui.screen.recipebook.RecipeBookWidget");
      cRecipeBookScreen = Refl.cls(cl, "class_10260", "net.minecraft.client.gui.screen.ingame.RecipeBookScreen");
      cTextField = Refl.cls(cl, "class_342", "net.minecraft.client.gui.widget.TextFieldWidget");
      fJumpingCooldown = Refl.field(cLivingEntity, "field_6228", "jumpingCooldown");
      mSetPitch = Refl.method(cEntity, "method_36457", "setPitch", Float.TYPE);
      mIsSneaking = Refl.method(cEntity, "method_5715", "isSneaking");
      mCanSee = Refl.method(cLivingEntity, "method_6057", "canSee", cEntity);
      mCancelBlockBreaking = Refl.method(cInteractionManager, "method_2925", "cancelBlockBreaking");
      mIsInvisible = Refl.method(cEntity, "method_5767", "isInvisible");
      mIsTeammate = Refl.method(cEntity, "method_5722", "isTeammate", cEntity);
      mGetFocused = Refl.method(cParentElement, "method_25399", "getFocused");
      mIsFocused = Refl.method(cElement, "method_25370", "isFocused");
      fRecipeBook = Refl.field(cRecipeBookScreen, "field_54474", "recipeBook");
      fRecipeSearch = Refl.field(cRecipeBookWidget, "field_3089", "searchField");
   }

   private static Constructor<?> constructor(Class<?> c, Class<?>... params) {
      if (c == null) {
         return null;
      } else {
         try {
            return c.getConstructor(params);
         } catch (Throwable var3) {
            Refl.missing().add("constructor " + c.getName());
            return null;
         }
      }
   }

   public static boolean isInitialized() {
      return initialized;
   }

   public static void onClientTick() {
      MainThread.drain();
      ++tickCount;
      Object world = getWorld();
      if (world != lastWorld) {
         lastWorld = world;
         PopTracker.clear();
      }

      if (isInGame()) {
         if (pendingSlot != -1) {
            invoke(mInvSetSelectedSlot, getInventory(), pendingSlot);
            pendingSlot = -1;
         }

         PopTracker.tick();
         Module exclusive = null;

         for(Module m : ModuleManager.getModules()) {
            if (m.isEnabled() && m.isExclusive()) {
               exclusive = m;
            }
         }

         inModuleTick = true;

         try {
            for(Module m : ModuleManager.getModules()) {
               if (m.isEnabled() && (exclusive == null || m == exclusive)) {
                  try {
                     m.onTick();
                  } catch (Throwable t) {
                     PrintStream var10000 = System.err;
                     String var10001 = m.getName();
                     var10000.println("[Wocky] " + var10001 + " tick failed: " + String.valueOf(t));
                  }
               }
            }
         } finally {
            inModuleTick = false;
         }

      }
   }

   public static boolean isInModuleTick() {
      return inModuleTick;
   }

   public static boolean shouldCancelItemUse() {
      if (!isInGame()) {
         return false;
      } else if (actionTick == tickCount && usedThisTick) {
         setItemUseCooldown(4);
         return true;
      } else {
         for(Module m : ModuleManager.getModules()) {
            if (m.isEnabled() && m.cancelsItemUse()) {
               setItemUseCooldown(4);
               return true;
            }
         }

         return false;
      }
   }

   public static boolean shouldCancelAttack() {
      if (!isInGame()) {
         return false;
      } else {
         for(Module m : ModuleManager.getModules()) {
            if (m.isEnabled() && m.cancelsAttack()) {
               if (isBreakingBlock()) {
                  invoke(mCancelBlockBreaking, getInteractionManager());
               }

               return true;
            }
         }

         return false;
      }
   }

   public static long getTickCount() {
      return tickCount;
   }

   public static Object getPlayer() {
      return get(fPlayer, mc);
   }

   public static Object getWorld() {
      return get(fWorld, mc);
   }

   public static Object getInteractionManager() {
      return get(fInteractionManager, mc);
   }

   public static Object getCrosshairTarget() {
      return get(fCrosshairTarget, mc);
   }

   public static Object getCurrentScreen() {
      return get(fCurrentScreen, mc);
   }

   public static void refreshCrosshair() {
      if (crosshairRefreshTick != tickCount) {
         crosshairRefreshTick = tickCount;
         invoke(mUpdateCrosshair, get(fGameRenderer, mc), 1.0F);
      }
   }

   public static boolean isInGame() {
      return mc != null && getPlayer() != null && getWorld() != null && getInteractionManager() != null;
   }

   public static void setItemUseCooldown(int ticks) {
      try {
         if (fItemUseCooldown != null && mc != null) {
            fItemUseCooldown.setInt(mc, ticks);
         }
      } catch (Throwable var2) {
      }

   }

   public static void setUseKeyPressed(boolean pressed) {
      Object options = get(fOptions, mc);
      Object useKey = get(fUseKey, options);
      invoke(mSetPressed, useKey, pressed);
   }

   public static String getSessionUsername() {
      Object r = invoke(mSessionUsername, invoke(mGetSession, mc));
      String var10000;
      if (r instanceof String s) {
         var10000 = s;
      } else {
         var10000 = "";
      }

      return var10000;
   }

   public static UUID getSessionUuid() {
      Object r = invoke(mSessionUuid, invoke(mGetSession, mc));
      UUID var10000;
      if (r instanceof UUID u) {
         var10000 = u;
      } else {
         var10000 = null;
      }

      return var10000;
   }

   public static boolean isSingleplayer() {
      return Boolean.TRUE.equals(invoke(mIsSingleplayer, mc));
   }

   private static Object getServerEntry() {
      return invoke(mGetServerEntry, mc);
   }

   public static String getServerAddress() {
      Object r = get(fServerAddress, getServerEntry());
      String var10000;
      if (r instanceof String s) {
         var10000 = s;
      } else {
         var10000 = "";
      }

      return var10000;
   }

   public static String getServerName() {
      Object r = get(fServerName, getServerEntry());
      String var10000;
      if (r instanceof String s) {
         var10000 = s;
      } else {
         var10000 = "";
      }

      return var10000;
   }

   public static byte[] getServerFavicon() {
      Object r = invoke(mServerFavicon, getServerEntry());
      byte[] var10000;
      if (r instanceof byte[] b) {
         var10000 = b;
      } else {
         var10000 = null;
      }

      return var10000;
   }

   public static int getCurrentFps() {
      Object r = invoke(mGetCurrentFps, mc);
      int var10000;
      if (r instanceof Integer i) {
         var10000 = i;
      } else {
         var10000 = 0;
      }

      return var10000;
   }

   public static int getPing() {
      UUID uuid = getSessionUuid();
      Object handler = invoke(mGetNetworkHandler, mc);
      if (uuid != null && handler != null) {
         Object r = invoke(mGetLatency, invoke(mGetPlayerListEntry, handler, uuid));
         int var10000;
         if (r instanceof Integer) {
            Integer i = (Integer)r;
            var10000 = i;
         } else {
            var10000 = -1;
         }

         return var10000;
      } else {
         return -1;
      }
   }

   public static void onWorldRender(Object[] args) {
      frame.valid = false;
      Object pos = invoke(mCameraPos, args[1]);
      if (pos != null && copyMatrix(args[2], frame.view) && copyMatrix(args[3], frame.projection)) {
         frame.camX = getDouble(fVecX, pos);
         frame.camY = getDouble(fVecY, pos);
         frame.camZ = getDouble(fVecZ, pos);
         Object td = invoke(mTickProgress, args[0], true);
         Frame var10000 = frame;
         float var10001;
         if (td instanceof Float) {
            Float f = (Float)td;
            var10001 = f;
         } else {
            var10001 = 1.0F;
         }

         var10000.tickDelta = var10001;
         frame.valid = true;
      }
   }

   public static void onHudRender(Object drawContext) {
      if (frame.valid && isInGame()) {
         Object window = invoke(mGetWindow, mc);
         Object sf = invoke(mScaleFactor, window);
         Object fw = invoke(mFbWidth, window);
         Object fh = invoke(mFbHeight, window);
         if (sf instanceof Integer) {
            Integer scale = (Integer)sf;
            if (fw instanceof Integer) {
               Integer w = (Integer)fw;
               if (fh instanceof Integer) {
                  Integer h = (Integer)fh;
                  hud.begin(drawContext, frame, Math.max(1, scale), w, h);

                  try {
                     for(Module m : ModuleManager.getModules()) {
                        if (m.isEnabled()) {
                           try {
                              m.onHudRender(hud);
                           } catch (Throwable t) {
                              PrintStream var10000 = System.err;
                              String var10001 = m.getName();
                              var10000.println("[Wocky] " + var10001 + " render failed: " + String.valueOf(t));
                           }
                        }
                     }
                  } finally {
                     hud.end();
                  }

                  return;
               }
            }
         }

      }
   }

   public static Object onHook(String id, Object arg) {
      switch (id) {
         case "hideLabel":
            return espTagsActive();
         case "hideEffects":
            return effectsHud != null && effectsHud.isEnabled();
         case "hideEntity":
            return espTagsActive() && isServerNametag(arg);
         case "beforeBlit":
            if (arg != null && arg == invoke(mGetFramebuffer, mc)) {
               Object tex = invoke(mColorAttachment, arg);
               Object texId = invoke(mTextureGlId, tex);
               Object w = invoke(mTextureWidth, tex, 0);
               Object h = invoke(mTextureHeight, tex, 0);
               if (texId instanceof Integer) {
                  Integer glId = (Integer)texId;
                  if (w instanceof Integer) {
                     Integer tw = (Integer)w;
                     if (h instanceof Integer) {
                        Integer th = (Integer)h;
                        GlOverlay.drawInto(glId, tw, th);
                     }
                  }
               }

               return null;
            }

            return null;
         case "lockMouse":
            if (!mouseLocked) {
               return false;
            }

            try {
               fMouseDeltaX.setDouble(arg, (double)0.0F);
               fMouseDeltaY.setDouble(arg, (double)0.0F);
            } catch (Throwable var11) {
            }

            return true;
         case "clickSlot":
            return !replayingClick && invWalk != null && invWalk.isEnabled() && invWalk.deferClick(arg);
         case "entityStatus":
            if (MainThread.isOnThread()) {
               PopTracker.onEntityStatus(arg);
            }

            return null;
         default:
            return null;
      }
   }

   public static void bindHudModules() {
      esp = (PlayerESP)ModuleManager.getByClass(PlayerESP.class);
      effectsHud = (StatusEffectsHud)ModuleManager.getByClass(StatusEffectsHud.class);
      invWalk = (InvWalk)ModuleManager.getByClass(InvWalk.class);
   }

   private static boolean espTagsActive() {
      return esp != null && esp.isEnabled() && esp.drawsNametags();
   }

   private static boolean isServerNametag(Object entity) {
      if (!isInstance(cTextDisplay, entity) && !isInstance(cArmorStand, entity)) {
         return false;
      } else {
         Object root = invoke(mGetRootVehicle, entity);
         return root != entity && isInstance(cPlayerEntity, root);
      }
   }

   public static List<Effect> getPlayerEffects() {
      Object r = invoke(mGetStatusEffects, getPlayer());
      if (r instanceof Collection<?> all) {
         ArrayList out = new ArrayList();

         for(Object inst : new ArrayList(all)) {
            if (Boolean.TRUE.equals(invoke(mEffectShowIcon, inst))) {
               Object entry = invoke(mEffectType, inst);
               Object id = invoke(mEntryId, entry);
               Object name = invoke(mTextGetString, invoke(mEffectName, invoke(mEntryValue, entry)));
               Object amp = invoke(mEffectAmplifier, inst);
               Object dur = invoke(mEffectDuration, inst);
               if (id instanceof String) {
                  String s = (String)id;
                  String path = s.contains(":") ? s.substring(s.indexOf(58) + 1) : s;
                  Effect var10001 = new Effect;
                  String var10004;
                  if (name instanceof String) {
                     String n = (String)name;
                     var10004 = n;
                  } else {
                     var10004 = path;
                  }

                  int var10005;
                  if (amp instanceof Integer) {
                     Integer a = (Integer)amp;
                     var10005 = a;
                  } else {
                     var10005 = 0;
                  }

                  int var10006;
                  if (dur instanceof Integer) {
                     Integer d = (Integer)dur;
                     var10006 = d;
                  } else {
                     var10006 = 0;
                  }

                  var10001.<init>(path, var10004, var10005, var10006, Boolean.TRUE.equals(invoke(mEffectInfinite, inst)));
                  out.add(var10001);
               }
            }
         }

         return out;
      } else {
         return Collections.emptyList();
      }
   }

   public static byte[] getEffectIconPng(String idPath) {
      try {
         InputStream in = mcLoader.getResourceAsStream("assets/minecraft/textures/mob_effect/" + idPath + ".png");

         byte[] var2;
         try {
            var2 = in == null ? null : in.readAllBytes();
         } catch (Throwable var5) {
            if (in != null) {
               try {
                  in.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }
            }

            throw var5;
         }

         if (in != null) {
            in.close();
         }

         return var2;
      } catch (Throwable var6) {
         return null;
      }
   }

   public static boolean isHudEditing() {
      return hudEditing;
   }

   public static boolean isHudVisible() {
      return hudEditing || isHudOnlyScreen();
   }

   public static void setHudEditing(boolean on) {
      if (on != hudEditing) {
         Object options = get(fOptions, mc);

         try {
            if (on) {
               savedPauseOnLostFocus = fPauseOnLostFocus.getBoolean(options);
               fPauseOnLostFocus.setBoolean(options, false);
            } else if (savedPauseOnLostFocus != null) {
               fPauseOnLostFocus.setBoolean(options, savedPauseOnLostFocus);
               savedPauseOnLostFocus = null;
            }
         } catch (Throwable var3) {
         }

         hudEditing = on;
      }
   }

   public static String hudJson() {
      JsonObject o = new JsonObject();
      long handle = getWindowHandle();
      int[] x = new int[1];
      int[] y = new int[1];
      int[] w = new int[1];
      int[] h = new int[1];
      invokeStatic(mGlfwGetWindowPos, handle, x, y);
      invokeStatic(mGlfwGetWindowSize, handle, w, h);
      JsonArray win = new JsonArray();
      win.add((Number)x[0]);
      win.add((Number)y[0]);
      win.add((Number)w[0]);
      win.add((Number)h[0]);
      o.add("window", win);
      Object window = invoke(mGetWindow, mc);
      JsonArray fb = new JsonArray();
      fb.add((Number)((Integer)invoke(mFbWidth, window)));
      fb.add((Number)((Integer)invoke(mFbHeight, window)));
      o.add("framebuffer", fb);
      JsonArray elements = new JsonArray();
      float[] rects = GlOverlay.lastRects();

      for(int i = 0; rects != null && i < HUD_SLOTS.length; ++i) {
         if (!Float.isNaN(rects[i * 4])) {
            Module m = ModuleManager.getByClass(HUD_SLOTS[i].asSubclass(Module.class));
            if (m != null) {
               JsonObject e = new JsonObject();
               e.addProperty("id", m.getName());
               JsonArray r = new JsonArray();

               for(int k = 0; k < 4; ++k) {
                  r.add((Number)rects[i * 4 + k]);
               }

               e.add("rect", r);
               elements.add((JsonElement)e);
            }
         }
      }

      o.add("elements", elements);
      return o.toString();
   }

   public static boolean hudMove(String id, float x, float y) {
      float[] rects = GlOverlay.lastRects();
      Object window = invoke(mGetWindow, mc);
      Object fw = invoke(mFbWidth, window);
      Object fh = invoke(mFbHeight, window);
      if (rects != null && fw instanceof Integer sw) {
         if (fh instanceof Integer sh) {
            for(int i = 0; i < HUD_SLOTS.length; ++i) {
               Module m = ModuleManager.getByClass(HUD_SLOTS[i].asSubclass(Module.class));
               if (m instanceof HudElement el) {
                  if (m.getName().equalsIgnoreCase(id)) {
                     if (Float.isNaN(rects[i * 4])) {
                        return false;
                     }

                     el.hudPosition().place(x, y, rects[i * 4 + 2] - rects[i * 4], rects[i * 4 + 3] - rects[i * 4 + 1], (float)sw, (float)sh);
                     ModuleManager.saveConfig();
                     return true;
                  }
               }
            }

            return false;
         }
      }

      return false;
   }

   public static void hudReset(String id) {
      for(Module m : ModuleManager.getModules()) {
         if (m instanceof HudElement el) {
            if (id == null || m.getName().equalsIgnoreCase(id)) {
               el.hudPosition().reset();
            }
         }
      }

      ModuleManager.saveConfig();
   }

   public static boolean isHudOnlyScreen() {
      Object screen = getCurrentScreen();
      return screen == null || isInstance(cChatScreen, screen);
   }

   private static boolean copyMatrix(Object matrix, float[] out) {
      if (matrix == null) {
         return false;
      } else {
         try {
            if (mMatrix4fGet == null) {
               mMatrix4fGet = matrix.getClass().getMethod("get", float[].class);
            }

            mMatrix4fGet.invoke(matrix, out);
            return true;
         } catch (Throwable var3) {
            return false;
         }
      }
   }

   private static double getDouble(Field f, Object owner) {
      Object r = get(f, owner);
      double var10000;
      if (r instanceof Double d) {
         var10000 = d;
      } else {
         var10000 = (double)0.0F;
      }

      return var10000;
   }

   public static List<Object> getPlayers() {
      Object r = invoke(mGetPlayers, getWorld());
      Object var10000;
      if (r instanceof List<?> l) {
         var10000 = new ArrayList(l);
      } else {
         var10000 = Collections.emptyList();
      }

      return (List<Object>)var10000;
   }

   public static Object getCameraEntity() {
      return invoke(mGetCameraEntity, mc);
   }

   public static boolean isFirstPerson() {
      Object perspective = invoke(mGetPerspective, get(fOptions, mc));
      return perspective == null || Boolean.TRUE.equals(invoke(mIsFirstPerson, perspective));
   }

   public static double[] getLerpedPos(Object entity, float tickDelta) {
      Object v = invoke(mLerpedPos, entity, tickDelta);
      return v == null ? null : new double[]{getDouble(fVecX, v), getDouble(fVecY, v), getDouble(fVecZ, v)};
   }

   public static double[] getBoundingBox(Object entity) {
      Object b = invoke(mGetBoundingBox, entity);
      return b == null ? null : new double[]{getDouble(fBoxMinX, b), getDouble(fBoxMinY, b), getDouble(fBoxMinZ, b), getDouble(fBoxMaxX, b), getDouble(fBoxMaxY, b), getDouble(fBoxMaxZ, b)};
   }

   public static boolean isDead(Object entity) {
      return Boolean.TRUE.equals(invoke(mIsDead, entity));
   }

   public static String getEntityName(Object entity) {
      Object r = invoke(mTextGetString, invoke(mGetName, entity));
      String var10000;
      if (r instanceof String s) {
         var10000 = s;
      } else {
         var10000 = "";
      }

      return var10000;
   }

   public static void drawFill(Object ctx, int x1, int y1, int x2, int y2, int argb) {
      invoke(mDrawFill, ctx, x1, y1, x2, y2, argb);
   }

   public static void drawText(Object ctx, String text, int x, int y, int argb, boolean shadow) {
      invoke(mDrawText, ctx, get(fTextRenderer, mc), text, x, y, argb, shadow);
   }

   public static int textWidth(String text) {
      Object r = invoke(mTextWidth, get(fTextRenderer, mc), text);
      int var10000;
      if (r instanceof Integer i) {
         var10000 = i;
      } else {
         var10000 = 0;
      }

      return var10000;
   }

   public static int fontHeight() {
      Object r = get(fFontHeight, get(fTextRenderer, mc));
      int var10000;
      if (r instanceof Integer i) {
         var10000 = i;
      } else {
         var10000 = 9;
      }

      return var10000;
   }

   public static void pushDrawScale(Object ctx, float scale) {
      Object stack = invoke(mDrawGetMatrices, ctx);
      if (stack != null) {
         try {
            if (mStackPush == null) {
               mStackPush = stack.getClass().getMethod("pushMatrix");
               mStackPop = stack.getClass().getMethod("popMatrix");
               mStackScale = stack.getClass().getMethod("scale", Float.TYPE, Float.TYPE);
            }

            mStackPush.invoke(stack);
            mStackScale.invoke(stack, scale, scale);
         } catch (Throwable var4) {
         }

      }
   }

   public static void popDrawScale(Object ctx) {
      Object stack = invoke(mDrawGetMatrices, ctx);

      try {
         if (stack != null && mStackPop != null) {
            mStackPop.invoke(stack);
         }
      } catch (Throwable var3) {
      }

   }

   public static long getWindowHandle() {
      Object window = invoke(mGetWindow, mc);
      Object handle = invoke(mWindowHandle, window);
      long var10000;
      if (handle instanceof Long l) {
         var10000 = l;
      } else {
         var10000 = 0L;
      }

      return var10000;
   }

   public static int getGlfwKey(int key) {
      long handle = getWindowHandle();
      if (mGlfwGetKey != null && handle != 0L) {
         Object r = invokeStatic(mGlfwGetKey, handle, key);
         int var10000;
         if (r instanceof Integer) {
            Integer i = (Integer)r;
            var10000 = i;
         } else {
            var10000 = 0;
         }

         return var10000;
      } else {
         return 0;
      }
   }

   public static int getGlfwMouseButton(int button) {
      long handle = getWindowHandle();
      if (mGlfwGetMouseButton != null && handle != 0L) {
         Object r = invokeStatic(mGlfwGetMouseButton, handle, button);
         int var10000;
         if (r instanceof Integer) {
            Integer i = (Integer)r;
            var10000 = i;
         } else {
            var10000 = 0;
         }

         return var10000;
      } else {
         return 0;
      }
   }

   public static boolean isKeyDown(int key) {
      if (key <= 0) {
         return false;
      } else if (key >= 1001 && key <= 1005) {
         return getGlfwMouseButton(key - 1001) == 1;
      } else {
         return getGlfwKey(key) == 1;
      }
   }

   public static String itemId(Object stack) {
      if (stack != null && !Boolean.TRUE.equals(invoke(mStackIsEmpty, stack))) {
         Object item = invoke(mStackGetItem, stack);
         return item == null ? "" : (String)itemIds.computeIfAbsent(item, (i) -> stripNamespace(i.toString()));
      } else {
         return "";
      }
   }

   public static boolean isItem(Object stack, String id) {
      return itemId(stack).equals(id);
   }

   public static boolean isSword(Object stack) {
      return itemId(stack).endsWith("_sword");
   }

   public static Object getMainHandStack() {
      return invoke(mGetMainHandStack, getPlayer());
   }

   public static Object getOffHandStack() {
      return invoke(mGetOffHandStack, getPlayer());
   }

   public static boolean isHolding(String id) {
      return isItem(getMainHandStack(), id);
   }

   public static boolean isHoldingSword() {
      return isSword(getMainHandStack());
   }

   private static Object getInventory() {
      return invoke(mGetInventory, getPlayer());
   }

   public static Object getStackInSlot(int slot) {
      return invoke(mInvGetStack, getInventory(), slot);
   }

   public static int getSelectedSlot() {
      Object r = invoke(mInvGetSelectedSlot, getInventory());
      int var10000;
      if (r instanceof Integer i) {
         var10000 = i;
      } else {
         var10000 = 0;
      }

      return var10000;
   }

   public static void setSelectedSlot(int slot) {
      if (slot >= 0 && slot <= 8) {
         if (actedThisTick()) {
            pendingSlot = slot == getSelectedSlot() ? -1 : slot;
         } else {
            pendingSlot = -1;
            if (getSelectedSlot() != slot) {
               invoke(mInvSetSelectedSlot, getInventory(), slot);
            }

         }
      }
   }

   public static int findHotbarSlot(String id) {
      for(int i = 0; i < 9; ++i) {
         if (isItem(getStackInSlot(i), id)) {
            return i;
         }
      }

      return -1;
   }

   public static int findSwordSlot() {
      for(int i = 0; i < 9; ++i) {
         if (isSword(getStackInSlot(i))) {
            return i;
         }
      }

      return -1;
   }

   public static boolean isAxe(Object stack) {
      return itemId(stack).endsWith("_axe");
   }

   public static int findAxeSlot() {
      for(int i = 0; i < 9; ++i) {
         if (isAxe(getStackInSlot(i))) {
            return i;
         }
      }

      return -1;
   }

   public static boolean selectHotbarItem(String id) {
      if (isHolding(id)) {
         return true;
      } else {
         int slot = findHotbarSlot(id);
         if (slot == -1) {
            return false;
         } else {
            setSelectedSlot(slot);
            return isHolding(id);
         }
      }
   }

   public static float getPlayerHealth() {
      Object r = invoke(mGetHealth, getPlayer());
      float var10000;
      if (r instanceof Float f) {
         var10000 = f;
      } else {
         var10000 = 20.0F;
      }

      return var10000;
   }

   public static boolean hasWeakness() {
      return weaknessEffect != null && Boolean.TRUE.equals(invoke(mHasStatusEffect, getPlayer(), weaknessEffect));
   }

   public static Object blockPos(int x, int y, int z) {
      try {
         return ctorBlockPos != null ? ctorBlockPos.newInstance(x, y, z) : null;
      } catch (Throwable var4) {
         return null;
      }
   }

   public static int[] coords(Object pos) {
      if (pos == null) {
         return null;
      } else {
         Object x = invoke(mPosX, pos);
         Object y = invoke(mPosY, pos);
         Object z = invoke(mPosZ, pos);
         return x != null && y != null && z != null ? new int[]{(Integer)x, (Integer)y, (Integer)z} : null;
      }
   }

   public static String blockId(Object pos) {
      return blockIdOf(invoke(mGetBlock, getBlockState(pos)));
   }

   public static String blockIdOf(Object block) {
      return block == null ? "" : (String)blockIds.computeIfAbsent(block, (b) -> {
         String s = b.toString();
         int open = s.indexOf(123);
         int close = s.lastIndexOf(125);
         return stripNamespace(open >= 0 && close > open ? s.substring(open + 1, close) : s);
      });
   }

   public static String stateBlockId(Object state) {
      return blockIdOf(invoke(mGetBlock, state));
   }

   public static int anchorCharges(Object pos) {
      if (!blockId(pos).equals("respawn_anchor")) {
         return -1;
      } else {
         String s = blockStateString(pos);
         int i = s.indexOf("charges=");
         return i >= 0 && i + 8 < s.length() ? Character.digit(s.charAt(i + 8), 10) : 0;
      }
   }

   public static String blockStateString(Object pos) {
      Object state = getBlockState(pos);
      return state != null ? state.toString() : "";
   }

   public static boolean isAir(Object pos) {
      return Boolean.TRUE.equals(invoke(mIsAir, getWorld(), pos));
   }

   private static Object getBlockState(Object pos) {
      return pos == null ? null : invoke(mGetBlockState, getWorld(), pos);
   }

   public static boolean canPlaceCrystal(Object basePos) {
      String base = blockId(basePos);
      if (!base.equals("obsidian") && !base.equals("bedrock")) {
         return false;
      } else {
         Object up = invoke(mPosUp, basePos);
         if (up != null && isAir(up)) {
            int[] c = coords(up);
            if (c == null) {
               return false;
            } else {
               for(Object e : getEntitiesIn((double)c[0], (double)c[1], (double)c[2], (double)(c[0] + 1), (double)(c[1] + 2), (double)(c[2] + 1))) {
                  if (!isEntityRemoved(e)) {
                     return false;
                  }
               }

               return true;
            }
         } else {
            return false;
         }
      }
   }

   public static boolean isFreeForBlock(Object pos) {
      int[] c = coords(pos);
      if (c == null) {
         return false;
      } else {
         for(Object e : getEntitiesIn((double)c[0], (double)c[1], (double)c[2], (double)(c[0] + 1), (double)(c[1] + 1), (double)(c[2] + 1))) {
            if (!isEntityRemoved(e) && !isInstance(cItemEntity, e) && !isInstance(cExperienceOrb, e)) {
               return false;
            }
         }

         return true;
      }
   }

   public static Object up(Object pos) {
      return invoke(mPosUp, pos);
   }

   public static boolean isBlockHit(Object hit) {
      return isInstance(cBlockHitResult, hit) && invoke(mHitType, hit) == hitTypeBlock;
   }

   public static Object getHitBlockPos(Object hit) {
      return isInstance(cBlockHitResult, hit) ? invoke(mHitBlockPos, hit) : null;
   }

   public static Object getPlacementPos(Object hit) {
      if (!isInstance(cBlockHitResult, hit)) {
         return null;
      } else {
         Object pos = invoke(mHitBlockPos, hit);
         if (pos != null && isReplaceable(pos)) {
            return pos;
         } else {
            Object side = invoke(mHitSide, hit);
            return side != null ? invoke(mPosOffset, pos, side) : null;
         }
      }
   }

   public static boolean canPlaceBlockAt(Object hit) {
      Object pos = getPlacementPos(hit);
      return pos != null && isReplaceable(pos) && isFreeForBlock(pos);
   }

   public static Object getHitEntity(Object hit) {
      return isInstance(cEntityHitResult, hit) ? invoke(mHitEntity, hit) : null;
   }

   public static boolean isEndCrystal(Object entity) {
      return isInstance(cEndCrystal, entity);
   }

   public static boolean isEntityRemoved(Object entity) {
      return entity == null || Boolean.TRUE.equals(invoke(mIsRemoved, entity));
   }

   public static double getEntityX(Object e) {
      Object r = invoke(mGetX, e);
      double var10000;
      if (r instanceof Double d) {
         var10000 = d;
      } else {
         var10000 = (double)0.0F;
      }

      return var10000;
   }

   public static double getEntityY(Object e) {
      Object r = invoke(mGetY, e);
      double var10000;
      if (r instanceof Double d) {
         var10000 = d;
      } else {
         var10000 = (double)0.0F;
      }

      return var10000;
   }

   public static double getEntityZ(Object e) {
      Object r = invoke(mGetZ, e);
      double var10000;
      if (r instanceof Double d) {
         var10000 = d;
      } else {
         var10000 = (double)0.0F;
      }

      return var10000;
   }

   public static List<Object> getEntities() {
      Object iterable = invoke(mGetEntities, getWorld());
      if (iterable instanceof Iterable<?> it) {
         ArrayList list = new ArrayList();

         for(Object e : it) {
            if (e != null) {
               list.add(e);
            }
         }

         return list;
      } else {
         return Collections.emptyList();
      }
   }

   private static List<?> getEntitiesIn(double x1, double y1, double z1, double x2, double y2, double z2) {
      try {
         Object box = ctorBox.newInstance(x1, y1, z1, x2, y2, z2);
         Object r = invoke(mGetOtherEntities, getWorld(), null, box);
         List var10000;
         if (r instanceof List<?> l) {
            var10000 = l;
         } else {
            var10000 = Collections.emptyList();
         }

         return var10000;
      } catch (Throwable var15) {
         return Collections.emptyList();
      }
   }

   public static boolean isDeadPlayerNearby() {
      Object self = getPlayer();

      for(Object e : getEntities()) {
         if (e != self && isInstance(cPlayerEntity, e) && Boolean.TRUE.equals(invoke(mIsDead, e))) {
            return true;
         }
      }

      return false;
   }

   private static boolean actedThisTick() {
      return actionTick == tickCount && (attackedThisTick || usedThisTick);
   }

   private static void markAction(boolean use) {
      if (actionTick != tickCount) {
         actionTick = tickCount;
         attackedThisTick = false;
         usedThisTick = false;
      }

      if (use) {
         usedThisTick = true;
      } else {
         attackedThisTick = true;
      }

   }

   public static boolean canAct(boolean use) {
      Object player = getPlayer();
      if (player != null && !Boolean.TRUE.equals(invoke(mIsUsingItem, player)) && !Boolean.TRUE.equals(invoke(mIsRiding, player))) {
         if (pendingSlot != -1) {
            return false;
         } else if (!use) {
            if (actionTick == tickCount && usedThisTick) {
               return false;
            } else {
               return !Boolean.TRUE.equals(invoke(mBelowMinAttackCharge, player, getMainHandStack(), 0));
            }
         } else {
            return (actionTick != tickCount || !usedThisTick) && !Boolean.TRUE.equals(invoke(mIsBreakingBlock, getInteractionManager()));
         }
      } else {
         return false;
      }
   }

   private static void swingAfterUse(Object result, boolean swing) {
      if (swing && isInstance(cActionSuccess, result) && invoke(mSwingSource, result) == swingClient) {
         swingMainHand();
      }

   }

   public static boolean interactBlock(Object blockHit, boolean swing) {
      if (!canAct(true)) {
         return false;
      } else {
         Object result = invoke(mInteractBlock, getInteractionManager(), getPlayer(), handMain, blockHit);
         markAction(true);
         swingAfterUse(result, swing);
         return result != null && Boolean.TRUE.equals(invoke(mIsAccepted, result));
      }
   }

   public static boolean interactBlockAgain(Object blockHit, boolean swing) {
      boolean saved = usedThisTick;
      usedThisTick = false;

      boolean var3;
      try {
         var3 = interactBlock(blockHit, swing);
      } finally {
         usedThisTick = saved || usedThisTick;
      }

      return var3;
   }

   public static boolean interactItem() {
      if (!canAct(true)) {
         return false;
      } else {
         Object result = invoke(mInteractItem, getInteractionManager(), getPlayer(), handMain);
         markAction(true);
         swingAfterUse(result, true);
         return result != null && Boolean.TRUE.equals(invoke(mIsAccepted, result));
      }
   }

   public static boolean attackEntity(Object entity, boolean swing) {
      if (entity != null && canAct(false)) {
         invoke(mAttackEntity, getInteractionManager(), getPlayer(), entity);
         markAction(false);
         if (swing) {
            swingMainHand();
         }

         if (isEndCrystal(entity)) {
            CrystalOptimizer optimizer = (CrystalOptimizer)ModuleManager.getByClass(CrystalOptimizer.class);
            if (optimizer != null && optimizer.isEnabled()) {
               invoke(mDiscard, entity);
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public static void sendCloseInventory() {
      try {
         if (ctorCloseScreenPacket == null) {
            return;
         }

         invoke(mSendPacket, invoke(mGetNetworkHandler, mc), ctorCloseScreenPacket.newInstance(0));
      } catch (Throwable var1) {
      }

   }

   public static void swingMainHand() {
      invoke(mSwingHand, getPlayer(), handMain);
   }

   public static boolean clickSlot(int syncId, int slotId, int button, boolean swap) {
      if (invWalk != null && invWalk.isEnabled() && !invWalk.clickReady()) {
         return false;
      } else {
         clickSlotNow(syncId, slotId, button, swap);
         return true;
      }
   }

   public static void clickSlotNow(int syncId, int slotId, int button, boolean swap) {
      replayClick(new Object[]{getInteractionManager(), syncId, slotId, button, swap ? actionSwap : actionPickup, getPlayer()});
   }

   public static void replayClick(Object[] args) {
      replayingClick = true;

      try {
         invoke(mClickSlot, args[0], args[1], args[2], args[3], args[4], args[5]);
      } finally {
         replayingClick = false;
      }

   }

   public static boolean isHandledScreenOpen() {
      Object screen = getCurrentScreen();
      return isInstance(cHandledScreen, screen) && !isInstance(cCreativeScreen, screen);
   }

   public static int getScreenSyncId() {
      Object handler = get(fScreenHandler, getCurrentScreen());

      try {
         return handler != null && fSyncId != null ? fSyncId.getInt(handler) : -1;
      } catch (Throwable var2) {
         return -1;
      }
   }

   public static Object getFocusedSlot() {
      Object screen = getCurrentScreen();
      return isInstance(cHandledScreen, screen) ? get(fFocusedSlot, screen) : null;
   }

   public static int getSlotId(Object slot) {
      try {
         return slot != null && fSlotId != null ? fSlotId.getInt(slot) : -1;
      } catch (Throwable var2) {
         return -1;
      }
   }

   public static Object getSlotStack(Object slot) {
      return invoke(mSlotGetStack, slot);
   }

   public static boolean isPlayer(Object entity) {
      return isInstance(cPlayerEntity, entity);
   }

   public static boolean isBlocking(Object entity) {
      return Boolean.TRUE.equals(invoke(mIsBlocking, entity));
   }

   public static boolean shieldBlocksUs(Object target) {
      if (!isBlocking(target)) {
         return false;
      } else {
         Object me = getPlayer();
         double dx = getEntityX(me) - getEntityX(target);
         double dz = getEntityZ(me) - getEntityZ(target);
         double yaw = Math.toRadians((double)getYaw(target));
         return -Math.sin(yaw) * dx + Math.cos(yaw) * dz > (double)0.0F;
      }
   }

   public static float getHealth(Object entity) {
      Object r = invoke(mGetHealth, entity);
      float var10000;
      if (r instanceof Float f) {
         var10000 = f;
      } else {
         var10000 = 0.0F;
      }

      return var10000;
   }

   public static float getMaxHealth(Object entity) {
      Object r = invoke(mGetMaxHealth, entity);
      float var10000;
      if (r instanceof Float f) {
         if (f > 0.0F) {
            var10000 = f;
            return var10000;
         }
      }

      var10000 = 20.0F;
      return var10000;
   }

   public static float getAbsorption(Object entity) {
      Object r = invoke(mGetAbsorption, entity);
      float var10000;
      if (r instanceof Float f) {
         var10000 = f;
      } else {
         var10000 = 0.0F;
      }

      return var10000;
   }

   public static int getHurtTime(Object entity) {
      Object r = get(fHurtTime, entity);
      int var10000;
      if (r instanceof Integer i) {
         var10000 = i;
      } else {
         var10000 = 0;
      }

      return var10000;
   }

   public static UUID getUuid(Object entity) {
      Object r = invoke(mGetUuid, entity);
      UUID var10000;
      if (r instanceof UUID u) {
         var10000 = u;
      } else {
         var10000 = null;
      }

      return var10000;
   }

   public static float getYaw(Object entity) {
      Object r = invoke(mGetYaw, entity);
      float var10000;
      if (r instanceof Float f) {
         var10000 = f;
      } else {
         var10000 = 0.0F;
      }

      return var10000;
   }

   public static int getSkinGlId(Object player) {
      if (!isInstance(cClientPlayerLike, player)) {
         return 0;
      } else {
         Object path = invoke(mAssetTexturePath, invoke(mSkinBody, invoke(mGetSkin, player)));
         if (path == null) {
            return 0;
         } else {
            Object texture = invoke(mGetTexture, invoke(mGetTextureManager, mc), path);
            Object id = invoke(mTextureGlId, invoke(mGetGlTexture, texture));
            int var10000;
            if (id instanceof Integer) {
               Integer i = (Integer)id;
               var10000 = i;
            } else {
               var10000 = 0;
            }

            return var10000;
         }
      }
   }

   public static double[] getVelocity(Object entity) {
      Object v = invoke(mGetVelocity, entity);
      return v == null ? new double[3] : new double[]{getDouble(fVecX, v), getDouble(fVecY, v), getDouble(fVecZ, v)};
   }

   public static double[] getLastPos(Object entity) {
      return new double[]{getDouble(fLastX, entity), getDouble(fLastY, entity), getDouble(fLastZ, entity)};
   }

   public static boolean isOnGround(Object entity) {
      return Boolean.TRUE.equals(invoke(mIsOnGround, entity));
   }

   public static double getFallDistance(Object entity) {
      return getDouble(fFallDistance, entity);
   }

   public static boolean isFreeFalling(Object entity) {
      return entity != null && !isOnGround(entity) && getVelocity(entity)[1] < (double)0.0F && !Boolean.TRUE.equals(invoke(mIsGliding, entity)) && !Boolean.TRUE.equals(invoke(mIsTouchingWater, entity)) && !Boolean.TRUE.equals(invoke(mIsInLava, entity)) && !Boolean.TRUE.equals(invoke(mIsClimbing, entity)) && !Boolean.TRUE.equals(invoke(mHasVehicle, entity));
   }

   public static double getEyeY(Object entity) {
      Object r = invoke(mGetEyeY, entity);
      double var10000;
      if (r instanceof Double d) {
         var10000 = d;
      } else {
         var10000 = getEntityY(entity) + 1.62;
      }

      return var10000;
   }

   public static boolean isSprinting(Object entity) {
      return Boolean.TRUE.equals(invoke(mIsSprinting, entity));
   }

   public static float getPitch(Object entity) {
      Object r = invoke(mGetPitch, entity);
      float var10000;
      if (r instanceof Float f) {
         var10000 = f;
      } else {
         var10000 = 0.0F;
      }

      return var10000;
   }

   public static void setMouseLocked(boolean locked) {
      mouseLocked = locked;
   }

   public static boolean isMouseLocked() {
      return mouseLocked;
   }

   private static Object keyBinding(MoveKey key) {
      Object options = get(fOptions, mc);
      Field var10000;
      switch (key.ordinal()) {
         case 0 -> var10000 = fForwardKey;
         case 1 -> var10000 = fBackKey;
         case 2 -> var10000 = fLeftKey;
         case 3 -> var10000 = fRightKey;
         case 4 -> var10000 = fJumpKey;
         case 5 -> var10000 = fSneakKey;
         case 6 -> var10000 = fSprintKey;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return get(var10000, options);
   }

   public static void holdKey(MoveKey key, boolean down) {
      Object binding = keyBinding(key);
      if (binding != null && fKeyPressed != null) {
         try {
            fKeyPressed.setBoolean(binding, !movementHalted && (down || !movementOverride && physicallyDown(binding)));
         } catch (Throwable var4) {
         }

      }
   }

   public static void setMovementOverride(boolean on) {
      if (movementOverride != on) {
         movementOverride = on;
         if (!on) {
            for(MoveKey key : MinecraftBridge.MoveKey.values()) {
               holdKey(key, false);
            }
         }

      }
   }

   public static void setMovementHalted(boolean halted) {
      movementHalted = halted;
   }

   public static boolean isSneaking(Object entity) {
      return Boolean.TRUE.equals(invoke(mIsSneaking, entity));
   }

   public static boolean isPhysicallyDown(MoveKey key) {
      Object binding = keyBinding(key);
      return binding != null && physicallyDown(binding);
   }

   private static boolean physicallyDown(Object keyBinding) {
      Object key = get(fBoundKey, keyBinding);
      Object code = invoke(mKeyCode, key);
      if (code instanceof Integer c) {
         if (c >= 0) {
            return invoke(mKeyCategory, key) == inputTypeMouse ? getGlfwMouseButton(c) == 1 : getGlfwKey(c) == 1;
         }
      }

      return false;
   }

   public static boolean canSee(Object entity) {
      return Boolean.TRUE.equals(invoke(mCanSee, getPlayer(), entity));
   }

   public static boolean isInvisible(Object entity) {
      return Boolean.TRUE.equals(invoke(mIsInvisible, entity));
   }

   public static boolean isTeammate(Object entity) {
      return Boolean.TRUE.equals(invoke(mIsTeammate, getPlayer(), entity));
   }

   public static boolean isBreakingBlock() {
      return Boolean.TRUE.equals(invoke(mIsBreakingBlock, getInteractionManager()));
   }

   public static void resetJumpCooldown() {
      try {
         if (fJumpingCooldown != null && getPlayer() != null) {
            fJumpingCooldown.setInt(getPlayer(), 0);
         }
      } catch (Throwable var1) {
      }

   }

   public static boolean isGliding(Object entity) {
      return Boolean.TRUE.equals(invoke(mIsGliding, entity));
   }

   public static boolean isInLiquidOrClimbing(Object entity) {
      return Boolean.TRUE.equals(invoke(mIsTouchingWater, entity)) || Boolean.TRUE.equals(invoke(mIsInLava, entity)) || Boolean.TRUE.equals(invoke(mIsClimbing, entity)) || Boolean.TRUE.equals(invoke(mHasVehicle, entity));
   }

   public static boolean isWalkableScreen() {
      Object screen = getCurrentScreen();
      if (!isHandledScreenOpen()) {
         return false;
      } else {
         Object focused = invoke(mGetFocused, screen);
         if (isInstance(cTextField, focused) && Boolean.TRUE.equals(invoke(mIsFocused, focused))) {
            return false;
         } else {
            if (isInstance(cRecipeBookScreen, screen)) {
               Object search = get(fRecipeSearch, get(fRecipeBook, screen));
               if (Boolean.TRUE.equals(invoke(mIsFocused, search))) {
                  return false;
               }
            }

            return true;
         }
      }
   }

   public static boolean interactItemAtPitch(float pitch) {
      Object player = getPlayer();
      if (player != null && mSetPitch != null) {
         float saved = getPitch(player);
         invoke(mSetPitch, player, pitch);

         boolean var3;
         try {
            var3 = interactItem();
         } finally {
            invoke(mSetPitch, player, saved);
         }

         return var3;
      } else {
         return false;
      }
   }

   public static boolean isReplaceable(Object pos) {
      return isAir(pos) || Boolean.TRUE.equals(invoke(mIsReplaceable, getBlockState(pos)));
   }

   public static double getBlockInteractionRange() {
      Object r = invoke(mBlockRange, getPlayer());
      double var10000;
      if (r instanceof Double d) {
         var10000 = d;
      } else {
         var10000 = (double)4.5F;
      }

      return var10000;
   }

   public static float getAttackChargeForHit() {
      Object r = invoke(mAttackCooldown, getPlayer(), 0.5F);
      float var10000;
      if (r instanceof Float f) {
         var10000 = f;
      } else {
         var10000 = 1.0F;
      }

      return var10000;
   }

   public static boolean canCritNow() {
      Object me = getPlayer();
      if (me != null && !(getAttackChargeForHit() <= 0.9F)) {
         if (!(getFallDistance(me) <= (double)0.0F) && !isOnGround(me) && !isSprinting(me) && !isInLiquidOrClimbing(me)) {
            return blindnessEffect == null || !Boolean.TRUE.equals(invoke(mHasStatusEffect, me, blindnessEffect));
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static void releaseKey(MoveKey key) {
      Object binding = keyBinding(key);
      if (binding != null && fKeyPressed != null) {
         try {
            fKeyPressed.setBoolean(binding, false);
         } catch (Throwable var3) {
         }

      }
   }

   public static float getAttackCooldownProgress() {
      Object r = invoke(mAttackCooldown, getPlayer(), 0.0F);
      float var10000;
      if (r instanceof Float f) {
         var10000 = f;
      } else {
         var10000 = 1.0F;
      }

      return var10000;
   }

   public static boolean isLiving(Object entity) {
      return isInstance(cLivingEntity, entity) && !isInstance(cArmorStand, entity);
   }

   public static double getEntityInteractionRange() {
      Object r = invoke(mInteractionRange, getPlayer());
      double var10000;
      if (r instanceof Double d) {
         var10000 = d;
      } else {
         var10000 = (double)3.0F;
      }

      return var10000;
   }

   public static boolean canPlayerMoveBy(double dx, double dy, double dz) {
      Object player = getPlayer();
      Object box = invoke(mBoxOffset, invoke(mGetBoundingBox, player), dx, dy, dz);
      return box == null || Boolean.TRUE.equals(invoke(mIsSpaceEmpty, getWorld(), player, box));
   }

   public static void turnPlayer(float deltaYaw, float deltaPitch) {
      invoke(mChangeLook, getPlayer(), (double)deltaYaw / 0.15, (double)deltaPitch / 0.15);
   }

   public static int getDamage(Object stack) {
      Object r = invoke(mStackDamage, stack);
      int var10000;
      if (r instanceof Integer i) {
         var10000 = i;
      } else {
         var10000 = 0;
      }

      return var10000;
   }

   public static int getMaxDamage(Object stack) {
      Object r = invoke(mStackMaxDamage, stack);
      int var10000;
      if (r instanceof Integer i) {
         var10000 = i;
      } else {
         var10000 = 0;
      }

      return var10000;
   }

   public static Map<String, Integer> getEnchantments(Object stack) {
      Map<String, Integer> out = new HashMap();
      Object entries = invoke(mEnchantmentEntries, invoke(mStackEnchantments, stack));
      if (entries instanceof Iterable) {
         for(Object e : (Iterable)entries) {
            if (e instanceof Map.Entry) {
               Map.Entry<?, ?> entry = (Map.Entry)e;
               Object id = invoke(mEntryId, entry.getKey());
               if (id instanceof String) {
                  String s = (String)id;
                  Object var10 = entry.getValue();
                  if (var10 instanceof Integer) {
                     Integer level = (Integer)var10;
                     out.put(stripNamespace(s), level);
                  }
               }
            }
         }

         return out;
      } else {
         return out;
      }
   }

   public static boolean isCursorEmpty() {
      Object handler = get(fCurrentScreenHandler, getPlayer());
      Object stack = invoke(mGetCursorStack, handler);
      return stack == null || itemId(stack).isEmpty();
   }

   public static boolean isInventoryScreenOpen() {
      return isInstance(cInventoryScreen, getCurrentScreen());
   }

   public static Object[] getChunkSections(int chunkX, int chunkZ) {
      Object r = invoke(mChunkSections, invoke(mWorldGetChunk, getWorld(), chunkX, chunkZ));
      Object[] var10000;
      if (r instanceof Object[] a) {
         var10000 = a;
      } else {
         var10000 = null;
      }

      return var10000;
   }

   public static int getBottomSectionCoord() {
      Object r = invoke(mBottomSectionCoord, getWorld());
      int var10000;
      if (r instanceof Integer i) {
         var10000 = i;
      } else {
         var10000 = 0;
      }

      return var10000;
   }

   public static boolean isSectionEmpty(Object section) {
      return section == null || Boolean.TRUE.equals(invoke(mSectionIsEmpty, section));
   }

   public static boolean sectionHasAny(Object section, Predicate<Object> test) {
      return Boolean.TRUE.equals(invoke(mSectionHasAny, section, test));
   }

   public static Object sectionBlockState(Object section, int x, int y, int z) {
      return invoke(mSectionGetState, section, x, y, z);
   }

   public static List<Object> getAllBlocks() {
      List<Object> out = new ArrayList();
      Object var2 = blockRegistry;
      if (var2 instanceof Iterable) {
         for(Object b : (Iterable)var2) {
            out.add(b);
         }
      }

      return out;
   }

   public static String blockName(Object block) {
      Object r = invoke(mTextGetString, invoke(mBlockName, block));
      String var10000;
      if (r instanceof String s) {
         var10000 = s;
      } else {
         var10000 = blockIdOf(block);
      }

      return var10000;
   }

   public static int blockMapColor(Object block) {
      return stateMapColor(invoke(mDefaultState, block));
   }

   public static int stateMapColor(Object state) {
      Object r = get(fMapColorValue, invoke(mMapColor, state, getWorld(), originPos));
      int var10000;
      if (r instanceof Integer i) {
         var10000 = i;
      } else {
         var10000 = 0;
      }

      return var10000;
   }

   public static byte[] getGameResource(String path) {
      try {
         InputStream in = mcLoader.getResourceAsStream(path);

         byte[] var2;
         try {
            var2 = in == null ? null : in.readAllBytes();
         } catch (Throwable var5) {
            if (in != null) {
               try {
                  in.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }
            }

            throw var5;
         }

         if (in != null) {
            in.close();
         }

         return var2;
      } catch (Throwable var6) {
         return null;
      }
   }

   public static double getGamma() {
      Object r = get(fOptionValue, invoke(mGetGamma, get(fOptions, mc)));
      double var10000;
      if (r instanceof Double d) {
         var10000 = d;
      } else {
         var10000 = (double)0.5F;
      }

      return var10000;
   }

   public static void setGamma(double value) {
      Object option = invoke(mGetGamma, get(fOptions, mc));

      try {
         if (option != null && fOptionValue != null) {
            fOptionValue.set(option, value);
         }
      } catch (Throwable var4) {
      }

   }

   public static int entityStatus(Object packet) {
      Object r = invoke(mStatusGetStatus, packet);
      byte var10000;
      if (r instanceof Byte b) {
         var10000 = b;
      } else {
         var10000 = -1;
      }

      return var10000;
   }

   public static Object entityStatusEntity(Object packet) {
      return invoke(mStatusGetEntity, packet, getWorld());
   }

   private static boolean isInstance(Class<?> c, Object o) {
      return c != null && c.isInstance(o);
   }

   private static String stripNamespace(String id) {
      return id.startsWith("minecraft:") ? id.substring(10) : id;
   }

   private static Object get(Field f, Object owner) {
      if (f != null && owner != null) {
         try {
            return f.get(owner);
         } catch (Throwable var3) {
            return null;
         }
      } else {
         return null;
      }
   }

   private static Object invoke(Method m, Object target, Object... args) {
      if (m != null && target != null) {
         try {
            return m.invoke(target, args);
         } catch (Throwable var4) {
            return null;
         }
      } else {
         return null;
      }
   }

   private static Object invokeStatic(Method m, Object... args) {
      if (m == null) {
         return null;
      } else {
         try {
            return m.invoke((Object)null, args);
         } catch (Throwable var3) {
            return null;
         }
      }
   }

   public static final class Frame {
      public double camX;
      public double camY;
      public double camZ;
      public final float[] view = new float[16];
      public final float[] projection = new float[16];
      public float tickDelta;
      public boolean valid;
   }

   public static record Effect(String id, String name, int amplifier, int ticks, boolean infinite) {
   }

   public static enum MoveKey {
      FORWARD,
      BACK,
      LEFT,
      RIGHT,
      JUMP,
      SNEAK,
      SPRINT;

      // $FF: synthetic method
      private static MoveKey[] $values() {
         return new MoveKey[]{FORWARD, BACK, LEFT, RIGHT, JUMP, SNEAK, SPRINT};
      }
   }
}
