package lol.wocky.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Supplier;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleManager;
import lol.wocky.core.module.property.BlockListProperty;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.EnumProperty;
import lol.wocky.core.module.property.KeyProperty;
import lol.wocky.core.module.property.NameListProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;

public final class IpcServer {
   public static final int FIRST_PORT = 41123;
   public static final int LAST_PORT = 41135;
   private static final long MAIN_THREAD_TIMEOUT_MS = 1000L;
   private static volatile boolean running = false;
   private static ServerSocket serverSocket;
   private static final Set<Socket> clients = ConcurrentHashMap.newKeySet();
   private static final CopyOnWriteArrayList<PrintWriter> eventListeners = new CopyOnWriteArrayList();

   private IpcServer() {
   }

   public static Path portFile(long pid) {
      return Path.of(System.getProperty("java.io.tmpdir"), ".wocky_ipc_" + pid);
   }

   public static synchronized void start() {
      if (!running) {
         InetAddress loopback = InetAddress.getLoopbackAddress();

         for(int p = 41123; p <= 41135 && serverSocket == null; ++p) {
            try {
               serverSocket = new ServerSocket(p, 50, loopback);
            } catch (Throwable var4) {
            }
         }

         if (serverSocket == null) {
            System.err.println("[Wocky] IPC: no free port in 41123-41135");
         } else {
            running = true;
            int port = serverSocket.getLocalPort();

            try {
               Files.writeString(portFile(ProcessHandle.current().pid()), String.valueOf(port));
            } catch (Throwable t) {
               System.err.println("[Wocky] IPC: could not write port file: " + String.valueOf(t));
            }

            System.out.println("[Wocky] IPC listening on 127.0.0.1:" + port);
            ServerSocket server = serverSocket;
            daemon("Wocky-IPC-Server", () -> {
               while(true) {
                  if (running) {
                     try {
                        Socket client = server.accept();
                        clients.add(client);
                        daemon("Wocky-IPC-Client", () -> handleClient(client));
                        continue;
                     } catch (Throwable var2) {
                        if (running) {
                           continue;
                        }
                     }
                  }

                  return;
               }
            });
         }
      }
   }

   public static synchronized void stop() {
      if (running) {
         running = false;

         try {
            serverSocket.close();
         } catch (Throwable var5) {
         }

         serverSocket = null;

         for(Socket s : clients) {
            try {
               s.close();
            } catch (Throwable var4) {
            }
         }

         clients.clear();
         eventListeners.clear();

         try {
            Files.deleteIfExists(portFile(ProcessHandle.current().pid()));
         } catch (Throwable var3) {
         }

      }
   }

   public static void broadcast(String msg) {
      for(PrintWriter w : eventListeners) {
         synchronized(w) {
            w.println(msg);
            if (w.checkError()) {
               eventListeners.remove(w);
            }
         }
      }

   }

   private static void handleClient(Socket client) {
      PrintWriter writer = null;

      try {
         Socket var2 = client;

         try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));

            try {
               writer = new PrintWriter(client.getOutputStream(), true, StandardCharsets.UTF_8);

               String line;
               while((line = reader.readLine()) != null) {
                  if (line.equalsIgnoreCase("LISTEN_EVENTS")) {
                     writer.println("OK:LISTENING");
                     eventListeners.add(writer);

                     while(reader.readLine() != null) {
                     }
                     break;
                  }

                  String reply = handleCommand(line);
                  synchronized(writer) {
                     writer.println(reply);
                  }

                  if (line.equalsIgnoreCase("UNINJECT")) {
                     daemon("Wocky-Uninject", WockyCore::shutdown);
                     break;
                  }
               }
            } catch (Throwable var19) {
               try {
                  reader.close();
               } catch (Throwable var17) {
                  var19.addSuppressed(var17);
               }

               throw var19;
            }

            reader.close();
         } catch (Throwable var20) {
            if (client != null) {
               try {
                  var2.close();
               } catch (Throwable var16) {
                  var20.addSuppressed(var16);
               }
            }

            throw var20;
         }

         if (client != null) {
            client.close();
         }
      } catch (Throwable var21) {
      } finally {
         if (writer != null) {
            eventListeners.remove(writer);
         }

         clients.remove(client);
      }

   }

   private static String handleCommand(String line) {
      if (line.equalsIgnoreCase("PING")) {
         return "PONG";
      } else if (line.equalsIgnoreCase("GET_PID")) {
         return String.valueOf(ProcessHandle.current().pid());
      } else if (line.equalsIgnoreCase("GET_SESSION")) {
         return serializeSession();
      } else if (line.equalsIgnoreCase("GET_MODULES")) {
         String json = (String)MainThread.call(IpcServer::serializeModules, (Object)null, 1000L);
         return json != null ? json : "ERR:TIMEOUT";
      } else if (line.equalsIgnoreCase("UNINJECT")) {
         return "OK:UNINJECTING";
      } else if (line.equalsIgnoreCase("TOGGLE_OVERLAY")) {
         broadcast("EVENT:TOGGLE_OVERLAY");
         return "OK";
      } else if (!line.startsWith("SET_ENABLED ") && !line.startsWith("SET_MODULE ")) {
         if (line.startsWith("TOGGLE ")) {
            Module m = ModuleManager.getByName(line.substring(7).trim());
            return m == null ? "ERR:NOT_FOUND" : setEnabled(m, !m.isEnabled());
         } else if (line.startsWith("BIND ")) {
            String[] parts = line.substring(5).trim().split("\\s+", 2);
            if (parts.length != 2) {
               return "ERR:BAD_ARGS";
            } else {
               Module m = ModuleManager.getByName(parts[0]);
               if (m == null) {
                  return "ERR:NOT_FOUND";
               } else {
                  int key;
                  try {
                     key = Integer.parseInt(parts[1]);
                  } catch (NumberFormatException var5) {
                     return "ERR:BAD_KEY";
                  }

                  MainThread.run(() -> m.setKey(key));
                  ModuleManager.saveConfig();
                  String var10000 = m.getName();
                  broadcast("EVENT:MODULE_BOUND:" + var10000 + ":" + key);
                  return "OK:" + key;
               }
            }
         } else if (line.startsWith("CONFIG_")) {
            return handleConfig(line);
         } else if (line.startsWith("SET_MENU_KEY ")) {
            int key;
            try {
               key = Integer.parseInt(line.substring(13).trim());
            } catch (NumberFormatException var6) {
               return "ERR:BAD_KEY";
            }

            if (!ModuleManager.setMenuKey(key)) {
               return "ERR:BAD_KEY";
            } else {
               broadcast("EVENT:MENU_KEY:" + key);
               return "OK:" + key;
            }
         } else if (line.equalsIgnoreCase("GET_BLOCKS")) {
            String json = BlockCatalog.get();
            return json != null ? json : "WAIT";
         } else if (line.equalsIgnoreCase("GET_HUD")) {
            String json = (String)MainThread.call(MinecraftBridge::hudJson, (Object)null, 1000L);
            return json != null ? json : "ERR:TIMEOUT";
         } else if (line.startsWith("HUD_EDIT ")) {
            boolean on = line.substring(9).trim().equalsIgnoreCase("on");
            MainThread.run(() -> MinecraftBridge.setHudEditing(on));
            return "OK";
         } else if (line.startsWith("HUD_MOVE ")) {
            String[] parts = line.substring(9).trim().split("\\s+");
            if (parts.length != 3) {
               return "ERR:BAD_ARGS";
            } else {
               try {
                  float x = Float.parseFloat(parts[1]);
                  float y = Float.parseFloat(parts[2]);
                  MainThread.run(() -> MinecraftBridge.hudMove(parts[0], x, y));
                  return "OK";
               } catch (NumberFormatException var7) {
                  return "ERR:BAD_ARGS";
               }
            }
         } else if (!line.equalsIgnoreCase("HUD_RESET") && !line.startsWith("HUD_RESET ")) {
            if (line.startsWith("BIND_MODE ")) {
               String[] parts = line.substring(10).trim().split("\\s+", 2);
               if (parts.length != 2) {
                  return "ERR:BAD_ARGS";
               } else {
                  Module m = ModuleManager.getByName(parts[0]);
                  if (m == null) {
                     return "ERR:NOT_FOUND";
                  } else {
                     boolean hold;
                     if (parts[1].equalsIgnoreCase("hold")) {
                        hold = true;
                     } else {
                        if (!parts[1].equalsIgnoreCase("toggle")) {
                           return "ERR:BAD_MODE";
                        }

                        hold = false;
                     }

                     MainThread.run(() -> {
                        m.setHoldMode(hold);
                        if (hold && m.isEnabled()) {
                           m.setEnabled(false);
                           broadcast("EVENT:MODULE_TOGGLED:" + m.getName() + ":false");
                        }

                     });
                     ModuleManager.saveConfig();
                     return "OK:" + (hold ? "hold" : "toggle");
                  }
               }
            } else if (line.startsWith("SET ")) {
               String[] parts = line.substring(4).split("\\|", 3);
               if (parts.length != 3) {
                  return "ERR:BAD_ARGS";
               } else {
                  Module m = ModuleManager.getByName(parts[0]);
                  if (m == null) {
                     return "ERR:NOT_FOUND";
                  } else {
                     Property<?> p = ModuleManager.getProperty(m, parts[1]);
                     if (p == null) {
                        return "ERR:NO_PROPERTY";
                     } else {
                        Boolean ok = (Boolean)MainThread.call(() -> {
                           boolean applied = ModuleManager.applyValue(p, parts[2]);
                           if (applied) {
                              ModuleManager.saveConfig();
                           }

                           return applied;
                        }, (Object)null, 1000L);
                        if (ok == null) {
                           return "OK:PENDING";
                        } else {
                           return ok ? "OK" : "ERR:BAD_VALUE";
                        }
                     }
                  }
               }
            } else {
               return "ERR:UNKNOWN";
            }
         } else {
            String id = line.length() > 9 ? line.substring(9).trim() : null;
            MainThread.run(() -> MinecraftBridge.hudReset(id != null && !id.isEmpty() ? id : null));
            return "OK";
         }
      } else {
         String[] parts = line.substring(line.indexOf(32) + 1).trim().split("\\s+", 2);
         if (parts.length != 2) {
            return "ERR:BAD_ARGS";
         } else {
            Module m = ModuleManager.getByName(parts[0]);
            return m == null ? "ERR:NOT_FOUND" : setEnabled(m, Boolean.parseBoolean(parts[1]));
         }
      }
   }

   private static String handleConfig(String line) {
      int sp = line.indexOf(32);
      String cmd = sp < 0 ? line : line.substring(0, sp);
      String arg = sp < 0 ? "" : line.substring(sp + 1).trim();
      Supplier<String> task;
      switch (cmd) {
         case "CONFIG_LIST":
            task = ConfigProfiles::list;
            break;
         case "CONFIG_LOAD":
            task = () -> {
               String r = ConfigProfiles.load(arg);
               if (r.equals("OK")) {
                  broadcast("EVENT:CONFIG_LOADED:" + arg);
               }

               return r;
            };
            break;
         case "CONFIG_DUPLICATE":
            task = () -> ConfigProfiles.duplicate(arg);
            break;
         case "CONFIG_DELETE":
            task = () -> ConfigProfiles.delete(arg);
            break;
         case "CONFIG_SAVE":
         case "CONFIG_EDIT":
            JsonObject o;
            try {
               o = JsonParser.parseString(arg).getAsJsonObject();
            } catch (Throwable var14) {
               return "ERR:BAD_ARGS";
            }

            String id = o.has("id") && !o.get("id").isJsonNull() ? o.get("id").getAsString() : null;
            String name = o.has("name") ? o.get("name").getAsString() : null;
            List<String> tags = null;
            JsonElement var12 = o.get("tags");
            if (var12 instanceof JsonArray a) {
               tags = new ArrayList();

               for(JsonElement e : a) {
                  tags.add(e.getAsString());
               }
            }

            if (cmd.equals("CONFIG_SAVE")) {
               task = () -> ConfigProfiles.save(id, name, tags);
            } else {
               if (id == null) {
                  return "ERR:BAD_ARGS";
               }

               task = () -> ConfigProfiles.edit(id, name, tags);
            }
            break;
         default:
            return "ERR:UNKNOWN";
      }

      String r = (String)MainThread.call(task, (Object)null, 3000L);
      return r != null ? r : "ERR:TIMEOUT";
   }

   private static String setEnabled(Module m, boolean enabled) {
      Boolean state = (Boolean)MainThread.call(() -> {
         m.setEnabled(enabled);
         ModuleManager.saveConfig();
         String var10000 = m.getName();
         broadcast("EVENT:MODULE_TOGGLED:" + var10000 + ":" + m.isEnabled());
         return m.isEnabled();
      }, (Object)null, 1000L);
      return state == null ? "OK:PENDING" : "OK:" + state;
   }

   private static String serializeSession() {
      JsonObject o = (JsonObject)MainThread.call(() -> {
         JsonObject s = new JsonObject();
         s.addProperty("username", MinecraftBridge.getSessionUsername());
         UUID uuid = MinecraftBridge.getSessionUuid();
         s.addProperty("uuid", uuid != null ? uuid.toString() : "");
         s.addProperty("inGame", MinecraftBridge.isInGame());
         s.addProperty("singleplayer", MinecraftBridge.isSingleplayer());
         s.addProperty("server", MinecraftBridge.getServerAddress());
         s.addProperty("serverName", MinecraftBridge.getServerName());
         s.addProperty("ping", (Number)MinecraftBridge.getPing());
         s.addProperty("fps", (Number)MinecraftBridge.getCurrentFps());
         return s;
      }, (Object)null, 1000L);
      if (o == null) {
         o = new JsonObject();
         o.addProperty("username", MinecraftBridge.getSessionUsername());
         UUID uuid = MinecraftBridge.getSessionUuid();
         o.addProperty("uuid", uuid != null ? uuid.toString() : "");
      }

      o.addProperty("pid", (Number)ProcessHandle.current().pid());
      o.addProperty("menuKey", (Number)ModuleManager.getMenuKey());
      return o.toString();
   }

   public static String serializeModules() {
      JsonArray array = new JsonArray();

      label83:
      for(Module m : ModuleManager.getModules()) {
         JsonObject obj = new JsonObject();
         obj.addProperty("name", m.getName());
         obj.addProperty("description", m.getDescription());
         obj.addProperty("category", m.getCategory().name());
         obj.addProperty("enabled", m.isEnabled());
         obj.addProperty("key", (Number)m.getKey());
         obj.addProperty("holdMode", m.isHoldMode());
         if (m.getWarning() != null) {
            obj.addProperty("warning", m.getWarning());
         }

         JsonArray props = new JsonArray();
         Iterator var5 = m.getProperties().iterator();

         while(true) {
            JsonObject po;
            while(true) {
               if (!var5.hasNext()) {
                  obj.add("properties", props);
                  array.add((JsonElement)obj);
                  continue label83;
               }

               Property<?> p = (Property)var5.next();
               if (!p.isHidden()) {
                  po = new JsonObject();
                  po.addProperty("name", p.getName());
                  if (p instanceof BooleanProperty) {
                     BooleanProperty bp = (BooleanProperty)p;
                     po.addProperty("type", "boolean");
                     po.addProperty("value", (Boolean)bp.getValue());
                     break;
                  }

                  if (p instanceof KeyProperty) {
                     KeyProperty kp = (KeyProperty)p;
                     po.addProperty("type", "key");
                     po.addProperty("value", (Number)kp.getKey());
                     break;
                  }

                  if (p instanceof NumberProperty) {
                     NumberProperty np = (NumberProperty)p;
                     po.addProperty("type", "number");
                     po.addProperty("value", (Number)np.getValue());
                     po.addProperty("min", np.getMin());
                     po.addProperty("max", np.getMax());
                     po.addProperty("step", np.getStep());
                     po.addProperty("integer", np.isInteger());
                     break;
                  }

                  if (p instanceof BlockListProperty) {
                     BlockListProperty bl = (BlockListProperty)p;
                     po.addProperty("type", "blocks");
                     JsonArray ids = new JsonArray();

                     for(String id : (Set)bl.getValue()) {
                        ids.add(id);
                     }

                     po.add("value", ids);
                     break;
                  }

                  if (p instanceof NameListProperty) {
                     NameListProperty nl = (NameListProperty)p;
                     po.addProperty("type", "names");
                     JsonArray names = new JsonArray();

                     for(String n : (Set)nl.getValue()) {
                        names.add(n);
                     }

                     po.add("value", names);
                     break;
                  }

                  if (p instanceof EnumProperty) {
                     EnumProperty<?> ep = (EnumProperty)p;
                     po.addProperty("type", "enum");
                     po.addProperty("value", ((Enum)ep.getValue()).name());
                     JsonArray options = new JsonArray();

                     for(String o : ep.getOptions()) {
                        options.add(o);
                     }

                     po.add("options", options);
                     break;
                  }
               }
            }

            props.add((JsonElement)po);
         }
      }

      return array.toString();
   }

   private static void daemon(String name, Runnable r) {
      Thread t = new Thread(r, name);
      t.setDaemon(true);
      t.start();
   }
}
