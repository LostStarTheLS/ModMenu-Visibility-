package lol.wocky.core;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

public final class MainThread {
   private static final ConcurrentLinkedQueue<Runnable> queue = new ConcurrentLinkedQueue();
   private static volatile Thread clientThread;

   private MainThread() {
   }

   public static boolean isOnThread() {
      return Thread.currentThread() == clientThread;
   }

   public static void run(Runnable task) {
      if (isOnThread()) {
         task.run();
      } else {
         queue.add(task);
      }

   }

   public static <T> T call(Supplier<T> task, T fallback, long timeoutMs) {
      if (isOnThread()) {
         return (T)task.get();
      } else {
         CompletableFuture<T> future = new CompletableFuture();
         queue.add((Runnable)() -> {
            try {
               future.complete(task.get());
            } catch (Throwable t) {
               future.completeExceptionally(t);
            }

         });

         try {
            return (T)future.get(timeoutMs, TimeUnit.MILLISECONDS);
         } catch (Throwable var6) {
            return fallback;
         }
      }
   }

   static void drain() {
      clientThread = Thread.currentThread();

      Runnable task;
      while((task = (Runnable)queue.poll()) != null) {
         try {
            task.run();
         } catch (Throwable t) {
            t.printStackTrace();
         }
      }

   }

   static void clear() {
      queue.clear();
      clientThread = null;
   }
}
