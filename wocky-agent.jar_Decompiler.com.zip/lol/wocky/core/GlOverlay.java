package lol.wocky.core;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

public final class GlOverlay {
   private static Method mTag;
   private static Method mShapes;
   private static Method mTargetHud;
   private static Method mWatermark;
   private static Method mModuleList;
   private static Method mEffects;
   private static Method mEffectIcon;
   private static Method mLastRects;
   private static Method mRender;
   private static Method mClear;
   private static Method mDispose;
   private static Method mFailed;
   private static volatile long lastDraw;

   private GlOverlay() {
   }

   static void load(ClassLoader minecraftLoader) {
      try {
         URL jar = GlOverlay.class.getProtectionDomain().getCodeSource().getLocation();
         ClassLoader loader = new URLClassLoader("wocky-gl", new URL[]{jar}, minecraftLoader);
         Class<?> c = Class.forName("lol.wocky.gl.Overlay", true, loader);
         c.getMethod("setFont", byte[].class).invoke((Object)null, resource("/fonts/Inter-SemiBold.ttf"));
         c.getMethod("setLogo", byte[].class).invoke((Object)null, resource("/textures/logo_hud.png"));
         mTag = c.getMethod("tag", Float.TYPE, Float.TYPE, String.class, Float.TYPE);
         mShapes = c.getMethod("shapes", float[].class, int[].class, Integer.TYPE, Float.TYPE, float[].class, int[].class, Integer.TYPE);
         mTargetHud = c.getMethod("targetHud", String.class, Integer.TYPE, float[].class, String.class, String.class, Float.TYPE, float[].class);
         mWatermark = c.getMethod("watermark", String.class, String.class, Float.TYPE, float[].class);
         mModuleList = c.getMethod("moduleList", String[].class, Float.TYPE, float[].class);
         mEffects = c.getMethod("effects", String[].class, String[].class, String[].class, boolean[].class, Float.TYPE, float[].class);
         mLastRects = c.getMethod("lastRects");
         mEffectIcon = c.getMethod("effectIcon", String.class, byte[].class);
         mRender = c.getMethod("render", Integer.TYPE, Integer.TYPE, Integer.TYPE);
         mClear = c.getMethod("clear");
         mDispose = c.getMethod("dispose");
         mFailed = c.getMethod("isFailed");
      } catch (Throwable t) {
         mTag = null;
         System.err.println("[Wocky] Glass overlay unavailable: " + String.valueOf(t));
      }

   }

   private static byte[] resource(String path) throws Exception {
      InputStream in = GlOverlay.class.getResourceAsStream(path);

      byte[] var2;
      try {
         if (in == null) {
            throw new IllegalStateException(path + " missing from agent jar");
         }

         var2 = in.readAllBytes();
      } catch (Throwable var5) {
         if (in != null) {
            try {
               in.close();
            } catch (Throwable var4) {
               var5.addSuppressed(var4);
            }
         }

         throw var5;
      }

      if (in != null) {
         in.close();
      }

      return var2;
   }

   public static boolean active() {
      if (mTag != null && System.nanoTime() - lastDraw <= 1000000000L) {
         try {
            return !Boolean.TRUE.equals(mFailed.invoke((Object)null));
         } catch (Throwable var1) {
            return false;
         }
      } else {
         return false;
      }
   }

   public static void tag(float cx, float bottom, String text, float unit) {
      call(mTag, cx, bottom, text, unit);
   }

   public static void shapes(float[] lines, int[] lineColors, int lineCount, float lineWidth, float[] tris, int[] triColors, int triCount) {
      call(mShapes, lines, lineColors, lineCount, lineWidth, tris, triColors, triCount);
   }

   public static void targetHud(String name, int skinGlId, float[] v, String distance, String info, float unit, float[] pos) {
      call(mTargetHud, name, skinGlId, v, distance, info, unit, pos);
   }

   public static void watermark(String title, String info, float unit, float[] pos) {
      call(mWatermark, title, info, unit, pos);
   }

   public static void moduleList(String[] names, float unit, float[] pos) {
      call(mModuleList, names, unit, pos);
   }

   public static void effects(String[] ids, String[] labels, String[] times, boolean[] expiring, float unit, float[] pos) {
      call(mEffects, ids, labels, times, expiring, unit, pos);
   }

   public static float[] lastRects() {
      try {
         return mLastRects == null ? null : (float[])mLastRects.invoke((Object)null);
      } catch (Throwable var1) {
         return null;
      }
   }

   public static void effectIcon(String id, byte[] png) {
      call(mEffectIcon, id, png);
   }

   private static void call(Method m, Object... args) {
      if (m != null) {
         try {
            m.invoke((Object)null, args);
         } catch (Throwable var3) {
         }

      }
   }

   static void drawInto(int textureId, int width, int height) {
      if (mRender != null) {
         lastDraw = System.nanoTime();

         try {
            mRender.invoke((Object)null, textureId, width, height);
         } catch (Throwable var4) {
            call(mClear);
         }

      }
   }

   static void dispose() {
      call(mDispose);
   }
}
