package lol.wocky.core;

import java.lang.instrument.Instrumentation;
import lol.wocky.core.module.ModuleManager;
import lol.wocky.feature.combat.AimAssist;
import lol.wocky.feature.combat.AnchorMacro;
import lol.wocky.feature.combat.AutoArmor;
import lol.wocky.feature.combat.AutoCrystal;
import lol.wocky.feature.combat.AutoDoubleHand;
import lol.wocky.feature.combat.AutoHitCrystal;
import lol.wocky.feature.combat.CrystalOptimizer;
import lol.wocky.feature.combat.DexDTap;
import lol.wocky.feature.combat.DoubleAnchor;
import lol.wocky.feature.combat.HoverTotem;
import lol.wocky.feature.combat.MaceAssist;
import lol.wocky.feature.combat.SafeAnchor;
import lol.wocky.feature.combat.ShieldBreaker;
import lol.wocky.feature.combat.TriggerBot;
import lol.wocky.feature.combat.TripleTap;
import lol.wocky.feature.misc.AutoXP;
import lol.wocky.feature.movement.ElytraSwap;
import lol.wocky.feature.movement.InvWalk;
import lol.wocky.feature.movement.JumpReset;
import lol.wocky.feature.movement.NoJumpDelay;
import lol.wocky.feature.movement.Sprint;
import lol.wocky.feature.movement.WindJump;
import lol.wocky.feature.render.ArrayListHud;
import lol.wocky.feature.render.BlockESP;
import lol.wocky.feature.render.Fullbright;
import lol.wocky.feature.render.PlayerESP;
import lol.wocky.feature.render.StatusEffectsHud;
import lol.wocky.feature.render.TargetHud;
import lol.wocky.feature.render.Tracers;
import lol.wocky.feature.render.Watermark;

public final class WockyCore {
   private static boolean running = false;
   private static Class<?> hook;
   private static Class<?> renderHook;
   private static Class<?> hooks;

   private WockyCore() {
   }

   public static synchronized void init(Instrumentation inst, Class<?> hookClass, Class<?> renderHookClass, Class<?> hooksClass) {
      if (!running) {
         hook = hookClass;
         renderHook = renderHookClass;
         hooks = hooksClass;
         System.out.println("[Wocky] Initializing core");
         if (!MinecraftBridge.init(inst)) {
            System.err.println("[Wocky] Minecraft bridge failed to initialize; aborting");
         } else {
            ModuleManager.register(new AutoHitCrystal());
            ModuleManager.register(new AutoCrystal());
            ModuleManager.register(new DexDTap());
            ModuleManager.register(new HoverTotem());
            ModuleManager.register(new AutoDoubleHand());
            ModuleManager.register(new AutoXP());
            ModuleManager.register(new CrystalOptimizer());
            ModuleManager.register(new AnchorMacro());
            ModuleManager.register(new SafeAnchor());
            ModuleManager.register(new DoubleAnchor());
            ModuleManager.register(new TripleTap());
            ModuleManager.register(new ShieldBreaker());
            ModuleManager.register(new AutoArmor());
            ModuleManager.register(new MaceAssist());
            ModuleManager.register(new TriggerBot());
            ModuleManager.register(new AimAssist());
            ModuleManager.register(new Sprint());
            ModuleManager.register(new InvWalk());
            ModuleManager.register(new NoJumpDelay());
            ModuleManager.register(new JumpReset());
            ModuleManager.register(new WindJump());
            ModuleManager.register(new ElytraSwap());
            ModuleManager.register(new PlayerESP());
            ModuleManager.register(new Tracers());
            ModuleManager.register(new BlockESP());
            ModuleManager.register(new Fullbright());
            ModuleManager.register(new Watermark());
            ModuleManager.register(new ArrayListHud());
            ModuleManager.register(new StatusEffectsHud());
            ModuleManager.register(new TargetHud());
            MinecraftBridge.bindHudModules();
            MainThread.run(ModuleManager::loadConfig);
            setHook("onTick", MinecraftBridge::onClientTick);
            setHook("cancelItemUse", MinecraftBridge::shouldCancelItemUse);
            setHook("cancelAttack", MinecraftBridge::shouldCancelAttack);
            setHook("activeShutdown", WockyCore::shutdown);
            setRenderHook("onWorldRender", MinecraftBridge::onWorldRender);
            setRenderHook("onHudRender", MinecraftBridge::onHudRender);
            GlOverlay.load(hookClass.getClassLoader());
            setHooksHandler(MinecraftBridge::onHook);
            if (!AsmClientTransformer.install(inst)) {
               System.err.println("[Wocky] Could not hook the client tick; modules will not run");
            }

            IpcServer.start();
            MinecraftKeyHook.start();
            running = true;
            System.out.println("[Wocky] Core initialized");
         }
      }
   }

   public static synchronized void shutdown() {
      if (running) {
         running = false;
         System.out.println("[Wocky] Shutting down");
         MinecraftKeyHook.stop();
         IpcServer.stop();
         MainThread.call(() -> {
            MinecraftBridge.setHudEditing(false);
            ModuleManager.disableAll();
            GlOverlay.dispose();
            return null;
         }, (Object)null, 1000L);
         ModuleManager.shutdown();
         setHook("onTick", (Object)null);
         setHook("cancelItemUse", (Object)null);
         setHook("cancelAttack", (Object)null);
         setHook("activeShutdown", (Object)null);
         setRenderHook("onWorldRender", (Object)null);
         setRenderHook("onHudRender", (Object)null);
         setHooksHandler((Object)null);
         AsmClientTransformer.uninstall();
         MainThread.clear();
      }
   }

   private static void setHooksHandler(Object value) {
      try {
         hooks.getField("handler").set((Object)null, value);
      } catch (Throwable t) {
         System.err.println("[Wocky] Failed to set Hooks.handler: " + String.valueOf(t));
      }

   }

   private static void setRenderHook(String field, Object value) {
      try {
         renderHook.getField(field).set((Object)null, value);
      } catch (Throwable t) {
         System.err.println("[Wocky] Failed to set RenderHook." + field + ": " + String.valueOf(t));
      }

   }

   private static void setHook(String field, Object value) {
      try {
         hook.getField(field).set((Object)null, value);
      } catch (Throwable t) {
         System.err.println("[Wocky] Failed to set ClientInputHook." + field + ": " + String.valueOf(t));
      }

   }
}
