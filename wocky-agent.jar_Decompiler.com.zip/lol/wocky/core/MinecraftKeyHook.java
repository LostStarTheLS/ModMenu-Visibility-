package lol.wocky.core;

import java.util.HashSet;
import java.util.Set;
import lol.wocky.core.module.Module;
import lol.wocky.core.module.ModuleManager;

public final class MinecraftKeyHook {
   private static final long POLL_MS = 15L;
   private static volatile Thread thread;

   private MinecraftKeyHook() {
   }

   public static synchronized void start() {
      if (thread == null) {
         Thread t = new Thread(MinecraftKeyHook::loop, "Wocky-KeyHook");
         t.setDaemon(true);
         thread = t;
         t.start();
      }
   }

   public static synchronized void stop() {
      Thread t = thread;
      thread = null;
      if (t != null) {
         t.interrupt();
      }

   }

   private static void setEnabled(Module m, boolean enabled, boolean save) {
      MainThread.run(() -> {
         if (m.isEnabled() != enabled) {
            m.setEnabled(enabled);
            if (save) {
               ModuleManager.saveConfig();
            }

            String var10000 = m.getName();
            IpcServer.broadcast("EVENT:MODULE_TOGGLED:" + var10000 + ":" + m.isEnabled());
         }
      });
   }

   private static void loop() {
      Thread self = Thread.currentThread();
      Set<Integer> held = new HashSet();
      boolean overlayKeyHeld = false;
      int lastMenuKey = ModuleManager.getMenuKey();

      while(thread == self) {
         try {
            Thread.sleep(15L);
         } catch (InterruptedException var12) {
            return;
         }

         try {
            int menuKey = ModuleManager.getMenuKey();
            if (menuKey != lastMenuKey) {
               lastMenuKey = menuKey;
               overlayKeyHeld = true;
            }

            boolean overlayKey = MinecraftBridge.getGlfwKey(menuKey) == 1;
            if (overlayKey && !overlayKeyHeld) {
               IpcServer.broadcast("EVENT:TOGGLE_OVERLAY");
            }

            overlayKeyHeld = overlayKey;
            Set<Integer> down = new HashSet();
            if (MinecraftBridge.getCurrentScreen() == null) {
               for(Module m : ModuleManager.getModules()) {
                  int key = m.getKey();
                  if (key > 0 && (down.contains(key) || MinecraftBridge.isKeyDown(key))) {
                     down.add(key);
                  }
               }
            }

            for(Module m : ModuleManager.getModules()) {
               int key = m.getKey();
               if (key > 0) {
                  boolean pressed = down.contains(key) && !held.contains(key);
                  boolean released = !down.contains(key) && held.contains(key);
                  if (m.isHoldMode()) {
                     if (pressed) {
                        setEnabled(m, true, false);
                     } else if (released) {
                        setEnabled(m, false, false);
                     }
                  } else if (pressed) {
                     setEnabled(m, !m.isEnabled(), true);
                  }
               }
            }

            held = down;
         } catch (Throwable t) {
            System.err.println("[Wocky] Key polling error: " + String.valueOf(t));
         }
      }

   }
}
