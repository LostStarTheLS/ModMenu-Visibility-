package lol.wocky.core.module;

public enum ModuleCategory {
   CPVP("CPvP"),
   COMBAT("Combat"),
   MOVEMENT("Movement"),
   RENDER("Render"),
   MISC("Misc");

   private final String displayName;

   private ModuleCategory(String displayName) {
      this.displayName = displayName;
   }

   public String getDisplayName() {
      return this.displayName;
   }

   // $FF: synthetic method
   private static ModuleCategory[] $values() {
      return new ModuleCategory[]{CPVP, COMBAT, MOVEMENT, RENDER, MISC};
   }
}
