package lol.wocky.core.module.property;

public class EnumProperty<T extends Enum<T>> extends Property<T> {
   public EnumProperty(CharSequence name, T defaultValue) {
      super(name, defaultValue);
   }

   public void cycle() {
      T[] constants = (T[])(((Enum)this.getValue()).getDeclaringClass().getEnumConstants());
      int next = (((Enum)this.getValue()).ordinal() + 1) % constants.length;
      this.setValue(constants[next]);
   }

   public boolean setValueByName(String name) {
      for(T constant : (Enum[])((Enum)this.getValue()).getDeclaringClass().getEnumConstants()) {
         if (constant.name().equalsIgnoreCase(name)) {
            this.setValue(constant);
            return true;
         }
      }

      return false;
   }

   public String[] getOptions() {
      T[] constants = (T[])(((Enum)this.getValue()).getDeclaringClass().getEnumConstants());
      String[] names = new String[constants.length];

      for(int i = 0; i < constants.length; ++i) {
         names[i] = constants[i].name();
      }

      return names;
   }
}
