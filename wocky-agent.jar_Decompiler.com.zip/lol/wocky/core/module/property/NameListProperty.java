package lol.wocky.core.module.property;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class NameListProperty extends Property<Set<String>> {
   private Set<String> lower = Collections.emptySet();

   public NameListProperty(CharSequence name) {
      super(name, Collections.emptySet());
   }

   public void setValue(Set<String> value) {
      Set<String> names = new LinkedHashSet();
      Set<String> keys = new LinkedHashSet();

      for(String n : value) {
         String name = n.trim();
         if (name.matches("[A-Za-z0-9_]{1,16}") && keys.add(name.toLowerCase(Locale.ROOT))) {
            names.add(name);
         }
      }

      super.setValue(Collections.unmodifiableSet(names));
      this.lower = Collections.unmodifiableSet(keys);
   }

   public void setFromString(String list) {
      this.setValue(new LinkedHashSet(List.of(list.split("[,\\s]+"))));
   }

   public String asString() {
      return String.join(",", (Iterable)this.getValue());
   }

   public boolean contains(String name) {
      return name != null && this.lower.contains(name.toLowerCase(Locale.ROOT));
   }
}
