package lol.wocky.core.module.property;

public class BooleanProperty extends Property<Boolean> {
   public BooleanProperty(CharSequence name, boolean defaultValue) {
      super(name, defaultValue);
   }

   public void toggle() {
      this.setValue(!(Boolean)this.getValue());
   }
}
