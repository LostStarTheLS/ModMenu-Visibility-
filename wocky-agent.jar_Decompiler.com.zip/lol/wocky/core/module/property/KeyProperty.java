package lol.wocky.core.module.property;

import lol.wocky.core.MinecraftBridge;

public class KeyProperty extends NumberProperty {
   public KeyProperty(CharSequence name, int defaultKey) {
      super(name, defaultKey, 0, 1005, 1);
   }

   public int getKey() {
      return this.intValue();
   }

   public boolean isDown() {
      return MinecraftBridge.isKeyDown(this.getKey());
   }
}
