package lol.wocky.core.module.property;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class BlockListProperty extends Property<Set<String>> {
   private int version;

   public BlockListProperty(CharSequence name, String... defaults) {
      super(name, Collections.unmodifiableSet(new LinkedHashSet(List.of(defaults))));
   }

   public void setValue(Set<String> value) {
      super.setValue(Collections.unmodifiableSet(new LinkedHashSet(value)));
      ++this.version;
   }

   public void setFromString(String csv) {
      Set<String> ids = new LinkedHashSet();

      for(String part : csv.split(",")) {
         String id = part.trim().toLowerCase(Locale.ROOT);
         if (id.startsWith("minecraft:")) {
            id = id.substring(10);
         }

         if (!id.isEmpty()) {
            ids.add(id);
         }
      }

      this.setValue(ids);
   }

   public String asString() {
      return String.join(",", (Iterable)this.getValue());
   }

   public boolean contains(String id) {
      return ((Set)this.getValue()).contains(id);
   }

   public int version() {
      return this.version;
   }
}
