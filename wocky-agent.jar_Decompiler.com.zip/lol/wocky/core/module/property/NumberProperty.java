package lol.wocky.core.module.property;

public class NumberProperty extends Property<Number> {
   private final Number min;
   private final Number max;
   private final Number step;

   public NumberProperty(CharSequence name, Number defaultValue, Number min, Number max, Number step) {
      super(name, defaultValue);
      this.min = min;
      this.max = max;
      this.step = step;
   }

   public Number getMin() {
      return this.min;
   }

   public Number getMax() {
      return this.max;
   }

   public void setValue(Number value) {
      if (value != null) {
         double v = Math.max(this.min.doubleValue(), Math.min(this.max.doubleValue(), value.doubleValue()));
         if (this.isInteger()) {
            super.setValue((int)Math.round(v));
         } else {
            super.setValue(v);
         }

      }
   }

   public boolean isInteger() {
      return this.min instanceof Integer && this.max instanceof Integer && this.step instanceof Integer;
   }

   public Number getStep() {
      return this.step;
   }

   public int intValue() {
      return ((Number)this.getValue()).intValue();
   }

   public double doubleValue() {
      return ((Number)this.getValue()).doubleValue();
   }

   public float floatValue() {
      return ((Number)this.getValue()).floatValue();
   }

   public long longValue() {
      return ((Number)this.getValue()).longValue();
   }
}
