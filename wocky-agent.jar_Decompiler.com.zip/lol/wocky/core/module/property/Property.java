package lol.wocky.core.module.property;

import java.util.function.Supplier;

public class Property<T> {
   private final CharSequence name;
   private T value;
   private Supplier<Boolean> hideCondition;

   public Property(CharSequence name, T defaultValue) {
      this.name = name;
      this.value = defaultValue;
   }

   public String getName() {
      return this.name.toString();
   }

   public T getValue() {
      return this.value;
   }

   public void setValue(T value) {
      this.value = value;
   }

   public <P extends Property<T>> P hideIf(Supplier<Boolean> condition) {
      this.hideCondition = condition;
      return (P)this;
   }

   public boolean isHidden() {
      return this.hideCondition != null && (Boolean)this.hideCondition.get();
   }
}
