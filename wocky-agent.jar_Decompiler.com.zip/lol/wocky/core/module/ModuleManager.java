package lol.wocky.core.module;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.File;
import java.io.PrintStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import lol.wocky.core.module.property.BlockListProperty;
import lol.wocky.core.module.property.BooleanProperty;
import lol.wocky.core.module.property.EnumProperty;
import lol.wocky.core.module.property.NameListProperty;
import lol.wocky.core.module.property.NumberProperty;
import lol.wocky.core.module.property.Property;

public final class ModuleManager {
   private static final List<Module> modules = new CopyOnWriteArrayList();
   private static final File CONFIG_DIR = resolveConfigDir();
   private static final File CONFIG_FILE;
   private static final Gson GSON;
   private static final ScheduledExecutorService saver;
   private static ScheduledFuture<?> pendingSave;
   private static final Map<String, String> FORMER_NAMES;
   public static final int DEFAULT_MENU_KEY = 344;
   private static volatile int menuKey;

   public static void migrateNames(JsonObject root) {
      for(Map.Entry<String, String> e : FORMER_NAMES.entrySet()) {
         if (!root.has((String)e.getKey()) && root.has((String)e.getValue())) {
            root.add((String)e.getKey(), root.get((String)e.getValue()));
         }

         root.remove((String)e.getValue());
      }

   }

   private ModuleManager() {
   }

   public static int getMenuKey() {
      return menuKey;
   }

   public static boolean setMenuKey(int key) {
      if (key >= 32 && key <= 348 && key != 256) {
         menuKey = key;
         saveConfig();
         return true;
      } else {
         return false;
      }
   }

   public static void register(Module module) {
      modules.add(module);
   }

   public static void disableAll() {
      for(Module m : modules) {
         try {
            m.setEnabled(false);
         } catch (Throwable t) {
            PrintStream var10000 = System.err;
            String var10001 = m.getName();
            var10000.println("[Wocky] Failed to disable " + var10001 + ": " + String.valueOf(t));
         }
      }

   }

   public static List<Module> getModules() {
      return Collections.unmodifiableList(modules);
   }

   public static List<Module> getModulesByCategory(ModuleCategory category) {
      List<Module> list = new ArrayList();

      for(Module m : modules) {
         if (m.getCategory() == category) {
            list.add(m);
         }
      }

      return list;
   }

   public static <T extends Module> T getByClass(Class<T> clazz) {
      for(Module m : modules) {
         if (clazz.isInstance(m)) {
            return (T)m;
         }
      }

      return null;
   }

   public static Module getByName(String name) {
      for(Module m : modules) {
         if (m.getName().equalsIgnoreCase(name)) {
            return m;
         }
      }

      return null;
   }

   public static Property<?> getProperty(Module m, String name) {
      for(Property<?> p : m.getProperties()) {
         if (p.getName().equalsIgnoreCase(name)) {
            return p;
         }
      }

      return null;
   }

   public static boolean applyValue(Property<?> p, String value) {
      try {
         if (p instanceof BooleanProperty bp) {
            bp.setValue(Boolean.parseBoolean(value));
         } else if (p instanceof NumberProperty np) {
            np.setValue((Number)Double.parseDouble(value));
         } else {
            if (p instanceof EnumProperty<?> ep) {
               return ep.setValueByName(value);
            }

            if (p instanceof BlockListProperty bl) {
               bl.setFromString(value);
            } else {
               if (!(p instanceof NameListProperty)) {
                  return false;
               }

               NameListProperty nl = (NameListProperty)p;
               nl.setFromString(value);
            }
         }

         return true;
      } catch (NumberFormatException var7) {
         return false;
      }
   }

   public static synchronized void saveConfig() {
      if (pendingSave != null) {
         pendingSave.cancel(false);
      }

      pendingSave = saver.schedule(ModuleManager::writeConfig, 500L, TimeUnit.MILLISECONDS);
   }

   public static synchronized void shutdown() {
      if (pendingSave != null && pendingSave.cancel(false)) {
         writeConfig();
      }

      pendingSave = null;
      saver.shutdown();
   }

   public static JsonObject snapshot() {
      JsonObject root = new JsonObject();

      for(Module m : modules) {
         JsonObject modJson = new JsonObject();
         modJson.addProperty("enabled", m.isEnabled() && !m.isHoldMode());
         modJson.addProperty("key", (Number)m.getKey());
         modJson.addProperty("holdMode", m.isHoldMode());
         JsonObject props = new JsonObject();

         for(Property<?> p : m.getProperties()) {
            if (p instanceof BooleanProperty bp) {
               props.addProperty(p.getName(), (Boolean)bp.getValue());
            } else if (p instanceof NumberProperty np) {
               props.addProperty(p.getName(), (Number)np.getValue());
            } else if (p instanceof EnumProperty<?> ep) {
               props.addProperty(p.getName(), ((Enum)ep.getValue()).name());
            } else if (p instanceof BlockListProperty bl) {
               props.addProperty(p.getName(), bl.asString());
            } else if (p instanceof NameListProperty nl) {
               props.addProperty(p.getName(), nl.asString());
            }
         }

         modJson.add("properties", props);
         root.add(m.getName(), modJson);
      }

      return root;
   }

   public static void apply(JsonObject root, boolean disableMissing) {
      migrateNames(root);

      for(Module m : modules) {
         if (!root.has(m.getName())) {
            if (disableMissing) {
               m.setEnabled(false);
            }
         } else {
            try {
               JsonObject modJson = root.getAsJsonObject(m.getName());
               if (modJson.has("key")) {
                  m.setKey(modJson.get("key").getAsInt());
               }

               if (modJson.has("holdMode")) {
                  m.setHoldMode(modJson.get("holdMode").getAsBoolean());
               }

               if (modJson.has("properties")) {
                  JsonObject props = modJson.getAsJsonObject("properties");

                  for(Property<?> p : m.getProperties()) {
                     JsonElement v = props.get(p.getName());
                     if (v != null && v.isJsonPrimitive()) {
                        applyValue(p, v.getAsString());
                     }
                  }
               }

               boolean on = modJson.has("enabled") && modJson.get("enabled").getAsBoolean();
               m.setEnabled(on && !m.isHoldMode());
            } catch (Throwable t) {
               PrintStream var10000 = System.err;
               String var10001 = m.getName();
               var10000.println("[Wocky] Bad config entry for " + var10001 + ": " + String.valueOf(t));
            }
         }
      }

   }

   private static File resolveConfigDir() {
      File home = new File(System.getProperty("user.home"));
      File dir = new File(home, ".wallah");
      File old = new File(home, ".wockyv3");
      if (!dir.exists() && old.isDirectory()) {
         try {
            Stream<Path> files = Files.walk(old.toPath());

            try {
               Objects.requireNonNull(files);

               for(Path src : files::iterator) {
                  Path dst = dir.toPath().resolve(old.toPath().relativize(src).toString());
                  if (Files.isDirectory(src, new LinkOption[0])) {
                     Files.createDirectories(dst);
                  } else {
                     Files.copy(src, dst, StandardCopyOption.REPLACE_EXISTING);
                  }
               }
            } catch (Throwable var8) {
               if (files != null) {
                  try {
                     files.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (files != null) {
               files.close();
            }
         } catch (Throwable t) {
            PrintStream var10000 = System.err;
            String var10001 = String.valueOf(old);
            var10000.println("[Wocky] Could not copy settings from " + var10001 + ": " + String.valueOf(t));
         }
      }

      return dir;
   }

   public static File configDir() {
      return CONFIG_DIR;
   }

   private static void writeConfig() {
      try {
         JsonObject root = snapshot();
         JsonObject client = new JsonObject();
         client.addProperty("menuKey", (Number)menuKey);
         root.add("_client", client);
         CONFIG_DIR.mkdirs();
         File tmp = new File(CONFIG_DIR, "config.json.tmp");
         Writer w = Files.newBufferedWriter(tmp.toPath(), StandardCharsets.UTF_8);

         try {
            GSON.toJson((JsonElement)root, (Appendable)w);
         } catch (Throwable var7) {
            if (w != null) {
               try {
                  w.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (w != null) {
            w.close();
         }

         Files.move(tmp.toPath(), CONFIG_FILE.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
      } catch (Throwable t) {
         System.err.println("[Wocky] Failed to save config: " + String.valueOf(t));
      }

   }

   public static void loadConfig() {
      if (CONFIG_FILE.exists()) {
         JsonObject root;
         try {
            Reader r = Files.newBufferedReader(CONFIG_FILE.toPath(), StandardCharsets.UTF_8);

            try {
               root = JsonParser.parseReader(r).getAsJsonObject();
            } catch (Throwable var5) {
               if (r != null) {
                  try {
                     r.close();
                  } catch (Throwable var4) {
                     var5.addSuppressed(var4);
                  }
               }

               throw var5;
            }

            if (r != null) {
               r.close();
            }
         } catch (Throwable t) {
            System.err.println("[Wocky] Failed to read config: " + String.valueOf(t));
            return;
         }

         apply(root, false);
         JsonElement var2 = root.get("_client");
         if (var2 instanceof JsonObject) {
            JsonObject client = (JsonObject)var2;
            if (client.has("menuKey")) {
               int key = client.get("menuKey").getAsInt();
               if (key >= 32 && key <= 348 && key != 256) {
                  menuKey = key;
               }
            }
         }

      }
   }

   static {
      CONFIG_FILE = new File(CONFIG_DIR, "config.json");
      GSON = (new GsonBuilder()).setPrettyPrinting().create();
      saver = Executors.newSingleThreadScheduledExecutor((r) -> {
         Thread t = new Thread(r, "Wocky-ConfigSaver");
         t.setDaemon(true);
         return t;
      });
      FORMER_NAMES = Map.of("AllahDTap", "DexDTap");
      menuKey = 344;
   }
}
