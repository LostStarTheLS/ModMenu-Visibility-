package lol.wocky.core.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import lol.wocky.core.module.property.Property;
import lol.wocky.core.render.Hud2D;

public abstract class Module {
   private final CharSequence name;
   private final CharSequence description;
   private final ModuleCategory category;
   private int key;
   private boolean holdMode;
   private boolean enabled;
   private String warning;
   private final List<Property<?>> properties;

   public Module(CharSequence name, CharSequence description, ModuleCategory category) {
      this.properties = new ArrayList();
      this.name = name;
      this.description = description;
      this.category = category;
      this.key = 0;
      this.enabled = false;
   }

   public Module(CharSequence name, CharSequence description, ModuleCategory category, int key) {
      this(name, description, category);
      this.key = key;
   }

   public void addProperties(Property<?>... props) {
      Collections.addAll(this.properties, props);
   }

   public String getName() {
      return this.name.toString();
   }

   public String getDescription() {
      return this.description.toString();
   }

   public String getWarning() {
      return this.warning;
   }

   protected void setWarning(String warning) {
      this.warning = warning;
   }

   public ModuleCategory getCategory() {
      return this.category;
   }

   public int getKey() {
      return this.key;
   }

   public void setKey(int key) {
      this.key = key;
   }

   public boolean isHoldMode() {
      return this.holdMode;
   }

   public void setHoldMode(boolean holdMode) {
      this.holdMode = holdMode;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean enabled) {
      if (this.enabled != enabled) {
         this.enabled = enabled;
         if (enabled) {
            this.onEnable();
         } else {
            this.onDisable();
         }
      }

   }

   public void toggle() {
      this.setEnabled(!this.enabled);
   }

   public List<Property<?>> getProperties() {
      return this.properties;
   }

   public void onEnable() {
   }

   public void onDisable() {
   }

   public void onTick() {
   }

   public void onHudRender(Hud2D hud) {
   }

   public boolean isExclusive() {
      return false;
   }

   public boolean cancelsItemUse() {
      return false;
   }

   public boolean cancelsAttack() {
      return false;
   }
}
