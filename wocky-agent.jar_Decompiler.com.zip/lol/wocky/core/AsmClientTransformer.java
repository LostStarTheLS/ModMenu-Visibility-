package lol.wocky.core;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.List;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

public final class AsmClientTransformer {
   private static final String INPUT_HOOK = "lol/wocky/hook/ClientInputHook";
   private static final String RENDER_HOOK = "lol/wocky/hook/RenderHook";
   private static final String HOOKS = "lol/wocky/hook/Hooks";
   private static final int EXPECTED_HOOKS = 13;
   private static final String[][] TARGETS = new String[][]{{"net.minecraft.class_310", "net.minecraft.client.MinecraftClient"}, {"net.minecraft.class_761", "net.minecraft.client.render.WorldRenderer"}, {"net.minecraft.class_329", "net.minecraft.client.gui.hud.InGameHud"}, {"net.minecraft.class_1007", "net.minecraft.client.render.entity.PlayerEntityRenderer"}, {"net.minecraft.class_898", "net.minecraft.client.render.entity.EntityRenderManager"}, {"net.minecraft.class_276", "net.minecraft.client.gl.Framebuffer"}, {"net.minecraft.class_634", "net.minecraft.client.network.ClientPlayNetworkHandler"}, {"net.minecraft.class_312", "net.minecraft.client.Mouse"}, {"net.minecraft.class_636", "net.minecraft.client.network.ClientPlayerInteractionManager"}};
   private static Instrumentation instrumentation;
   private static final List<Class<?>> targets = new ArrayList();
   private static ClassFileTransformer transformer;

   private AsmClientTransformer() {
   }

   public static synchronized boolean install(Instrumentation inst) {
      if (transformer != null) {
         return true;
      } else {
         targets.clear();

         for(String[] names : TARGETS) {
            for(Class<?> c : inst.getAllLoadedClasses()) {
               if (c.getName().equals(names[0]) || c.getName().equals(names[1])) {
                  targets.add(c);
                  break;
               }
            }
         }

         if (!targets.isEmpty() && isMinecraftClient((Class)targets.get(0))) {
            final ClassLoader targetLoader = ((Class)targets.get(0)).getClassLoader();
            final List<String> targetNames = new ArrayList();

            for(String[] names : TARGETS) {
               for(String n : names) {
                  targetNames.add(n.replace('.', '/'));
               }
            }

            final int[] hooked = new int[]{0};
            ClassFileTransformer t = new ClassFileTransformer() {
               public byte[] transform(ClassLoader loader, String className, Class<?> redefined, ProtectionDomain domain, byte[] bytes) {
                  if (loader == targetLoader && targetNames.contains(className)) {
                     try {
                        ClassReader reader = new ClassReader(bytes);
                        ClassWriter writer = new ClassWriter(1);
                        reader.accept(new HookVisitor(writer, className, hooked), 8);
                        return writer.toByteArray();
                     } catch (Throwable e) {
                        System.err.println("[Wocky] Failed to transform " + className + ": " + String.valueOf(e));
                        e.printStackTrace();
                        return null;
                     }
                  } else {
                     return null;
                  }
               }
            };

            try {
               inst.addTransformer(t, true);
               inst.retransformClasses((Class[])targets.toArray(new Class[0]));
            } catch (Throwable e) {
               inst.removeTransformer(t);
               System.err.println("[Wocky] Failed to hook Minecraft: " + String.valueOf(e));
               return false;
            }

            instrumentation = inst;
            transformer = t;
            if (targets.size() < TARGETS.length) {
               System.out.println("[Wocky] Hooked " + hooked[0] + " Minecraft methods; " + (TARGETS.length - targets.size()) + " target class(es) will be hooked when they load");
            } else if (hooked[0] != 13) {
               System.err.println("[Wocky] Only " + hooked[0] + "/13 Minecraft methods were hooked; check mappings");
            } else {
               System.out.println("[Wocky] Hooked MinecraftClient, WorldRenderer, InGameHud, PlayerEntityRenderer, EntityRenderManager, Framebuffer, ClientPlayNetworkHandler, Mouse, ClientPlayerInteractionManager");
            }

            return true;
         } else {
            System.err.println("[Wocky] Cannot hook: MinecraftClient is not loaded");
            return false;
         }
      }
   }

   private static boolean isMinecraftClient(Class<?> c) {
      return c.getName().equals(TARGETS[0][0]) || c.getName().equals(TARGETS[0][1]);
   }

   public static synchronized void uninstall() {
      if (transformer != null) {
         try {
            instrumentation.removeTransformer(transformer);
            List<Class<?>> loaded = new ArrayList(targets);

            for(Class<?> c : instrumentation.getAllLoadedClasses()) {
               if (!loaded.contains(c) && c.getClassLoader() == ((Class)targets.get(0)).getClassLoader()) {
                  for(String[] names : TARGETS) {
                     if (c.getName().equals(names[0]) || c.getName().equals(names[1])) {
                        loaded.add(c);
                     }
                  }
               }
            }

            instrumentation.retransformClasses((Class[])loaded.toArray(new Class[0]));
            System.out.println("[Wocky] Restored original Minecraft classes");
         } catch (Throwable e) {
            System.err.println("[Wocky] Failed to restore Minecraft classes: " + String.valueOf(e));
         }

         transformer = null;
      }
   }

   private static final class HookVisitor extends ClassVisitor {
      private final String owner;
      private final int[] hooked;

      HookVisitor(ClassVisitor next, String owner, int[] hooked) {
         super(589824, next);
         this.owner = owner;
         this.hooked = hooked;
      }

      public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
         MethodVisitor mv = super.visitMethod(access, name, desc, signature, exceptions);
         if (!this.owner.endsWith("class_310") && !this.owner.endsWith("MinecraftClient")) {
            if (!this.owner.endsWith("class_761") && !this.owner.endsWith("WorldRenderer")) {
               if (!this.owner.endsWith("class_329") && !this.owner.endsWith("InGameHud")) {
                  if (!this.owner.endsWith("class_1007") && !this.owner.endsWith("PlayerEntityRenderer")) {
                     if (!this.owner.endsWith("class_898") && !this.owner.endsWith("EntityRenderManager")) {
                        if (!this.owner.endsWith("class_276") && !this.owner.endsWith("gl/Framebuffer")) {
                           if (!this.owner.endsWith("class_312") && !this.owner.endsWith("client/Mouse")) {
                              if (!this.owner.endsWith("class_634") && !this.owner.endsWith("ClientPlayNetworkHandler")) {
                                 if ((this.owner.endsWith("/class_636") || this.owner.endsWith("ClientPlayerInteractionManager")) && is(name, "method_2906", "clickSlot") && Type.getArgumentTypes(desc).length == 5) {
                                    int var18 = this.hooked[0]++;
                                    return hookTestArgs(mv, "clickSlot", this.owner, desc, 177);
                                 }
                              } else if (is(name, "method_11148", "onEntityStatus") && Type.getArgumentTypes(desc).length == 1) {
                                 int var17 = this.hooked[0]++;
                                 return notifyHook(mv, "entityStatus", 1);
                              }
                           } else if (is(name, "method_1606", "updateMouse") && desc.equals("(D)V")) {
                              int var16 = this.hooked[0]++;
                              return hookTest(mv, "lockMouse", 0, entryLocals(this.owner, desc), 177);
                           }
                        } else if (is(name, "method_1237", "blitToScreen") && desc.equals("()V")) {
                           int var15 = this.hooked[0]++;
                           return notifyHook(mv, "beforeBlit", 0);
                        }
                     } else if (is(name, "method_3950", "shouldRender") && desc.endsWith("DDD)Z") && Type.getArgumentTypes(desc).length == 5) {
                        int var14 = this.hooked[0]++;
                        return hookTest(mv, "hideEntity", entryLocals(this.owner, desc), 3, 172);
                     }
                  } else if (is(name, "method_74935", "hasLabel") && desc.endsWith("D)Z") && Type.getArgumentTypes(desc).length == 2) {
                     int var13 = this.hooked[0]++;
                     return hookTest(mv, "hideLabel", entryLocals(this.owner, desc), 3, 172);
                  }
               } else {
                  if (is(name, "method_1765", "renderStatusEffectOverlay") && Type.getArgumentTypes(desc).length == 2) {
                     int var12 = this.hooked[0]++;
                     return hookTest(mv, "hideEffects", entryLocals(this.owner, desc), 177);
                  }

                  if (is(name, "method_1753", "render") && Type.getArgumentTypes(desc).length == 2) {
                     int var11 = this.hooked[0]++;
                     return new AtStart(mv) {
                        {
                           super(mv);
                        }

                        void inject() {
                           this.mv.visitVarInsn(25, 1);
                           this.mv.visitMethodInsn(184, "lol/wocky/hook/RenderHook", "hudRender", "(Ljava/lang/Object;)V", false);
                        }
                     };
                  }
               }
            } else if (is(name, "method_22710", "render") && Type.getArgumentTypes(desc).length == 10) {
               int var10 = this.hooked[0]++;
               return new AtStart(mv) {
                  {
                     super(mv);
                  }

                  void inject() {
                     this.mv.visitVarInsn(25, 2);
                     this.mv.visitVarInsn(25, 4);
                     this.mv.visitVarInsn(25, 5);
                     this.mv.visitVarInsn(25, 6);
                     this.mv.visitMethodInsn(184, "lol/wocky/hook/RenderHook", "worldRender", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V", false);
                  }
               };
            }
         } else {
            if (is(name, "method_1574", "tick") && desc.equals("()V")) {
               int var9 = this.hooked[0]++;
               return new AtStart(mv) {
                  {
                     super(mv);
                  }

                  void inject() {
                     this.mv.visitMethodInsn(184, "lol/wocky/hook/ClientInputHook", "tick", "()V", false);
                  }
               };
            }

            if (is(name, "method_1583", "doItemUse") && desc.equals("()V")) {
               int var8 = this.hooked[0]++;
               return cancellable(mv, "cancelItemUse", new Object[]{this.owner}, 177);
            }

            if (is(name, "method_1536", "doAttack") && desc.equals("()Z")) {
               int var7 = this.hooked[0]++;
               return cancellable(mv, "cancelAttack", new Object[]{this.owner}, 3, 172);
            }

            if (is(name, "method_1590", "handleBlockBreaking") && desc.equals("(Z)V")) {
               int var10002 = this.hooked[0]++;
               return cancellable(mv, "cancelAttack", new Object[]{this.owner, Opcodes.INTEGER}, 177);
            }
         }

         return mv;
      }

      private static MethodVisitor hookTestArgs(MethodVisitor mv, String id, String owner, String desc, int... returnOps) {
         Object[] entryLocals = entryLocals(owner, desc);
         Type[] args = Type.getArgumentTypes(desc);
         return new AtStart(mv, id, args, returnOps, entryLocals) {
            // $FF: synthetic field
            final String val$id;
            // $FF: synthetic field
            final Type[] val$args;
            // $FF: synthetic field
            final int[] val$returnOps;
            // $FF: synthetic field
            final Object[] val$entryLocals;

            {
               super(mv);
               this.val$id = var2;
               this.val$args = var3;
               this.val$returnOps = var4;
               this.val$entryLocals = var5;
            }

            void inject() {
               Label proceed = new Label();
               this.mv.visitLdcInsn(this.val$id);
               this.mv.visitLdcInsn(this.val$args.length + 1);
               this.mv.visitTypeInsn(189, "java/lang/Object");
               this.mv.visitInsn(89);
               this.mv.visitInsn(3);
               this.mv.visitVarInsn(25, 0);
               this.mv.visitInsn(83);
               int slot = 1;

               for(int i = 0; i < this.val$args.length; ++i) {
                  this.mv.visitInsn(89);
                  this.mv.visitLdcInsn(i + 1);
                  this.mv.visitVarInsn(this.val$args[i].getOpcode(21), slot);
                  AsmClientTransformer.HookVisitor.box(this.mv, this.val$args[i]);
                  this.mv.visitInsn(83);
                  slot += this.val$args[i].getSize();
               }

               this.mv.visitMethodInsn(184, "lol/wocky/hook/Hooks", "test", "(Ljava/lang/String;Ljava/lang/Object;)Z", false);
               this.mv.visitJumpInsn(153, proceed);

               for(int op : this.val$returnOps) {
                  this.mv.visitInsn(op);
               }

               this.mv.visitLabel(proceed);
               this.mv.visitFrame(-1, this.val$entryLocals.length, this.val$entryLocals, 0, new Object[0]);
               this.mv.visitInsn(0);
            }
         };
      }

      private static void box(MethodVisitor mv, Type t) {
         String var10000;
         switch (t.getSort()) {
            case 1 -> var10000 = "java/lang/Boolean";
            case 2 -> var10000 = "java/lang/Character";
            case 3 -> var10000 = "java/lang/Byte";
            case 4 -> var10000 = "java/lang/Short";
            case 5 -> var10000 = "java/lang/Integer";
            case 6 -> var10000 = "java/lang/Float";
            case 7 -> var10000 = "java/lang/Long";
            case 8 -> var10000 = "java/lang/Double";
            default -> var10000 = null;
         }

         String wrapper = var10000;
         if (wrapper != null) {
            mv.visitMethodInsn(184, wrapper, "valueOf", "(" + t.getDescriptor() + ")L" + wrapper + ";", false);
         }

      }

      private static MethodVisitor notifyHook(MethodVisitor mv, String id, int slot) {
         return new AtStart(mv, id, slot) {
            // $FF: synthetic field
            final String val$id;
            // $FF: synthetic field
            final int val$slot;

            {
               super(mv);
               this.val$id = var2;
               this.val$slot = var3;
            }

            void inject() {
               this.mv.visitLdcInsn(this.val$id);
               this.mv.visitVarInsn(25, this.val$slot);
               this.mv.visitMethodInsn(184, "lol/wocky/hook/Hooks", "test", "(Ljava/lang/String;Ljava/lang/Object;)Z", false);
               this.mv.visitInsn(87);
            }
         };
      }

      private static MethodVisitor hookTest(MethodVisitor mv, String id, Object[] entryLocals, int... returnOps) {
         return hookTest(mv, id, 1, entryLocals, returnOps);
      }

      private static MethodVisitor hookTest(MethodVisitor mv, String id, int slot, Object[] entryLocals, int... returnOps) {
         return new AtStart(mv, id, slot, returnOps, entryLocals) {
            // $FF: synthetic field
            final String val$id;
            // $FF: synthetic field
            final int val$slot;
            // $FF: synthetic field
            final int[] val$returnOps;
            // $FF: synthetic field
            final Object[] val$entryLocals;

            {
               super(mv);
               this.val$id = var2;
               this.val$slot = var3;
               this.val$returnOps = var4;
               this.val$entryLocals = var5;
            }

            void inject() {
               Label proceed = new Label();
               this.mv.visitLdcInsn(this.val$id);
               this.mv.visitVarInsn(25, this.val$slot);
               this.mv.visitMethodInsn(184, "lol/wocky/hook/Hooks", "test", "(Ljava/lang/String;Ljava/lang/Object;)Z", false);
               this.mv.visitJumpInsn(153, proceed);

               for(int op : this.val$returnOps) {
                  this.mv.visitInsn(op);
               }

               this.mv.visitLabel(proceed);
               this.mv.visitFrame(-1, this.val$entryLocals.length, this.val$entryLocals, 0, new Object[0]);
               this.mv.visitInsn(0);
            }
         };
      }

      private static Object[] entryLocals(String owner, String desc) {
         Type[] args = Type.getArgumentTypes(desc);
         Object[] locals = new Object[args.length + 1];
         locals[0] = owner;

         for(int i = 0; i < args.length; ++i) {
            int var10001 = i + 1;
            Object var10002;
            switch (args[i].getSort()) {
               case 1:
               case 2:
               case 3:
               case 4:
               case 5:
                  var10002 = Opcodes.INTEGER;
                  break;
               case 6:
                  var10002 = Opcodes.FLOAT;
                  break;
               case 7:
                  var10002 = Opcodes.LONG;
                  break;
               case 8:
                  var10002 = Opcodes.DOUBLE;
                  break;
               default:
                  var10002 = args[i].getInternalName();
            }

            locals[var10001] = var10002;
         }

         return locals;
      }

      private static MethodVisitor cancellable(MethodVisitor mv, String predicate, Object[] entryLocals, int... returnOps) {
         return new AtStart(mv, predicate, returnOps, entryLocals) {
            // $FF: synthetic field
            final String val$predicate;
            // $FF: synthetic field
            final int[] val$returnOps;
            // $FF: synthetic field
            final Object[] val$entryLocals;

            {
               super(mv);
               this.val$predicate = var2;
               this.val$returnOps = var3;
               this.val$entryLocals = var4;
            }

            void inject() {
               Label proceed = new Label();
               this.mv.visitMethodInsn(184, "lol/wocky/hook/ClientInputHook", this.val$predicate, "()Z", false);
               this.mv.visitJumpInsn(153, proceed);

               for(int op : this.val$returnOps) {
                  this.mv.visitInsn(op);
               }

               this.mv.visitLabel(proceed);
               this.mv.visitFrame(-1, this.val$entryLocals.length, this.val$entryLocals, 0, new Object[0]);
               this.mv.visitInsn(0);
            }
         };
      }

      private static boolean is(String name, String intermediary, String named) {
         return name.equals(intermediary) || name.equals(named);
      }
   }

   private abstract static class AtStart extends MethodVisitor {
      AtStart(MethodVisitor mv) {
         super(589824, mv);
      }

      abstract void inject();

      public void visitCode() {
         super.visitCode();
         this.inject();
      }
   }
}
