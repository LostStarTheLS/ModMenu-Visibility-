package lol.wocky.agent;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.Method;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import lol.wocky.core.WockyCore;

public final class AgentBootstrap {
   private static final String HOOK_CLASS = "lol.wocky.hook.ClientInputHook";
   private static final String RENDER_HOOK_CLASS = "lol.wocky.hook.RenderHook";
   private static final String HOOKS_CLASS = "lol.wocky.hook.Hooks";

   private AgentBootstrap() {
   }

   public static void start(Instrumentation inst, File jar) {
      try {
         PrintStream var10000 = System.out;
         String var10001 = buildStamp(jar);
         var10000.println("[Wocky] Agent attached (build " + var10001 + ", " + String.valueOf(jar) + ")");
         ClassLoader mcLoader = findMinecraftLoader(inst);
         if (mcLoader == null) {
            System.err.println("[Wocky] MinecraftClient is not loaded; is this a Minecraft 1.21.11 client?");
            return;
         }

         Class<?> hook = installHook(mcLoader, jar, "lol.wocky.hook.ClientInputHook");
         shutdownPrevious(hook);
         Class<?> renderHook = installHook(mcLoader, jar, "lol.wocky.hook.RenderHook");
         Class<?> hooks = installHook(mcLoader, jar, "lol.wocky.hook.Hooks");
         WockyCore.init(inst, hook, renderHook, hooks);
      } catch (Throwable t) {
         System.err.println("[Wocky] Agent initialization failed: " + String.valueOf(t));
         t.printStackTrace();
      }

   }

   private static String buildStamp(File jar) {
      try {
         JarFile jf = new JarFile(jar);

         String var3;
         try {
            String stamp = jf.getManifest().getMainAttributes().getValue("Wocky-Build");
            var3 = stamp != null ? stamp : "unknown";
         } catch (Throwable var5) {
            try {
               jf.close();
            } catch (Throwable var4) {
               var5.addSuppressed(var4);
            }

            throw var5;
         }

         jf.close();
         return var3;
      } catch (Throwable var6) {
         return "unknown";
      }
   }

   private static ClassLoader findMinecraftLoader(Instrumentation inst) {
      for(Class<?> c : inst.getAllLoadedClasses()) {
         String n = c.getName();
         if (n.equals("net.minecraft.class_310") || n.equals("net.minecraft.client.MinecraftClient")) {
            return c.getClassLoader();
         }
      }

      return null;
   }

   private static Class<?> installHook(ClassLoader mcLoader, File agentJar, String className) throws Exception {
      try {
         return Class.forName(className, true, mcLoader);
      } catch (NoClassDefFoundError | ClassNotFoundException var6) {
         Method addUrl;
         try {
            addUrl = mcLoader.getClass().getMethod("addUrlFwd", URL.class);
            addUrl.setAccessible(true);
         } catch (NoSuchMethodException var5) {
            throw new IllegalStateException("Cannot expose the hook to " + mcLoader.getClass().getName());
         }

         addUrl.invoke(mcLoader, extractHookJar(agentJar, className).toUri().toURL());
         return Class.forName(className, true, mcLoader);
      }
   }

   private static Path extractHookJar(File agentJar, String className) throws Exception {
      String entryName = className.replace('.', '/') + ".class";
      Path hookJar = Files.createTempFile("wocky-hook", ".jar");
      hookJar.toFile().deleteOnExit();
      JarFile src = new JarFile(agentJar);

      try {
         OutputStream fileOut = Files.newOutputStream(hookJar);

         try {
            JarOutputStream out = new JarOutputStream(fileOut);

            try {
               JarEntry entry = src.getJarEntry(entryName);
               if (entry == null) {
                  throw new IllegalStateException(entryName + " missing from " + String.valueOf(agentJar));
               }

               out.putNextEntry(new JarEntry(entryName));
               InputStream in = src.getInputStream(entry);

               try {
                  in.transferTo(out);
               } catch (Throwable var15) {
                  if (in != null) {
                     try {
                        in.close();
                     } catch (Throwable var14) {
                        var15.addSuppressed(var14);
                     }
                  }

                  throw var15;
               }

               if (in != null) {
                  in.close();
               }

               out.closeEntry();
            } catch (Throwable var16) {
               try {
                  out.close();
               } catch (Throwable var13) {
                  var16.addSuppressed(var13);
               }

               throw var16;
            }

            out.close();
         } catch (Throwable var17) {
            if (fileOut != null) {
               try {
                  fileOut.close();
               } catch (Throwable var12) {
                  var17.addSuppressed(var12);
               }
            }

            throw var17;
         }

         if (fileOut != null) {
            fileOut.close();
         }
      } catch (Throwable var18) {
         try {
            src.close();
         } catch (Throwable var11) {
            var18.addSuppressed(var11);
         }

         throw var18;
      }

      src.close();
      return hookJar;
   }

   private static void shutdownPrevious(Class<?> hook) {
      try {
         Runnable previous = (Runnable)hook.getField("activeShutdown").get((Object)null);
         if (previous != null) {
            System.out.println("[Wocky] Shutting down previous injection");
            previous.run();
         }
      } catch (Throwable t) {
         System.err.println("[Wocky] Could not shut down previous injection: " + String.valueOf(t));
      }

   }
}
