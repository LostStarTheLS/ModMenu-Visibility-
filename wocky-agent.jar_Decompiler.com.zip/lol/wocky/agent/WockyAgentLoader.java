package lol.wocky.agent;

import java.io.File;
import java.lang.instrument.Instrumentation;
import java.net.URL;
import java.net.URLClassLoader;

public final class WockyAgentLoader {
   private WockyAgentLoader() {
   }

   public static void agentmain(String args, Instrumentation inst) {
      try {
         File jar = args != null && !args.isBlank() && (new File(args.trim())).isFile() ? new File(args.trim()) : new File(WockyAgentLoader.class.getProtectionDomain().getCodeSource().getLocation().toURI());
         ClassLoader loader = new AgentClassLoader(new URL[]{jar.toURI().toURL()});
         loader.loadClass("lol.wocky.agent.AgentBootstrap").getMethod("start", Instrumentation.class, File.class).invoke((Object)null, inst, jar);
      } catch (Throwable t) {
         System.err.println("[Wocky] Agent failed to start: " + String.valueOf(t));
         t.printStackTrace();
      }

   }

   public static void premain(String args, Instrumentation inst) {
      agentmain(args, inst);
   }

   public static final class AgentClassLoader extends URLClassLoader {
      public AgentClassLoader(URL[] urls) {
         super("wocky-agent", urls, ClassLoader.getPlatformClassLoader());
      }

      protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
         if (!name.startsWith("java.") && !name.startsWith("javax.") && !name.startsWith("jdk.") && !name.startsWith("sun.")) {
            synchronized(this.getClassLoadingLock(name)) {
               Class<?> c = this.findLoadedClass(name);
               if (c == null) {
                  try {
                     c = this.findClass(name);
                  } catch (ClassNotFoundException var7) {
                     return super.loadClass(name, resolve);
                  }
               }

               if (resolve) {
                  this.resolveClass(c);
               }

               return c;
            }
         } else {
            return super.loadClass(name, resolve);
         }
      }
   }
}
