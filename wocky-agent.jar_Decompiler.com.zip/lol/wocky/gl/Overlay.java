package lol.wocky.gl;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL33;
import org.lwjgl.stb.STBImage;
import org.lwjgl.stb.STBTTAlignedQuad;
import org.lwjgl.stb.STBTTFontinfo;
import org.lwjgl.stb.STBTTPackContext;
import org.lwjgl.stb.STBTTPackedchar;
import org.lwjgl.stb.STBTruetype;
import org.lwjgl.system.MemoryStack;

public final class Overlay {
   private static final List<Tag> tags = new ArrayList();
   private static final List<Shapes> shapes = new ArrayList();
   private static Watermark watermark;
   private static ModuleList moduleList;
   private static Effects effects;
   private static TargetCard target;
   private static final int SLOTS = 4;
   private static final float[] rects = new float[16];
   private static float[] published = nanRects();
   private static final long[] lastDrawn = new long[4];
   private static final long RECT_HOLD_NS = 400000000L;
   private static final int FIRST_CHAR = 32;
   private static final int CHAR_COUNT = 224;
   private static final int ATLAS = 1024;
   private static final char INFINITY = '∞';
   private static ByteBuffer ttf;
   private static STBTTFontinfo fontInfo;
   private static final Map<Float, Font> fonts = new HashMap();
   private static ByteBuffer logoPng;
   private static int logoTex;
   private static final Map<String, ByteBuffer> iconPng = new HashMap();
   private static final Map<String, Integer> iconTex = new HashMap();
   private static boolean ready;
   private static long retryAt;
   private static int vao;
   private static int vbo;
   private static int progBlur;
   private static int progPill;
   private static int progFlat;
   private static int samplerNearest;
   private static float glassAlpha = 1.0F;
   private static int fbW;
   private static int fbH;
   private static int texA;
   private static int texB;
   private static int fboA;
   private static int fboB;
   private static int targetFbo;
   private static int targetTex;
   private static FloatBuffer verts = BufferUtils.createFloatBuffer(12288);
   private static final int MODE_SOLID = 0;
   private static final int MODE_TEXT = 1;
   private static final int MODE_TEXT_WAVE = 2;
   private static final int MODE_SOLID_WAVE = 3;
   private static final int MODE_IMAGE = 4;
   private static final int MODE_LINE = 5;
   private static final String VERT = "#version 150\nin vec2 aPos;\nin vec2 aUv;\nin vec4 aCol;\nuniform vec2 uScreen;\nout vec2 vUv;\nout vec4 vCol;\nvoid main() {\n    vUv = aUv;\n    vCol = aCol;\n    gl_Position = vec4(aPos.x / uScreen.x * 2.0 - 1.0, 1.0 - aPos.y / uScreen.y * 2.0, 0.0, 1.0);\n}\n";
   private static final String FRAG_BLUR = "#version 150\nuniform sampler2D uTex;\nuniform vec2 uTexel;\nuniform vec2 uDir;\nuniform float uSpread;\nout vec4 fragColor;\nvoid main() {\n    vec2 uv = gl_FragCoord.xy * uTexel;\n    vec2 step = uDir * uTexel * uSpread;\n    vec4 c = texture(uTex, uv) * 0.2270270270;\n    c += texture(uTex, uv + step * 1.3846153846) * 0.3162162162;\n    c += texture(uTex, uv - step * 1.3846153846) * 0.3162162162;\n    c += texture(uTex, uv + step * 3.2307692308) * 0.0702702703;\n    c += texture(uTex, uv - step * 3.2307692308) * 0.0702702703;\n    fragColor = vec4(c.rgb, 1.0);\n}\n";
   private static final String FRAG_PILL = "#version 150\nuniform sampler2D uTex;\nuniform vec2 uTexel;\nuniform vec4 uRect;\nuniform float uRadius;\nuniform vec4 uTint;\nuniform vec4 uEdge;\nuniform float uAlpha;\nout vec4 fragColor;\nfloat sdRoundRect(vec2 p, vec2 b, float r) {\n    vec2 q = abs(p) - b + r;\n    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;\n}\nvoid main() {\n    vec2 center = (uRect.xy + uRect.zw) * 0.5;\n    vec2 halfSize = (uRect.zw - uRect.xy) * 0.5;\n    float d = sdRoundRect(gl_FragCoord.xy - center, halfSize, uRadius);\n    float alpha = clamp(0.5 - d, 0.0, 1.0);\n    vec3 col = mix(texture(uTex, gl_FragCoord.xy * uTexel).rgb, uTint.rgb, uTint.a);\n    // Hairline rim, brighter along the top like the GUI's glass cards.\n    float rim = clamp(1.0 - abs(d + 0.75), 0.0, 1.0);\n    float top = clamp((gl_FragCoord.y - center.y) / halfSize.y * 0.5 + 0.5, 0.0, 1.0);\n    col = mix(col, uEdge.rgb, rim * uEdge.a * (0.45 + 0.55 * top));\n    fragColor = vec4(col, alpha * uAlpha);\n}\n";
   private static final String FRAG_FLAT = "#version 150\nuniform sampler2D uTex;\nuniform int uMode;\nuniform vec2 uWave;\nuniform float uTime;\nuniform vec3 uColA;\nuniform vec3 uColB;\nin vec2 vUv;\nin vec4 vCol;\nout vec4 fragColor;\nvec3 wave() {\n    float t = 0.5 + 0.5 * sin(dot(gl_FragCoord.xy, uWave) + uTime);\n    return mix(uColA, uColB, smoothstep(0.0, 1.0, t));\n}\nvoid main() {\n    if (uMode == 4) {\n        vec4 img = texture(uTex, vUv);\n        fragColor = vec4(img.rgb * vCol.rgb, img.a * vCol.a);\n        return;\n    }\n    if (uMode == 5) {\n        fragColor = vec4(vCol.rgb, vCol.a * clamp(vUv.x + 0.5 - abs(vUv.y), 0.0, 1.0));\n        return;\n    }\n    float a = (uMode == 1 || uMode == 2) ? texture(uTex, vUv).r : 1.0;\n    vec3 rgb = (uMode == 2 || uMode == 3) ? wave() : vCol.rgb;\n    fragColor = vec4(rgb, vCol.a * a);\n}\n";
   private static final float[] WHITE = new float[]{1.0F, 1.0F, 1.0F};
   private static final float[] PINK = new float[]{0.925F, 0.431F, 0.816F};
   private static final float[] GOLD = new float[]{1.0F, 0.82F, 0.36F};

   private Overlay() {
   }

   public static void tag(float cx, float bottom, String text, float unit) {
      if (tags.size() > 512) {
         tags.clear();
      }

      tags.add(new Tag(cx, bottom, text, unit));
   }

   public static void shapes(float[] lines, int[] lineColors, int lineCount, float lineWidth, float[] tris, int[] triColors, int triCount) {
      if (lineCount > 0 || triCount > 0) {
         if (shapes.size() > 64) {
            shapes.clear();
         }

         shapes.add(new Shapes(Arrays.copyOf(lines, lineCount * 4), Arrays.copyOf(lineColors, lineCount * 2), lineCount, lineWidth, Arrays.copyOf(tris, triCount * 6), Arrays.copyOf(triColors, triCount), triCount));
      }
   }

   public static void targetHud(String name, int skin, float[] v, String distance, String info, float unit, float[] pos) {
      target = new TargetCard(name, skin, (float[])(([F)v).clone(), distance, info, unit, pos);
   }

   public static void watermark(String title, String info, float unit, float[] pos) {
      watermark = new Watermark(title, info, unit, pos);
   }

   public static void moduleList(String[] names, float unit, float[] pos) {
      moduleList = new ModuleList(names, unit, pos);
   }

   public static void effects(String[] ids, String[] labels, String[] times, boolean[] expiring, float unit, float[] pos) {
      effects = new Effects(ids, labels, times, expiring, unit, pos);
   }

   private static double animTime() {
      return (double)System.nanoTime() / (double)1.0E9F;
   }

   private static float[] nanRects() {
      float[] r = new float[16];
      Arrays.fill(r, Float.NaN);
      return r;
   }

   public static float[] lastRects() {
      return (float[])published.clone();
   }

   private static void record(int slot, float x1, float y1, float x2, float y2) {
      lastDrawn[slot] = System.nanoTime();
      rects[slot * 4] = x1;
      rects[slot * 4 + 1] = y1;
      rects[slot * 4 + 2] = x2;
      rects[slot * 4 + 3] = y2;
   }

   private static void publishRects() {
      float[] next = (float[])published.clone();
      long now = System.nanoTime();

      for(int slot = 0; slot < 4; ++slot) {
         boolean drawn = !Float.isNaN(rects[slot * 4]);
         if (drawn) {
            System.arraycopy(rects, slot * 4, next, slot * 4, 4);
         } else if (now - lastDrawn[slot] > 400000000L) {
            Arrays.fill(next, slot * 4, slot * 4 + 4, Float.NaN);
         }
      }

      published = next;
   }

   private static float[] place(float w, float h, float[] pos, float defX, float defY) {
      float x = defX;
      float y = defY;
      if (pos != null) {
         x = pos[2] > 0.5F ? pos[0] * (float)fbW - w : pos[0] * (float)fbW;
         y = pos[3] > 0.5F ? pos[1] * (float)fbH - h : pos[1] * (float)fbH;
      }

      x = Math.max(0.0F, Math.min((float)fbW - w, x));
      y = Math.max(0.0F, Math.min((float)fbH - h, y));
      return new float[]{(float)Math.round(x), (float)Math.round(y)};
   }

   public static void effectIcon(String id, byte[] png) {
      iconPng.put(id, BufferUtils.createByteBuffer(png.length).put(png).flip());
   }

   public static void clear() {
      tags.clear();
      shapes.clear();
      watermark = null;
      moduleList = null;
      effects = null;
      target = null;
   }

   public static boolean isFailed() {
      return System.nanoTime() < retryAt;
   }

   public static void setFont(byte[] bytes) {
      ttf = BufferUtils.createByteBuffer(bytes.length).put(bytes).flip();
   }

   public static void setLogo(byte[] png) {
      logoPng = BufferUtils.createByteBuffer(png.length).put(png).flip();
   }

   private static STBTTFontinfo fontInfo() {
      if (fontInfo == null) {
         fontInfo = STBTTFontinfo.malloc();
         if (!STBTruetype.stbtt_InitFont(fontInfo, ttf)) {
            throw new IllegalStateException("bad font");
         }
      }

      return fontInfo;
   }

   private static Font font(float px) {
      return (Font)fonts.computeIfAbsent((float)Math.round(px), Font::new);
   }

   private static int glyph(char c) {
      int i = c - 32;
      return i >= 0 && i < 224 ? i : 31;
   }

   public static void render(int targetTexture, int width, int height) {
      boolean empty = tags.isEmpty() && shapes.isEmpty() && watermark == null && moduleList == null && effects == null && target == null;
      if (!empty && !isFailed() && ttf != null && width > 0 && height > 0) {
         GlState saved = Overlay.GlState.capture();
         boolean broken = false;

         try {
            if (!ready) {
               init();
            }

            ensureTargets(width, height);
            if (!bindTarget(targetTexture)) {
               return;
            }

            prepareCommonState();

            for(Shapes sh : shapes) {
               drawShapes(sh);
            }

            for(Tag t : tags) {
               drawTag(t);
            }

            Arrays.fill(rects, Float.NaN);
            if (watermark != null) {
               drawWatermark(watermark);
            }

            if (effects != null) {
               drawEffects(effects);
            }

            if (moduleList != null) {
               drawModuleList(moduleList);
            }

            if (target != null) {
               drawTarget(target);
            }

            publishRects();
         } catch (Throwable t) {
            broken = true;
            System.err.println("[Wocky] Overlay renderer error, retrying in 2s: " + String.valueOf(t));
            t.printStackTrace();
         } finally {
            saved.restore();
            clear();
         }

         if (broken) {
            dispose();
            retryAt = System.nanoTime() + 2000000000L;
         }

      } else {
         Arrays.fill(rects, Float.NaN);
         publishRects();
         clear();
      }
   }

   public static void dispose() {
      if (ready || targetFbo != 0) {
         GlState saved = Overlay.GlState.capture();

         try {
            GL33.glDeleteProgram(progBlur);
            GL33.glDeleteProgram(progPill);
            GL33.glDeleteProgram(progFlat);
            if (samplerNearest != 0) {
               GL33.glDeleteSamplers(samplerNearest);
            }

            samplerNearest = 0;
            GL33.glDeleteBuffers(vbo);
            GL33.glDeleteVertexArrays(vao);
            deleteTargets();
            if (targetFbo != 0) {
               GL33.glDeleteFramebuffers(targetFbo);
            }

            targetTex = 0;
            targetFbo = 0;

            for(Font f : fonts.values()) {
               f.free();
            }

            if (logoTex != 0) {
               GL33.glDeleteTextures(logoTex);
            }

            for(int tex : iconTex.values()) {
               GL33.glDeleteTextures(tex);
            }
         } finally {
            saved.restore();
         }

         fonts.clear();
         iconTex.clear();
         if (fontInfo != null) {
            fontInfo.free();
         }

         fontInfo = null;
         logoTex = 0;
         ready = false;
      }
   }

   private static void init() {
      progBlur = program("#version 150\nin vec2 aPos;\nin vec2 aUv;\nin vec4 aCol;\nuniform vec2 uScreen;\nout vec2 vUv;\nout vec4 vCol;\nvoid main() {\n    vUv = aUv;\n    vCol = aCol;\n    gl_Position = vec4(aPos.x / uScreen.x * 2.0 - 1.0, 1.0 - aPos.y / uScreen.y * 2.0, 0.0, 1.0);\n}\n", "#version 150\nuniform sampler2D uTex;\nuniform vec2 uTexel;\nuniform vec2 uDir;\nuniform float uSpread;\nout vec4 fragColor;\nvoid main() {\n    vec2 uv = gl_FragCoord.xy * uTexel;\n    vec2 step = uDir * uTexel * uSpread;\n    vec4 c = texture(uTex, uv) * 0.2270270270;\n    c += texture(uTex, uv + step * 1.3846153846) * 0.3162162162;\n    c += texture(uTex, uv - step * 1.3846153846) * 0.3162162162;\n    c += texture(uTex, uv + step * 3.2307692308) * 0.0702702703;\n    c += texture(uTex, uv - step * 3.2307692308) * 0.0702702703;\n    fragColor = vec4(c.rgb, 1.0);\n}\n");
      progPill = program("#version 150\nin vec2 aPos;\nin vec2 aUv;\nin vec4 aCol;\nuniform vec2 uScreen;\nout vec2 vUv;\nout vec4 vCol;\nvoid main() {\n    vUv = aUv;\n    vCol = aCol;\n    gl_Position = vec4(aPos.x / uScreen.x * 2.0 - 1.0, 1.0 - aPos.y / uScreen.y * 2.0, 0.0, 1.0);\n}\n", "#version 150\nuniform sampler2D uTex;\nuniform vec2 uTexel;\nuniform vec4 uRect;\nuniform float uRadius;\nuniform vec4 uTint;\nuniform vec4 uEdge;\nuniform float uAlpha;\nout vec4 fragColor;\nfloat sdRoundRect(vec2 p, vec2 b, float r) {\n    vec2 q = abs(p) - b + r;\n    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;\n}\nvoid main() {\n    vec2 center = (uRect.xy + uRect.zw) * 0.5;\n    vec2 halfSize = (uRect.zw - uRect.xy) * 0.5;\n    float d = sdRoundRect(gl_FragCoord.xy - center, halfSize, uRadius);\n    float alpha = clamp(0.5 - d, 0.0, 1.0);\n    vec3 col = mix(texture(uTex, gl_FragCoord.xy * uTexel).rgb, uTint.rgb, uTint.a);\n    // Hairline rim, brighter along the top like the GUI's glass cards.\n    float rim = clamp(1.0 - abs(d + 0.75), 0.0, 1.0);\n    float top = clamp((gl_FragCoord.y - center.y) / halfSize.y * 0.5 + 0.5, 0.0, 1.0);\n    col = mix(col, uEdge.rgb, rim * uEdge.a * (0.45 + 0.55 * top));\n    fragColor = vec4(col, alpha * uAlpha);\n}\n");
      progFlat = program("#version 150\nin vec2 aPos;\nin vec2 aUv;\nin vec4 aCol;\nuniform vec2 uScreen;\nout vec2 vUv;\nout vec4 vCol;\nvoid main() {\n    vUv = aUv;\n    vCol = aCol;\n    gl_Position = vec4(aPos.x / uScreen.x * 2.0 - 1.0, 1.0 - aPos.y / uScreen.y * 2.0, 0.0, 1.0);\n}\n", "#version 150\nuniform sampler2D uTex;\nuniform int uMode;\nuniform vec2 uWave;\nuniform float uTime;\nuniform vec3 uColA;\nuniform vec3 uColB;\nin vec2 vUv;\nin vec4 vCol;\nout vec4 fragColor;\nvec3 wave() {\n    float t = 0.5 + 0.5 * sin(dot(gl_FragCoord.xy, uWave) + uTime);\n    return mix(uColA, uColB, smoothstep(0.0, 1.0, t));\n}\nvoid main() {\n    if (uMode == 4) {\n        vec4 img = texture(uTex, vUv);\n        fragColor = vec4(img.rgb * vCol.rgb, img.a * vCol.a);\n        return;\n    }\n    if (uMode == 5) {\n        fragColor = vec4(vCol.rgb, vCol.a * clamp(vUv.x + 0.5 - abs(vUv.y), 0.0, 1.0));\n        return;\n    }\n    float a = (uMode == 1 || uMode == 2) ? texture(uTex, vUv).r : 1.0;\n    vec3 rgb = (uMode == 2 || uMode == 3) ? wave() : vCol.rgb;\n    fragColor = vec4(rgb, vCol.a * a);\n}\n");
      samplerNearest = GL33.glGenSamplers();
      GL33.glSamplerParameteri(samplerNearest, 10241, 9728);
      GL33.glSamplerParameteri(samplerNearest, 10240, 9728);
      GL33.glSamplerParameteri(samplerNearest, 10242, 33071);
      GL33.glSamplerParameteri(samplerNearest, 10243, 33071);
      vao = GL33.glGenVertexArrays();
      vbo = GL33.glGenBuffers();
      GL33.glBindVertexArray(vao);
      GL33.glBindBuffer(34962, vbo);
      int stride = 32;
      GL33.glEnableVertexAttribArray(0);
      GL33.glVertexAttribPointer(0, 2, 5126, false, stride, 0L);
      GL33.glEnableVertexAttribArray(1);
      GL33.glVertexAttribPointer(1, 2, 5126, false, stride, 8L);
      GL33.glEnableVertexAttribArray(2);
      GL33.glVertexAttribPointer(2, 4, 5126, false, stride, 16L);
      fontInfo();
      ready = true;
   }

   private static void prepareCommonState() {
      GL33.glBindVertexArray(vao);
      GL33.glBindBuffer(34962, vbo);
      GL33.glBindBuffer(35052, 0);
      GL33.glActiveTexture(33984);
      GL33.glBindSampler(0, 0);
      GL33.glDisable(2929);
      GL33.glDisable(2884);
      GL33.glDisable(2960);
      GL33.glDisable(3089);
      GL33.glColorMask(true, true, true, true);
      GL33.glDepthMask(false);
      GL33.glBlendEquation(32774);
      GL33.glBlendFuncSeparate(770, 771, 1, 771);
      GL33.glViewport(0, 0, fbW, fbH);
   }

   private static void drawTag(Tag t) {
      float u = t.unit();
      Font f = font(12.0F * u + 1.0F);
      float padX = (float)Math.round(7.0F * u);
      float padY = (float)Math.round(4.0F * u);
      float w = (float)Math.round(f.width(t.text()) + padX * 2.0F);
      float h = (float)Math.round(f.lineHeight() + padY * 2.0F);
      float x1 = (float)Math.round(t.cx() - w / 2.0F);
      float y2 = (float)Math.round(t.bottom());
      float y1 = y2 - h;
      float x2 = x1 + w;
      float radius = Math.min(h / 2.0F, 6.0F * u);
      if (blurRegion(x1, y1, x2, y2, u)) {
         glass(x1, y1, x2, y2, radius);
         float lineT = Math.max(1.0F, (float)Math.round(u));
         flatBegin(0);
         quad(x1 + radius, y2 - lineT, x2 - radius, y2, 0.0F, 0.0F, 0.0F, 0.0F, PINK[0], PINK[1], PINK[2], 1.0F);
         draw();
         flatBegin(1);
         text(f, t.text(), x1 + padX, y1 + padY, 1.0F, 1.0F, 1.0F, 1.0F);
      }
   }

   private static void drawWatermark(Watermark wm) {
      float u = wm.unit();
      Font title = font(14.0F * u + 1.0F);
      Font small = font(11.0F * u + 1.0F);
      float margin = (float)Math.round(6.0F * u);
      float padX = (float)Math.round(8.0F * u);
      float padY = (float)Math.round(5.0F * u);
      float logo = (float)Math.round(18.0F * u);
      float gap = (float)Math.round(6.0F * u);
      boolean hasInfo = wm.info() != null && !wm.info().isEmpty();
      float titleW = title.width(wm.title());
      float infoW = hasInfo ? small.width(wm.info()) : 0.0F;
      float sep = hasInfo ? (float)Math.round(9.0F * u) : 0.0F;
      float h = (float)Math.round(Math.max(logo, title.lineHeight()) + padY * 2.0F);
      float w = (float)Math.round(padX + logo + gap + titleW + (hasInfo ? sep * 2.0F + infoW : 0.0F) + padX);
      float[] at = place(w, h, wm.pos(), margin, margin);
      float x1 = at[0];
      float y1 = at[1];
      float x2 = x1 + w;
      float y2 = y1 + h;
      float radius = Math.min(h / 2.0F, 7.0F * u);
      if (blurRegion(x1, y1, x2, y2, u)) {
         glass(x1, y1, x2, y2, radius);
         record(0, x1, y1, x2, y2);
         float cy = (y1 + y2) / 2.0F;
         float lx = x1 + padX;
         if (logoPng != null) {
            flatBegin(4);
            bindLogo();
            quad(lx, (float)Math.round(cy - logo / 2.0F), lx + logo, (float)Math.round(cy - logo / 2.0F) + logo, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F);
            draw();
         }

         float tx = lx + logo + gap;
         flatBegin(2);
         waveUniforms((float)(-Math.PI / (double)Math.max(1.0F, titleW)), 0.0F);
         text(title, wm.title(), tx, (float)Math.round(cy - title.lineHeight() / 2.0F), 1.0F, 1.0F, 1.0F, 1.0F);
         if (hasInfo) {
            float sx = tx + titleW + sep;
            flatBegin(0);
            quad(sx - Math.max(1.0F, (float)Math.round(u)), (float)Math.round(cy - 6.0F * u), sx, (float)Math.round(cy + 6.0F * u), 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, 0.22F);
            draw();
            flatBegin(1);
            text(small, wm.info(), sx + sep, (float)Math.round(cy - small.lineHeight() / 2.0F), 1.0F, 1.0F, 1.0F, 0.72F);
         }

      }
   }

   private static void drawEffects(Effects fx) {
      int n = fx.labels().length;
      if (n != 0) {
         float u = fx.unit();
         Font f = font(12.0F * u + 1.0F);
         float margin = (float)Math.round(6.0F * u);
         float padX = (float)Math.round(6.0F * u);
         float padY = (float)Math.round(3.0F * u);
         float icon = (float)Math.round(16.0F * u);
         float gapIcon = (float)Math.round(6.0F * u);
         float gapTime = (float)Math.round(12.0F * u);
         float gap = (float)Math.round(2.0F * u);
         float rowH = (float)Math.round(Math.max(icon, f.lineHeight()) + padY * 2.0F);
         float radius = Math.min(rowH / 2.0F, 5.0F * u);
         float labelW = 0.0F;
         float timeW = 0.0F;

         for(int i = 0; i < n; ++i) {
            labelW = Math.max(labelW, f.width(fx.labels()[i]));
            timeW = Math.max(timeW, f.width(fx.times()[i]));
         }

         float w = (float)Math.round(padX + icon + gapIcon + labelW + gapTime + timeW + padX);
         float totalH = (float)n * rowH + (float)(n - 1) * gap;
         float[] at = place(w, totalH, fx.pos(), margin, (float)Math.round(((float)fbH - totalH) / 2.0F));
         float x1 = at[0];
         float x2 = x1 + w;
         float top = at[1];
         if (blurRegion(x1, top, x2, top + totalH, u)) {
            record(1, x1, top, x2, top + totalH);
            float y = top;

            for(int i = 0; i < n; ++i) {
               glass(x1, y, x2, y + rowH, radius);
               y += rowH + gap;
            }

            flatBegin(4);
            y = top;

            for(int i = 0; i < n; ++i) {
               if (bindIcon(fx.ids()[i])) {
                  float iy = (float)Math.round(y + (rowH - icon) / 2.0F);
                  quad(x1 + padX, iy, x1 + padX + icon, iy + icon, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F);
                  draw();
               }

               y += rowH + gap;
            }

            flatBegin(1);
            f.bind();
            float pulse = 0.65F + 0.35F * (float)Math.abs(Math.sin(animTime() * Math.PI * 1.6));
            y = top;

            for(int i = 0; i < n; ++i) {
               float ty = (float)Math.round(y + (rowH - f.lineHeight()) / 2.0F);
               textQuads(f, fx.labels()[i], x1 + padX + icon + gapIcon, ty, 1.0F, 1.0F, 1.0F, 1.0F);
               String time = fx.times()[i];
               float tx = x2 - padX - f.width(time);
               if (fx.expiring()[i]) {
                  textQuads(f, time, tx, ty, PINK[0], PINK[1], PINK[2], pulse);
               } else {
                  textQuads(f, time, tx, ty, 1.0F, 1.0F, 1.0F, 0.62F);
               }

               y += rowH + gap;
            }

            draw();
         }
      }
   }

   private static boolean bindIcon(String id) {
      Integer tex = (Integer)iconTex.get(id);
      if (tex == null) {
         ByteBuffer png = (ByteBuffer)iconPng.get(id);
         if (png == null) {
            return false;
         }

         tex = uploadPng(png, false);
         iconTex.put(id, tex);
      }

      if (tex == 0) {
         return false;
      } else {
         GL33.glBindTexture(3553, tex);
         return true;
      }
   }

   private static int uploadPng(ByteBuffer png, boolean mipmaps) {
      MemoryStack stack = MemoryStack.stackPush();

      int tex;
      label52: {
         int var8;
         try {
            IntBuffer w = stack.mallocInt(1);
            IntBuffer h = stack.mallocInt(1);
            IntBuffer c = stack.mallocInt(1);
            ByteBuffer pixels = STBImage.stbi_load_from_memory(png, w, h, c, 4);
            if (pixels == null) {
               tex = 0;
               break label52;
            }

            tex = GL33.glGenTextures();
            GL33.glBindTexture(3553, tex);
            GL33.glPixelStorei(3317, 4);
            GL33.glPixelStorei(3314, 0);
            GL33.glPixelStorei(3316, 0);
            GL33.glPixelStorei(3315, 0);
            GL33.glTexImage2D(3553, 0, 32856, w.get(0), h.get(0), 0, 6408, 5121, pixels);
            if (mipmaps) {
               GL33.glGenerateMipmap(3553);
            }

            GL33.glTexParameteri(3553, 10241, mipmaps ? 9987 : 9729);
            GL33.glTexParameteri(3553, 10240, 9729);
            GL33.glTexParameteri(3553, 10242, 33071);
            GL33.glTexParameteri(3553, 10243, 33071);
            STBImage.stbi_image_free(pixels);
            var8 = tex;
         } catch (Throwable var10) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var9) {
                  var10.addSuppressed(var9);
               }
            }

            throw var10;
         }

         if (stack != null) {
            stack.close();
         }

         return var8;
      }

      if (stack != null) {
         stack.close();
      }

      return tex;
   }

   private static void drawModuleList(ModuleList ml) {
      if (ml.names().length != 0) {
         float u = ml.unit();
         Font f = font(12.0F * u + 1.0F);
         String[] names = (String[])ml.names().clone();
         Arrays.sort(names, Comparator.comparingDouble((s) -> (double)f.width(s)).reversed().thenComparing((s) -> s));
         float margin = (float)Math.round(6.0F * u);
         float padX = (float)Math.round(6.0F * u);
         float padY = (float)Math.round(3.0F * u);
         float bar = Math.max(2.0F, (float)Math.round(2.0F * u));
         float gap = (float)Math.round(2.0F * u);
         float lineH = (float)Math.round(f.lineHeight() + padY * 2.0F);
         float radius = Math.min(lineH / 2.0F, 5.0F * u);
         int n = names.length;
         float widest = (float)Math.round(f.width(names[0]) + padX * 2.0F + bar);
         float totalH = (float)n * lineH + (float)(n - 1) * gap;
         float[] pos = ml.pos();
         boolean alignRight = pos == null || pos[2] > 0.5F;
         boolean fromBottom = pos != null && pos[3] > 0.5F;
         float[] at = place(widest, totalH, pos, (float)fbW - margin - widest, margin);
         float bx1 = at[0];
         float bx2 = bx1 + widest;
         float top = at[1];
         if (blurRegion(bx1, top, bx2, top + totalH, u)) {
            record(2, bx1, top, bx2, top + totalH);
            float[] rowX1 = new float[n];
            float[] rowX2 = new float[n];
            float[] rowY = new float[n];

            for(int i = 0; i < n; ++i) {
               float w = (float)Math.round(f.width(names[i]) + padX * 2.0F + bar);
               int slot = fromBottom ? n - 1 - i : i;
               rowY[i] = top + (float)slot * (lineH + gap);
               rowX1[i] = alignRight ? bx2 - w : bx1;
               rowX2[i] = rowX1[i] + w;
               glass(rowX1[i], rowY[i], rowX2[i], rowY[i] + lineH, radius);
            }

            float waveY = (float)((Math.PI * 2D) / (double)((lineH + gap) * 9.0F));
            float waveX = waveY * 0.25F;
            float inset = (float)Math.round(2.0F * u);
            float barInset = (float)Math.round(3.0F * u);
            flatBegin(3);
            waveUniforms(waveX, waveY);

            for(int i = 0; i < n; ++i) {
               float bx = alignRight ? rowX2[i] - inset - bar : rowX1[i] + inset;
               quad(bx, rowY[i] + barInset, bx + bar, rowY[i] + lineH - barInset, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, 1.0F);
            }

            draw();
            flatBegin(2);
            waveUniforms(waveX, waveY);
            f.bind();

            for(int i = 0; i < n; ++i) {
               float tx = alignRight ? rowX1[i] + padX : rowX1[i] + padX + bar;
               textQuads(f, names[i], tx, rowY[i] + padY, 1.0F, 1.0F, 1.0F, 1.0F);
            }

            draw();
         }
      }
   }

   private static void drawShapes(Shapes sh) {
      GL33.glEnable(3042);
      if (sh.triCount() > 0) {
         flatBegin(0);
         float[] t = sh.tris();

         for(int i = 0; i < sh.triCount(); ++i) {
            int c = sh.triColors()[i];
            float r = (float)(c >> 16 & 255) / 255.0F;
            float g = (float)(c >> 8 & 255) / 255.0F;
            float b = (float)(c & 255) / 255.0F;
            float a = (float)(c >>> 24) / 255.0F;
            ensureCapacity(24);
            vertex(t[i * 6], t[i * 6 + 1], 0.0F, 0.0F, r, g, b, a);
            vertex(t[i * 6 + 2], t[i * 6 + 3], 0.0F, 0.0F, r, g, b, a);
            vertex(t[i * 6 + 4], t[i * 6 + 5], 0.0F, 0.0F, r, g, b, a);
         }

         draw();
      }

      if (sh.lineCount() > 0) {
         flatBegin(5);
         float hw = Math.max(0.5F, sh.lineWidth() / 2.0F);
         float e = hw + 1.0F;
         float[] l = sh.lines();

         for(int i = 0; i < sh.lineCount(); ++i) {
            float x1 = l[i * 4];
            float y1 = l[i * 4 + 1];
            float x2 = l[i * 4 + 2];
            float y2 = l[i * 4 + 3];
            float dx = x2 - x1;
            float dy = y2 - y1;
            float len = (float)Math.sqrt((double)(dx * dx + dy * dy));
            if (!(len < 0.01F)) {
               float nx = -dy / len * e;
               float ny = dx / len * e;
               int c1 = sh.lineColors()[i * 2];
               int c2 = sh.lineColors()[i * 2 + 1];
               float r1 = (float)(c1 >> 16 & 255) / 255.0F;
               float g1 = (float)(c1 >> 8 & 255) / 255.0F;
               float b1 = (float)(c1 & 255) / 255.0F;
               float a1 = (float)(c1 >>> 24) / 255.0F;
               float r2 = (float)(c2 >> 16 & 255) / 255.0F;
               float g2 = (float)(c2 >> 8 & 255) / 255.0F;
               float b2 = (float)(c2 & 255) / 255.0F;
               float a2 = (float)(c2 >>> 24) / 255.0F;
               ensureCapacity(48);
               vertex(x1 + nx, y1 + ny, hw, e, r1, g1, b1, a1);
               vertex(x1 - nx, y1 - ny, hw, -e, r1, g1, b1, a1);
               vertex(x2 - nx, y2 - ny, hw, -e, r2, g2, b2, a2);
               vertex(x1 + nx, y1 + ny, hw, e, r1, g1, b1, a1);
               vertex(x2 - nx, y2 - ny, hw, -e, r2, g2, b2, a2);
               vertex(x2 + nx, y2 + ny, hw, e, r2, g2, b2, a2);
            }
         }

         draw();
      }

   }

   private static void drawTarget(TargetCard tc) {
      float[] v = tc.v();
      float alpha = Math.max(0.0F, Math.min(1.0F, v[5]));
      if (!(alpha <= 0.01F)) {
         float u = tc.unit();
         Font nameFont = font(13.0F * u + 1.0F);
         Font small = font(11.0F * u + 1.0F);
         float pad = (float)Math.round(7.0F * u);
         float head = (float)Math.round(34.0F * u);
         float gap = (float)Math.round(8.0F * u);
         float barH = Math.max(3.0F, (float)Math.round(5.0F * u));
         float lineGap = (float)Math.round(4.0F * u);
         String hp = formatHealth(v[0]);
         String absorb = v[2] > 0.05F ? " +" + formatHealth(v[2]) : "";
         float textW = Math.max(nameFont.width(tc.name()) + gap + small.width(tc.distance()), small.width(hp) + small.width(absorb) + gap + small.width(tc.info()));
         float colW = Math.max((float)Math.round(118.0F * u), textW);
         float contentH = nameFont.lineHeight() + lineGap + barH + lineGap + small.lineHeight();
         float w = (float)Math.round(pad + head + gap + colW + pad);
         float h = (float)Math.round(Math.max(head, contentH) + pad * 2.0F);
         float[] at = place(w, h, tc.pos(), (float)Math.round((float)fbW / 2.0F + 40.0F * u), (float)Math.round((float)fbH / 2.0F + 34.0F * u));
         float x1 = at[0];
         float y1 = at[1] + (float)Math.round((1.0F - alpha) * 6.0F * u);
         float x2 = x1 + w;
         float y2 = y1 + h;
         if (blurRegion(x1, y1, x2, y2, u)) {
            glassAlpha = alpha;
            glass(x1, y1, x2, y2, Math.min(h / 2.0F, 8.0F * u));
            glassAlpha = 1.0F;
            record(3, x1, at[1], x2, at[1] + h);
            float hx = x1 + pad;
            float hy = (float)Math.round((y1 + y2 - head) / 2.0F);
            float hurt = Math.max(0.0F, Math.min(1.0F, v[4]));
            float tint = 1.0F - 0.55F * hurt;
            if (tc.skin() != 0) {
               flatBegin(4);
               GL33.glBindTexture(3553, tc.skin());
               GL33.glBindSampler(0, samplerNearest);
               quad(hx, hy, hx + head, hy + head, 0.125F, 0.125F, 0.25F, 0.25F, 1.0F, tint, tint, alpha);
               float o = (float)Math.round(head / 16.0F);
               quad(hx - o, hy - o, hx + head + o, hy + head + o, 0.625F, 0.125F, 0.75F, 0.25F, 1.0F, tint, tint, alpha);
               draw();
               GL33.glBindSampler(0, 0);
            } else {
               flatBegin(0);
               quad(hx, hy, hx + head, hy + head, 0.0F, 0.0F, 0.0F, 0.0F, PINK[0] * tint, PINK[1] * tint, PINK[2] * tint, 0.85F * alpha);
               draw();
               String letter = tc.name().isEmpty() ? "?" : tc.name().substring(0, 1).toUpperCase(Locale.ROOT);
               flatBegin(1);
               text(nameFont, letter, (float)Math.round(hx + (head - nameFont.width(letter)) / 2.0F), (float)Math.round(hy + (head - nameFont.lineHeight()) / 2.0F), 1.0F, 1.0F, 1.0F, alpha);
            }

            float cx = hx + head + gap;
            float right = x2 - pad;
            float ty = (float)Math.round((y1 + y2 - contentH) / 2.0F);
            flatBegin(1);
            nameFont.bind();
            textQuads(nameFont, tc.name(), cx, ty, 1.0F, 1.0F, 1.0F, alpha);
            draw();
            small.bind();
            float nameMid = ty + nameFont.lineHeight() / 2.0F;
            textQuads(small, tc.distance(), right - small.width(tc.distance()), (float)Math.round(nameMid - small.lineHeight() / 2.0F), 1.0F, 1.0F, 1.0F, 0.6F * alpha);
            draw();
            float by = (float)Math.round(ty + nameFont.lineHeight() + lineGap);
            float barW = right - cx;
            float max = Math.max(1.0F, v[1]);
            float fill = clamp01(v[0] / max);
            float ghost = clamp01(v[3] / max);
            float extra = clamp01(v[2] / max);
            flatBegin(0);
            quad(cx, by, right, by + barH, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, 0.1F * alpha);
            if (ghost > fill) {
               quad(cx + barW * fill, by, cx + barW * ghost, by + barH, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, 0.38F * alpha);
            }

            if (extra > 0.0F) {
               float ax = cx + barW * fill;
               quad(ax, by, Math.min(right, ax + barW * extra), by + barH, 0.0F, 0.0F, 0.0F, 0.0F, GOLD[0], GOLD[1], GOLD[2], 0.9F * alpha);
            }

            draw();
            if (fill > 0.0F) {
               flatBegin(3);
               waveUniforms((float)(-Math.PI / (double)Math.max(1.0F, barW)), 0.0F);
               quad(cx, by, cx + barW * fill, by + barH, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, alpha);
               draw();
            }

            float iy = (float)Math.round(by + barH + lineGap);
            flatBegin(1);
            small.bind();
            textQuads(small, hp, cx, iy, 1.0F, 1.0F, 1.0F, 0.9F * alpha);
            if (!absorb.isEmpty()) {
               textQuads(small, absorb, cx + small.width(hp), iy, GOLD[0], GOLD[1], GOLD[2], alpha);
            }

            if (!tc.info().isEmpty()) {
               textQuads(small, tc.info(), right - small.width(tc.info()), iy, PINK[0], PINK[1], PINK[2], alpha);
            }

            draw();
         }
      }
   }

   private static String formatHealth(float hp) {
      float r = (float)Math.round(hp * 2.0F) / 2.0F;
      return r == (float)((int)r) ? String.valueOf((int)r) : String.valueOf(r);
   }

   private static float clamp01(float f) {
      return Math.max(0.0F, Math.min(1.0F, f));
   }

   private static boolean blurRegion(float x1, float y1, float x2, float y2, float u) {
      int margin = Math.round(26.0F * u);
      int rx = clamp((int)x1 - margin, 0, fbW);
      int ry = clamp((int)y1 - margin, 0, fbH);
      int rx2 = clamp((int)Math.ceil((double)x2) + margin, 0, fbW);
      int ry2 = clamp((int)Math.ceil((double)y2) + margin, 0, fbH);
      int rw = rx2 - rx;
      int rh = ry2 - ry;
      if (rw > 0 && rh > 0) {
         int glY = fbH - ry2;
         GL33.glBindFramebuffer(36008, targetFbo);
         GL33.glBindTexture(3553, texA);
         GL33.glCopyTexSubImage2D(3553, 0, rx, glY, rx, glY, rw, rh);
         GL33.glDisable(3042);
         GL33.glEnable(3089);
         GL33.glScissor(rx, glY, rw, rh);
         GL33.glUseProgram(progBlur);
         GL33.glUniform2f(GL33.glGetUniformLocation(progBlur, "uScreen"), (float)fbW, (float)fbH);
         GL33.glUniform2f(GL33.glGetUniformLocation(progBlur, "uTexel"), 1.0F / (float)fbW, 1.0F / (float)fbH);
         GL33.glUniform1i(GL33.glGetUniformLocation(progBlur, "uTex"), 0);
         float spread = 2.2F * u;
         blurPass(texA, fboB, 1.0F, 0.0F, spread, rx, ry, rx2, ry2);
         blurPass(texB, fboA, 0.0F, 1.0F, spread, rx, ry, rx2, ry2);
         blurPass(texA, fboB, 1.0F, 0.0F, u, rx, ry, rx2, ry2);
         blurPass(texB, fboA, 0.0F, 1.0F, u, rx, ry, rx2, ry2);
         GL33.glDisable(3089);
         GL33.glBindFramebuffer(36009, targetFbo);
         GL33.glEnable(3042);
         return true;
      } else {
         return false;
      }
   }

   private static void blurPass(int srcTex, int dstFbo, float dx, float dy, float spread, int x1, int y1, int x2, int y2) {
      GL33.glBindFramebuffer(36009, dstFbo);
      GL33.glBindTexture(3553, srcTex);
      GL33.glUniform2f(GL33.glGetUniformLocation(progBlur, "uDir"), dx, dy);
      GL33.glUniform1f(GL33.glGetUniformLocation(progBlur, "uSpread"), spread);
      verts.clear();
      quad((float)x1, (float)y1, (float)x2, (float)y2, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, 1.0F);
      draw();
   }

   private static void glass(float x1, float y1, float x2, float y2, float radius) {
      GL33.glUseProgram(progPill);
      GL33.glUniform2f(GL33.glGetUniformLocation(progPill, "uScreen"), (float)fbW, (float)fbH);
      GL33.glUniform2f(GL33.glGetUniformLocation(progPill, "uTexel"), 1.0F / (float)fbW, 1.0F / (float)fbH);
      GL33.glUniform1i(GL33.glGetUniformLocation(progPill, "uTex"), 0);
      GL33.glUniform4f(GL33.glGetUniformLocation(progPill, "uRect"), x1, (float)fbH - y2, x2, (float)fbH - y1);
      GL33.glUniform1f(GL33.glGetUniformLocation(progPill, "uRadius"), radius);
      GL33.glUniform4f(GL33.glGetUniformLocation(progPill, "uTint"), 0.02F, 0.02F, 0.03F, 0.46F);
      GL33.glUniform4f(GL33.glGetUniformLocation(progPill, "uEdge"), 1.0F, 1.0F, 1.0F, 0.22F);
      GL33.glUniform1f(GL33.glGetUniformLocation(progPill, "uAlpha"), glassAlpha);
      GL33.glBindTexture(3553, texA);
      verts.clear();
      quad(x1, y1, x2, y2, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, 1.0F);
      draw();
   }

   private static void flatBegin(int mode) {
      GL33.glUseProgram(progFlat);
      GL33.glUniform2f(GL33.glGetUniformLocation(progFlat, "uScreen"), (float)fbW, (float)fbH);
      GL33.glUniform1i(GL33.glGetUniformLocation(progFlat, "uTex"), 0);
      GL33.glUniform1i(GL33.glGetUniformLocation(progFlat, "uMode"), mode);
      verts.clear();
   }

   private static void waveUniforms(float kx, float ky) {
      float time = (float)(animTime() % (double)10000.0F) * 2.2F;
      GL33.glUniform2f(GL33.glGetUniformLocation(progFlat, "uWave"), kx, ky);
      GL33.glUniform1f(GL33.glGetUniformLocation(progFlat, "uTime"), time);
      GL33.glUniform3f(GL33.glGetUniformLocation(progFlat, "uColA"), WHITE[0], WHITE[1], WHITE[2]);
      GL33.glUniform3f(GL33.glGetUniformLocation(progFlat, "uColB"), PINK[0], PINK[1], PINK[2]);
   }

   private static void text(Font f, String s, float x, float top, float r, float g, float b, float a) {
      f.bind();
      textQuads(f, s, x, top, r, g, b, a);
      draw();
   }

   private static void textQuads(Font f, String s, float x, float top, float r, float g, float b, float a) {
      MemoryStack stack = MemoryStack.stackPush();

      try {
         FloatBuffer px = stack.floats((float)Math.round(x));
         FloatBuffer py = stack.floats((float)Math.round(top + f.ascent));
         STBTTAlignedQuad q = STBTTAlignedQuad.malloc(stack);

         for(int i = 0; i < s.length(); ++i) {
            f.advance(s.charAt(i), px, py, q);
            if (q.x1() > q.x0()) {
               quad(q.x0(), q.y0(), q.x1(), q.y1(), q.s0(), q.t0(), q.s1(), q.t1(), r, g, b, a);
            }
         }
      } catch (Throwable var14) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var13) {
               var14.addSuppressed(var13);
            }
         }

         throw var14;
      }

      if (stack != null) {
         stack.close();
      }

   }

   private static void bindLogo() {
      if (logoTex == 0) {
         logoTex = uploadPng(logoPng, true);
         if (logoTex == 0) {
            throw new IllegalStateException("logo: " + STBImage.stbi_failure_reason());
         }
      } else {
         GL33.glBindTexture(3553, logoTex);
      }

   }

   private static void quad(float x1, float y1, float x2, float y2, float u1, float v1, float u2, float v2, float r, float g, float b, float a) {
      ensureCapacity(48);
      vertex(x1, y1, u1, v1, r, g, b, a);
      vertex(x2, y1, u2, v1, r, g, b, a);
      vertex(x2, y2, u2, v2, r, g, b, a);
      vertex(x1, y1, u1, v1, r, g, b, a);
      vertex(x2, y2, u2, v2, r, g, b, a);
      vertex(x1, y2, u1, v2, r, g, b, a);
   }

   private static void vertex(float x, float y, float u, float v, float r, float g, float b, float a) {
      verts.put(x).put(y).put(u).put(v).put(r).put(g).put(b).put(a);
   }

   private static void ensureCapacity(int floats) {
      if (verts.remaining() < floats) {
         FloatBuffer bigger = BufferUtils.createFloatBuffer(verts.capacity() * 2 + floats);
         verts.flip();
         bigger.put(verts);
         verts = bigger;
      }
   }

   private static void draw() {
      int count = verts.position() / 8;
      if (count != 0) {
         verts.flip();
         GL33.glBufferData(34962, verts, 35040);
         GL33.glDrawArrays(4, 0, count);
         verts.clear();
      }
   }

   private static boolean bindTarget(int texture) {
      if (targetFbo == 0) {
         targetFbo = GL33.glGenFramebuffers();
      }

      GL33.glBindFramebuffer(36160, targetFbo);
      GL33.glFramebufferTexture2D(36160, 36064, 3553, texture, 0);
      targetTex = texture;
      return GL33.glCheckFramebufferStatus(36160) == 36053;
   }

   private static void ensureTargets(int width, int height) {
      if (width != fbW || height != fbH || texA == 0) {
         deleteTargets();
         fbW = width;
         fbH = height;
         texA = colorTexture(width, height);
         texB = colorTexture(width, height);
         fboA = framebuffer(texA);
         fboB = framebuffer(texB);
      }
   }

   private static void deleteTargets() {
      if (fboA != 0) {
         GL33.glDeleteFramebuffers(fboA);
      }

      if (fboB != 0) {
         GL33.glDeleteFramebuffers(fboB);
      }

      if (texA != 0) {
         GL33.glDeleteTextures(texA);
      }

      if (texB != 0) {
         GL33.glDeleteTextures(texB);
      }

      texB = 0;
      texA = 0;
      fboB = 0;
      fboA = 0;
   }

   private static int colorTexture(int w, int h) {
      int tex = GL33.glGenTextures();
      GL33.glBindTexture(3553, tex);
      GL33.glTexImage2D(3553, 0, 32856, w, h, 0, 6408, 5121, (ByteBuffer)null);
      GL33.glTexParameteri(3553, 10241, 9729);
      GL33.glTexParameteri(3553, 10240, 9729);
      GL33.glTexParameteri(3553, 10242, 33071);
      GL33.glTexParameteri(3553, 10243, 33071);
      return tex;
   }

   private static int framebuffer(int tex) {
      int fbo = GL33.glGenFramebuffers();
      GL33.glBindFramebuffer(36160, fbo);
      GL33.glFramebufferTexture2D(36160, 36064, 3553, tex, 0);
      if (GL33.glCheckFramebufferStatus(36160) != 36053) {
         throw new IllegalStateException("incomplete framebuffer");
      } else {
         return fbo;
      }
   }

   private static int clamp(int v, int lo, int hi) {
      return Math.max(lo, Math.min(hi, v));
   }

   private static int program(String vs, String fs) {
      int p = GL33.glCreateProgram();
      int v = shader(35633, vs);
      int f = shader(35632, fs);
      GL33.glAttachShader(p, v);
      GL33.glAttachShader(p, f);
      GL33.glBindAttribLocation(p, 0, "aPos");
      GL33.glBindAttribLocation(p, 1, "aUv");
      GL33.glBindAttribLocation(p, 2, "aCol");
      GL33.glBindFragDataLocation(p, 0, "fragColor");
      GL33.glLinkProgram(p);
      GL33.glDeleteShader(v);
      GL33.glDeleteShader(f);
      if (GL33.glGetProgrami(p, 35714) == 0) {
         throw new IllegalStateException(GL33.glGetProgramInfoLog(p));
      } else {
         return p;
      }
   }

   private static int shader(int type, String src) {
      int s = GL33.glCreateShader(type);
      GL33.glShaderSource(s, src);
      GL33.glCompileShader(s);
      if (GL33.glGetShaderi(s, 35713) == 0) {
         throw new IllegalStateException(GL33.glGetShaderInfoLog(s));
      } else {
         return s;
      }
   }

   private static record Tag(float cx, float bottom, String text, float unit) {
   }

   private static record Watermark(String title, String info, float unit, float[] pos) {
   }

   private static record ModuleList(String[] names, float unit, float[] pos) {
   }

   private static record Effects(String[] ids, String[] labels, String[] times, boolean[] expiring, float unit, float[] pos) {
   }

   private static record TargetCard(String name, int skin, float[] v, String distance, String info, float unit, float[] pos) {
   }

   private static record Shapes(float[] lines, int[] lineColors, int lineCount, float lineWidth, float[] tris, int[] triColors, int triCount) {
   }

   private static final class Font {
      final float px;
      final STBTTPackedchar.Buffer chars;
      final STBTTPackedchar.Buffer extra;
      ByteBuffer bitmap;
      final float ascent;
      final float descent;
      int tex;

      Font(float px) {
         this.px = px;
         ByteBuffer bmp = BufferUtils.createByteBuffer(1048576);
         this.chars = STBTTPackedchar.malloc(224);
         this.extra = STBTTPackedchar.malloc(1);
         STBTTPackContext pc = STBTTPackContext.malloc();

         try {
            STBTruetype.stbtt_PackBegin(pc, bmp, 1024, 1024, 0, 1, 0L);
            STBTruetype.stbtt_PackSetOversampling(pc, 2, 2);
            STBTruetype.stbtt_PackFontRange(pc, Overlay.ttf, 0, px, 32, this.chars);
            STBTruetype.stbtt_PackFontRange(pc, Overlay.ttf, 0, px, 8734, this.extra);
            STBTruetype.stbtt_PackEnd(pc);
         } catch (Throwable var11) {
            if (pc != null) {
               try {
                  pc.close();
               } catch (Throwable var9) {
                  var11.addSuppressed(var9);
               }
            }

            throw var11;
         }

         if (pc != null) {
            pc.close();
         }

         this.bitmap = bmp;
         MemoryStack stack = MemoryStack.stackPush();

         try {
            IntBuffer a = stack.mallocInt(1);
            IntBuffer d = stack.mallocInt(1);
            IntBuffer g = stack.mallocInt(1);
            STBTruetype.stbtt_GetFontVMetrics(Overlay.fontInfo(), a, d, g);
            float scale = STBTruetype.stbtt_ScaleForPixelHeight(Overlay.fontInfo(), px);
            this.ascent = (float)Math.round((float)a.get(0) * scale);
            this.descent = (float)Math.round((float)d.get(0) * scale);
         } catch (Throwable var10) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var8) {
                  var10.addSuppressed(var8);
               }
            }

            throw var10;
         }

         if (stack != null) {
            stack.close();
         }

      }

      float lineHeight() {
         return this.ascent - this.descent;
      }

      float width(String s) {
         MemoryStack stack = MemoryStack.stackPush();

         float var9;
         try {
            FloatBuffer x = stack.floats(0.0F);
            FloatBuffer y = stack.floats(0.0F);
            STBTTAlignedQuad q = STBTTAlignedQuad.malloc(stack);

            for(int i = 0; i < s.length(); ++i) {
               this.advance(s.charAt(i), x, y, q);
            }

            var9 = x.get(0);
         } catch (Throwable var8) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }
            }

            throw var8;
         }

         if (stack != null) {
            stack.close();
         }

         return var9;
      }

      void bind() {
         if (this.tex == 0) {
            this.tex = GL33.glGenTextures();
            GL33.glBindTexture(3553, this.tex);
            GL33.glPixelStorei(3317, 1);
            GL33.glPixelStorei(3314, 0);
            GL33.glPixelStorei(3316, 0);
            GL33.glPixelStorei(3315, 0);
            GL33.glTexImage2D(3553, 0, 33321, 1024, 1024, 0, 6403, 5121, this.bitmap);
            GL33.glTexParameteri(3553, 10241, 9729);
            GL33.glTexParameteri(3553, 10240, 9729);
            GL33.glTexParameteri(3553, 10242, 33071);
            GL33.glTexParameteri(3553, 10243, 33071);
            this.bitmap = null;
         } else {
            GL33.glBindTexture(3553, this.tex);
         }

      }

      void advance(char c, FloatBuffer x, FloatBuffer y, STBTTAlignedQuad q) {
         if (c == 8734) {
            STBTruetype.stbtt_GetPackedQuad(this.extra, 1024, 1024, 0, x, y, q, false);
         } else {
            STBTruetype.stbtt_GetPackedQuad(this.chars, 1024, 1024, Overlay.glyph(c), x, y, q, false);
         }

      }

      void free() {
         if (this.tex != 0) {
            GL33.glDeleteTextures(this.tex);
         }

         this.tex = 0;
         this.chars.free();
         this.extra.free();
      }
   }

   private static final class GlState {
      int program;
      int vao;
      int arrayBuffer;
      int unpackBuffer;
      int activeTexture;
      int texture0;
      int sampler0;
      int drawFbo;
      int readFbo;
      int blendSrcRgb;
      int blendDstRgb;
      int blendSrcA;
      int blendDstA;
      int blendEqRgb;
      int blendEqA;
      int unpackAlign;
      int unpackRowLength;
      int unpackSkipPixels;
      int unpackSkipRows;
      boolean blend;
      boolean depth;
      boolean cull;
      boolean scissor;
      boolean stencil;
      boolean depthMask;
      final int[] viewport = new int[4];
      final int[] scissorBox = new int[4];
      final boolean[] colorMask = new boolean[4];

      static GlState capture() {
         GlState s = new GlState();
         s.program = GL33.glGetInteger(35725);
         s.vao = GL33.glGetInteger(34229);
         s.arrayBuffer = GL33.glGetInteger(34964);
         s.unpackBuffer = GL33.glGetInteger(35055);
         s.activeTexture = GL33.glGetInteger(34016);
         GL33.glActiveTexture(33984);
         s.texture0 = GL33.glGetInteger(32873);
         s.sampler0 = GL33.glGetInteger(35097);
         s.drawFbo = GL33.glGetInteger(36006);
         s.readFbo = GL33.glGetInteger(36010);
         s.blendSrcRgb = GL33.glGetInteger(32969);
         s.blendDstRgb = GL33.glGetInteger(32968);
         s.blendSrcA = GL33.glGetInteger(32971);
         s.blendDstA = GL33.glGetInteger(32970);
         s.blendEqRgb = GL33.glGetInteger(32777);
         s.blendEqA = GL33.glGetInteger(34877);
         s.unpackAlign = GL33.glGetInteger(3317);
         s.unpackRowLength = GL33.glGetInteger(3314);
         s.unpackSkipPixels = GL33.glGetInteger(3316);
         s.unpackSkipRows = GL33.glGetInteger(3315);
         s.blend = GL33.glIsEnabled(3042);
         s.depth = GL33.glIsEnabled(2929);
         s.cull = GL33.glIsEnabled(2884);
         s.scissor = GL33.glIsEnabled(3089);
         s.stencil = GL33.glIsEnabled(2960);
         s.depthMask = GL33.glGetBoolean(2930);
         GL33.glGetIntegerv(2978, s.viewport);
         GL33.glGetIntegerv(3088, s.scissorBox);
         MemoryStack stack = MemoryStack.stackPush();

         try {
            ByteBuffer mask = stack.malloc(4);
            GL33.glGetBooleanv(3107, mask);

            for(int i = 0; i < 4; ++i) {
               s.colorMask[i] = mask.get(i) != 0;
            }
         } catch (Throwable var5) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }
            }

            throw var5;
         }

         if (stack != null) {
            stack.close();
         }

         return s;
      }

      void restore() {
         GL33.glUseProgram(this.program);
         GL33.glBindVertexArray(this.vao);
         GL33.glBindBuffer(34962, this.arrayBuffer);
         GL33.glBindBuffer(35052, this.unpackBuffer);
         GL33.glActiveTexture(33984);
         GL33.glBindTexture(3553, this.texture0);
         GL33.glBindSampler(0, this.sampler0);
         GL33.glActiveTexture(this.activeTexture);
         GL33.glBindFramebuffer(36009, this.drawFbo);
         GL33.glBindFramebuffer(36008, this.readFbo);
         GL33.glBlendFuncSeparate(this.blendSrcRgb, this.blendDstRgb, this.blendSrcA, this.blendDstA);
         GL33.glBlendEquationSeparate(this.blendEqRgb, this.blendEqA);
         GL33.glPixelStorei(3317, this.unpackAlign);
         GL33.glPixelStorei(3314, this.unpackRowLength);
         GL33.glPixelStorei(3316, this.unpackSkipPixels);
         GL33.glPixelStorei(3315, this.unpackSkipRows);
         set(3042, this.blend);
         set(2929, this.depth);
         set(2884, this.cull);
         set(3089, this.scissor);
         set(2960, this.stencil);
         GL33.glDepthMask(this.depthMask);
         GL33.glColorMask(this.colorMask[0], this.colorMask[1], this.colorMask[2], this.colorMask[3]);
         GL33.glViewport(this.viewport[0], this.viewport[1], this.viewport[2], this.viewport[3]);
         GL33.glScissor(this.scissorBox[0], this.scissorBox[1], this.scissorBox[2], this.scissorBox[3]);
      }

      private static void set(int cap, boolean on) {
         if (on) {
            GL33.glEnable(cap);
         } else {
            GL33.glDisable(cap);
         }

      }
   }
}
